<?php
/**
 * CPTT_Date_Utils — تنها منبع حقیقت (single source of truth) برای تاریخ و عدد.
 *
 * این کلاس در نسخه‌ی 8.4.0 برای رفع ریشه‌ای باگ E-1 اضافه شد.
 *
 * قواعد ریشه‌ای:
 *   1. هر ورودی از کاربر (چه فارسی، چه انگلیسی، چه با ساعت، چه بدون ساعت) اول
 *      از این کلاس عبور می‌کند و به فرمت «canonical» تبدیل می‌شود.
 *   2. فرمت canonical تاریخ:  YYYY/MM/DD  (بدون ساعت، ارقام انگلیسی)
 *   3. فرمت canonical تاریخ+ساعت:  YYYY/MM/DD HH:MM  (ارقام انگلیسی)
 *   4. مقایسه‌ی تاریخ‌ها همیشه با `date_cmp()` انجام می‌شود — نه با «>» ساده،
 *      نه با «strcmp»، نه با «localeCompare». این تابع، هر دو رشته را
 *      normalize می‌کند و بعد بر اساس YYYYMMDD عددی مقایسه می‌کند.
 *   5. برای نمایش به کاربر از `to_display_date()` استفاده می‌شود که ارقام
 *      را فارسی می‌کند ولی فرمت را حفظ می‌کند.
 *   6. برای مبلغ‌ها از `parse_amount()` استفاده می‌شود که هم ارقام فارسی/عربی
 *      و هم جداکننده‌های هزارگان (،  ٬  ,  فاصله) را تحمل می‌کند.
 *
 * غیرمخرب بودن:
 *   - این کلاس هیچ داده‌ی قبلاً ذخیره‌شده‌ای را تغییر نمی‌دهد.
 *   - وقتی داده‌ی قدیمی «کثیف» (مثلاً «۱۴۰۴/۱۲/۲۹ ۲۳:۵۹» یا مخلوط ارقام)
 *     خوانده می‌شود، در زمان مقایسه/نمایش با همان توابع normalize شده و درست
 *     نتیجه می‌دهد — بدون نیاز به migration دیتابیس.
 */
if ( ! defined('ABSPATH') ) exit;

class CPTT_Date_Utils {

	/* =========================================================
	 * DIGITS
	 * ========================================================= */

	/** ارقام فارسی/عربی را به انگلیسی تبدیل می‌کند. */
	public static function to_en_digits($s) {
		if ($s === null || $s === '') return '';
		$fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
		$ar = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
		$en = ['0','1','2','3','4','5','6','7','8','9'];
		return str_replace($fa, $en, str_replace($ar, $en, (string)$s));
	}

	/** ارقام انگلیسی/عربی را به فارسی تبدیل می‌کند (برای نمایش). */
	public static function to_fa_digits($s) {
		if ($s === null || $s === '') return '';
		$s = self::to_en_digits($s);
		$en = ['0','1','2','3','4','5','6','7','8','9'];
		$fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
		return str_replace($en, $fa, (string)$s);
	}

	/* =========================================================
	 * DATES
	 * ========================================================= */

	/**
	 * هر رشته‌ی تاریخ (فارسی/انگلیسی، با یا بدون ساعت، با «/» یا «-» یا «.»)
	 * را به فرمت canonical «YYYY/MM/DD» تبدیل می‌کند.
	 * اگر معتبر نبود، رشته‌ی خالی برمی‌گرداند.
	 */
	public static function to_canonical_date($s) {
		if ($s === null) return '';
		$s = trim(self::to_en_digits((string)$s));
		if ($s === '') return '';
		// فقط ۳ گروه اول عدد را می‌گیریم — بقیه (ساعت/دقیقه) کنار گذاشته می‌شود.
		if (!preg_match('#(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})#', $s, $m)) return '';
		$y = (int)$m[1]; $mo = (int)$m[2]; $d = (int)$m[3];
		if ($y < 1300 || $y > 1600) return '';
		if ($mo < 1 || $mo > 12) return '';
		if ($d  < 1 || $d  > 31) return '';
		return sprintf('%04d/%02d/%02d', $y, $mo, $d);
	}

	/**
	 * هر رشته‌ی تاریخ+ساعت را به فرمت canonical «YYYY/MM/DD HH:MM» تبدیل می‌کند.
	 * اگر ساعت نداشت، «00:00» ضمیمه می‌کند.
	 */
	public static function to_canonical_datetime($s) {
		if ($s === null) return '';
		$s = trim(self::to_en_digits((string)$s));
		if ($s === '') return '';
		if (!preg_match('#(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})(?:[\sT]+(\d{1,2})[:\.](\d{1,2}))?#', $s, $m)) return '';
		$y = (int)$m[1]; $mo = (int)$m[2]; $d = (int)$m[3];
		if ($y < 1300 || $y > 1600) return '';
		if ($mo < 1 || $mo > 12) return '';
		if ($d  < 1 || $d  > 31) return '';
		$hh = isset($m[4]) ? (int)$m[4] : 0;
		$ii = isset($m[5]) ? (int)$m[5] : 0;
		if ($hh < 0 || $hh > 23) $hh = 0;
		if ($ii < 0 || $ii > 59) $ii = 0;
		return sprintf('%04d/%02d/%02d %02d:%02d', $y, $mo, $d, $hh, $ii);
	}

	/**
	 * تبدیل canonical (انگلیسی) → نمایش (فارسی)، بدون تغییر فرمت.
	 * اگر شامل ساعت بود، ساعت هم فارسی می‌شود.
	 */
	public static function to_display_date($s) {
		return self::to_fa_digits(self::to_canonical_date($s) ?: (string)$s);
	}
	public static function to_display_datetime($s) {
		$c = self::to_canonical_datetime($s);
		return self::to_fa_digits($c !== '' ? $c : (string)$s);
	}

	/**
	 * کلید مقایسه‌ی امن: YYYYMMDD به‌صورت integer.
	 * اگر رشته معتبر نبود، 0 برمی‌گرداند.
	 */
	public static function date_key($s) {
		$c = self::to_canonical_date($s);
		if ($c === '') return 0;
		return (int) str_replace('/', '', $c);
	}

	/**
	 * کلید مقایسه‌ی امن با ساعت: YYYYMMDDHHMM.
	 */
	public static function datetime_key($s) {
		$c = self::to_canonical_datetime($s);
		if ($c === '') return 0;
		return (int) preg_replace('/\D/', '', $c);
	}

	/**
	 * مقایسه‌ی امن دو تاریخ. -1 / 0 / +1.
	 * صرف نظر از فرمت (فارسی/انگلیسی، با/بدون ساعت، YYYY/MM/DD یا YYYY-MM-DD)،
	 * نتیجه‌ی درست می‌دهد.
	 */
	public static function date_cmp($a, $b) {
		$ka = self::date_key($a);
		$kb = self::date_key($b);
		if ($ka === $kb) return 0;
		return $ka < $kb ? -1 : 1;
	}

	/** آیا رشته‌ی داده‌شده یک تاریخ شمسی معتبر (بعد از normalize) است؟ */
	public static function is_valid_date($s) {
		return self::to_canonical_date($s) !== '';
	}

	/* =========================================================
	 * TIMESTAMP HELPERS  (delegate to CPTT_Core if available)
	 * ========================================================= */

	/**
	 * تاریخ امروز شمسی (canonical، انگلیسی، بدون ساعت).
	 * جایگزین امن fa_today() قدیمی.
	 */
	public static function today() {
		if (class_exists('CPTT_Core')) {
			$ts = current_time('timestamp', true);
			$dt = new DateTime('@' . (int)$ts);
			$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
			$gy = (int)$dt->format('Y'); $gm = (int)$dt->format('n'); $gd = (int)$dt->format('j');
			[$jy, $jm, $jd] = CPTT_Core::gregorian_to_jalali($gy, $gm, $gd);
			return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
		}
		return date('Y/m/d');
	}

	/**
	 * تبدیل timestamp به تاریخ شمسی canonical (انگلیسی، بدون ساعت).
	 * جایگزین امن fa_date_of() قدیمی.
	 */
	public static function date_of($ts) {
		if (!$ts) return self::today();
		if (class_exists('CPTT_Core')) {
			$dt = new DateTime('@' . (int)$ts);
			$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
			$gy = (int)$dt->format('Y'); $gm = (int)$dt->format('n'); $gd = (int)$dt->format('j');
			[$jy, $jm, $jd] = CPTT_Core::gregorian_to_jalali($gy, $gm, $gd);
			return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
		}
		return date('Y/m/d', (int)$ts);
	}

	/**
	 * تبدیل timestamp به تاریخ+ساعت شمسی canonical (انگلیسی).
	 */
	public static function datetime_of($ts) {
		if (!$ts) $ts = current_time('timestamp', true);
		if (class_exists('CPTT_Core')) {
			$dt = new DateTime('@' . (int)$ts);
			$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
			$gy = (int)$dt->format('Y'); $gm = (int)$dt->format('n'); $gd = (int)$dt->format('j');
			$time = $dt->format('H:i');
			[$jy, $jm, $jd] = CPTT_Core::gregorian_to_jalali($gy, $gm, $gd);
			return sprintf('%04d/%02d/%02d %s', $jy, $jm, $jd, $time);
		}
		return date('Y/m/d H:i', (int)$ts);
	}

	/**
	 * تبدیل یک رشته‌ی جلالی (فارسی/انگلیسی، با/بدون ساعت) به timestamp UTC.
	 * اگر شکست خورد 0 برمی‌گرداند.
	 */
	public static function jalali_to_timestamp($s) {
		$c = self::to_canonical_datetime($s);
		if ($c === '') {
			$d = self::to_canonical_date($s);
			if ($d === '') return 0;
			$c = $d . ' 00:00';
		}
		if (!preg_match('#(\d{4})/(\d{2})/(\d{2}) (\d{2}):(\d{2})#', $c, $m)) return 0;
		if (!class_exists('CPTT_Core') || !method_exists('CPTT_Core', 'jalali_to_gregorian')) return 0;
		[$gy, $gm, $gd] = CPTT_Core::jalali_to_gregorian((int)$m[1], (int)$m[2], (int)$m[3]);
		try {
			$dt = new DateTime('now', new DateTimeZone('Asia/Tehran'));
			$dt->setDate($gy, $gm, $gd);
			$dt->setTime((int)$m[4], (int)$m[5], 0);
			return (int)$dt->getTimestamp();
		} catch (Exception $e) { return 0; }
	}

	/* =========================================================
	 * AMOUNTS / NUMBERS
	 * ========================================================= */

	/**
	 * Normalize یک ورودی مبلغ. تحمل‌کننده:
	 *   - ارقام فارسی/عربی/انگلیسی
	 *   - جداکننده‌های هزارگان: ',' '٬' '،' ' ' '_'
	 *   - علامت منفی
	 *   - رقم اعشار «.» یا «٫» یا «،»‌ (توجه: کاما فقط اگر تنها یکی و بعدش
	 *     ۱-۳ رقم است اعشار محسوب می‌شود، وگرنه جداکننده‌ی هزارگان)
	 * خروجی: float.
	 */
	public static function parse_amount($v) {
		if ($v === null || $v === '') return 0.0;
		if (is_int($v) || is_float($v)) return (float)$v;
		$s = self::to_en_digits((string)$v);
		$s = trim($s);
		if ($s === '') return 0.0;
		// جداکننده‌های واضح هزارگان
		$s = str_replace(['٬','،', ' ', ' ', '_'], '', $s);
		// نگه‌داشتن فقط: عدد، نقطه، کاما، خط تیره (منفی)
		$s = preg_replace('/[^0-9\.\,\-]/', '', $s);
		// اگر هم کاما هم نقطه دارد → کاما = هزارگان، نقطه = اعشار
		if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
			$s = str_replace(',', '', $s);
		} elseif (strpos($s, ',') !== false) {
			// فقط کاما — اگر یک بار آمده و بعدش 1-3 رقم است، اعشار محسوب می‌شود
			$parts = explode(',', $s);
			if (count($parts) === 2 && strlen($parts[1]) >= 1 && strlen($parts[1]) <= 3 && strlen($parts[1]) !== 3) {
				$s = $parts[0] . '.' . $parts[1];
			} else {
				$s = str_replace(',', '', $s);
			}
		}
		if ($s === '' || $s === '-' || $s === '.') return 0.0;
		return (float)$s;
	}

	/** نسخه‌ی int از parse_amount. */
	public static function parse_int($v) {
		return (int) round(self::parse_amount($v));
	}

	/* =========================================================
	 * NORMALIZE HOOKS FOR $_POST
	 * ========================================================= */

	/**
	 * Normalize خودکار همه‌ی ورودی‌های POST که «شبیه تاریخ» یا «شبیه عدد»
	 * هستند. این تابع در یک هوک زودهنگام صدا زده می‌شود تا وقتی هر handler
	 * می‌خواهد $_POST را بخواند، ارقام قبلاً به انگلیسی تبدیل شده باشند.
	 *
	 * غیرمخرب: هیچ داده‌ی موجود در دیتابیس تغییر نمی‌کند — فقط ورودی جدید
	 * یکسان‌سازی می‌شود. رشته‌های غیرعددی (مثل توضیحات فارسی) دست نمی‌خورند.
	 */
	public static function normalize_post_digits_in_place() {
		if (empty($_POST) || !is_array($_POST)) return;
		self::_walk_normalize($_POST);
		// $_REQUEST هم که ترکیب POST و GET است باید هماهنگ بماند
		if (is_array($_REQUEST)) self::_walk_normalize($_REQUEST);
	}

	private static function _walk_normalize(&$arr) {
		foreach ($arr as $k => &$v) {
			if (is_array($v)) {
				self::_walk_normalize($v);
			} elseif (is_string($v)) {
				if (self::_looks_like_number_or_date($k, $v)) {
					$v = self::to_en_digits($v);
				}
			}
		}
	}

	/**
	 * تشخیص هوشمند: کدام کلیدهای POST باید ارقامشان normalize شود.
	 * ملاک:
	 *   الف) اسم کلید نشان می‌دهد که تاریخ/عدد است
	 *   ب) یا مقدار فقط شامل ارقام (فارسی/انگلیسی) + کاراکترهای مالی است
	 * برای بقیه (توضیحات، عنوان، ...) دست نمی‌زنیم تا متن فارسی خراب نشود.
	 */
	/* =========================================================
	 * SHARED ASSET REGISTRATION
	 * ========================================================= */

	/**
	 * ثبت اسکریپت و CSS مشترک (input-normalizer + datepicker).
	 * چند بار قابل صدا زدن است — WordPress خودش idempotent می‌کند.
	 */
	public static function register_shared_assets() {
		if (!defined('CPTT_URL') || !defined('CPTT_VERSION')) return;
		wp_register_script(
			'cptt-input-normalize',
			CPTT_URL . 'assets/js/cptt-input-normalize.js',
			[],
			CPTT_VERSION,
			false // در <head> — تا interceptor fetch/XHR قبل از هر AJAX نصب شود
		);
		wp_register_style(
			'cptt-datepicker',
			CPTT_URL . 'assets/css/cptt-datepicker.css',
			[],
			CPTT_VERSION
		);
	}

	/** Enqueue helper — همه جا فقط این را صدا بزن. */
	public static function enqueue_shared_assets() {
		self::register_shared_assets();
		wp_enqueue_script('cptt-input-normalize');
		wp_enqueue_style('cptt-datepicker');
	}

	private static function _looks_like_number_or_date($key, $val) {
		if ($val === '') return false;
		$k = strtolower((string)$key);
		// کلیدهای مشکوک به تاریخ یا عدد
		$patterns = [
			'date','deadline','due','from','to','_at','_ts','start','end',
			'amount','mablagh','cost','price','paid','debit','credit','rate',
			'balance','total','sum','qty','quantity','count','number','num',
			'percent','rial','toman','fee','discount','tax','vat','row_amounts',
			'fiscal','year','month','day','time',
		];
		foreach ($patterns as $p) { if (strpos($k, $p) !== false) return true; }
		// یا: مقدار فقط ارقام + جداکننده‌های عددی/تاریخ است
		if (preg_match('/^[\s\-\+\.\,\/\:\d\x{06F0}-\x{06F9}\x{0660}-\x{0669}٬،]*$/u', $val)) {
			// ولی رشته‌ی خالی از رقم را رها کن
			if (preg_match('/[\d\x{06F0}-\x{06F9}\x{0660}-\x{0669}]/u', $val)) return true;
		}
		return false;
	}
}
