/*!
 * cptt-input-normalize.js — v8.4.0 (E-1 root fix, client side)
 *
 * این اسکریپت روی *هر* صفحه از افزونه لود می‌شود و کاری می‌کند که:
 *   - همه‌ی فیلدهای تاریخ، ورودی فارسی یا انگلیسی را قبول کنند و در
 *     زمان submit فرم به فرمت canonical (انگلیسی) تبدیل شوند.
 *   - همه‌ی فیلدهای عدد/مبلغ، ورودی فارسی/انگلیسی + جداکننده‌ی هزارگان
 *     را قبول کنند و مقدار عددی درست بدهند.
 *   - همه‌ی <input class="cptt-jalali-datetime"> و <input data-cptt-date>
 *     یک datepicker شمسی داشته باشند.
 *   - همه‌ی <input class="cptt-currency-input"> یا data-cptt-amount
 *     در حین تایپ به‌صورت 1,234,567 (فارسی برای نمایش) فرمت شوند.
 *
 * بدون وابستگی به jQuery — vanilla JS.
 * غیرمخرب: هیچ داده‌ای در سرور تغییر نمی‌دهد.
 */
(function(global){
	'use strict';
	if (global.CPTT_InputNormalize) return; // idempotent

	/* ---------- Digit helpers ---------- */
	var FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
	var AR = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
	function toEn(s){
		if (s === null || s === undefined) return '';
		s = String(s);
		for (var i=0;i<10;i++){
			s = s.split(FA[i]).join(String(i)).split(AR[i]).join(String(i));
		}
		return s;
	}
	function toFa(s){
		if (s === null || s === undefined) return '';
		s = toEn(String(s));
		for (var i=0;i<10;i++) s = s.split(String(i)).join(FA[i]);
		return s;
	}
	function isDigit(ch){ return /[0-9۰-۹٠-٩]/.test(ch); }

	/* ---------- Date normalize ---------- */
	// هر رشته‌ی تاریخ → "YYYY/MM/DD" (canonical)  یا  '' اگر معتبر نبود
	function canonicalDate(s){
		if (!s) return '';
		var en = toEn(String(s)).trim();
		var m = en.match(/(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})/);
		if (!m) return '';
		var y = +m[1], mo = +m[2], d = +m[3];
		if (y < 1300 || y > 1600 || mo < 1 || mo > 12 || d < 1 || d > 31) return '';
		return (
			('0000'+y).slice(-4)+'/'+
			('00'+mo).slice(-2)+'/'+
			('00'+d).slice(-2)
		);
	}
	// نسخه با ساعت (برای فیلدهایی که ساعت هم قبول می‌کنند)
	function canonicalDateTime(s){
		if (!s) return '';
		var en = toEn(String(s)).trim();
		var m = en.match(/(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})(?:[\sT]+(\d{1,2})[:\.](\d{1,2}))?/);
		if (!m) return '';
		var y = +m[1], mo = +m[2], d = +m[3];
		if (y < 1300 || y > 1600 || mo < 1 || mo > 12 || d < 1 || d > 31) return '';
		var hh = m[4] ? +m[4] : 0, ii = m[5] ? +m[5] : 0;
		if (hh<0||hh>23) hh = 0;
		if (ii<0||ii>59) ii = 0;
		return (
			('0000'+y).slice(-4)+'/'+
			('00'+mo).slice(-2)+'/'+
			('00'+d).slice(-2)+' '+
			('00'+hh).slice(-2)+':'+
			('00'+ii).slice(-2)
		);
	}
	function dateKey(s){
		var c = canonicalDate(s);
		if (!c) return 0;
		return +(c.replace(/\//g,''));
	}
	function dateCmp(a,b){
		var ka = dateKey(a), kb = dateKey(b);
		return ka === kb ? 0 : (ka < kb ? -1 : 1);
	}

	/* ---------- Amount normalize ---------- */
	function parseAmount(v){
		if (v === null || v === undefined || v === '') return 0;
		if (typeof v === 'number') return v;
		var s = toEn(String(v)).trim();
		if (!s) return 0;
		s = s.replace(/[٬،_\s ]/g,'');
		s = s.replace(/[^0-9\.\,\-]/g,'');
		if (s.indexOf(',')>=0 && s.indexOf('.')>=0){
			s = s.replace(/,/g,'');
		} else if (s.indexOf(',')>=0){
			var parts = s.split(',');
			if (parts.length === 2 && parts[1].length >= 1 && parts[1].length < 3){
				s = parts[0] + '.' + parts[1];
			} else {
				s = s.replace(/,/g,'');
			}
		}
		if (!s || s === '-' || s === '.') return 0;
		var n = parseFloat(s);
		return isFinite(n) ? n : 0;
	}
	function formatAmount(n, forDisplay){
		if (!isFinite(n)) n = 0;
		var neg = n < 0;
		var abs = Math.abs(n);
		var intp = Math.floor(abs);
		var frac = abs - intp;
		var s = String(intp).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
		if (frac > 0){
			var fs = frac.toFixed(6).replace(/0+$/,'').replace(/\.$/,'');
			s += fs.substring(1);
		}
		if (neg) s = '-'+s;
		return forDisplay ? toFa(s) : s;
	}

	/* ---------- Jalali <-> Gregorian (ported from CPTT_Core) ---------- */
	function j2g(jy,jm,jd){
		jy = parseInt(jy,10) + 1595;
		var days = -355668 + (365*jy) + Math.floor(jy/33)*8 + Math.floor(((jy%33)+3)/4) + parseInt(jd,10);
		days += (jm < 7) ? ((jm-1)*31) : (((jm-7)*30)+186);
		var gy = 400*Math.floor(days/146097); days %= 146097;
		if (days>36524){ gy += 100*Math.floor(--days/36524); days %= 36524; if (days>=365) days++; }
		gy += 4*Math.floor(days/1461); days %= 1461;
		if (days>365){ gy += Math.floor((days-1)/365); days = (days-1)%365; }
		var gd = days+1;
		var sal = [0,31,(((gy%4===0)&&(gy%100!==0))||(gy%400===0))?29:28,31,30,31,30,31,31,30,31,30,31];
		var gm = 1;
		for (; gm<=12; gm++){ if (gd<=sal[gm]) break; gd -= sal[gm]; }
		return [gy,gm,gd];
	}
	function g2j(gy,gm,gd){
		var gDM = [0,31,59,90,120,151,181,212,243,273,304,334];
		var gy2 = (gm>2) ? (gy+1) : gy;
		var days = 355666 + (365*gy) + Math.floor((gy2+3)/4) - Math.floor((gy2+99)/100) + Math.floor((gy2+399)/400) + gd + gDM[gm-1];
		var jy = -1595 + 33*Math.floor(days/12053); days %= 12053;
		jy += 4*Math.floor(days/1461); days %= 1461;
		if (days>365){ jy += Math.floor((days-1)/365); days = (days-1)%365; }
		var jm, jd;
		if (days<186){ jm = 1 + Math.floor(days/31); jd = 1 + (days%31); }
		else { jm = 7 + Math.floor((days-186)/30); jd = 1 + ((days-186)%30); }
		return [jy,jm,jd];
	}
	function todayJ(){
		var n = new Date();
		return g2j(n.getFullYear(), n.getMonth()+1, n.getDate());
	}
	function monthLen(jy,jm){
		if (jm <= 6) return 31;
		if (jm <= 11) return 30;
		// اسفند: 30 روز در سال کبیسه، 29 در بقیه
		var g = j2g(jy, 12, 1);
		var next = j2g(jy+1, 1, 1);
		var d1 = Date.UTC(g[0], g[1]-1, g[2]);
		var d2 = Date.UTC(next[0], next[1]-1, next[2]);
		return Math.round((d2-d1)/86400000);
	}
	var MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

	/* ---------- Jalali Datepicker ---------- */
	var pickerEl = null, activeInput = null, view = null, wantsTime = false;

	function buildPicker(){
		if (pickerEl) return pickerEl;
		pickerEl = document.createElement('div');
		pickerEl.className = 'cptt-jdp';
		pickerEl.setAttribute('dir','rtl');
		pickerEl.style.display = 'none';
		document.body.appendChild(pickerEl);

		pickerEl.addEventListener('mousedown', function(e){ e.stopPropagation(); });
		pickerEl.addEventListener('click', function(e){
			var t = e.target;
			if (!t || t.nodeType !== 1) return;
			var nav = t.getAttribute('data-nav');
			if (nav){
				view.jm += (nav === 'next') ? 1 : -1;
				if (view.jm > 12){ view.jm = 1; view.jy++; }
				if (view.jm < 1){ view.jm = 12; view.jy--; }
				draw();
				return;
			}
			if (t.getAttribute('data-close') !== null){ hidePicker(); return; }
			if (t.getAttribute('data-today') !== null){
				var tj = todayJ();
				view.jy = tj[0]; view.jm = tj[1]; view.jd = tj[2];
				commit(tj[2]);
				return;
			}
			var day = t.getAttribute('data-day');
			if (day){ commit(+day); return; }
		});
		// wheel/number input for time
		pickerEl.addEventListener('input', function(e){
			if (!e.target || !e.target.classList.contains('cptt-jdp__t')) return;
			// nothing on-the-fly, we read on commit
		});
		return pickerEl;
	}
	function draw(){
		if (!pickerEl || !view) return;
		var ml = monthLen(view.jy, view.jm);
		var g = j2g(view.jy, view.jm, 1);
		var first = new Date(g[0], g[1]-1, g[2]).getDay(); // 0=Sun..6=Sat
		// شنبه ابتدای هفته
		var startEmpty = (first + 1) % 7;
		var tj = todayJ();
		var html = '<div class="cptt-jdp__head">'
			+ '<button type="button" data-nav="prev" aria-label="ماه قبل">‹</button>'
			+ '<strong>'+MONTHS[view.jm-1]+' '+toFa(view.jy)+'</strong>'
			+ '<button type="button" data-nav="next" aria-label="ماه بعد">›</button>'
			+ '</div>';
		html += '<div class="cptt-jdp__week"><span>ش</span><span>ی</span><span>د</span><span>س</span><span>چ</span><span>پ</span><span>ج</span></div>';
		html += '<div class="cptt-jdp__days">';
		for (var i=0;i<startEmpty;i++) html += '<span></span>';
		for (var d=1; d<=ml; d++){
			var cls = '';
			if (view.jd === d) cls += ' is-selected';
			if (tj[0] === view.jy && tj[1] === view.jm && tj[2] === d) cls += ' is-today';
			html += '<button type="button" class="'+cls.trim()+'" data-day="'+d+'">'+toFa(d)+'</button>';
		}
		html += '</div>';
		if (wantsTime){
			html += '<div class="cptt-jdp__time">'
				+ '<input type="number" class="cptt-jdp__t" min="0" max="23" value="'+String(view.hh||0).padStart(2,'0')+'">'
				+ '<span>:</span>'
				+ '<input type="number" class="cptt-jdp__t" min="0" max="59" value="'+String(view.ii||0).padStart(2,'0')+'">'
				+ '</div>';
		}
		html += '<div class="cptt-jdp__foot">'
			+ '<button type="button" data-today="1">امروز</button>'
			+ '<button type="button" data-close="1">بستن</button>'
			+ '</div>';
		pickerEl.innerHTML = html;
	}
	function commit(day){
		if (!activeInput || !view) return;
		var y = view.jy, mo = view.jm, d = day;
		var val = ('0000'+y).slice(-4)+'/'+('00'+mo).slice(-2)+'/'+('00'+d).slice(-2);
		if (wantsTime){
			var ts = pickerEl.querySelectorAll('.cptt-jdp__t');
			var hh = ts[0] ? Math.max(0, Math.min(23, parseInt(ts[0].value||'0', 10))) : 0;
			var ii = ts[1] ? Math.max(0, Math.min(59, parseInt(ts[1].value||'0', 10))) : 0;
			val += ' '+('00'+hh).slice(-2)+':'+('00'+ii).slice(-2);
		}
		setInputValue(activeInput, toFa(val));  // نمایش با ارقام فارسی (canonical انگلیسی وقتی submit شود)
		hidePicker();
	}
	function setInputValue(input, val){
		var proto = window.HTMLInputElement && window.HTMLInputElement.prototype;
		var setter = proto && Object.getOwnPropertyDescriptor(proto, 'value');
		if (setter && setter.set){
			setter.set.call(input, val);
		} else {
			input.value = val;
		}
		input.dispatchEvent(new Event('input',  { bubbles: true }));
		input.dispatchEvent(new Event('change', { bubbles: true }));
	}
	function showPicker(input){
		buildPicker();
		activeInput = input;
		wantsTime = /cptt-jalali-datetime|data-cptt-datetime/.test(input.className)
					|| input.hasAttribute('data-cptt-datetime')
					|| /HH|ساعت/.test(input.placeholder || '');
		var parsed = canonicalDateTime(input.value) || canonicalDate(input.value);
		if (parsed){
			var m = parsed.match(/(\d{4})\/(\d{2})\/(\d{2})(?: (\d{2}):(\d{2}))?/);
			view = { jy:+m[1], jm:+m[2], jd:+m[3], hh:m[4]?+m[4]:0, ii:m[5]?+m[5]:0 };
		} else {
			var tj = todayJ();
			var now = new Date();
			view = { jy:tj[0], jm:tj[1], jd:tj[2], hh:now.getHours(), ii:now.getMinutes() };
		}
		draw();
		var r = input.getBoundingClientRect();
		var top = window.scrollY + r.bottom + 6;
		var left = window.scrollX + r.left;
		pickerEl.style.display = 'block';
		pickerEl.style.top = top + 'px';
		pickerEl.style.left = left + 'px';
		// اگر از پایین صفحه خارج شد، بالای input قرار بده
		var pr = pickerEl.getBoundingClientRect();
		if (r.bottom + pr.height > window.innerHeight){
			pickerEl.style.top = (window.scrollY + r.top - pr.height - 6) + 'px';
		}
	}
	function hidePicker(){
		if (pickerEl) pickerEl.style.display = 'none';
		activeInput = null;
	}

	/* ---------- Auto-detect date/amount inputs ---------- */
	function isDateInput(el){
		if (!el || el.tagName !== 'INPUT') return false;
		if (el.type === 'hidden' || el.type === 'button' || el.type === 'submit' || el.type === 'checkbox' || el.type === 'radio') return false;
		if (el.dataset && el.dataset.cpttDate !== undefined) return true;
		if (el.dataset && el.dataset.cpttDatetime !== undefined) return true;
		if (el.classList && (el.classList.contains('cptt-jalali-datetime') || el.classList.contains('cptt-jalali-date'))) return true;
		// heuristics: placeholder یا name شامل کلیدواژه
		var hint = ((el.placeholder||'') + ' ' + (el.name||'') + ' ' + (el.id||'')).toLowerCase();
		if (/\bتاریخ\b|\bمهلت\b|\bاز تاریخ\b|\bتا تاریخ\b|deadline|due|from_date|to_date|date_from|date_to|start_date|end_date|start_at|end_at/.test(hint)) return true;
		return false;
	}
	function isAmountInput(el){
		if (!el || el.tagName !== 'INPUT') return false;
		if (el.type === 'hidden' || el.type === 'button' || el.type === 'submit' || el.type === 'checkbox' || el.type === 'radio') return false;
		if (el.classList && (el.classList.contains('cptt-currency-input') || el.classList.contains('cptt-num-format'))) return true;
		if (el.dataset && (el.dataset.cpttAmount !== undefined || el.dataset.cpttNumber !== undefined)) return true;
		return false;
	}

	function attachDate(el){
		if (el._cpttDateAttached) return;
		el._cpttDateAttached = true;
		// جلو زدن keyboard در موبایل
		el.setAttribute('autocomplete','off');
		el.setAttribute('inputmode','text');
		el.addEventListener('focus', function(){ showPicker(el); });
		el.addEventListener('click', function(){ showPicker(el); });
		el.addEventListener('blur', function(){
			// نرمالایز نهایی: تاریخ به canonical و ارقام فارسی برای نمایش
			var v = el.value;
			var c = canonicalDateTime(v);
			if (c){
				// اگر ورودی ساعت نداشت، فقط تاریخ نگه‌دار
				if (!/\s\d{2}:\d{2}$/.test(v.replace(/[۰-۹]/g, function(ch){ return String.fromCharCode(ch.charCodeAt(0)-1728); })) && c.indexOf(' 00:00') === c.length - 6){
					c = c.substring(0, 10);
				}
				setInputValue(el, toFa(c));
			} else {
				var d = canonicalDate(v);
				if (d) setInputValue(el, toFa(d));
			}
		});
	}
	function attachAmount(el){
		if (el._cpttAmountAttached) return;
		el._cpttAmountAttached = true;
		el.setAttribute('autocomplete','off');
		el.setAttribute('inputmode','decimal');
		el.addEventListener('input', function(){
			var raw = el.value;
			var caret = el.selectionStart;
			var n = parseAmount(raw);
			var formatted = formatAmount(n, true); // فارسی برای نمایش
			// فقط اگر واقعا مقدار عوض شد بازنویسی کن — برای preserve کردن caret
			if (formatted !== raw){
				setInputValue(el, formatted);
				try { el.setSelectionRange(formatted.length, formatted.length); } catch(e){}
			}
		});
		el.addEventListener('blur', function(){
			var n = parseAmount(el.value);
			setInputValue(el, formatAmount(n, true));
		});
	}
	function scan(root){
		root = root || document;
		var inputs = root.querySelectorAll ? root.querySelectorAll('input') : [];
		for (var i=0;i<inputs.length;i++){
			var el = inputs[i];
			if (isDateInput(el))   attachDate(el);
			if (isAmountInput(el)) attachAmount(el);
		}
	}

	/* ---------- Form-submit normalizer ----------
	 * قبل از submit، هر input تاریخ/عدد از فارسی به انگلیسی canonical تبدیل
	 * می‌شود، submit انجام می‌شود، بعد مقدار نمایشی برمی‌گردد. این تضمین
	 * می‌کند سرور مقدار canonical بگیرد (defense in depth: normalize روی
	 * سرور هم انجام می‌شود).
	 */
	function preSubmitNormalize(form){
		var restore = [];
		var inputs = form.querySelectorAll('input, textarea');
		for (var i=0;i<inputs.length;i++){
			var el = inputs[i];
			if (el.disabled) continue;
			var isDate = isDateInput(el);
			var isAmt  = isAmountInput(el);
			if (!isDate && !isAmt) continue;
			var orig = el.value;
			var next;
			if (isDate){
				next = canonicalDateTime(orig);
				if (!next) next = canonicalDate(orig);
				if (!next) continue;
				// اگر ساعت 00:00 و ورودی اصلی ساعت نداشت، فقط تاریخ نگه‌دار
				var hadTime = /\s\d{1,2}[:\.]\d{1,2}/.test(toEn(orig));
				if (!hadTime && next.length > 10) next = next.substring(0,10);
			} else {
				next = String(parseAmount(orig));
			}
			if (next === orig) continue;
			restore.push([el, orig]);
			el.value = next;
		}
		// بعد از submit، مقدار نمایشی برگردد
		setTimeout(function(){
			for (var i=0;i<restore.length;i++){
				try { restore[i][0].value = restore[i][1]; } catch(e){}
			}
		}, 0);
	}
	document.addEventListener('submit', function(e){
		if (e.target && e.target.tagName === 'FORM') preSubmitNormalize(e.target);
	}, true);

	/* ---------- fetch / XHR normalizer (for React panel & any AJAX) ----------
	 * سه کار:
	 *   (الف) body بدنه‌ی درخواست (FormData/URLSearchParams/string) را
	 *         برای فیلدهای شبیه تاریخ/مبلغ نرمالایز می‌کنیم.
	 *   (ب) response JSON را برای فیلدهایی که کلیدشان *_fa، date، due،
	 *         at_fa و … است به فرمت canonical تبدیل می‌کنیم تا مقایسه‌های
	 *         بعدی در React یک‌دست باشند (بدون شکستن نمایش، چون React
	 *         خودش با ie() ارقام را برای نمایش فارسی می‌کند).
	 *   (ج) هیچ داده‌ی متنی طولانی (توضیحات، عنوان) دست نمی‌خورد.
	 */
	var DATE_KEY_RE   = /(^|_)(date|due|deadline|start|end|from|to|at_fa|_fa|expiry|expiryDate|paidDate|dueDate)($|_)/i;
	var AMOUNT_KEY_RE = /(amount|price|cost|paid|debit|credit|balance|total|sum|fee|discount|tax|vat|rate|rial|toman|qty|quantity)$/i;
	// v8.4.2 — کلیدهایی که با «تاریخ+ساعت» هستند و نباید ساعت‌شان دور ریخته شود.
	var DATETIME_KEY_RE = /(createdAt|updatedAt|settleAt|deletedAt|approvedAt|_at$|At$|_ts$|Ts$)/;

	/**
	 * آیا یک رشته «خالص یک تاریخ» است (بدون متن اضافه، بدون «•»، بدون نام)؟
	 * v8.4.2 — اصلاح‌شده: قبلاً هر رشته‌ای که فقط شامل ارقام + «/» بود
	 * را «تاریخ» می‌دیدیم — این باعث می‌شد رشته‌های غنی‌شده‌ای مثل
	 * "ادمین • 1405/04/17 14:30" با نسخه‌ی canonical فقط تاریخ عوض شوند
	 * و ساعت + نام پاک شوند. الآن فقط رشته‌های *واقعاً خالص* تاریخ را
	 * می‌پذیریم (بدون حروف، بدون •، بدون کاراکترهای غیرعددی/غیرجداکننده).
	 */
	function looksLikeDateVal(v){
		if (typeof v !== 'string' || v.length < 4 || v.length > 40) return false;
		var en = toEn(v).trim();
		// باید فقط شامل: ارقام، /، -، .، :، فاصله باشد. هیچ حرف/سمبل دیگر.
		if (!/^[\d\/\-\.\:\sT]+$/.test(en)) return false;
		// و باید یک الگوی تاریخ در آن باشد
		return /\d{4}[\/\-\.]\d{1,2}[\/\-\.]\d{1,2}/.test(en);
	}
	/** آیا رشته شامل ساعت است؟ (برای تصمیم اینکه به canonical date یا datetime تبدیل کنیم) */
	function hasTimePart(v){
		return /\d{1,2}[:\.]\d{1,2}/.test(toEn(String(v||'')));
	}

	function normalizeValue(key, v){
		if (v === null || v === undefined) return v;
		if (typeof v === 'string'){
			if (DATE_KEY_RE.test(key)){
				// v8.4.2 — اگر کلید صراحتاً «تاریخ+ساعت» است (مثل createdAt، updatedAt، …)،
				// یا مقدار ساعت دارد، ساعت را حفظ کن
				if (DATETIME_KEY_RE.test(key) || hasTimePart(v)){
					var dt = canonicalDateTime(v); if (dt) return dt;
				} else {
					var d = canonicalDate(v); if (d) return d;
				}
				return v;
			}
			// اعداد در JSON اغلب عدد هستند نه رشته؛ فقط اگر رشته‌ای بود و کلید مبلغ:
			if (AMOUNT_KEY_RE.test(key)){
				if (/^[\s\-\+\d\.\,٬،۰-۹٠-٩]+$/.test(v)){
					return parseAmount(v);
				}
			}
			// heuristic: فقط رشته‌های *واقعاً خالص* تاریخ (بدون متن اضافه)
			if (looksLikeDateVal(v)){
				if (hasTimePart(v)){
					var dt2 = canonicalDateTime(v); if (dt2) return dt2;
				} else {
					var c = canonicalDate(v); if (c) return c;
				}
			}
			return v;
		}
		if (Array.isArray(v)){
			for (var i=0;i<v.length;i++) v[i] = normalizeValue(key, v[i]);
			return v;
		}
		if (typeof v === 'object'){
			return walkNormalize(v);
		}
		return v;
	}
	function walkNormalize(obj){
		if (!obj || typeof obj !== 'object') return obj;
		if (Array.isArray(obj)){
			for (var i=0;i<obj.length;i++){
				if (obj[i] && typeof obj[i] === 'object') walkNormalize(obj[i]);
				else if (typeof obj[i] === 'string' && looksLikeDateVal(obj[i])){
					if (hasTimePart(obj[i])){
						var dt = canonicalDateTime(obj[i]); if (dt) obj[i] = dt;
					} else {
						var c = canonicalDate(obj[i]); if (c) obj[i] = c;
					}
				}
			}
			return obj;
		}
		for (var k in obj){
			if (!Object.prototype.hasOwnProperty.call(obj, k)) continue;
			obj[k] = normalizeValue(k, obj[k]);
		}
		return obj;
	}
	// —— fetch interceptor ——
	// v8.5.1 — response normalizer به‌طور کامل غیرفعال شد. تجربه نشان داد که
	// دست‌کاری response ممکن است فیلدهایی که React انتظار فرمت خاصی از آنها
	// را دارد را بشکند (مثلاً باگ "hh is not defined" در تب‌های خزانه‌داری).
	// چون سرور خودش POSTها را نرمالایز می‌کند و React از ابتدا با ارقام
	// فارسی/انگلیسی هر دو کار می‌کرد، این interceptor فقط outgoing را نرمالایز
	// می‌کند. response کاملاً بدون دست می‌ماند.
	if (global.fetch){
		var origFetch = global.fetch.bind(global);
		global.fetch = function(input, init){
			try {
				if (init && init.body){
					if (init.body instanceof FormData){
						init.body.forEach(function(val, key){
							if (typeof val !== 'string') return;
							if (DATE_KEY_RE.test(key)){
								var d = canonicalDate(val); if (d) init.body.set(key, d);
							} else if (AMOUNT_KEY_RE.test(key)){
								var n = parseAmount(val); init.body.set(key, String(n));
							} else if (/[۰-۹٠-٩]/.test(val)){
								// ارقام فارسی → انگلیسی (فقط اگر رشته «شبیه عدد» بود)
								if (/^[\s\-\+\.\,\/\:\d۰-۹٠-٩٬،]+$/.test(val)){
									init.body.set(key, toEn(val));
								}
							}
						});
					} else if (init.body instanceof URLSearchParams){
						var keys = [];
						init.body.forEach(function(_, k){ keys.push(k); });
						keys.forEach(function(k){
							var val = init.body.get(k);
							if (typeof val !== 'string') return;
							if (DATE_KEY_RE.test(k)){
								var d = canonicalDate(val); if (d) init.body.set(k, d);
							} else if (AMOUNT_KEY_RE.test(k)){
								init.body.set(k, String(parseAmount(val)));
							} else if (/[۰-۹٠-٩]/.test(val) && /^[\s\-\+\.\,\/\:\d۰-۹٠-٩٬،]+$/.test(val)){
								init.body.set(k, toEn(val));
							}
						});
					}
				}
			} catch(e){ /* ignore */ }
			// response دست‌نخورده برمی‌گردد (بر خلاف نسخه‌های 8.4.0-8.4.2)
			return origFetch(input, init);
		};
	}
	// —— XHR interceptor ——
	(function(){
		if (!global.XMLHttpRequest) return;
		var XHR = global.XMLHttpRequest;
		var origOpen = XHR.prototype.open;
		var origSend = XHR.prototype.send;
		XHR.prototype.open = function(method, url){
			this._cpttUrl = url;
			this._cpttMethod = method;
			return origOpen.apply(this, arguments);
		};
		XHR.prototype.send = function(body){
			// Normalize outgoing form-encoded / FormData bodies
			try {
				if (body && typeof body === 'string' && /[۰-۹٠-٩]/.test(body) && body.indexOf('=') >= 0){
					// application/x-www-form-urlencoded
					var params = new URLSearchParams(body);
					var keys = [];
					params.forEach(function(_, k){ keys.push(k); });
					var changed = false;
					keys.forEach(function(k){
						var v = params.get(k);
						if (typeof v !== 'string') return;
						if (DATE_KEY_RE.test(k)){
							var d = canonicalDate(v); if (d && d !== v){ params.set(k, d); changed = true; }
						} else if (AMOUNT_KEY_RE.test(k)){
							var n = String(parseAmount(v)); if (n !== v){ params.set(k, n); changed = true; }
						} else if (/[۰-۹٠-٩]/.test(v) && /^[\s\-\+\.\,\/\:\d۰-۹٠-٩٬،]+$/.test(v)){
							params.set(k, toEn(v)); changed = true;
						}
					});
					if (changed) body = params.toString();
				} else if (body instanceof FormData){
					body.forEach(function(val, key){
						if (typeof val !== 'string') return;
						if (DATE_KEY_RE.test(key)){
							var d = canonicalDate(val); if (d) body.set(key, d);
						} else if (AMOUNT_KEY_RE.test(key)){
							body.set(key, String(parseAmount(val)));
						} else if (/[۰-۹٠-٩]/.test(val) && /^[\s\-\+\.\,\/\:\d۰-۹٠-٩٬،]+$/.test(val)){
							body.set(key, toEn(val));
						}
					});
				}
			} catch(e){}
			// v8.5.1 — response normalization به‌طور کامل حذف شد
			return origSend.call(this, body);
		};
	})();

	/* ---------- Boot ---------- */
	function boot(){
		scan(document);
		// هر بار DOM تغییر کرد، دوباره اسکن کن (برای پنل React)
		if (global.MutationObserver){
			var obs = new MutationObserver(function(muts){
				for (var i=0;i<muts.length;i++){
					var m = muts[i];
					if (m.addedNodes){
						for (var j=0;j<m.addedNodes.length;j++){
							var n = m.addedNodes[j];
							if (n && n.nodeType === 1) scan(n);
						}
					}
				}
			});
			obs.observe(document.body, { childList:true, subtree:true });
		}
		// بستن picker با کلیک بیرون
		document.addEventListener('mousedown', function(e){
			if (!pickerEl || pickerEl.style.display === 'none') return;
			if (e.target === activeInput) return;
			if (pickerEl.contains(e.target)) return;
			hidePicker();
		}, true);
		document.addEventListener('keydown', function(e){
			if (e.key === 'Escape') hidePicker();
		});
	}
	if (document.readyState === 'loading'){
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

	/* ---------- Public API ---------- */
	global.CPTT_InputNormalize = {
		toEn: toEn, toFa: toFa,
		canonicalDate: canonicalDate,
		canonicalDateTime: canonicalDateTime,
		dateCmp: dateCmp, dateKey: dateKey,
		parseAmount: parseAmount, formatAmount: formatAmount,
		attachDate: attachDate, attachAmount: attachAmount,
		scan: scan,
		showPicker: showPicker, hidePicker: hidePicker
	};
})(window);
