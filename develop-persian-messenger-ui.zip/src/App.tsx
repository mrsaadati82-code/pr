import { useEffect } from "react";
import IconRail from "./components/IconRail";
import Sidebar from "./components/Sidebar/Sidebar";
import ChatWindow from "./components/Chat/ChatWindow";
import WelcomeScreen from "./components/WelcomeScreen";
import InfoPanel from "./components/InfoPanel";
import MobileNav from "./components/MobileNav";
import NewChatModal from "./components/Modals/NewChatModal";
import SettingsModal from "./components/Modals/SettingsModal";
import ToastStack from "./components/common/ToastStack";
import { useChatStore } from "./store/chatStore";
import { useMediaQuery } from "./hooks/useMediaQuery";

export default function App() {
  const theme = useChatStore((s) => s.theme);
  const activeChatId = useChatStore((s) => s.activeChatId);
  const setActiveChat = useChatStore((s) => s.setActiveChat);
  const chats = useChatStore((s) => s.chats);
  const isMobile = useMediaQuery("(max-width: 767px)");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const activeChat = chats.find((c) => c.id === activeChatId);
  const showSidebarArea = !isMobile || !activeChat;
  const showChatArea = !isMobile || !!activeChat;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#eef0f5] text-slate-800 antialiased dark:bg-[#0f1117] dark:text-slate-100">
      <IconRail section="chats" onSectionChange={() => {}} />

      {showSidebarArea && (
        <div className="flex h-full w-full flex-col md:w-auto">
          <div className="min-h-0 flex-1">
            <Sidebar />
          </div>
          {isMobile && <MobileNav />}
        </div>
      )}

      {showChatArea && (activeChat ? <ChatWindow chat={activeChat} onBack={() => setActiveChat(null)} /> : <WelcomeScreen />)}

      <InfoPanel />

      <NewChatModal />
      <SettingsModal />
      <ToastStack />
    </div>
  );
}
