import type { Chat, Message, Participant } from "../types";

export const CURRENT_USER_ID = "me";

export const CURRENT_USER: Participant = {
  id: CURRENT_USER_ID,
  name: "شما",
  avatarColor: "from-violet-500 to-indigo-600",
  online: true,
  username: "shoma_",
  bio: "به پرنیان خوش اومدی ✌️",
};

const colorPalette = [
  "from-rose-400 to-pink-600",
  "from-amber-400 to-orange-600",
  "from-emerald-400 to-teal-600",
  "from-sky-400 to-blue-600",
  "from-violet-400 to-purple-600",
  "from-fuchsia-400 to-pink-600",
  "from-cyan-400 to-sky-600",
  "from-lime-400 to-green-600",
  "from-red-400 to-rose-600",
  "from-indigo-400 to-blue-700",
];

function colorFor(seed: number) {
  return colorPalette[seed % colorPalette.length];
}

export const CONTACTS: Participant[] = [
  { id: "u1", name: "سارا احمدی", avatarColor: colorFor(0), online: true, username: "sara_a", bio: "طراح گرافیک 🎨 | عاشق قهوه" },
  { id: "u2", name: "علی محمدی", avatarColor: colorFor(1), online: false, lastSeen: Date.now() - 1000 * 60 * 42, username: "ali_m", bio: "برنامه‌نویس فرانت‌اند" },
  { id: "u3", name: "مریم رضایی", avatarColor: colorFor(2), online: true, username: "maryamr", bio: "دانشجوی پزشکی" },
  { id: "u4", name: "حسین کریمی", avatarColor: colorFor(3), online: false, lastSeen: Date.now() - 1000 * 60 * 60 * 5, username: "hkarimi" },
  { id: "u5", name: "نگار حسینی", avatarColor: colorFor(4), online: true, username: "negar.h", bio: "عکاس | سفرهای بی‌پایان ✈️" },
  { id: "u6", name: "امیر صادقی", avatarColor: colorFor(5), online: false, lastSeen: Date.now() - 1000 * 60 * 60 * 24, username: "amirsadeghi" },
  { id: "u7", name: "الهام نوری", avatarColor: colorFor(6), online: true, username: "elham_n" },
  { id: "u8", name: "رضا قاسمی", avatarColor: colorFor(7), online: false, lastSeen: Date.now() - 1000 * 60 * 15, username: "reza_gh" },
  { id: "u9", name: "فاطمه جعفری", avatarColor: colorFor(8), online: true, username: "fjafari" },
  { id: "u10", name: "کیان مرادی", avatarColor: colorFor(9), online: false, lastSeen: Date.now() - 1000 * 60 * 60 * 3, username: "kian_m" },
  { id: "bot1", name: "دستیار پرنیان", avatarColor: "from-teal-400 to-cyan-600", online: true, username: "parnian_bot", bio: "دستیار هوشمند پرنیان 🤖" },
];

const now = Date.now();
const min = 60 * 1000;
const hour = 60 * min;
const day = 24 * hour;

let msgCounter = 1;
function id() {
  return `m${msgCounter++}`;
}

function mkMsg(partial: Partial<Message> & { chatId: string; senderId: string; senderName: string; text: string; createdAt: number }): Message {
  return {
    id: id(),
    type: "text",
    status: "read",
    ...partial,
  };
}

export const INITIAL_MESSAGES: Record<string, Message[]> = {
  c1: [
    mkMsg({ chatId: "c1", senderId: "u1", senderName: "سارا احمدی", text: "سلام! صبح بخیر ☀️", createdAt: now - day }),
    mkMsg({ chatId: "c1", senderId: CURRENT_USER_ID, senderName: "شما", text: "سلام سارا جان، صبح توام بخیر 🌸", createdAt: now - day + 2 * min, status: "read" }),
    mkMsg({ chatId: "c1", senderId: "u1", senderName: "سارا احمدی", text: "طرح‌های جدید لوگو رو فرستادم، یه نگاه بنداز", createdAt: now - hour * 5 }),
    mkMsg({
      chatId: "c1",
      senderId: "u1",
      senderName: "سارا احمدی",
      text: "",
      type: "image",
      attachment: { kind: "image", color: "from-rose-300 to-orange-300", name: "logo-concept.png" },
      createdAt: now - hour * 5 + min,
    }),
    mkMsg({ chatId: "c1", senderId: CURRENT_USER_ID, senderName: "شما", text: "وای عالی شدن 😍 نسخه سوم رو خیلی دوست دارم", createdAt: now - hour * 4, status: "read", reactions: [{ emoji: "🔥", count: 1, reactedByMe: false }] }),
    mkMsg({ chatId: "c1", senderId: "u1", senderName: "سارا احمدی", text: "پس همون رو نهایی می‌کنم", createdAt: now - hour * 3 }),
    mkMsg({ chatId: "c1", senderId: "u1", senderName: "سارا احمدی", text: "راستی جمعه وقت داری بریم بیرون؟", createdAt: now - min * 6 }),
  ],
  c2: [
    mkMsg({ chatId: "c2", senderId: "u2", senderName: "علی محمدی", text: "کد پول ریکوئست رو زدم برات", createdAt: now - hour * 8 }),
    mkMsg({ chatId: "c2", senderId: CURRENT_USER_ID, senderName: "شما", text: "دیدم، فقط یه کامنت گذاشتم", createdAt: now - hour * 7, status: "read" }),
    mkMsg({ chatId: "c2", senderId: "u2", senderName: "علی محمدی", text: "باشه الان چک می‌کنم", createdAt: now - hour * 7 + 3 * min }),
    mkMsg({ chatId: "c2", senderId: "u2", senderName: "علی محمدی", text: "مرسی که ریویو کردی 🙏", createdAt: now - min * 50 }),
  ],
  c3: [
    mkMsg({ chatId: "c3", senderId: "u5", senderName: "نگار حسینی", text: "عکس‌های سفر شمال رو دیدی؟", createdAt: now - day * 2 }),
    mkMsg({ chatId: "c3", senderId: CURRENT_USER_ID, senderName: "شما", text: "نه هنوز، بفرست ببینم", createdAt: now - day * 2 + min, status: "read" }),
    mkMsg({
      chatId: "c3",
      senderId: "u5",
      senderName: "نگار حسینی",
      text: "",
      type: "voice",
      attachment: { kind: "voice", duration: 18 },
      createdAt: now - hour * 20,
    }),
    mkMsg({ chatId: "c3", senderId: "u5", senderName: "نگار حسینی", text: "خیلی خوش گذشت واقعا ✨", createdAt: now - min * 30 }),
  ],
  c4: [
    mkMsg({ chatId: "c4", senderId: "u3", senderName: "مریم رضایی", text: "جزوه فیزیولوژی رو داری؟", createdAt: now - hour * 30 }),
    mkMsg({ chatId: "c4", senderId: CURRENT_USER_ID, senderName: "شما", text: "آره الان می‌فرستم", createdAt: now - hour * 29, status: "delivered" }),
  ],
  g1: [
    mkMsg({ chatId: "g1", senderId: "u4", senderName: "حسین کریمی", text: "بچه‌ها جلسه فردا ساعت ۱۰ هست", createdAt: now - hour * 12 }),
    mkMsg({ chatId: "g1", senderId: "u7", senderName: "الهام نوری", text: "من هستم 👍", createdAt: now - hour * 11 }),
    mkMsg({ chatId: "g1", senderId: "u9", senderName: "فاطمه جعفری", text: "لینک میت رو بفرستید لطفا", createdAt: now - hour * 10 }),
    mkMsg({ chatId: "g1", senderId: CURRENT_USER_ID, senderName: "شما", text: "الان می‌فرستم", createdAt: now - hour * 9, status: "read" }),
    mkMsg({ chatId: "g1", senderId: "u4", senderName: "حسین کریمی", text: "دمت گرم 🙌", createdAt: now - min * 20 }),
  ],
  g2: [
    mkMsg({ chatId: "g2", senderId: "u6", senderName: "امیر صادقی", text: "کدوم فریم‌ورک برای پروژه جدید بهتره؟", createdAt: now - day }),
    mkMsg({ chatId: "g2", senderId: "u8", senderName: "رضا قاسمی", text: "به نظرم ریکت با ویت", createdAt: now - day + 2 * hour }),
    mkMsg({ chatId: "g2", senderId: "u10", senderName: "کیان مرادی", text: "موافقم، سریع‌تره", createdAt: now - hour * 15 }),
  ],
  ch1: [
    mkMsg({ chatId: "ch1", senderId: "u1", senderName: "اخبار فناوری", text: "🚀 نسخه جدید مدل‌های هوش مصنوعی امروز رونمایی شد و سرعت پردازش را دو برابر کرده است.", createdAt: now - hour * 6 }),
    mkMsg({ chatId: "ch1", senderId: "u1", senderName: "اخبار فناوری", text: "📱 گوشی‌های جدید با باتری هفت‌روزه به بازار می‌آیند.", createdAt: now - hour * 2 }),
  ],
  saved: [
    mkMsg({ chatId: "saved", senderId: CURRENT_USER_ID, senderName: "شما", text: "لیست خرید: نان، شیر، تخم‌مرغ، میوه", createdAt: now - day * 3, status: "read" }),
    mkMsg({ chatId: "saved", senderId: CURRENT_USER_ID, senderName: "شما", text: "یادداشت: فردا حتما پیگیری قرارداد", createdAt: now - hour * 20, status: "read" }),
  ],
  bot1: [
    mkMsg({ chatId: "bot1", senderId: "bot1", senderName: "دستیار پرنیان", text: "سلام 👋 من دستیار پرنیانم. هر سوالی داری بپرس!", createdAt: now - hour * 1 }),
  ],
};

export const INITIAL_CHATS: Chat[] = [
  {
    id: "c1",
    type: "private",
    title: "سارا احمدی",
    avatarColor: colorFor(0),
    participants: [CONTACTS[0]],
    unreadCount: 2,
    muted: false,
    pinned: true,
    archived: false,
    lastMessageId: null,
    username: "sara_a",
    bio: CONTACTS[0].bio,
  },
  {
    id: "g1",
    type: "group",
    title: "تیم طراحی 🎨",
    avatarColor: colorFor(3),
    participants: [CONTACTS[3], CONTACTS[6], CONTACTS[8], CONTACTS[0]],
    memberCount: 24,
    unreadCount: 5,
    muted: false,
    pinned: true,
    archived: false,
    lastMessageId: null,
  },
  {
    id: "c2",
    type: "private",
    title: "علی محمدی",
    avatarColor: colorFor(1),
    participants: [CONTACTS[1]],
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
    username: "ali_m",
    bio: CONTACTS[1].bio,
  },
  {
    id: "ch1",
    type: "channel",
    title: "اخبار فناوری",
    avatarColor: colorFor(5),
    avatarEmoji: "📡",
    participants: [],
    memberCount: 154000,
    unreadCount: 1,
    muted: true,
    pinned: false,
    archived: false,
    verified: true,
    lastMessageId: null,
  },
  {
    id: "c3",
    type: "private",
    title: "نگار حسینی",
    avatarColor: colorFor(4),
    participants: [CONTACTS[4]],
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
    username: "negar.h",
    bio: CONTACTS[4].bio,
  },
  {
    id: "saved",
    type: "saved",
    title: "پیام‌های ذخیره‌شده",
    avatarColor: "from-blue-400 to-indigo-600",
    avatarEmoji: "🔖",
    participants: [],
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
  },
  {
    id: "g2",
    type: "group",
    title: "برنامه‌نویسان وب",
    avatarColor: colorFor(7),
    participants: [CONTACTS[5], CONTACTS[7], CONTACTS[9]],
    memberCount: 312,
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
  },
  {
    id: "c4",
    type: "private",
    title: "مریم رضایی",
    avatarColor: colorFor(2),
    participants: [CONTACTS[2]],
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
    username: "maryamr",
    bio: CONTACTS[2].bio,
  },
  {
    id: "bot1",
    type: "bot",
    title: "دستیار پرنیان",
    avatarColor: "from-teal-400 to-cyan-600",
    avatarEmoji: "🤖",
    participants: [CONTACTS[10]],
    unreadCount: 0,
    muted: false,
    pinned: false,
    archived: false,
    lastMessageId: null,
    bio: "دستیار هوشمند پرنیان",
  },
];

export const AUTO_REPLIES = [
  "باشه، متوجه شدم 👍",
  "چه جالب! بیشتر توضیح بده",
  "الان دارم بررسی می‌کنم...",
  "موافقم 🙌",
  "ممنون که گفتی!",
  "بذار یه فکری بکنم و بهت خبر می‌دم",
  "😄😄😄",
  "دقیقا همینطوره",
  "کی وقت داری صحبت کنیم؟",
  "فایل رو دریافت کردم، مرسی",
];
