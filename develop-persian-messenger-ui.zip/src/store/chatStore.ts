import { create } from "zustand";
import type { Chat, Message, Toast } from "../types";
import { AUTO_REPLIES, CONTACTS, CURRENT_USER, CURRENT_USER_ID, INITIAL_CHATS, INITIAL_MESSAGES } from "../data/mockData";

export type FilterTab = "all" | "unread" | "private" | "group" | "channel";
export type ThemeMode = "light" | "dark";
export type InfoPanelState = { open: boolean; chatId: string | null };

interface ChatState {
  chats: Chat[];
  messages: Record<string, Message[]>;
  activeChatId: string | null;
  filter: FilterTab;
  searchQuery: string;
  theme: ThemeMode;
  toasts: Toast[];
  infoPanel: InfoPanelState;
  newChatOpen: boolean;
  settingsOpen: boolean;
  profileName: string;
  profileBio: string;
  profileUsername: string;
  notificationsEnabled: boolean;
  soundsEnabled: boolean;
  setProfile: (data: Partial<{ name: string; bio: string; username: string }>) => void;
  toggleNotifications: () => void;
  toggleSounds: () => void;
  replyDraft: Record<string, { messageId: string; senderName: string; preview: string } | undefined>;
  editDraft: Record<string, string | undefined>;
  typingTimers: Record<string, number>;

  setActiveChat: (id: string | null) => void;
  setFilter: (f: FilterTab) => void;
  setSearchQuery: (q: string) => void;
  toggleTheme: () => void;
  sendMessage: (chatId: string, text: string, opts?: { type?: Message["type"]; attachment?: Message["attachment"] }) => void;
  deleteMessage: (chatId: string, messageId: string) => void;
  editMessage: (chatId: string, messageId: string, newText: string) => void;
  toggleReaction: (chatId: string, messageId: string, emoji: string) => void;
  pinMessage: (chatId: string, messageId: string) => void;
  togglePinChat: (chatId: string) => void;
  toggleMuteChat: (chatId: string) => void;
  deleteChat: (chatId: string) => void;
  markChatRead: (chatId: string) => void;
  setReplyDraft: (chatId: string, draft: { messageId: string; senderName: string; preview: string } | undefined) => void;
  setEditDraft: (chatId: string, messageId: string | undefined, text?: string) => void;
  openInfoPanel: (chatId: string) => void;
  closeInfoPanel: () => void;
  setNewChatOpen: (v: boolean) => void;
  setSettingsOpen: (v: boolean) => void;
  createChatWithContact: (contactId: string) => string;
  pushToast: (text: string, icon?: string) => void;
  removeToast: (id: string) => void;
}

let toastCounter = 0;
let messageCounter = 100;

function newMessageId() {
  messageCounter += 1;
  return `msg-${Date.now()}-${messageCounter}`;
}

export const useChatStore = create<ChatState>((set, get) => ({
  chats: INITIAL_CHATS,
  messages: INITIAL_MESSAGES,
  activeChatId: null,
  filter: "all",
  searchQuery: "",
  theme: (localStorage.getItem("parnian-theme") as ThemeMode) || "light",
  toasts: [],
  infoPanel: { open: false, chatId: null },
  newChatOpen: false,
  settingsOpen: false,
  profileName: CURRENT_USER.name,
  profileBio: CURRENT_USER.bio || "",
  profileUsername: CURRENT_USER.username || "",
  notificationsEnabled: true,
  soundsEnabled: true,
  replyDraft: {},
  editDraft: {},
  typingTimers: {},

  setActiveChat: (id) => {
    set({ activeChatId: id });
    if (id) get().markChatRead(id);
  },

  setFilter: (f) => set({ filter: f }),
  setSearchQuery: (q) => set({ searchQuery: q }),

  toggleTheme: () =>
    set((state) => {
      const next = state.theme === "light" ? "dark" : "light";
      localStorage.setItem("parnian-theme", next);
      return { theme: next };
    }),

  sendMessage: (chatId, text, opts) => {
    if (!text.trim() && !opts?.attachment) return;
    const draft = get().replyDraft[chatId];
    const editing = get().editDraft[chatId];

    if (editing) {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: state.messages[chatId].map((m) => (m.id === editing ? { ...m, text, edited: true } : m)),
        },
        editDraft: { ...state.editDraft, [chatId]: undefined },
      }));
      return;
    }

    const message: Message = {
      id: newMessageId(),
      chatId,
      senderId: CURRENT_USER_ID,
      senderName: "شما",
      text,
      type: opts?.type || "text",
      attachment: opts?.attachment,
      createdAt: Date.now(),
      status: "sending",
      replyTo: draft,
    };

    set((state) => ({
      messages: { ...state.messages, [chatId]: [...(state.messages[chatId] || []), message] },
      replyDraft: { ...state.replyDraft, [chatId]: undefined },
      chats: state.chats.map((c) => (c.id === chatId ? { ...c, unreadCount: 0 } : c)),
    }));

    // simulate network send -> sent -> delivered -> read
    window.setTimeout(() => {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: state.messages[chatId].map((m) => (m.id === message.id ? { ...m, status: "sent" } : m)),
        },
      }));
    }, 350);

    window.setTimeout(() => {
      set((state) => ({
        messages: {
          ...state.messages,
          [chatId]: state.messages[chatId].map((m) => (m.id === message.id ? { ...m, status: "delivered" } : m)),
        },
      }));
    }, 800);

    const chat = get().chats.find((c) => c.id === chatId);
    const canAutoReply = chat && chat.type !== "saved" && chat.type !== "channel";

    if (canAutoReply) {
      window.setTimeout(() => {
        set((state) => ({
          messages: {
            ...state.messages,
            [chatId]: state.messages[chatId].map((m) => (m.id === message.id ? { ...m, status: "read" } : m)),
          },
          chats: state.chats.map((c) => (c.id === chatId ? { ...c, typingUserId: chat!.participants[0]?.id || "u1" } : c)),
        }));
      }, 1200);

      window.setTimeout(() => {
        const state = get();
        const reply = AUTO_REPLIES[Math.floor(Math.random() * AUTO_REPLIES.length)];
        const sender = chat!.participants[0];
        const replyMsg: Message = {
          id: newMessageId(),
          chatId,
          senderId: sender?.id || "u1",
          senderName: sender?.name || chat!.title,
          text: reply,
          type: "text",
          createdAt: Date.now(),
          status: "read",
        };
        const isActive = state.activeChatId === chatId;
        set({
          messages: { ...state.messages, [chatId]: [...state.messages[chatId], replyMsg] },
          chats: state.chats.map((c) =>
            c.id === chatId ? { ...c, typingUserId: null, unreadCount: isActive ? 0 : c.unreadCount + 1 } : c
          ),
        });
        if (!isActive) get().pushToast(`${sender?.name || chat!.title}: ${reply}`, "💬");
      }, 2600 + Math.random() * 1200);
    }
  },

  deleteMessage: (chatId, messageId) =>
    set((state) => ({
      messages: { ...state.messages, [chatId]: state.messages[chatId].filter((m) => m.id !== messageId) },
    })),

  editMessage: (chatId, messageId, newText) =>
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: state.messages[chatId].map((m) => (m.id === messageId ? { ...m, text: newText, edited: true } : m)),
      },
    })),

  toggleReaction: (chatId, messageId, emoji) =>
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: state.messages[chatId].map((m) => {
          if (m.id !== messageId) return m;
          const reactions = m.reactions ? [...m.reactions] : [];
          const idx = reactions.findIndex((r) => r.emoji === emoji);
          if (idx === -1) {
            reactions.push({ emoji, count: 1, reactedByMe: true });
          } else if (reactions[idx].reactedByMe) {
            reactions[idx] = { ...reactions[idx], count: reactions[idx].count - 1, reactedByMe: false };
            if (reactions[idx].count <= 0) reactions.splice(idx, 1);
          } else {
            reactions[idx] = { ...reactions[idx], count: reactions[idx].count + 1, reactedByMe: true };
          }
          return { ...m, reactions };
        }),
      },
    })),

  pinMessage: (chatId, messageId) =>
    set((state) => ({
      messages: {
        ...state.messages,
        [chatId]: state.messages[chatId].map((m) => (m.id === messageId ? { ...m, pinned: !m.pinned } : { ...m, pinned: false })),
      },
    })),

  togglePinChat: (chatId) =>
    set((state) => ({
      chats: state.chats.map((c) => (c.id === chatId ? { ...c, pinned: !c.pinned } : c)),
    })),

  toggleMuteChat: (chatId) =>
    set((state) => ({
      chats: state.chats.map((c) => (c.id === chatId ? { ...c, muted: !c.muted } : c)),
    })),

  deleteChat: (chatId) =>
    set((state) => ({
      chats: state.chats.filter((c) => c.id !== chatId),
      activeChatId: state.activeChatId === chatId ? null : state.activeChatId,
    })),

  markChatRead: (chatId) =>
    set((state) => ({
      chats: state.chats.map((c) => (c.id === chatId ? { ...c, unreadCount: 0 } : c)),
    })),

  setReplyDraft: (chatId, draft) => set((state) => ({ replyDraft: { ...state.replyDraft, [chatId]: draft } })),

  setEditDraft: (chatId, messageId) =>
    set((state) => ({ editDraft: { ...state.editDraft, [chatId]: messageId } })),

  openInfoPanel: (chatId) => set({ infoPanel: { open: true, chatId } }),
  closeInfoPanel: () => set({ infoPanel: { open: false, chatId: null } }),

  setNewChatOpen: (v) => set({ newChatOpen: v }),
  setSettingsOpen: (v) => set({ settingsOpen: v }),

  createChatWithContact: (contactId) => {
    const state = get();
    const existing = state.chats.find(
      (c) => c.type === "private" && c.participants.some((p) => p.id === contactId)
    );
    if (existing) return existing.id;

    const contact = CONTACTS.find((c) => c.id === contactId);
    if (!contact) return state.activeChatId || "";

    const newId = `c-${contactId}-${Date.now()}`;
    const newChat: Chat = {
      id: newId,
      type: "private",
      title: contact.name,
      avatarColor: contact.avatarColor,
      participants: [contact],
      unreadCount: 0,
      muted: false,
      pinned: false,
      archived: false,
      lastMessageId: null,
      username: contact.username,
      bio: contact.bio,
    };

    set({
      chats: [newChat, ...state.chats],
      messages: { ...state.messages, [newId]: [] },
    });
    return newId;
  },

  pushToast: (text, icon) => {
    toastCounter += 1;
    const toastId = `toast-${toastCounter}`;
    set((state) => ({ toasts: [...state.toasts, { id: toastId, text, icon }] }));
    window.setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== toastId) }));
    }, 3800);
  },
  removeToast: (id) => set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),

  setProfile: (data) =>
    set((state) => ({
      profileName: data.name ?? state.profileName,
      profileBio: data.bio ?? state.profileBio,
      profileUsername: data.username ?? state.profileUsername,
    })),
  toggleNotifications: () => set((state) => ({ notificationsEnabled: !state.notificationsEnabled })),
  toggleSounds: () => set((state) => ({ soundsEnabled: !state.soundsEnabled })),
}));
