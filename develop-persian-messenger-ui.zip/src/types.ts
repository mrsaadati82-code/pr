export type ChatType = "private" | "group" | "channel" | "saved" | "bot";

export type MessageStatus = "sending" | "sent" | "delivered" | "read" | "failed";

export type MessageType = "text" | "image" | "voice" | "file" | "sticker";

export interface Reaction {
  emoji: string;
  count: number;
  reactedByMe: boolean;
}

export interface ReplyRef {
  messageId: string;
  senderName: string;
  preview: string;
}

export interface Attachment {
  kind: "image" | "file" | "voice";
  url?: string;
  name?: string;
  size?: string;
  duration?: number;
  color?: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  text: string;
  type: MessageType;
  attachment?: Attachment;
  createdAt: number;
  status: MessageStatus;
  edited?: boolean;
  reactions?: Reaction[];
  replyTo?: ReplyRef;
  pinned?: boolean;
}

export interface Participant {
  id: string;
  name: string;
  avatarColor: string;
  online?: boolean;
  lastSeen?: number;
  bio?: string;
  username?: string;
  isAdmin?: boolean;
}

export interface Chat {
  id: string;
  type: ChatType;
  title: string;
  avatarColor: string;
  avatarEmoji?: string;
  participants: Participant[];
  memberCount?: number;
  unreadCount: number;
  muted: boolean;
  pinned: boolean;
  archived: boolean;
  verified?: boolean;
  draft?: string;
  typingUserId?: string | null;
  lastMessageId?: string | null;
  bio?: string;
  username?: string;
}

export interface Toast {
  id: string;
  text: string;
  icon?: string;
}
