import { AnimatePresence, motion } from "framer-motion";
import { BellOff, BellRing, Image as ImageIcon, Pin, Trash2, Users, X, AtSign, Info } from "lucide-react";
import Avatar from "./Avatar";
import { useChatStore } from "../store/chatStore";
import { formatLastSeen, formatMemberCount } from "../utils/format";

export default function InfoPanel() {
  const infoPanel = useChatStore((s) => s.infoPanel);
  const closeInfoPanel = useChatStore((s) => s.closeInfoPanel);
  const chats = useChatStore((s) => s.chats);
  const messages = useChatStore((s) => s.messages);
  const toggleMuteChat = useChatStore((s) => s.toggleMuteChat);
  const deleteChat = useChatStore((s) => s.deleteChat);
  const pushToast = useChatStore((s) => s.pushToast);

  const chat = chats.find((c) => c.id === infoPanel.chatId);

  const mediaCount = chat ? (messages[chat.id] || []).filter((m) => m.type === "image").length : 0;

  return (
    <AnimatePresence>
      {infoPanel.open && chat && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/30 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeInfoPanel}
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", duration: 0.4, bounce: 0.15 }}
            className="fixed left-0 top-0 z-50 h-full w-[86%] max-w-[340px] overflow-y-auto scrollbar-thin bg-white shadow-2xl dark:bg-[#171922] md:static md:z-0 md:w-[320px] md:max-w-none md:shrink-0 md:border-r md:border-slate-200/70 md:shadow-none md:dark:border-white/5"
          >
            <div className="flex items-center justify-between px-4 py-3">
              <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200">اطلاعات</h2>
              <button onClick={closeInfoPanel} className="flex h-8 w-8 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5">
                <X size={17} />
              </button>
            </div>

            <div className="flex flex-col items-center gap-3 px-6 py-6 text-center">
              <Avatar name={chat.title} color={chat.avatarColor} emoji={chat.avatarEmoji} size={96} online={chat.type === "private" && chat.participants[0]?.online} />
              <div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">{chat.title}</h3>
                <p className="text-sm text-slate-400">
                  {chat.type === "private" || chat.type === "bot"
                    ? chat.participants[0]?.online
                      ? "آنلاین"
                      : formatLastSeen(chat.participants[0]?.lastSeen)
                    : chat.type === "group"
                    ? formatMemberCount(chat.memberCount)
                    : chat.type === "channel"
                    ? formatMemberCount(chat.memberCount)
                    : "فضای شخصی شما"}
                </p>
              </div>
            </div>

            <div className="space-y-1 px-3">
              {chat.username && (
                <div className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-slate-50 dark:hover:bg-white/5">
                  <AtSign size={17} className="text-violet-500" />
                  <div>
                    <p className="text-sm text-slate-700 dark:text-slate-200">@{chat.username}</p>
                    <p className="text-xs text-slate-400">نام کاربری</p>
                  </div>
                </div>
              )}
              {chat.bio && (
                <div className="flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-slate-50 dark:hover:bg-white/5">
                  <Info size={17} className="text-violet-500" />
                  <div>
                    <p className="text-sm text-slate-700 dark:text-slate-200">{chat.bio}</p>
                    <p className="text-xs text-slate-400">بیوگرافی</p>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-2 border-t border-slate-100 px-3 py-2 dark:border-white/5">
              <button
                onClick={() => toggleMuteChat(chat.id)}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-white/5"
              >
                {chat.muted ? <BellRing size={17} className="text-emerald-500" /> : <BellOff size={17} className="text-amber-500" />}
                {chat.muted ? "فعال کردن اعلان‌ها" : "بی‌صدا کردن اعلان‌ها"}
              </button>
              <button
                onClick={() => pushToast(`${mediaCount} رسانه اشتراک‌گذاری‌شده`, "🖼")}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-white/5"
              >
                <ImageIcon size={17} className="text-sky-500" />
                رسانه‌های مشترک ({mediaCount})
              </button>
              {chat.type === "group" && (
                <button
                  onClick={() => pushToast(`${chat.memberCount} عضو در این گروه`, "👥")}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-white/5"
                >
                  <Users size={17} className="text-indigo-500" />
                  اعضای گروه
                </button>
              )}
              <button
                onClick={() => pushToast("پیام‌های سنجاق‌شده نمایش داده شد", "📌")}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-white/5"
              >
                <Pin size={17} className="text-violet-500" />
                پیام‌های سنجاق‌شده
              </button>
            </div>

            {chat.type === "group" && chat.participants.length > 0 && (
              <div className="mt-2 border-t border-slate-100 px-3 py-2 dark:border-white/5">
                <p className="px-3 py-1.5 text-xs font-bold text-slate-400">اعضا</p>
                {chat.participants.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-slate-50 dark:hover:bg-white/5">
                    <Avatar name={p.name} color={p.avatarColor} online={p.online} size={36} />
                    <div className="min-w-0">
                      <p className="truncate text-sm text-slate-700 dark:text-slate-200">{p.name}</p>
                      <p className="text-xs text-slate-400">{p.online ? "آنلاین" : "آفلاین"}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {chat.type !== "saved" && (
              <div className="mt-2 border-t border-slate-100 px-3 py-2 dark:border-white/5">
                <button
                  onClick={() => {
                    deleteChat(chat.id);
                    closeInfoPanel();
                  }}
                  className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10"
                >
                  <Trash2 size={17} />
                  حذف و خروج از گفتگو
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
