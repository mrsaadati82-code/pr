import { Bookmark, MessageCircle, Settings, UserPlus } from "lucide-react";
import { useChatStore } from "../store/chatStore";
import { cn } from "../utils/cn";

export default function MobileNav() {
  const setActiveChat = useChatStore((s) => s.setActiveChat);
  const activeChatId = useChatStore((s) => s.activeChatId);
  const setNewChatOpen = useChatStore((s) => s.setNewChatOpen);
  const setSettingsOpen = useChatStore((s) => s.setSettingsOpen);

  const items = [
    { key: "chats", label: "گفتگوها", icon: MessageCircle, onClick: () => setActiveChat(null) },
    { key: "saved", label: "ذخیره‌شده", icon: Bookmark, onClick: () => setActiveChat("saved") },
    { key: "new", label: "جدید", icon: UserPlus, onClick: () => setNewChatOpen(true) },
    { key: "settings", label: "تنظیمات", icon: Settings, onClick: () => setSettingsOpen(true) },
  ];

  return (
    <div className="flex items-center justify-around border-t border-slate-200/70 bg-white py-1.5 dark:border-white/5 dark:bg-[#171922] md:hidden">
      {items.map((item) => {
        const Icon = item.icon;
        const active = item.key === "chats" ? !activeChatId : item.key === "saved" && activeChatId === "saved";
        return (
          <button key={item.key} onClick={item.onClick} className="flex flex-col items-center gap-0.5 px-4 py-1.5">
            <Icon size={21} className={cn(active ? "text-violet-500" : "text-slate-400")} strokeWidth={active ? 2.4 : 2} />
            <span className={cn("text-[10px]", active ? "font-bold text-violet-500" : "text-slate-400")}>{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}
