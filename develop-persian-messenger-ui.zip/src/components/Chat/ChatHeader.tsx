import { useState } from "react";
import { ArrowRight, BellOff, BellRing, MoreVertical, Phone, Pin, Search, Trash2, Video } from "lucide-react";
import Avatar from "../Avatar";
import type { Chat } from "../../types";
import { formatLastSeen, formatMemberCount } from "../../utils/format";
import { useChatStore } from "../../store/chatStore";
import ContextMenu, { type ContextMenuItem } from "../common/ContextMenu";

interface ChatHeaderProps {
  chat: Chat;
  onBack?: () => void;
}

export default function ChatHeader({ chat, onBack }: ChatHeaderProps) {
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);
  const openInfoPanel = useChatStore((s) => s.openInfoPanel);
  const toggleMuteChat = useChatStore((s) => s.toggleMuteChat);
  const pushToast = useChatStore((s) => s.pushToast);

  const contact = chat.participants[0];
  const subtitle =
    chat.type === "private" || chat.type === "bot"
      ? contact?.online
        ? "آنلاین"
        : formatLastSeen(contact?.lastSeen)
      : chat.type === "group"
      ? formatMemberCount(chat.memberCount)
      : chat.type === "channel"
      ? `کانال · ${formatMemberCount(chat.memberCount)}`
      : "فقط شما به این پیام‌ها دسترسی دارید";

  const items: ContextMenuItem[] = [
    { label: "مشاهده پروفایل", icon: <Search size={16} />, onClick: () => openInfoPanel(chat.id) },
    { label: chat.muted ? "فعال کردن اعلان‌ها" : "بی‌صدا کردن", icon: chat.muted ? <BellRing size={16} /> : <BellOff size={16} />, onClick: () => toggleMuteChat(chat.id) },
    { label: "پیام‌های سنجاق‌شده", icon: <Pin size={16} />, onClick: () => pushToast("موردی سنجاق‌نشده یافت نشد", "📌") },
    { label: "پاک‌سازی گفتگو", icon: <Trash2 size={16} />, onClick: () => pushToast("گفتگو پاک‌سازی شد", "🧹"), danger: true, divider: true },
  ];

  return (
    <div className="flex items-center gap-2 border-b border-slate-200/70 bg-white/80 px-3 py-2.5 backdrop-blur-xl dark:border-white/5 dark:bg-[#171922]/90 sm:px-5">
      {onBack && (
        <button onClick={onBack} className="flex h-9 w-9 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 md:hidden">
          <ArrowRight size={20} />
        </button>
      )}
      <button className="flex min-w-0 flex-1 items-center gap-3 rounded-xl px-1 py-1 text-right transition hover:bg-slate-100/70 dark:hover:bg-white/5" onClick={() => openInfoPanel(chat.id)}>
        <Avatar name={chat.title} color={chat.avatarColor} emoji={chat.avatarEmoji} online={chat.type === "private" && contact?.online} size={40} />
        <div className="min-w-0">
          <p className="truncate text-[15px] font-bold text-slate-800 dark:text-slate-100">{chat.title}</p>
          <p className="truncate text-xs text-slate-400">{subtitle}</p>
        </div>
      </button>

      <div className="flex items-center gap-0.5 sm:gap-1">
        <button onClick={() => pushToast("قابلیت تماس صوتی به‌زودی", "📞")} className="hidden h-9 w-9 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/5 sm:flex">
          <Phone size={18} />
        </button>
        <button onClick={() => pushToast("قابلیت تماس تصویری به‌زودی", "🎥")} className="hidden h-9 w-9 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/5 sm:flex">
          <Video size={18} />
        </button>
        <button onClick={() => pushToast("جستجو در گفتگو به‌زودی", "🔎")} className="flex h-9 w-9 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/5">
          <Search size={18} />
        </button>
        <button
          onClick={(e) => setMenu({ x: e.clientX, y: e.clientY })}
          className="flex h-9 w-9 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-white/5"
        >
          <MoreVertical size={18} />
        </button>
      </div>

      {menu && <ContextMenu x={menu.x} y={menu.y} items={items} onClose={() => setMenu(null)} />}
    </div>
  );
}
