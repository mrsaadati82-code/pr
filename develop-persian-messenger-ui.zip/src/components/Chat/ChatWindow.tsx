import { useEffect, useMemo, useRef } from "react";
import { Pin, X } from "lucide-react";
import ChatHeader from "./ChatHeader";
import MessageBubble from "./MessageBubble";
import MessageInput from "./MessageInput";
import TypingIndicator from "./TypingIndicator";
import { useChatStore } from "../../store/chatStore";
import { formatDateSeparator, isSameDay } from "../../utils/format";
import type { Chat } from "../../types";

interface ChatWindowProps {
  chat: Chat;
  onBack?: () => void;
}

export default function ChatWindow({ chat, onBack }: ChatWindowProps) {
  const messages = useChatStore((s) => s.messages[chat.id]) || [];
  const pinMessage = useChatStore((s) => s.pinMessage);
  const endRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "auto" });
  }, [chat.id]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, chat.typingUserId]);

  const isGroup = chat.type === "group" || chat.type === "channel";
  const pinnedMessage = useMemo(() => messages.find((m) => m.pinned), [messages]);

  const items = useMemo(() => {
    const result: { type: "date" | "message"; date?: number; message?: (typeof messages)[number] }[] = [];
    messages.forEach((m, idx) => {
      const prev = messages[idx - 1];
      if (!prev || !isSameDay(prev.createdAt, m.createdAt)) {
        result.push({ type: "date", date: m.createdAt });
      }
      result.push({ type: "message", message: m });
    });
    return result;
  }, [messages]);

  return (
    <div className="flex h-full min-w-0 flex-1 flex-col bg-[#eef0f5] dark:bg-[#0f1117]">
      <ChatHeader chat={chat} onBack={onBack} />

      {pinnedMessage && (
        <div className="flex items-center gap-2.5 border-b border-slate-200/70 bg-white/90 px-4 py-2 dark:border-white/5 dark:bg-[#171922]/90">
          <Pin size={15} className="shrink-0 text-violet-500" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-violet-500">پیام سنجاق‌شده</p>
            <p className="truncate text-xs text-slate-500 dark:text-slate-400">{pinnedMessage.text || "پیوست"}</p>
          </div>
          <button
            onClick={() => pinMessage(chat.id, pinnedMessage.id)}
            className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10"
          >
            <X size={14} />
          </button>
        </div>
      )}

      <div
        ref={scrollContainerRef}
        className="scrollbar-thin flex-1 overflow-y-auto py-4"
        style={{
          backgroundImage:
            "radial-gradient(circle at 15% 20%, rgba(139,92,246,0.05) 0%, transparent 45%), radial-gradient(circle at 85% 75%, rgba(99,102,241,0.06) 0%, transparent 45%)",
        }}
      >
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center text-slate-400">
            <span className="text-5xl">👋</span>
            <p className="text-sm">هنوز پیامی رد و بدل نشده. اولین پیام رو بفرست!</p>
          </div>
        ) : (
          <div className="flex flex-col gap-1.5">
            {items.map((item, idx) => {
              if (item.type === "date") {
                return (
                  <div key={`date-${idx}`} className="my-2 flex justify-center">
                    <span className="rounded-full bg-white/80 px-3 py-1 text-[11px] font-semibold text-slate-500 shadow-sm dark:bg-white/5 dark:text-slate-400">
                      {formatDateSeparator(item.date!)}
                    </span>
                  </div>
                );
              }
              const m = item.message!;
              const idxInMessages = messages.findIndex((mm) => mm.id === m.id);
              const prev = messages[idxInMessages - 1];
              const showSender = !prev || prev.senderId !== m.senderId;
              return <MessageBubble key={m.id} message={m} chat={chat} showSender={showSender} isGroup={isGroup} />;
            })}
            {chat.typingUserId && <TypingIndicator />}
            <div ref={endRef} />
          </div>
        )}
      </div>

      <MessageInput chatId={chat.id} />
    </div>
  );
}
