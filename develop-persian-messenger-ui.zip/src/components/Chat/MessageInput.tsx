import { useEffect, useRef, useState } from "react";
import { Image as ImageIcon, Mic, Paperclip, Pencil, Send, Smile, Trash2, X } from "lucide-react";
import EmojiPicker from "./EmojiPicker";
import { useChatStore } from "../../store/chatStore";
import { cn } from "../../utils/cn";

interface MessageInputProps {
  chatId: string;
  disabled?: boolean;
}

export default function MessageInput({ chatId, disabled }: MessageInputProps) {
  const [text, setText] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordTime, setRecordTime] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recordInterval = useRef<number | null>(null);

  const sendMessage = useChatStore((s) => s.sendMessage);
  const replyDraft = useChatStore((s) => s.replyDraft[chatId]);
  const setReplyDraft = useChatStore((s) => s.setReplyDraft);
  const editDraftId = useChatStore((s) => s.editDraft[chatId]);
  const setEditDraft = useChatStore((s) => s.setEditDraft);
  const messages = useChatStore((s) => s.messages[chatId]);
  const pushToast = useChatStore((s) => s.pushToast);

  const editingMessage = editDraftId ? messages?.find((m) => m.id === editDraftId) : undefined;

  useEffect(() => {
    if (editingMessage) {
      setText(editingMessage.text);
      textareaRef.current?.focus();
    }
  }, [editingMessage]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 140) + "px";
    }
  }, [text]);

  useEffect(() => {
    setText("");
  }, [chatId]);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    sendMessage(chatId, trimmed);
    setText("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
    if (e.key === "Escape") {
      setReplyDraft(chatId, undefined);
      setEditDraft(chatId, undefined);
      setText("");
    }
  };

  const startRecording = () => {
    setRecording(true);
    setRecordTime(0);
    recordInterval.current = window.setInterval(() => setRecordTime((t) => t + 1), 1000);
  };

  const cancelRecording = () => {
    setRecording(false);
    if (recordInterval.current) window.clearInterval(recordInterval.current);
  };

  const finishRecording = () => {
    if (recordInterval.current) window.clearInterval(recordInterval.current);
    setRecording(false);
    if (recordTime >= 1) {
      sendMessage(chatId, "", { type: "voice", attachment: { kind: "voice", duration: recordTime } });
    }
    setRecordTime(0);
  };

  const handleMockAttach = (kind: "image" | "file") => {
    setShowAttach(false);
    if (kind === "image") {
      const colors = ["from-rose-300 to-orange-300", "from-sky-300 to-indigo-300", "from-emerald-300 to-teal-300", "from-violet-300 to-fuchsia-300"];
      sendMessage(chatId, "", { type: "image", attachment: { kind: "image", color: colors[Math.floor(Math.random() * colors.length)] } });
    } else {
      sendMessage(chatId, "", { type: "file", attachment: { kind: "file", name: "سند-پروژه.pdf", size: "842 KB" } });
    }
    pushToast("پیوست ارسال شد", "📎");
  };

  const cancelBanner = replyDraft ? "reply" : editingMessage ? "edit" : null;

  return (
    <div className="border-t border-slate-200/70 bg-white px-3 py-2.5 dark:border-white/5 dark:bg-[#171922] sm:px-5 sm:py-3">
      {cancelBanner && (
        <div className="mb-2 flex items-center justify-between rounded-xl bg-slate-100 px-3 py-1.5 dark:bg-white/5">
          <div className="flex items-center gap-2 border-r-2 border-violet-500 pr-2 text-sm">
            {cancelBanner === "edit" ? <Pencil size={14} className="text-violet-500" /> : <Pencil size={14} className="rotate-180 text-violet-500" />}
            <div className="min-w-0">
              <p className="text-xs font-bold text-violet-500">{cancelBanner === "edit" ? "ویرایش پیام" : `پاسخ به ${replyDraft?.senderName}`}</p>
              <p className="truncate text-xs text-slate-500 dark:text-slate-400">{cancelBanner === "edit" ? editingMessage?.text : replyDraft?.preview}</p>
            </div>
          </div>
          <button
            onClick={() => {
              setReplyDraft(chatId, undefined);
              setEditDraft(chatId, undefined);
              setText("");
            }}
            className="flex h-6 w-6 items-center justify-center rounded-full text-slate-400 hover:bg-slate-200 dark:hover:bg-white/10"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {recording ? (
        <div className="flex items-center gap-3 rounded-full bg-slate-100 px-4 py-2.5 dark:bg-white/5">
          <button onClick={cancelRecording} className="flex h-9 w-9 items-center justify-center rounded-full text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10">
            <Trash2 size={18} />
          </button>
          <div className="flex flex-1 items-center gap-2">
            <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-500" />
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300">در حال ضبط... {Math.floor(recordTime / 60)}:{(recordTime % 60).toString().padStart(2, "0")}</span>
          </div>
          <button onClick={finishRecording} className="flex h-9 w-9 items-center justify-center rounded-full bg-violet-500 text-white hover:bg-violet-600">
            <Send size={16} className="-scale-x-100" />
          </button>
        </div>
      ) : (
        <div className="flex items-end gap-2">
          <div className="relative">
            <button
              onClick={() => setShowAttach((v) => !v)}
              disabled={disabled}
              className="flex h-10 w-10 items-center justify-center rounded-full text-slate-400 transition hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/5"
            >
              <Paperclip size={20} />
            </button>
            {showAttach && (
              <div className="absolute bottom-12 right-0 z-20 flex flex-col gap-1 rounded-2xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-white/10 dark:bg-[#1c1f2b]">
                <button onClick={() => handleMockAttach("image")} className="flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-white/5">
                  <ImageIcon size={16} className="text-sky-500" /> عکس
                </button>
                <button onClick={() => handleMockAttach("file")} className="flex items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-white/5">
                  <Paperclip size={16} className="text-emerald-500" /> فایل
                </button>
              </div>
            )}
          </div>

          <div className="relative flex-1 rounded-2xl bg-slate-100 px-3 py-1.5 dark:bg-white/5">
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={disabled}
              rows={1}
              placeholder="پیام خود را بنویسید..."
              className="scrollbar-thin max-h-36 w-full resize-none bg-transparent py-1.5 text-sm text-slate-700 outline-none placeholder:text-slate-400 dark:text-slate-100"
            />
            <div className="absolute bottom-1.5 left-2">
              <button
                onClick={() => setShowEmoji((v) => !v)}
                className="flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-200 hover:text-amber-500 dark:hover:bg-white/10"
              >
                <Smile size={18} />
              </button>
              {showEmoji && (
                <EmojiPicker
                  onSelect={(e) => {
                    setText((t) => t + e);
                    textareaRef.current?.focus();
                  }}
                  onClose={() => setShowEmoji(false)}
                />
              )}
            </div>
          </div>

          {text.trim() ? (
            <button
              onClick={handleSend}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/30 transition-transform hover:scale-105 active:scale-95"
            >
              <Send size={18} className="-scale-x-100" />
            </button>
          ) : (
            <button
              onClick={startRecording}
              disabled={disabled}
              className={cn(
                "flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-slate-400 transition hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/5"
              )}
            >
              <Mic size={20} />
            </button>
          )}
        </div>
      )}
    </div>
  );
}
