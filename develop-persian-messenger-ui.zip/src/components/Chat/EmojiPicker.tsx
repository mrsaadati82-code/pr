import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef } from "react";

const EMOJI_GROUPS: { title: string; emojis: string[] }[] = [
  {
    title: "پرکاربرد",
    emojis: ["😀", "😂", "🥰", "😍", "😘", "😊", "🙂", "😉", "😎", "🤩", "😅", "😇", "🤔", "😐", "😴", "😢", "😭", "😡", "🥳", "😱"],
  },
  {
    title: "دست‌ها و اشاره",
    emojis: ["👍", "👎", "👏", "🙌", "🙏", "💪", "🤝", "✌️", "🤞", "👌", "👋", "🤙", "✊", "☝️"],
  },
  {
    title: "دل و احساسات",
    emojis: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "💔", "💕", "💞", "💫", "✨", "🔥", "🎉", "🎊", "🌹"],
  },
  {
    title: "اشیا و نمادها",
    emojis: ["☕", "🍕", "🎂", "🎁", "⚽", "🎮", "📱", "💻", "📷", "🎵", "🚗", "✈️", "🌙", "☀️", "🌈", "⭐"],
  },
];

interface EmojiPickerProps {
  onSelect: (emoji: string) => void;
  onClose: () => void;
}

export default function EmojiPicker({ onSelect, onClose }: EmojiPickerProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    window.addEventListener("mousedown", handler);
    return () => window.removeEventListener("mousedown", handler);
  }, [onClose]);

  return (
    <AnimatePresence>
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 10, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 10, scale: 0.95 }}
        transition={{ duration: 0.15 }}
        className="scrollbar-thin absolute bottom-14 right-0 z-30 h-72 w-80 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-3 shadow-2xl dark:border-white/10 dark:bg-[#1c1f2b]"
      >
        {EMOJI_GROUPS.map((group) => (
          <div key={group.title} className="mb-2">
            <p className="mb-1.5 px-1 text-xs font-bold text-slate-400">{group.title}</p>
            <div className="grid grid-cols-8 gap-1">
              {group.emojis.map((e) => (
                <button
                  key={e}
                  onClick={() => onSelect(e)}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-lg transition-transform hover:scale-125 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
        ))}
      </motion.div>
    </AnimatePresence>
  );
}
