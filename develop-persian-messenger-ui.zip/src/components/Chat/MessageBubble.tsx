import { memo, useState } from "react";
import { Check, CheckCheck, Clock, Copy, CornerUpLeft, Pause, Pin, Play, SmilePlus, Trash2, Pencil } from "lucide-react";
import type { Chat, Message } from "../../types";
import { formatTime, formatVoiceDuration } from "../../utils/format";
import { cn } from "../../utils/cn";
import { CURRENT_USER_ID } from "../../data/mockData";
import { useChatStore } from "../../store/chatStore";
import ContextMenu, { type ContextMenuItem } from "../common/ContextMenu";

const QUICK_EMOJIS = ["❤️", "😂", "👍", "😮", "😢", "🔥"];

interface MessageBubbleProps {
  message: Message;
  chat: Chat;
  showSender: boolean;
  isGroup: boolean;
}

function VoiceMessage({ isOwn, duration }: { isOwn: boolean; duration: number }) {
  const [playing, setPlaying] = useState(false);
  const bars = useState(() => Array.from({ length: 28 }, () => 6 + Math.random() * 18))[0];

  return (
    <div className="flex items-center gap-2 py-1" style={{ minWidth: 190 }}>
      <button
        onClick={() => setPlaying((p) => !p)}
        className={cn(
          "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
          isOwn ? "bg-white/25 text-white" : "bg-violet-500 text-white"
        )}
      >
        {playing ? <Pause size={16} /> : <Play size={16} className="mr-0.5" />}
      </button>
      <div className="flex h-8 flex-1 items-center gap-[2px]">
        {bars.map((h, i) => (
          <span
            key={i}
            className={cn("wave-bar w-[2.5px] rounded-full", isOwn ? "bg-white/70" : "bg-violet-400")}
            style={{ height: h, animationDelay: `${i * 0.03}s`, animationPlayState: playing ? "running" : "paused" }}
          />
        ))}
      </div>
      <span className={cn("shrink-0 text-[11px]", isOwn ? "text-white/80" : "text-slate-400")}>{formatVoiceDuration(duration)}</span>
    </div>
  );
}

function MessageBubble({ message, chat, showSender, isGroup }: MessageBubbleProps) {
  const isOwn = message.senderId === CURRENT_USER_ID;
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);
  const [showEmojiBar, setShowEmojiBar] = useState(false);
  const setReplyDraft = useChatStore((s) => s.setReplyDraft);
  const setEditDraft = useChatStore((s) => s.setEditDraft);
  const deleteMessage = useChatStore((s) => s.deleteMessage);
  const toggleReaction = useChatStore((s) => s.toggleReaction);
  const pinMessage = useChatStore((s) => s.pinMessage);

  const bubbleColor = isOwn
    ? "bg-gradient-to-br from-violet-500 to-indigo-600 text-white"
    : "bg-white text-slate-800 shadow-sm shadow-slate-200/60 dark:bg-[#242733] dark:text-slate-100 dark:shadow-none";

  const items: ContextMenuItem[] = [
    {
      label: "پاسخ",
      icon: <CornerUpLeft size={16} />,
      onClick: () =>
        setReplyDraft(chat.id, {
          messageId: message.id,
          senderName: isOwn ? "شما" : message.senderName,
          preview: message.type === "text" ? message.text : message.type === "image" ? "🖼 عکس" : "🎤 پیام صوتی",
        }),
    },
    { label: "کپی متن", icon: <Copy size={16} />, onClick: () => navigator.clipboard.writeText(message.text) },
    { label: message.pinned ? "برداشتن سنجاق" : "سنجاق کردن", icon: <Pin size={16} />, onClick: () => pinMessage(chat.id, message.id) },
  ];
  if (isOwn && message.type === "text") {
    items.push({ label: "ویرایش", icon: <Pencil size={16} />, onClick: () => setEditDraft(chat.id, message.id) });
  }
  if (isOwn) {
    items.push({ label: "حذف پیام", icon: <Trash2 size={16} />, onClick: () => deleteMessage(chat.id, message.id), danger: true, divider: true });
  }

  const StatusIcon = () => {
    if (!isOwn) return null;
    if (message.status === "sending") return <Clock size={12} className="text-white/70" />;
    if (message.status === "read") return <CheckCheck size={14} className="text-sky-200" />;
    if (message.status === "delivered") return <CheckCheck size={14} className="text-white/70" />;
    return <Check size={14} className="text-white/70" />;
  };

  return (
    <div
      className={cn("group flex px-3 sm:px-6", isOwn ? "justify-end" : "justify-start")}
      onContextMenu={(e) => {
        e.preventDefault();
        setMenu({ x: e.clientX, y: e.clientY });
      }}
    >
      <div className={cn("flex max-w-[78%] items-end gap-1.5 sm:max-w-[65%]", isOwn ? "flex-row" : "flex-row-reverse")}>
        <div
          className={cn(
            "invisible flex shrink-0 items-center gap-0.5 pb-1.5 group-hover:visible",
            isOwn ? "order-2" : "order-2"
          )}
        >
          <button
            onClick={() => setShowEmojiBar((v) => !v)}
            className="flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-200/70 dark:hover:bg-white/10"
          >
            <SmilePlus size={15} />
          </button>
          <button
            onClick={() =>
              setReplyDraft(chat.id, {
                messageId: message.id,
                senderName: isOwn ? "شما" : message.senderName,
                preview: message.type === "text" ? message.text : "پیوست",
              })
            }
            className="flex h-7 w-7 items-center justify-center rounded-full text-slate-400 hover:bg-slate-200/70 dark:hover:bg-white/10"
          >
            <CornerUpLeft size={15} />
          </button>
        </div>

        <div className="relative">
          {showEmojiBar && (
            <div
              className={cn(
                "absolute -top-11 z-10 flex items-center gap-0.5 rounded-full border border-slate-200 bg-white px-1.5 py-1 shadow-lg dark:border-white/10 dark:bg-[#242733]",
                isOwn ? "right-0" : "left-0"
              )}
            >
              {QUICK_EMOJIS.map((e) => (
                <button
                  key={e}
                  onClick={() => {
                    toggleReaction(chat.id, message.id, e);
                    setShowEmojiBar(false);
                  }}
                  className="rounded-full p-1 text-base transition-transform hover:scale-125"
                >
                  {e}
                </button>
              ))}
            </div>
          )}

          <div
            className={cn(
              "relative rounded-2xl px-3.5 py-2",
              bubbleColor,
              isOwn ? "rounded-bl-md" : "rounded-br-md",
              isGroup && !isOwn && "pt-1.5"
            )}
          >
            {message.pinned && (
              <Pin size={11} className={cn("absolute -top-1.5", isOwn ? "-left-1.5" : "-right-1.5", "text-amber-500")} />
            )}

            {isGroup && showSender && !isOwn && (
              <p className="mb-0.5 text-xs font-bold text-violet-500 dark:text-violet-400">{message.senderName}</p>
            )}

            {message.replyTo && (
              <div
                className={cn(
                  "mb-1.5 rounded-lg border-r-[3px] px-2 py-1 text-xs",
                  isOwn ? "border-white/50 bg-white/10 text-white/90" : "border-violet-400 bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300"
                )}
              >
                <p className="font-bold">{message.replyTo.senderName}</p>
                <p className="truncate opacity-80">{message.replyTo.preview}</p>
              </div>
            )}

            {message.type === "image" && (
              <div
                className={cn(
                  "mb-1.5 flex h-40 w-56 items-center justify-center rounded-xl bg-gradient-to-br text-4xl",
                  message.attachment?.color || "from-slate-300 to-slate-400"
                )}
              >
                🖼️
              </div>
            )}

            {message.type === "voice" && <VoiceMessage isOwn={isOwn} duration={message.attachment?.duration || 10} />}

            {message.type === "file" && (
              <div className={cn("mb-1 flex items-center gap-2.5 rounded-xl p-2", isOwn ? "bg-white/10" : "bg-slate-100 dark:bg-white/5")}>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-rose-400 text-white">📄</div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{message.attachment?.name || "فایل.pdf"}</p>
                  <p className={cn("text-xs", isOwn ? "text-white/70" : "text-slate-400")}>{message.attachment?.size || "1.2 MB"}</p>
                </div>
              </div>
            )}

            {message.text && <p className="whitespace-pre-wrap break-words text-[14.5px] leading-6">{message.text}</p>}

            <div className={cn("mt-0.5 flex items-center gap-1", isOwn ? "justify-start" : "justify-end")}>
              {message.edited && <span className={cn("text-[10px]", isOwn ? "text-white/70" : "text-slate-400")}>ویرایش‌شده</span>}
              <span className={cn("text-[10px]", isOwn ? "text-white/80" : "text-slate-400")}>{formatTime(message.createdAt)}</span>
              <StatusIcon />
            </div>
          </div>

          {message.reactions && message.reactions.length > 0 && (
            <div className={cn("mt-1 flex flex-wrap gap-1", isOwn ? "justify-start" : "justify-end")}>
              {message.reactions.map((r) => (
                <button
                  key={r.emoji}
                  onClick={() => toggleReaction(chat.id, message.id, r.emoji)}
                  className={cn(
                    "flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-xs shadow-sm",
                    r.reactedByMe
                      ? "border-violet-300 bg-violet-50 dark:border-violet-500/40 dark:bg-violet-500/10"
                      : "border-slate-200 bg-white dark:border-white/10 dark:bg-white/5"
                  )}
                >
                  <span>{r.emoji}</span>
                  <span className="text-slate-500 dark:text-slate-300">{r.count}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {menu && <ContextMenu x={menu.x} y={menu.y} items={items} onClose={() => setMenu(null)} />}
    </div>
  );
}

export default memo(MessageBubble);
