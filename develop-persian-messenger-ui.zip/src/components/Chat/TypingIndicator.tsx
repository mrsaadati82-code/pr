export default function TypingIndicator() {
  return (
    <div className="flex justify-start px-3 sm:px-6">
      <div className="flex items-center gap-1 rounded-2xl rounded-br-md bg-white px-4 py-3 shadow-sm dark:bg-[#242733]">
        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-slate-400" style={{ animationDelay: "0s" }} />
        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-slate-400" style={{ animationDelay: "0.15s" }} />
        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-slate-400" style={{ animationDelay: "0.3s" }} />
      </div>
    </div>
  );
}
