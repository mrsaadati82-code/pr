import { useMemo, useState } from "react";
import { Search, Users as UsersIcon, MessageSquarePlus } from "lucide-react";
import Modal from "../common/Modal";
import Avatar from "../Avatar";
import { CONTACTS } from "../../data/mockData";
import { useChatStore } from "../../store/chatStore";

export default function NewChatModal() {
  const open = useChatStore((s) => s.newChatOpen);
  const setOpen = useChatStore((s) => s.setNewChatOpen);
  const createChatWithContact = useChatStore((s) => s.createChatWithContact);
  const setActiveChat = useChatStore((s) => s.setActiveChat);
  const pushToast = useChatStore((s) => s.pushToast);
  const [query, setQuery] = useState("");

  const filtered = useMemo(
    () => CONTACTS.filter((c) => c.id !== "bot1" && c.name.toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  const handleSelect = (contactId: string) => {
    const chatId = createChatWithContact(contactId);
    setActiveChat(chatId);
    setOpen(false);
    setQuery("");
  };

  return (
    <Modal open={open} onClose={() => setOpen(false)} title="گفتگوی جدید" widthClass="max-w-sm">
      <div className="p-4">
        <div className="relative mb-3">
          <Search size={16} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="جستجوی مخاطب..."
            className="w-full rounded-full bg-slate-100 py-2.5 pr-10 pl-4 text-sm outline-none focus:ring-2 focus:ring-violet-400 dark:bg-white/5 dark:text-slate-100"
          />
        </div>

        <button
          onClick={() => pushToast("قابلیت ساخت گروه به‌زودی اضافه می‌شود", "👥")}
          className="mb-2 flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-right hover:bg-slate-50 dark:hover:bg-white/5"
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 text-white">
            <UsersIcon size={20} />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">ساخت گروه جدید</p>
            <p className="text-xs text-slate-400">دعوت از مخاطبین برای گفتگوی گروهی</p>
          </div>
        </button>

        <p className="mb-1 px-2 text-xs font-bold text-slate-400">مخاطبین</p>
        <div className="scrollbar-thin max-h-[320px] space-y-0.5 overflow-y-auto">
          {filtered.map((c) => (
            <button
              key={c.id}
              onClick={() => handleSelect(c.id)}
              className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-right hover:bg-slate-50 dark:hover:bg-white/5"
            >
              <Avatar name={c.name} color={c.avatarColor} online={c.online} size={44} />
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">{c.name}</p>
                <p className="truncate text-xs text-slate-400">{c.online ? "آنلاین" : "آفلاین"}</p>
              </div>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="flex flex-col items-center gap-2 py-8 text-slate-400">
              <MessageSquarePlus size={28} />
              <p className="text-sm">مخاطبی یافت نشد</p>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
