import { useState } from "react";
import { Bell, Check, Info, Moon, Palette, Pencil, Shield, Sun, Volume2, VolumeX } from "lucide-react";
import Modal from "../common/Modal";
import Avatar from "../Avatar";
import { useChatStore } from "../../store/chatStore";
import { CURRENT_USER } from "../../data/mockData";

type Tab = "profile" | "appearance" | "notifications" | "privacy";

export default function SettingsModal() {
  const open = useChatStore((s) => s.settingsOpen);
  const setOpen = useChatStore((s) => s.setSettingsOpen);
  const profileName = useChatStore((s) => s.profileName);
  const profileBio = useChatStore((s) => s.profileBio);
  const profileUsername = useChatStore((s) => s.profileUsername);
  const setProfile = useChatStore((s) => s.setProfile);
  const theme = useChatStore((s) => s.theme);
  const toggleTheme = useChatStore((s) => s.toggleTheme);
  const notificationsEnabled = useChatStore((s) => s.notificationsEnabled);
  const soundsEnabled = useChatStore((s) => s.soundsEnabled);
  const toggleNotifications = useChatStore((s) => s.toggleNotifications);
  const toggleSounds = useChatStore((s) => s.toggleSounds);
  const pushToast = useChatStore((s) => s.pushToast);

  const [tab, setTab] = useState<Tab>("profile");
  const [editing, setEditing] = useState(false);
  const [nameInput, setNameInput] = useState(profileName);
  const [bioInput, setBioInput] = useState(profileBio);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "profile", label: "پروفایل من", icon: <Pencil size={16} /> },
    { key: "appearance", label: "ظاهر برنامه", icon: <Palette size={16} /> },
    { key: "notifications", label: "اعلان‌ها", icon: <Bell size={16} /> },
    { key: "privacy", label: "حریم خصوصی", icon: <Shield size={16} /> },
  ];

  const saveProfile = () => {
    setProfile({ name: nameInput.trim() || profileName, bio: bioInput });
    setEditing(false);
    pushToast("پروفایل به‌روزرسانی شد", "✅");
  };

  return (
    <Modal open={open} onClose={() => setOpen(false)} title="تنظیمات" widthClass="max-w-lg">
      <div className="flex flex-col sm:flex-row">
        <div className="scrollbar-thin flex shrink-0 gap-1.5 overflow-x-auto p-3 sm:w-44 sm:flex-col sm:overflow-visible sm:border-l sm:border-slate-100 sm:dark:border-white/5">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                tab === t.key
                  ? "bg-violet-500 text-white"
                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5"
              }`}
            >
              {t.icon}
              <span className="whitespace-nowrap">{t.label}</span>
            </button>
          ))}
        </div>

        <div className="flex-1 p-5">
          {tab === "profile" && (
            <div className="space-y-5">
              <div className="flex flex-col items-center gap-3">
                <Avatar name={profileName} color={CURRENT_USER.avatarColor} size={88} online />
                {editing ? (
                  <div className="w-full space-y-2.5">
                    <div>
                      <label className="mb-1 block text-xs font-bold text-slate-400">نام نمایشی</label>
                      <input
                        value={nameInput}
                        onChange={(e) => setNameInput(e.target.value)}
                        className="w-full rounded-xl bg-slate-100 px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-violet-400 dark:bg-white/5 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-bold text-slate-400">بیوگرافی</label>
                      <textarea
                        value={bioInput}
                        onChange={(e) => setBioInput(e.target.value)}
                        rows={2}
                        className="w-full resize-none rounded-xl bg-slate-100 px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-violet-400 dark:bg-white/5 dark:text-slate-100"
                      />
                    </div>
                    <button
                      onClick={saveProfile}
                      className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-violet-500 py-2.5 text-sm font-bold text-white hover:bg-violet-600"
                    >
                      <Check size={16} /> ذخیره تغییرات
                    </button>
                  </div>
                ) : (
                  <div className="text-center">
                    <p className="text-lg font-bold text-slate-800 dark:text-slate-100">{profileName}</p>
                    <p className="text-sm text-slate-400">@{profileUsername}</p>
                    {profileBio && <p className="mt-1 max-w-xs text-sm text-slate-500 dark:text-slate-400">{profileBio}</p>}
                    <button
                      onClick={() => {
                        setNameInput(profileName);
                        setBioInput(profileBio);
                        setEditing(true);
                      }}
                      className="mt-3 rounded-full bg-violet-50 px-4 py-1.5 text-sm font-semibold text-violet-600 hover:bg-violet-100 dark:bg-violet-500/10 dark:text-violet-300"
                    >
                      ویرایش پروفایل
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === "appearance" && (
            <div className="space-y-3">
              <p className="text-sm font-bold text-slate-500 dark:text-slate-400">تم برنامه</p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => theme === "dark" && toggleTheme()}
                  className={`flex flex-col items-center gap-2 rounded-2xl border-2 p-4 transition ${
                    theme === "light" ? "border-violet-500 bg-violet-50 dark:bg-violet-500/10" : "border-slate-200 dark:border-white/10"
                  }`}
                >
                  <Sun size={22} className="text-amber-500" />
                  <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">روشن</span>
                </button>
                <button
                  onClick={() => theme === "light" && toggleTheme()}
                  className={`flex flex-col items-center gap-2 rounded-2xl border-2 p-4 transition ${
                    theme === "dark" ? "border-violet-500 bg-violet-50 dark:bg-violet-500/10" : "border-slate-200 dark:border-white/10"
                  }`}
                >
                  <Moon size={22} className="text-indigo-500" />
                  <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">تیره</span>
                </button>
              </div>
              <div className="flex items-start gap-2 rounded-xl bg-slate-50 p-3 text-xs text-slate-500 dark:bg-white/5 dark:text-slate-400">
                <Info size={14} className="mt-0.5 shrink-0" />
                تغییر تم به‌صورت آنی روی کل برنامه اعمال می‌شود.
              </div>
            </div>
          )}

          {tab === "notifications" && (
            <div className="space-y-2">
              <ToggleRow
                icon={<Bell size={17} className="text-violet-500" />}
                title="اعلان‌های پیام"
                desc="دریافت اعلان برای پیام‌های جدید"
                checked={notificationsEnabled}
                onChange={toggleNotifications}
              />
              <ToggleRow
                icon={soundsEnabled ? <Volume2 size={17} className="text-emerald-500" /> : <VolumeX size={17} className="text-slate-400" />}
                title="صدای پیام"
                desc="پخش صدا هنگام دریافت پیام"
                checked={soundsEnabled}
                onChange={toggleSounds}
              />
            </div>
          )}

          {tab === "privacy" && (
            <div className="space-y-2">
              <ToggleRow icon={<Shield size={17} className="text-emerald-500" />} title="آخرین بازدید" desc="نمایش آخرین بازدید به مخاطبین" checked={true} onChange={() => pushToast("این تنظیم به‌زودی فعال می‌شود", "🔒")} />
              <ToggleRow icon={<Shield size={17} className="text-sky-500" />} title="عکس پروفایل" desc="نمایش عکس پروفایل برای همه" checked={true} onChange={() => pushToast("این تنظیم به‌زودی فعال می‌شود", "🔒")} />
              <ToggleRow icon={<Shield size={17} className="text-rose-500" />} title="تایید دو مرحله‌ای" desc="افزایش امنیت حساب کاربری" checked={false} onChange={() => pushToast("این تنظیم به‌زودی فعال می‌شود", "🔒")} />
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

function ToggleRow({
  icon,
  title,
  desc,
  checked,
  onChange,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl px-2 py-2.5 hover:bg-slate-50 dark:hover:bg-white/5">
      <div className="flex items-center gap-3">
        {icon}
        <div>
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{title}</p>
          <p className="text-xs text-slate-400">{desc}</p>
        </div>
      </div>
      <button
        onClick={onChange}
        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? "bg-violet-500" : "bg-slate-300 dark:bg-white/10"}`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
            checked ? "right-0.5" : "right-5"
          }`}
        />
      </button>
    </div>
  );
}
