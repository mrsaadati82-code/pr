import { AnimatePresence, motion } from "framer-motion";
import { useChatStore } from "../../store/chatStore";

export default function ToastStack() {
  const toasts = useChatStore((s) => s.toasts);
  const removeToast = useChatStore((s) => s.removeToast);

  return (
    <div className="pointer-events-none fixed top-4 left-1/2 z-[100] flex w-full max-w-sm -translate-x-1/2 flex-col gap-2 px-4">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            onClick={() => removeToast(t.id)}
            className="pointer-events-auto flex items-center gap-2 rounded-2xl bg-slate-900/95 px-4 py-3 text-sm text-white shadow-xl backdrop-blur dark:bg-white/10"
          >
            {t.icon && <span>{t.icon}</span>}
            <span className="truncate">{t.text}</span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
