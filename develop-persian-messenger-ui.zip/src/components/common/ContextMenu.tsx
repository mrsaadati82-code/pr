import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { cn } from "../../utils/cn";

export interface ContextMenuItem {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
  divider?: boolean;
}

interface ContextMenuProps {
  x: number;
  y: number;
  items: ContextMenuItem[];
  onClose: () => void;
}

export default function ContextMenu({ x, y, items, onClose }: ContextMenuProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    window.addEventListener("mousedown", handler);
    window.addEventListener("scroll", onClose, true);
    return () => {
      window.removeEventListener("mousedown", handler);
      window.removeEventListener("scroll", onClose, true);
    };
  }, [onClose]);

  const menuWidth = 210;
  const menuHeight = items.length * 40 + 16;
  const adjustedX = Math.min(x, window.innerWidth - menuWidth - 12);
  const adjustedY = Math.min(y, window.innerHeight - menuHeight - 12);

  return createPortal(
    <AnimatePresence>
      <motion.div
        ref={ref}
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.12 }}
        style={{ position: "fixed", top: adjustedY, left: adjustedX, width: menuWidth, zIndex: 200 }}
        className="overflow-hidden rounded-xl border border-slate-200/60 bg-white/95 py-1.5 shadow-2xl backdrop-blur-md dark:border-white/10 dark:bg-[#20232f]/95"
      >
        {items.map((item, i) => (
          <div key={i}>
            {item.divider && <div className="my-1 h-px bg-slate-200/70 dark:bg-white/10" />}
            <button
              onClick={() => {
                item.onClick();
                onClose();
              }}
              className={cn(
                "flex w-full items-center gap-2.5 px-3.5 py-2 text-sm transition-colors",
                item.danger
                  ? "text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10"
                  : "text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/5"
              )}
            >
              {item.icon}
              {item.label}
            </button>
          </div>
        ))}
      </motion.div>
    </AnimatePresence>,
    document.body
  );
}
