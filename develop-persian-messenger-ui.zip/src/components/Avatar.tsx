import { getInitials } from "../utils/format";
import { cn } from "../utils/cn";

interface AvatarProps {
  name: string;
  color: string;
  emoji?: string;
  size?: number;
  online?: boolean;
  className?: string;
}

export default function Avatar({ name, color, emoji, size = 44, online, className }: AvatarProps) {
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div
        className={cn(
          "flex h-full w-full items-center justify-center rounded-full bg-gradient-to-br font-bold text-white select-none",
          color,
          className
        )}
        style={{ fontSize: size * 0.38 }}
      >
        {emoji ? <span style={{ fontSize: size * 0.5 }}>{emoji}</span> : getInitials(name)}
      </div>
      {online && (
        <span
          className="absolute bottom-0 left-0 rounded-full border-2 border-white bg-emerald-500 dark:border-[#12141c]"
          style={{ width: size * 0.28, height: size * 0.28 }}
        />
      )}
    </div>
  );
}
