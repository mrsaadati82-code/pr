import { Bookmark, MessageCircle, Moon, Settings, Sun, Users } from "lucide-react";
import Avatar from "./Avatar";
import { useChatStore } from "../store/chatStore";
import { CURRENT_USER } from "../data/mockData";
import { cn } from "../utils/cn";

type Section = "chats" | "contacts";

interface IconRailProps {
  section: Section;
  onSectionChange: (s: Section) => void;
}

export default function IconRail({ section, onSectionChange }: IconRailProps) {
  const theme = useChatStore((s) => s.theme);
  const toggleTheme = useChatStore((s) => s.toggleTheme);
  const setActiveChat = useChatStore((s) => s.setActiveChat);
  const setSettingsOpen = useChatStore((s) => s.setSettingsOpen);
  const profileName = useChatStore((s) => s.profileName);

  const items = [
    { key: "chats" as Section, icon: MessageCircle, label: "گفتگوها" },
    { key: "contacts" as Section, icon: Users, label: "مخاطبین" },
  ];

  return (
    <div className="hidden w-[76px] shrink-0 flex-col items-center border-l border-slate-200/70 bg-white/70 py-4 backdrop-blur-xl dark:border-white/5 dark:bg-[#12141c]/80 md:flex">
      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 text-lg font-black text-white shadow-lg shadow-indigo-500/30">
        پ
      </div>

      <div className="flex flex-1 flex-col items-center gap-2">
        {items.map((item) => {
          const Icon = item.icon;
          const active = section === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onSectionChange(item.key)}
              className={cn(
                "group relative flex h-12 w-12 flex-col items-center justify-center gap-1 rounded-2xl text-slate-400 transition-all hover:bg-slate-100 dark:text-slate-500 dark:hover:bg-white/5",
                active && "bg-violet-50 text-violet-600 dark:bg-violet-500/15 dark:text-violet-400"
              )}
              title={item.label}
            >
              <Icon size={21} strokeWidth={active ? 2.4 : 2} />
            </button>
          );
        })}

        <button
          onClick={() => setActiveChat("saved")}
          className="flex h-12 w-12 items-center justify-center rounded-2xl text-slate-400 transition-all hover:bg-slate-100 hover:text-amber-500 dark:text-slate-500 dark:hover:bg-white/5"
          title="پیام‌های ذخیره‌شده"
        >
          <Bookmark size={20} />
        </button>
      </div>

      <div className="flex flex-col items-center gap-3">
        <button
          onClick={toggleTheme}
          className="flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition-all hover:bg-slate-100 hover:text-amber-500 dark:text-slate-500 dark:hover:bg-white/5"
          title="تغییر پوسته"
        >
          {theme === "light" ? <Moon size={19} /> : <Sun size={19} />}
        </button>
        <button
          onClick={() => setSettingsOpen(true)}
          className="flex h-11 w-11 items-center justify-center rounded-2xl text-slate-400 transition-all hover:bg-slate-100 hover:text-slate-600 dark:text-slate-500 dark:hover:bg-white/5"
          title="تنظیمات"
        >
          <Settings size={19} />
        </button>
        <button onClick={() => setSettingsOpen(true)} title="پروفایل من">
          <Avatar name={profileName} color={CURRENT_USER.avatarColor} size={40} online />
        </button>
      </div>
    </div>
  );
}
