import { useMemo, useState } from "react";
import { BellOff, BellRing, Edit3, Pin, PinOff, Search, Trash2, X, CheckCheck } from "lucide-react";
import ChatListItem from "./ChatListItem";
import ContextMenu, { type ContextMenuItem } from "../common/ContextMenu";
import { useChatStore, type FilterTab } from "../../store/chatStore";
import Avatar from "../Avatar";
import { CURRENT_USER } from "../../data/mockData";

const TABS: { key: FilterTab; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "unread", label: "خوانده‌نشده" },
  { key: "private", label: "شخصی" },
  { key: "group", label: "گروه‌ها" },
  { key: "channel", label: "کانال‌ها" },
];

export default function Sidebar() {
  const chats = useChatStore((s) => s.chats);
  const messages = useChatStore((s) => s.messages);
  const activeChatId = useChatStore((s) => s.activeChatId);
  const filter = useChatStore((s) => s.filter);
  const searchQuery = useChatStore((s) => s.searchQuery);
  const setActiveChat = useChatStore((s) => s.setActiveChat);
  const setFilter = useChatStore((s) => s.setFilter);
  const setSearchQuery = useChatStore((s) => s.setSearchQuery);
  const togglePinChat = useChatStore((s) => s.togglePinChat);
  const toggleMuteChat = useChatStore((s) => s.toggleMuteChat);
  const deleteChat = useChatStore((s) => s.deleteChat);
  const markChatRead = useChatStore((s) => s.markChatRead);
  const setNewChatOpen = useChatStore((s) => s.setNewChatOpen);
  const setSettingsOpen = useChatStore((s) => s.setSettingsOpen);
  const profileName = useChatStore((s) => s.profileName);

  const [menu, setMenu] = useState<{ x: number; y: number; chatId: string } | null>(null);

  const filteredChats = useMemo(() => {
    let list = chats.filter((c) => !c.archived);
    if (filter === "unread") list = list.filter((c) => c.unreadCount > 0);
    else if (filter === "private") list = list.filter((c) => c.type === "private" || c.type === "bot");
    else if (filter === "group") list = list.filter((c) => c.type === "group");
    else if (filter === "channel") list = list.filter((c) => c.type === "channel");

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter((c) => c.title.toLowerCase().includes(q) || c.username?.toLowerCase().includes(q));
    }

    return [...list].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      const la = messages[a.id]?.at(-1)?.createdAt || 0;
      const lb = messages[b.id]?.at(-1)?.createdAt || 0;
      return lb - la;
    });
  }, [chats, filter, searchQuery, messages]);

  const contextItems = (chatId: string): ContextMenuItem[] => {
    const chat = chats.find((c) => c.id === chatId);
    if (!chat) return [];
    return [
      {
        label: chat.pinned ? "برداشتن سنجاق" : "سنجاق کردن",
        icon: chat.pinned ? <PinOff size={16} /> : <Pin size={16} />,
        onClick: () => togglePinChat(chatId),
      },
      {
        label: chat.muted ? "فعال کردن اعلان‌ها" : "بی‌صدا کردن",
        icon: chat.muted ? <BellRing size={16} /> : <BellOff size={16} />,
        onClick: () => toggleMuteChat(chatId),
      },
      {
        label: "علامت‌گذاری به‌عنوان خوانده‌شده",
        icon: <CheckCheck size={16} />,
        onClick: () => markChatRead(chatId),
      },
      {
        label: "حذف گفتگو",
        icon: <Trash2 size={16} />,
        onClick: () => deleteChat(chatId),
        danger: true,
        divider: true,
      },
    ];
  };

  return (
    <div className="relative flex h-full w-full flex-col bg-white dark:bg-[#171922] md:w-[360px] md:shrink-0 md:border-l md:border-slate-200/70 md:dark:border-white/5">
      <div className="flex items-center gap-2 px-4 pt-4 pb-2">
        <button
          onClick={() => setSettingsOpen(true)}
          className="shrink-0 md:hidden"
          title="پروفایل من"
        >
          <Avatar name={profileName} color={CURRENT_USER.avatarColor} size={38} />
        </button>
        <div className="relative flex-1">
          <Search size={17} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو در گفتگوها..."
            className="w-full rounded-full bg-slate-100 py-2.5 pr-10 pl-8 text-sm text-slate-700 outline-none transition focus:ring-2 focus:ring-violet-400 dark:bg-white/5 dark:text-slate-200"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute left-2.5 top-1/2 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full bg-slate-300 text-white dark:bg-white/20"
            >
              <X size={12} />
            </button>
          )}
        </div>
      </div>

      <div className="scrollbar-thin flex items-center gap-1.5 overflow-x-auto px-4 py-2">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors ${
              filter === tab.key
                ? "bg-violet-500 text-white shadow-sm shadow-violet-300 dark:shadow-none"
                : "bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-white/5 dark:text-slate-400 dark:hover:bg-white/10"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="scrollbar-thin flex-1 space-y-0.5 overflow-y-auto px-2.5 pb-24 pt-1">
        {filteredChats.length === 0 && (
          <div className="mt-16 flex flex-col items-center gap-2 text-center text-slate-400">
            <span className="text-4xl">🔍</span>
            <p className="text-sm">چیزی پیدا نشد</p>
          </div>
        )}
        {filteredChats.map((chat) => (
          <ChatListItem
            key={chat.id}
            chat={chat}
            lastMessage={messages[chat.id]?.at(-1)}
            active={activeChatId === chat.id}
            onClick={() => setActiveChat(chat.id)}
            onContextMenu={(e) => {
              e.preventDefault();
              setMenu({ x: e.clientX, y: e.clientY, chatId: chat.id });
            }}
          />
        ))}
      </div>

      <button
        onClick={() => setNewChatOpen(true)}
        className="absolute bottom-6 left-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-xl shadow-violet-500/40 transition-transform hover:scale-105 active:scale-95 md:bottom-6 md:left-6"
        title="گفتگوی جدید"
      >
        <Edit3 size={22} />
      </button>

      {menu && <ContextMenu x={menu.x} y={menu.y} items={contextItems(menu.chatId)} onClose={() => setMenu(null)} />}
    </div>
  );
}
