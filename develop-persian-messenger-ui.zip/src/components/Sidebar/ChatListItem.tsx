import { memo } from "react";
import { BellOff, Check, CheckCheck, Pin } from "lucide-react";
import Avatar from "../Avatar";
import type { Chat, Message } from "../../types";
import { formatListTime } from "../../utils/format";
import { cn } from "../../utils/cn";
import { CURRENT_USER_ID } from "../../data/mockData";

interface ChatListItemProps {
  chat: Chat;
  lastMessage?: Message;
  active: boolean;
  onClick: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
}

function renderPreview(msg?: Message) {
  if (!msg) return "هنوز پیامی نیست";
  if (msg.type === "image") return "🖼 عکس";
  if (msg.type === "voice") return "🎤 پیام صوتی";
  if (msg.type === "file") return "📎 فایل";
  return msg.text;
}

function ChatListItem({ chat, lastMessage, active, onClick, onContextMenu }: ChatListItemProps) {
  const isOwn = lastMessage?.senderId === CURRENT_USER_ID;
  const online = chat.type === "private" && chat.participants[0]?.online;

  return (
    <button
      onClick={onClick}
      onContextMenu={onContextMenu}
      className={cn(
        "group flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-right transition-colors",
        active ? "bg-violet-50 dark:bg-violet-500/15" : "hover:bg-slate-100 dark:hover:bg-white/5"
      )}
    >
      <Avatar name={chat.title} color={chat.avatarColor} emoji={chat.avatarEmoji} online={online} size={52} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <span className={cn("truncate text-[15px] font-semibold", active ? "text-violet-700 dark:text-violet-300" : "text-slate-800 dark:text-slate-100")}>
            {chat.title}
          </span>
          <span className={cn("shrink-0 text-[11px]", chat.unreadCount > 0 ? "font-semibold text-violet-500" : "text-slate-400")}>
            {lastMessage ? formatListTime(lastMessage.createdAt) : ""}
          </span>
        </div>
        <div className="mt-0.5 flex items-center justify-between gap-2">
          <div className="flex min-w-0 items-center gap-1 text-[13px] text-slate-500 dark:text-slate-400">
            {isOwn && lastMessage && (
              <span className="shrink-0 text-violet-400">
                {lastMessage.status === "read" ? <CheckCheck size={14} /> : <Check size={14} />}
              </span>
            )}
            {chat.typingUserId ? (
              <span className="truncate text-emerald-500">در حال تایپ...</span>
            ) : (
              <span className="truncate">{renderPreview(lastMessage)}</span>
            )}
          </div>
          <div className="flex shrink-0 items-center gap-1">
            {chat.muted && <BellOff size={13} className="text-slate-400" />}
            {chat.pinned && !chat.unreadCount && <Pin size={12} className="text-slate-400" />}
            {chat.unreadCount > 0 && (
              <span
                className={cn(
                  "flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-bold text-white",
                  chat.muted ? "bg-slate-400" : "bg-violet-500"
                )}
              >
                {chat.unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}

export default memo(ChatListItem);
