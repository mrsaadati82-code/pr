export default function WelcomeScreen() {
  return (
    <div className="hidden flex-1 flex-col items-center justify-center gap-5 bg-[#f4f5fa] text-center dark:bg-[#0f1117] md:flex">
      <div className="flex h-28 w-28 items-center justify-center rounded-[2rem] bg-gradient-to-br from-violet-500 to-indigo-600 text-5xl font-black text-white shadow-2xl shadow-violet-500/30">
        پ
      </div>
      <div>
        <h1 className="text-2xl font-bold text-slate-700 dark:text-slate-100">به پیام‌رسان پرنیان خوش آمدید</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-slate-400">
          یکی از گفتگوها را از فهرست سمت راست انتخاب کنید یا با کلیک روی دکمه پیام جدید، گفتگویی تازه آغاز کنید.
        </p>
      </div>
      <div className="flex items-center gap-2 rounded-full bg-white px-4 py-2 text-xs font-medium text-slate-400 shadow-sm dark:bg-white/5">
        <span className="h-2 w-2 rounded-full bg-emerald-500" />
        اتصال برقرار است
      </div>
    </div>
  );
}
