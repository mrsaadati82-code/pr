const timeFormatter = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit" });
const dateFormatter = new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long" });
const fullDateFormatter = new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long", year: "numeric" });

export function formatTime(ts: number) {
  return timeFormatter.format(new Date(ts));
}

export function isSameDay(a: number, b: number) {
  const d1 = new Date(a);
  const d2 = new Date(b);
  return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();
}

export function formatDateSeparator(ts: number) {
  const now = Date.now();
  if (isSameDay(ts, now)) return "امروز";
  if (isSameDay(ts, now - 86400000)) return "دیروز";
  return dateFormatter.format(new Date(ts));
}

export function formatLastSeen(ts?: number) {
  if (!ts) return "بازدید اخیر نامشخص";
  const diff = Date.now() - ts;
  const min = 60 * 1000;
  const hour = 60 * min;
  const day = 24 * hour;
  if (diff < min) return "همین الان آنلاین بود";
  if (diff < hour) return `${Math.floor(diff / min)} دقیقه پیش آنلاین بود`;
  if (diff < day) return `${Math.floor(diff / hour)} ساعت پیش آنلاین بود`;
  if (diff < day * 2) return "دیروز آنلاین بود";
  return `آخرین بازدید ${fullDateFormatter.format(new Date(ts))}`;
}

export function formatListTime(ts: number) {
  const now = Date.now();
  if (isSameDay(ts, now)) return formatTime(ts);
  if (isSameDay(ts, now - 86400000)) return "دیروز";
  return dateFormatter.format(new Date(ts));
}

export function getInitials(name: string) {
  const parts = name.trim().split(" ").filter(Boolean);
  if (parts.length === 0) return "؟";
  if (parts.length === 1) return parts[0].slice(0, 1);
  return parts[0].slice(0, 1) + parts[1].slice(0, 1);
}

export function formatMemberCount(n?: number) {
  if (!n) return "";
  if (n >= 1000) return `${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)} هزار عضو`;
  return `${n} عضو`;
}

export function formatVoiceDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
