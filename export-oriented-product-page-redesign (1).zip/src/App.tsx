import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { 
  Leaf, 
  ShieldCheck, 
  Globe, 
  ChevronRight, 
  Menu, 
  X,
  Mail,
  Phone,
  ArrowRight,
  Sun,
  ThermometerSnowflake,
  Package,
  Award,
  Share2,
  CheckCircle2
} from 'lucide-react';
import { cn } from './lib/utils';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { scrollYProgress } = useScroll();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#about' },
    { name: 'Specifications', href: '#specs' },
    { name: 'Packaging', href: '#packaging' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={cn(
      "fixed top-0 w-full z-50 transition-all duration-300",
      isScrolled ? "bg-white/80 backdrop-blur-md shadow-sm py-3" : "bg-transparent py-6"
    )}>
      <motion.div 
        className="absolute top-0 left-0 right-0 h-1 bg-green-500 origin-left z-50"
        style={{ scaleX: scrollYProgress }}
      />
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
            <Leaf className="text-white w-6 h-6" />
          </div>
          <span className={cn(
            "text-2xl font-bold tracking-tight",
            isScrolled ? "text-green-900" : "text-white"
          )}>
            ARASB <span className="text-green-500">TRADING</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-green-500",
                isScrolled ? "text-slate-600" : "text-white/90"
              )}
            >
              {link.name}
            </a>
          ))}
          <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-full font-medium transition-all transform hover:scale-105">
            Get Quote
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-green-900"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className={isScrolled ? "text-slate-900" : "text-white"} /> : <Menu className={isScrolled ? "text-slate-900" : "text-white"} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-white shadow-xl border-t md:hidden"
          >
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  className="text-lg font-medium text-slate-700 hover:text-green-600"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <button className="bg-green-600 text-white py-3 rounded-xl font-medium">
                Contact Sales
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);

  return (
    <section className="relative h-screen flex items-center overflow-hidden bg-slate-900">
      <motion.div 
        style={{ y: y1 }}
        className="absolute inset-0 z-0"
      >
        <img 
          src="/kiwi-hero.jpg" 
          alt="Premium Iranian Kiwi" 
          className="w-full h-full object-cover opacity-60 scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
      </motion.div>

      <div className="container mx-auto px-6 relative z-10 pt-20">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <div className="inline-flex items-center gap-2 bg-green-500/20 backdrop-blur-md border border-green-500/30 text-green-400 px-4 py-1 rounded-full mb-6">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-sm font-semibold tracking-wider uppercase">Premium Export Grade</span>
          </div>
          <h1 className="text-5xl md:text-8xl font-bold text-white leading-tight mb-6">
            Nature's Emerald <br />
            <span className="text-green-500">From Iran</span>
          </h1>
          <p className="text-xl text-slate-300 mb-10 max-w-xl leading-relaxed">
            Sourced from the lush orchards of Northern Iran. Fresh, vibrant green, and vitamin-rich kiwis delivered globally with advanced cold-chain expertise.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-green-600 hover:bg-green-700 text-white px-10 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-all"
            >
              Export Inquiry <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => document.getElementById('specs')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-full font-bold text-lg transition-all"
            >
              View Specs
            </button>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 w-full py-6 bg-black/20 backdrop-blur-sm border-t border-white/10 z-10 hidden lg:block">
        <div className="container mx-auto px-6 flex justify-between items-center text-white/70 text-sm font-medium">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> Global GAP Certified
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> ISO 22000
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" /> HACCP Standard
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            2026 Harvest Season Now Available
          </div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 hidden md:block"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-white/40 text-sm uppercase tracking-widest">Scroll to explore</span>
          <div className="w-px h-12 bg-gradient-to-b from-green-500 to-transparent" />
        </div>
      </motion.div>
    </section>
  );
};

const Features = () => {
  const features = [
    {
      icon: <Sun className="w-8 h-8 text-orange-400" />,
      title: "Perfect Climate",
      desc: "Grown in the fertile northern regions of Iran under ideal humidity and sun."
    },
    {
      icon: <ThermometerSnowflake className="w-8 h-8 text-blue-400" />,
      title: "Cold-Chain Logistics",
      desc: "Advanced temperature-controlled shipping to preserve freshness for months."
    },
    {
      icon: <Package className="w-8 h-8 text-green-400" />,
      title: "Custom Packaging",
      desc: "Flexible packaging solutions tailored to international retail requirements."
    },
    {
      icon: <Award className="w-8 h-8 text-yellow-400" />,
      title: "Global Standards",
      desc: "Meeting strict food safety, labeling, and import standards worldwide."
    }
  ];

  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              src="/kiwi-orchard.jpg" 
              alt="Iranian Kiwi Orchard" 
              className="rounded-3xl shadow-2xl z-10 relative"
            />
            <div className="absolute -bottom-6 -right-6 w-64 h-64 bg-green-100 rounded-3xl -z-10" />
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-green-600/10 rounded-full blur-3xl" />
          </motion.div>

          <div className="space-y-12">
            <div>
              <h2 className="text-green-600 font-bold uppercase tracking-wider mb-2">The Arasb Difference</h2>
              <h3 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
                Authentic Flavor, <br />Global Delivery.
              </h3>
              <p className="text-lg text-slate-600">
                Iranian kiwi fruit is increasingly recognized in global markets for its bright green color, tangy-sweet flavor, and outstanding nutritional profile. At Arasb Trading, we bridge the gap between local orchards and global tables.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {features.map((f, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="flex flex-col gap-4 p-6 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:shadow-xl hover:shadow-green-900/5 transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                    {f.icon}
                  </div>
                  <h4 className="font-bold text-slate-900 text-lg">{f.title}</h4>
                  <p className="text-slate-600 text-sm leading-relaxed">{f.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const QualityControl = () => {
  const steps = [
    { number: "01", title: "Hand Picking", desc: "Expert harvesters select fruits at optimal maturity to ensure high Brix potential." },
    { number: "02", title: "Optical Sorting", desc: "Advanced sensors grade kiwis by weight, shape, and external quality defects." },
    { number: "03", title: "Pre-Cooling", desc: "Rapid cooling immediately after harvest to stop ripening and lock in freshness." },
    { number: "04", title: "Smart Storage", desc: "CA (Controlled Atmosphere) storage maintains quality for up to 6 months." }
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16">
          <div className="lg:w-1/3">
            <h2 className="text-green-600 font-bold uppercase tracking-wider mb-4">Precision Engineering</h2>
            <h3 className="text-4xl font-bold text-slate-900 mb-6">Quality Control Journey</h3>
            <p className="text-slate-600 mb-8 leading-relaxed">
              We don't just ship fruit; we manage a scientific process to ensure the "Emerald of Iran" reaches your doorstep in pristine condition.
            </p>
            <div className="p-8 bg-green-50 rounded-3xl border border-green-100">
              <div className="text-3xl font-bold text-green-900 mb-2">98.5%</div>
              <div className="text-green-700 font-medium text-sm uppercase tracking-wider">Quality Acceptance Rate</div>
            </div>
          </div>
          
          <div className="lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="relative p-8 rounded-[2rem] bg-slate-50 border border-slate-100 hover:border-green-200 hover:bg-white hover:shadow-xl transition-all group"
              >
                <div className="text-6xl font-black text-slate-200 group-hover:text-green-100 absolute top-4 right-8 transition-colors">
                  {step.number}
                </div>
                <h4 className="text-xl font-bold text-slate-900 mb-3 relative z-10">{step.title}</h4>
                <p className="text-slate-600 text-sm leading-relaxed relative z-10">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const SpecsSection = () => {
  const specs = [
    { label: "Variety", value: "Hayward (Premium)" },
    { label: "Brix Level", value: "6.5% - 15%+" },
    { label: "Harvest Season", value: "October to January" },
    { label: "Sizing (gr)", value: "70g to 120g+" },
    { label: "Color", value: "Bright Emerald Green" },
    { label: "Shelf Life", value: "4-6 Months in Cold Storage" }
  ];

  return (
    <section id="specs" className="py-24 bg-slate-900 text-white relative">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-green-600/5 blur-3xl -z-0" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-green-500 font-bold uppercase tracking-wider mb-4">Product Details</h2>
          <h3 className="text-4xl md:text-5xl font-bold mb-6">Technical Specifications</h3>
          <p className="text-slate-400 text-lg">
            Our kiwis are graded with precision to ensure consistency in size, weight, and sweetness for international retail standards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {specs.map((spec, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="p-8 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center text-center group hover:bg-green-600/10 hover:border-green-600/30 transition-all"
            >
              <div className="text-green-500 text-sm font-medium mb-2 uppercase tracking-widest">{spec.label}</div>
              <div className="text-2xl font-bold group-hover:text-green-400 transition-colors">{spec.value}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Packaging = () => {
  const types = [
    { title: "Basket Packaging", info: "3kg / 4kg / 10kg Plastic Baskets", image: "/kiwi-packaging.jpg" },
    { title: "Cardboard Boxes", info: "Single Layer Tray (3kg / 3.5kg)", image: "/kiwi-packaging.jpg" },
    { title: "Custom Sizing", info: "Retail-ready clamshells & punnets", image: "/kiwi-packaging.jpg" }
  ];

  return (
    <section id="packaging" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-green-600 font-bold uppercase tracking-wider mb-4">Logistics & Design</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
              Export-Oriented Packaging Solutions
            </h3>
          </div>
          <p className="text-slate-600 text-lg max-w-md">
            We provide flexible packaging tailored to buyer specifications and regional requirements, ensuring long shelf life.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {types.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
              viewport={{ once: true }}
              className="group overflow-hidden rounded-3xl bg-white shadow-sm hover:shadow-2xl transition-all"
            >
              <div className="h-64 overflow-hidden">
                <img 
                  src={t.image} 
                  alt={t.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
              </div>
              <div className="p-8">
                <h4 className="text-2xl font-bold text-slate-900 mb-2">{t.title}</h4>
                <p className="text-slate-600 mb-6">{t.info}</p>
                <div className="flex items-center gap-2 text-green-600 font-bold group-hover:gap-4 transition-all cursor-pointer">
                  Request Detail <ArrowRight className="w-5 h-5" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const OtherProducts = () => {
  const products = [
    { name: "Persian Dates", category: "Dried Fruit", image: "https://images.unsplash.com/photo-1595204457635-4eb46be7301c?auto=format&fit=crop&q=80&w=800" },
    { name: "Premium Pistachios", category: "Nuts", image: "https://images.unsplash.com/photo-1551021215-1df3471b6ad5?auto=format&fit=crop&q=80&w=800" },
    { name: "Red Saffron", category: "Spices", image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=800" },
    { name: "Export Apples", category: "Fresh Fruit", image: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&q=80&w=800" }
  ];

  return (
    <section className="py-24 bg-slate-50">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-green-600 font-bold uppercase tracking-wider mb-4">Explore More</h2>
        <h3 className="text-4xl font-bold text-slate-900 mb-16">Other Premium Iranian Goods</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {products.map((p, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all text-left"
            >
              <div className="h-40 overflow-hidden">
                <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              </div>
              <div className="p-4">
                <div className="text-xs text-green-600 font-bold uppercase mb-1">{p.category}</div>
                <div className="font-bold text-slate-900">{p.name}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const MarketPresence = () => {
  const regions = [
    { name: "Middle East", share: "40%", markets: "UAE, Qatar, Oman" },
    { name: "Europe", share: "25%", markets: "Germany, Russia, CIS" },
    { name: "Asia / India", share: "30%", markets: "India, Malaysia, Thailand" },
    { name: "Others", share: "5%", markets: "North Africa" }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="bg-slate-900 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden">
          <div className="absolute bottom-0 right-0 w-full h-full opacity-10 pointer-events-none">
             <div className="absolute inset-0 bg-gradient-to-t from-green-500/20 to-transparent" />
          </div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-green-500 font-bold uppercase tracking-wider mb-4">Global Reach</h2>
              <h3 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">Trusted by Major <br />Markets Worldwide</h3>
              <p className="text-slate-400 text-lg mb-10">
                Our export volume has grown by 150% over the last three years, making us one of Iran's leading kiwi distributors for high-end retail chains.
              </p>
              <button className="flex items-center gap-2 text-white font-bold border-b-2 border-green-500 pb-2 hover:gap-4 transition-all">
                Download Export Catalog <ArrowRight className="w-5 h-5 text-green-500" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {regions.map((region, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="p-8 rounded-3xl bg-white/5 border border-white/10"
                >
                  <div className="text-3xl font-bold text-white mb-1">{region.share}</div>
                  <div className="text-green-500 font-bold mb-3">{region.name}</div>
                  <div className="text-slate-400 text-sm">{region.markets}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const CTA = () => {
  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-green-900">
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="bg-white rounded-[3rem] p-8 md:p-16 flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 leading-tight">
              Ready to Export <br />
              <span className="text-green-600">Fresh Quality?</span>
            </h2>
            <p className="text-xl text-slate-600 mb-10 leading-relaxed">
              Wholesalers, importers, and distributors – get a customized quote for your region and requirements today.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 font-medium">Call Us Directly</div>
                  <div className="text-xl font-bold text-slate-900">+98 912 345 6789</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 font-medium">Email Inquiry</div>
                  <div className="text-xl font-bold text-slate-900">export@arasbtrading.com</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-slate-500 font-medium">Global Markets</div>
                  <div className="text-xl font-bold text-slate-900">Asia, Europe, Middle East</div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 w-full">
            <form className="space-y-4 bg-slate-50 p-8 md:p-10 rounded-[2rem] border border-slate-100">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" placeholder="Your Name" className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 outline-none transition-all" />
                <input type="email" placeholder="Email Address" className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 outline-none transition-all" />
              </div>
              <input type="text" placeholder="Company Name" className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 outline-none transition-all" />
              <select className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 outline-none transition-all bg-white">
                <option>Select Target Region</option>
                <option>Middle East</option>
                <option>Europe</option>
                <option>Asia / Pacific</option>
                <option>North America</option>
              </select>
              <textarea placeholder="Tell us about your requirements..." rows={4} className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-green-500 outline-none transition-all" />
              <button className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-5 rounded-xl shadow-lg shadow-green-900/20 transition-all flex items-center justify-center gap-2">
                Send Inquiry <ArrowRight className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const ScrollToTop = () => {
  const [visible, setVisible] = useState(false);
  
  useEffect(() => {
    const toggleVisible = () => setVisible(window.scrollY > 500);
    window.addEventListener('scroll', toggleVisible);
    return () => window.removeEventListener('scroll', toggleVisible);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-8 right-8 z-50 p-4 bg-green-600 text-white rounded-full shadow-2xl hover:bg-green-700 transition-all"
        >
          <ArrowRight className="w-6 h-6 -rotate-90" />
        </motion.button>
      )}
    </AnimatePresence>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-20 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <Leaf className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-white tracking-tight">
                ARASB <span className="text-green-500">TRADING</span>
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-8">
              Premium Iranian agricultural products with consistent quality and authentic origin. Trusted by gourmet retailers and specialty markets worldwide.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-green-600 hover:text-white transition-all"><Share2 className="w-5 h-5" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-green-600 hover:text-white transition-all"><Phone className="w-5 h-5" /></a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-green-600 hover:text-white transition-all"><Mail className="w-5 h-5" /></a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">Our Products</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-green-500 transition-colors">Iranian Fresh Kiwi</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Premium Pistachios</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Organic Dates</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Persian Saffron</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Export Apples</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-green-500 transition-colors">About Company</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Quality Control</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Logistics & Storage</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Export Map</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Newsletter</h4>
            <p className="text-sm mb-4">Get the latest market updates and seasonal pricing.</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Email" className="bg-white/5 border border-white/10 rounded-lg px-4 py-2 w-full focus:ring-1 focus:ring-green-500 outline-none" />
              <button className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors">
                <ChevronRight />
              </button>
            </div>
          </div>
        </div>
        <div className="border-t border-white/5 pt-8 text-center text-xs">
          © {new Date().getFullYear()} Arasb Trading Company. All Rights Reserved. Designed for Excellence.
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-green-500 selection:text-white">
      <Navbar />
      <Hero />
      <Features />
      <QualityControl />
      <SpecsSection />
      <Packaging />
      <MarketPresence />
      <OtherProducts />
      <CTA />
      <Footer />
      <ScrollToTop />
    </div>
  );
}
