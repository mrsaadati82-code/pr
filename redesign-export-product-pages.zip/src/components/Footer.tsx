

const Footer = () => {
  return (
    <footer className="bg-emerald-950 text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 bg-emerald-800 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">A</span>
              </div>
              <span className="text-2xl font-bold tracking-tight">
                ARASB <span className="font-light">TRADING</span>
              </span>
            </div>
            <p className="text-emerald-100/60 max-w-md leading-relaxed">
              Arasb Trading is a premier supplier of Iranian dried fruits and nuts, dedicated to bringing the authentic taste of Persia to the global market through sustainable sourcing and rigorous quality control.
            </p>
          </div>

          <div>
            <h5 className="font-bold text-lg mb-6">Quick Links</h5>
            <ul className="space-y-4 text-emerald-100/60">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Products</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Quality Control</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Packaging</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">About Us</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-lg mb-6">Follow Us</h5>
            <ul className="space-y-4 text-emerald-100/60">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">LinkedIn</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Twitter (X)</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Facebook</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-emerald-900 flex flex-col md:row items-center justify-between gap-6 text-emerald-100/40 text-sm">
          <p>© 2024 Arasb Trading Company. All Rights Reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-emerald-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
