
import { Box, Package, ShoppingBag, Truck } from 'lucide-react';

const PackagingSection = () => {
  const options = [
    {
      icon: <Box size={32} />,
      title: 'Bulk Packing',
      desc: '10kg, 12.5kg, and 25kg vacuum packs or PP bags, designed for industrial and wholesale use.',
      tag: 'Best for B2B'
    },
    {
      icon: <ShoppingBag size={32} />,
      title: 'Retail Packaging',
      desc: 'Customized private label options from 250g to 1kg pouches with high-quality printing.',
      tag: 'Ready for Shelf'
    },
    {
      icon: <Package size={32} />,
      title: 'Protective Barrier',
      desc: 'Oxygen-barrier and moisture-proof packaging to maintain freshness and aroma.',
      tag: 'Quality First'
    },
    {
      icon: <Truck size={32} />,
      title: 'Global Logistics',
      desc: 'Optimized palletizing and shipping solutions by Sea (FCL/LCL) or Air freight.',
      tag: 'Door-to-Door'
    }
  ];

  return (
    <section id="packaging" className="py-24 bg-emerald-950 text-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl font-bold mb-6">Built for Global Transit</h2>
          <p className="text-emerald-200/70 text-lg">
            We offer versatile packaging solutions tailored to your market's specific needs, ensuring the product arrives in pristine condition.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {options.map((opt, i) => (
            <div 
              key={i}
              className="group p-8 rounded-3xl bg-emerald-900/40 border border-emerald-800 hover:bg-emerald-800/60 transition-all duration-300"
            >
              <div className="text-emerald-400 mb-6 group-hover:scale-110 transition-transform duration-300 origin-left">
                {opt.icon}
              </div>
              <span className="text-[10px] uppercase tracking-widest text-emerald-500 font-bold mb-3 block">
                {opt.tag}
              </span>
              <h4 className="text-xl font-bold mb-4">{opt.title}</h4>
              <p className="text-emerald-100/60 text-sm leading-relaxed">
                {opt.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PackagingSection;
