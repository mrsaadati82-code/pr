import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const varieties = [
  {
    id: 'akbari',
    name: 'Akbari (Super Long)',
    description: 'The most prestigious variety, known for its elongated shape and luxurious dark shell. Favored by the East Asian and European markets.',
    image: '/akbari.jpg',
    specs: {
      size: '18/20, 20/22, 22/24',
      shape: 'Super Long',
      taste: 'Rich & Sweet',
      shell: 'Dark/Creamy'
    }
  },
  {
    id: 'jumbo',
    name: 'Kalleh Ghouchi (Jumbo)',
    description: 'Characterized by its large size and round shape. It offers a higher kernel-to-shell ratio and is a favorite for snack lovers.',
    image: '/jumbo.jpg',
    specs: {
      size: '20/22, 22/24, 24/26',
      shape: 'Round & Large',
      taste: 'Buttery & Dense',
      shell: 'Bright Cream'
    }
  },
  {
    id: 'ahmad',
    name: 'Ahmad Aghaei (Long)',
    description: 'Extremely popular for its exquisite flavor and bright white shell. A top choice for markets seeking both beauty and taste.',
    image: 'https://images.pexels.com/photos/5202285/pexels-photo-5202285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800',
    specs: {
      size: '22/24, 24/26, 26/28',
      shape: 'Long',
      taste: 'Exquisite & Nutty',
      shell: 'Bone White'
    }
  }
];

const ProductShowcase = () => {
  const [activeTab, setActiveTab] = useState(varieties[0]);

  return (
    <section id="pistachios" className="py-24 bg-emerald-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-emerald-950 mb-4">Our Export Varieties</h2>
          <div className="w-20 h-1 bg-emerald-500 mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative aspect-square md:aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl">
            <AnimatePresence mode="wait">
              <motion.img
                key={activeTab.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.5 }}
                src={activeTab.image}
                alt={activeTab.name}
                className="w-full h-full object-cover"
              />
            </AnimatePresence>
            <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/40 to-transparent" />
          </div>

          {/* Info Side */}
          <div>
            <div className="flex flex-wrap gap-2 mb-8">
              {varieties.map((v) => (
                <button
                  key={v.id}
                  onClick={() => setActiveTab(v)}
                  className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
                    activeTab.id === v.id
                      ? 'bg-emerald-900 text-white shadow-lg'
                      : 'bg-white text-emerald-900 hover:bg-emerald-100'
                  }`}
                >
                  {v.name}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <h3 className="text-3xl font-bold text-emerald-900 mb-6">{activeTab.name}</h3>
                <p className="text-gray-600 text-lg leading-relaxed mb-8">
                  {activeTab.description}
                </p>

                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(activeTab.specs).map(([key, value]) => (
                    <div key={key} className="bg-white p-4 rounded-2xl border border-emerald-100">
                      <p className="text-xs uppercase tracking-widest text-emerald-600 font-bold mb-1">
                        {key}
                      </p>
                      <p className="text-emerald-950 font-medium">{value}</p>
                    </div>
                  ))}
                </div>

                <button className="mt-10 px-8 py-4 bg-emerald-900 text-white font-bold rounded-xl hover:bg-emerald-800 transition-colors">
                  Request Quote for {activeTab.name}
                </button>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;
