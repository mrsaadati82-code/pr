import { motion } from 'framer-motion';

const OriginStory = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="md:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -top-10 -left-10 text-[12rem] font-bold text-emerald-50 leading-none z-0 select-none">
                100%
              </div>
              <div className="relative z-10">
                <h2 className="text-4xl font-bold text-emerald-950 mb-8">Why the World Prefers <br /><span className="text-emerald-600">Persian Origins</span></h2>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="shrink-0 w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-sm">1</div>
                    <div>
                      <h4 className="font-bold text-emerald-900 mb-2">Unmatched Flavor Profile</h4>
                      <p className="text-gray-600">The high oil content in Iranian pistachios allows them to be roasted at higher temperatures, intensifying the flavor.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="shrink-0 w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-sm">2</div>
                    <div>
                      <h4 className="font-bold text-emerald-900 mb-2">Higher Kernel Ratio</h4>
                      <p className="text-gray-600">Persian varieties typically offer a better weight-to-meat ratio compared to California varieties.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="shrink-0 w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-sm">3</div>
                    <div>
                      <h4 className="font-bold text-emerald-900 mb-2">Historical Heritage</h4>
                      <p className="text-gray-600">Centuries of cultivation expertise in the Kerman region results in a product of incomparable tradition.</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
          <div className="md:w-1/2 grid grid-cols-2 gap-4">
            <motion.img 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
              src="https://images.pexels.com/photos/5472184/pexels-photo-5472184.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400" 
              className="rounded-2xl shadow-lg mt-8" 
              alt="Pistachio detail"
            />
            <motion.img 
              initial={{ opacity: 0, y: -20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              viewport={{ once: true }}
              src="https://images.pexels.com/photos/20346554/pexels-photo-20346554.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=400" 
              className="rounded-2xl shadow-lg" 
              alt="Harvest"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default OriginStory;
