
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative h-screen w-full overflow-hidden flex items-center">
      {/* Background Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/hero-pistachio.jpg"
          alt="Premium Iranian Pistachios"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/90 via-emerald-900/60 to-transparent" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block py-1 px-4 rounded-full bg-emerald-800/50 backdrop-blur-sm text-emerald-200 text-xs font-bold uppercase tracking-[0.2em] mb-6">
              Export Quality Guaranteed
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-[1.1] mb-6">
              The Gold Standard of <span className="text-emerald-400">Iranian</span> Pistachios
            </h1>
            <p className="text-xl text-emerald-50/80 mb-10 max-w-xl leading-relaxed">
              Arasb Trading delivers the finest varieties of Persian nuts, sourced directly from the heart of Kerman, processed with precision for the global market.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold rounded-full flex items-center justify-center gap-2 transition-all"
              >
                View Collection <ArrowRight size={20} />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-transparent border border-white/30 hover:border-white text-white font-bold rounded-full backdrop-blur-sm transition-all"
              >
                Download Catalog
              </motion.button>
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] uppercase tracking-widest">Scroll to explore</span>
        <ChevronDown size={20} />
      </motion.div>
    </section>
  );
};

export default Hero;
