
import { motion } from 'framer-motion';
import { ShieldCheck, Zap, Award, Microscope } from 'lucide-react';

const QualitySpecs = () => {
  const features = [
    {
      icon: <ShieldCheck className="text-emerald-500" />,
      title: 'Aflatoxin Control',
      desc: 'Rigorous testing to meet EU and international food safety standards.'
    },
    {
      icon: <Microscope className="text-emerald-500" />,
      title: 'Precision Sorting',
      desc: 'Laser sorting and hand-picking to ensure consistent size and quality.'
    },
    {
      icon: <Zap className="text-emerald-500" />,
      title: 'Modern Processing',
      desc: 'Hygienic processing facilities with temperature-controlled storage.'
    },
    {
      icon: <Award className="text-emerald-500" />,
      title: 'Global Certifications',
      desc: 'Complying with ISO, HACCP, and regional import regulations.'
    }
  ];

  return (
    <section id="quality" className="py-24 bg-white relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-50 rounded-full blur-3xl -mr-48 -mt-48 opacity-50" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-50 rounded-full blur-3xl -ml-48 -mb-48 opacity-50" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-4xl font-bold text-emerald-950 mb-6">
              Quality That Exceeds <br /> Global Standards
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              At Arasb Trading, we don't just export pistachios; we export trust. Every shipment undergoes multiple stages of quality control, ensuring that only the finest kernels reach our clients.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-8">
              {features.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mb-4">
                    {f.icon}
                  </div>
                  <h4 className="font-bold text-emerald-900 mb-2">{f.title}</h4>
                  <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="lg:w-1/2 relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="rounded-3xl overflow-hidden shadow-2xl"
            >
              <img
                src="https://images.pexels.com/photos/11842170/pexels-photo-11842170.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600"
                alt="Quality Control"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-emerald-900/10 mix-blend-multiply" />
            </motion.div>
            
            {/* Stats Overlay */}
            <div className="absolute -bottom-10 -left-10 bg-emerald-900 text-white p-8 rounded-2xl shadow-xl hidden md:block">
              <div className="flex gap-12">
                <div>
                  <p className="text-3xl font-bold mb-1">99.8%</p>
                  <p className="text-xs uppercase tracking-widest text-emerald-400">Purity Rate</p>
                </div>
                <div>
                  <p className="text-3xl font-bold mb-1">50+</p>
                  <p className="text-xs uppercase tracking-widest text-emerald-400">Countries Served</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default QualitySpecs;
