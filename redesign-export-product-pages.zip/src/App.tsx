import Navbar from './components/Navbar';
import Hero from './components/Hero';
import OriginStory from './components/OriginStory';
import ProductShowcase from './components/ProductShowcase';
import QualitySpecs from './components/QualitySpecs';
import PackagingSection from './components/PackagingSection';
import ContactCTA from './components/ContactCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <OriginStory />
        <ProductShowcase />
        <QualitySpecs />
        <PackagingSection />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
}
