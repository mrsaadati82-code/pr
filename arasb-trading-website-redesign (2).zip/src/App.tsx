import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Expertise from './components/Expertise';
import Products from './components/Products';
import Services from './components/Services';
import Showcase from './components/Showcase';
import Process from './components/Process';
import Countries from './components/Countries';
import Commitment from './components/Commitment';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <main className="relative font-sans">
      <Navbar />
      <Hero />
      <Expertise />
      <Products />
      <Showcase />
      <Services />
      <Countries />
      <Process />
      <Commitment />
      <Contact />
      <Footer />
    </main>
  );
}

export default App;
