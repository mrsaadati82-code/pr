import { motion } from 'framer-motion';

const Showcase = () => {
  return (
    <section className="py-24 bg-slate-900 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-24">
          {/* Saffron Section */}
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:w-1/2"
            >
              <h3 className="text-amber-500 font-bold uppercase tracking-widest mb-4">The Red Gold</h3>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Authentic Persian <br />Saffron (Grade A)
              </h2>
              <p className="text-slate-400 text-lg mb-8 leading-relaxed">
                Known for its intense aroma and deep color, our saffron is hand-picked and tested for purity in international laboratories. We provide bulk supplies with complete certification for global distributors.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-2xl font-bold text-white">100%</p>
                  <p className="text-sm text-slate-500 uppercase tracking-tighter">Organic Purity</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">Saffron</p>
                  <p className="text-sm text-slate-500 uppercase tracking-tighter">Grade-A Quality</p>
                </div>
              </div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:w-1/2 relative"
            >
              <div className="relative z-10 rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
                <img src="/saffron.jpg" alt="Persian Saffron" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -top-10 -right-10 w-64 h-64 bg-amber-500/20 rounded-full blur-3xl z-0" />
            </motion.div>
          </div>

          {/* Pistachio Section */}
          <div className="flex flex-col lg:flex-row-reverse items-center gap-16">
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:w-1/2"
            >
              <h3 className="text-amber-500 font-bold uppercase tracking-widest mb-4">Nutritious Excellence</h3>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Premium Iranian <br />Pistachios
              </h2>
              <p className="text-slate-400 text-lg mb-8 leading-relaxed">
                Exporting variety of pistachio types including Akbari, Ahmad Aghaei, and Fandoghi. Processed in state-of-the-art facilities ensuring maximum freshness and health standards.
              </p>
              <ul className="space-y-4 text-slate-300 font-medium">
                <li className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Multiple grading sizes available
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Aflatoxin-tested & certified
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  Customized export packaging
                </li>
              </ul>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:w-1/2 relative"
            >
              <div className="relative z-10 rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
                <img src="/pistachios.jpg" alt="Iranian Pistachios" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-amber-500/20 rounded-full blur-3xl z-0" />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Showcase;
