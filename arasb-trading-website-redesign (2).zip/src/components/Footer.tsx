import { Globe, MessageSquare, Send, Share2 } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-50 pt-24 pb-12 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 lg:col-span-1">
            <span className="text-2xl font-bold tracking-tighter text-slate-900 mb-6 block">
              ARASB<span className="text-amber-600">TRADING</span>
            </span>
            <p className="text-slate-500 mb-8 leading-relaxed">
              Leading the way in Iranian exports. Providing premium quality products and professional logistics solutions to global markets.
            </p>
            <div className="flex gap-4">
              {[Globe, MessageSquare, Send, Share2].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-slate-200 flex items-center justify-center text-slate-400 hover:text-amber-600 hover:border-amber-600 transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'About Us', 'Products', 'Services', 'Contact'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-amber-600 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 mb-6">Products</h4>
            <ul className="space-y-4">
              {['Fresh Fruits', 'Dried Fruits', 'Spices', 'Petroleum', 'Petrochemicals'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-slate-500 hover:text-amber-600 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-widest text-slate-900 mb-6">Newsletter</h4>
            <p className="text-slate-500 mb-4 text-sm">Subscribe to receive updates on market trends and new products.</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="Your email"
                className="w-full px-4 py-3 rounded-xl bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              />
              <button className="absolute right-2 top-1.5 bg-slate-900 text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-slate-800">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-sm font-medium">
          <p>© 2026 Arasb Trading Company. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-slate-600">Privacy Policy</a>
            <a href="#" className="hover:text-slate-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
