import { motion } from 'framer-motion';

const products = [
  {
    title: 'Premium Pistachios',
    description: 'Selected Iranian pistachios with superior quality and compliant packaging.',
    image: '/pistachios.jpg',
    category: 'Dried Fruits'
  },
  {
    title: 'Exquisite Saffron',
    description: 'The world’s finest saffron threads, sourced from certified farms.',
    image: '/saffron.jpg',
    category: 'Spices'
  },
  {
    title: 'Natural Dates',
    description: 'Rich, caramel-like dates prepared for international distribution.',
    image: '/dates.jpg',
    category: 'Fresh Fruits'
  },
  {
    title: 'Petrochemicals',
    description: 'Essential materials for global manufacturing and energy industries.',
    image: '/petroleum.jpg',
    category: 'Industrial'
  }
];

const Products = () => {
  return (
    <section id="products" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-slate-900 mb-4"
          >
            Our Featured Products
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-slate-600 max-w-2xl mx-auto"
          >
            We supply a diverse range of premium Iranian products meeting the highest international export standards.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl bg-white shadow-md hover:shadow-xl transition-all duration-500"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent flex flex-col justify-end p-6">
                <span className="text-amber-400 text-xs font-bold uppercase tracking-widest mb-2">
                  {product.category}
                </span>
                <h3 className="text-white text-xl font-bold mb-2">{product.title}</h3>
                <p className="text-slate-300 text-sm line-clamp-2 transform translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  {product.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;
