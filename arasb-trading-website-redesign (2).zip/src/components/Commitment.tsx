import { motion } from 'framer-motion';
import { Shield, Target, Zap, HeartHandshake } from 'lucide-react';

const Commitment = () => {
  const values = [
    {
      icon: <Shield size={32} />,
      title: 'Reliability',
      desc: 'Transparent tracking and consistent communication throughout the export journey.'
    },
    {
      icon: <Target size={32} />,
      title: 'Precision',
      desc: 'Meticulous documentation and compliance management for hassle-free customs.'
    },
    {
      icon: <Zap size={32} />,
      title: 'Efficiency',
      desc: 'Optimized logistics routes and rapid processing for time-sensitive cargo.'
    },
    {
      icon: <HeartHandshake size={32} />,
      title: 'Partnership',
      desc: 'Long-term commitment to our clients success and growth in global markets.'
    }
  ];

  return (
    <section className="py-24 bg-amber-600 relative overflow-hidden">
      {/* Decorative patterns */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 w-40 h-40 border-4 border-white rounded-full" />
        <div className="absolute bottom-10 right-10 w-60 h-60 border-4 border-white rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Commitment to Excellence</h2>
          <p className="text-amber-100 max-w-2xl mx-auto">
            Driven by quality and trust, we redefine the export experience for our global partners.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((v, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="p-8 bg-white/10 backdrop-blur-md border border-white/20 rounded-[2rem] text-white"
            >
              <div className="mb-6 text-amber-200">{v.icon}</div>
              <h3 className="text-xl font-bold mb-3">{v.title}</h3>
              <p className="text-amber-50 text-sm leading-relaxed opacity-80">{v.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Commitment;
