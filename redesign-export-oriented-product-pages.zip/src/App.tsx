import React from 'react';
import { motion } from 'framer-motion';
import { Globe, ShieldCheck, Truck, Menu, X, ArrowRight, Star } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans selection:bg-red-500 selection:text-white">
      <Navbar />
      <Hero />
      <Stats />
      <Features />
      <Varieties />
      <Process />
      <Packaging />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );

function Process() {
  const steps = [
    { title: 'Orchard Selection', desc: 'Sourcing from high-altitude orchards with optimal climate.' },
    { title: 'Cold Storage', desc: 'Precision temperature control to maintain crispness.' },
    { title: 'Grading', desc: 'Advanced sorting by size, color, and weight.' },
    { title: 'Logistics', desc: 'Door-to-door delivery with full tracking.' }
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-red-600 font-semibold tracking-wider uppercase mb-4">Farm to Port</h2>
          <p className="text-4xl lg:text-5xl font-bold text-gray-900">Our Seamless Process</p>
        </div>
        
        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, idx) => (
            <div key={idx} className="relative">
              {idx < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-red-100 -z-10"></div>
              )}
              <div className="bg-white border-2 border-red-50 p-8 rounded-2xl hover:border-red-600 transition-colors group">
                <div className="w-12 h-12 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-xl mb-6 group-hover:scale-110 transition-transform">
                  {idx + 1}
                </div>
                <h4 className="text-xl font-bold mb-3">{step.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
}

function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-2">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <span className="text-xl font-bold tracking-tight text-gray-900">ARASB <span className="text-red-600">TRADING</span></span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-600 hover:text-red-600 transition-colors">Home</a>
            <a href="#varieties" className="text-gray-600 hover:text-red-600 transition-colors">Varieties</a>
            <a href="#packaging" className="text-gray-600 hover:text-red-600 transition-colors">Packaging</a>
            <a href="#about" className="text-gray-600 hover:text-red-600 transition-colors">About</a>
            <button className="bg-red-600 text-white px-6 py-2.5 rounded-full font-medium hover:bg-red-700 transition-all transform hover:scale-105 active:scale-95">
              Contact Us
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600">
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-white border-b border-gray-100 px-4 py-6 space-y-4"
        >
          <a href="#" className="block text-lg font-medium text-gray-900">Home</a>
          <a href="#varieties" className="block text-lg font-medium text-gray-900">Varieties</a>
          <a href="#packaging" className="block text-lg font-medium text-gray-900">Packaging</a>
          <a href="#about" className="block text-lg font-medium text-gray-900">About</a>
          <button className="w-full bg-red-600 text-white px-6 py-3 rounded-xl font-medium">Contact Us</button>
        </motion.div>
      )}
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 bg-red-50 text-red-700 px-4 py-2 rounded-full text-sm font-bold mb-6">
              <span className="flex h-2 w-2 rounded-full bg-red-600 animate-pulse"></span>
              PREMIUM PERSIAN EXPORT QUALITY
            </div>
            <h1 className="text-5xl lg:text-7xl font-extrabold text-gray-900 leading-[1.1] mb-6">
              The Heart of <br />
              <span className="text-red-600">Nature's Crunch</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed max-w-lg">
              Experience the exceptional flavor, crisp texture, and vibrant color of premium Iranian apples. Direct from the finest orchards to global markets.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-gray-900 text-white px-8 py-4 rounded-full text-lg font-semibold flex items-center justify-center gap-2 hover:bg-gray-800 transition-all group">
                Explore Products
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border-2 border-gray-200 text-gray-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-50 transition-all">
                Download Catalog
              </button>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="mt-16 lg:mt-0 relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-700">
              <img 
                src="/hero-apple.jpg" 
                alt="Premium Apples" 
                className="w-full h-[500px] object-cover"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-red-100 rounded-full mix-blend-multiply filter blur-2xl opacity-70 animate-blob"></div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-green-100 rounded-full mix-blend-multiply filter blur-2xl opacity-70 animate-blob animation-delay-2000"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const stats = [
    { label: 'Export Destinations', value: '30+' },
    { label: 'Annual Production', value: '50k Tons' },
    { label: 'Quality Standards', value: 'ISO 9001' },
    { label: 'Global Partners', value: '150+' },
  ];

  return (
    <section className="bg-white py-20 border-y border-gray-100 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#dc2626 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="flex flex-col items-center"
            >
              <div className="text-4xl lg:text-5xl font-black text-gray-900 mb-2 tracking-tighter">
                {stat.value}
              </div>
              <div className="h-1 w-12 bg-red-600 mb-4"></div>
              <div className="text-gray-500 font-bold uppercase tracking-widest text-xs">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    {
      title: 'Global Export Grade',
      desc: 'Rigorous international quality standards met for Middle East, Europe, and Asia.',
      icon: <Globe className="w-8 h-8 text-red-600" />
    },
    {
      title: 'Premium Quality',
      desc: 'Carefully selected, graded, and packed to satisfy demanding wholesalers.',
      icon: <ShieldCheck className="w-8 h-8 text-red-600" />
    },
    {
      title: 'Cold Chain Logistics',
      desc: 'Advanced storage solutions ensuring freshness year-round during transit.',
      icon: <Truck className="w-8 h-8 text-red-600" />
    }
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-red-600 font-semibold tracking-wider uppercase mb-4">Why Arasb Trading</h2>
          <p className="text-4xl lg:text-5xl font-bold text-gray-900">Excellence in Every Harvest</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-12 text-center">
          {features.map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="group p-8 rounded-2xl border border-gray-100 hover:border-red-100 hover:shadow-xl hover:shadow-red-500/5 transition-all duration-300"
            >
              <div className="mb-6 inline-block p-4 bg-red-50 rounded-xl group-hover:bg-red-600 group-hover:text-white transition-colors duration-300">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Varieties() {
  const varieties = [
    { name: 'Red Delicious', color: 'Deep Red', taste: 'Sweet & Crunchy', img: '/hero-apple.jpg' },
    { name: 'Golden Delicious', color: 'Bright Yellow', taste: 'Mild & Mellow', img: '/apple-varieties.jpg' },
    { name: 'Granny Smith', color: 'Vibrant Green', taste: 'Tart & Crisp', img: '/apple-varieties.jpg' },
  ];

  return (
    <section id="varieties" className="py-24 bg-gray-900 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 gap-8">
          <div>
            <h2 className="text-red-500 font-semibold tracking-wider uppercase mb-4">Our Selection</h2>
            <p className="text-4xl lg:text-5xl font-bold">Premium Apple Varieties</p>
          </div>
          <p className="text-gray-400 max-w-md lg:text-right">
            Grown in the fertile orchards of Iran, each variety offers a unique flavor profile and crispness for discerning markets.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {varieties.map((item, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -10 }}
              className="relative group rounded-3xl overflow-hidden aspect-[4/5]"
            >
              <img 
                src={item.img} 
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60"
                alt={item.name}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/20 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-8 w-full">
                <div className="text-red-500 font-bold mb-2">{item.color}</div>
                <h3 className="text-3xl font-bold mb-2">{item.name}</h3>
                <p className="text-gray-300 mb-6">{item.taste}</p>
                <button className="flex items-center gap-2 text-white font-semibold hover:text-red-500 transition-colors">
                  Details <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Packaging() {
  return (
    <section id="packaging" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-24 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <div className="relative">
              <img 
                src="/apple-packaging.jpg" 
                alt="Export Packaging" 
                className="rounded-3xl shadow-2xl relative z-10"
              />
              <div className="absolute -top-6 -left-6 bg-red-600 text-white p-6 rounded-2xl shadow-xl z-20">
                <p className="text-3xl font-bold">100%</p>
                <p className="text-sm">Export Grade</p>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2 mt-12 lg:mt-0"
          >
            <h2 className="text-red-600 font-semibold tracking-wider uppercase mb-4">Logistics & Handling</h2>
            <h3 className="text-4xl lg:text-5xl font-bold mb-8">Export Packaging Solutions</h3>
            <div className="space-y-6">
              {[
                { title: 'Custom Sizing', desc: 'Precise grading based on weight and diameter to match your market needs.' },
                { title: 'Eco-Friendly Options', desc: 'Sustainable cardboard and paper tray options available.' },
                { title: 'Cold-Chain Ready', desc: 'Designed for optimal ventilation and protection during long-distance transit.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="mt-1 w-6 h-6 rounded-full bg-red-50 flex-shrink-0 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-red-600"></div>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-1">{item.title}</h4>
                    <p className="text-gray-600">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">Trusted by Global Partners</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          {[
            { quote: "The consistency in quality and sizing of Arasb apples has made them our preferred supplier for three years.", author: "Marcus Thompson", role: "Wholesale Manager, UAE" },
            { quote: "Outstanding logistics support. Even with tight deadlines, they ensure the fruit arrives crisp and fresh.", author: "Elena Rossi", role: "Retail Director, Italy" }
          ].map((t, i) => (
            <div key={i} className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100">
              <div className="flex gap-1 mb-6 text-yellow-400">
                {[...Array(5)].map((_, j) => <Star key={j} fill="currentColor" size={20} />)}
              </div>
              <p className="text-xl italic text-gray-700 mb-6">"{t.quote}"</p>
              <div>
                <p className="font-bold text-gray-900">{t.author}</p>
                <p className="text-gray-500 text-sm">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section className="py-24 bg-red-600 text-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-red-500 rounded-full translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-red-700 rounded-full -translate-x-1/2 translate-y-1/2"></div>
      
      <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
        <h2 className="text-4xl lg:text-6xl font-extrabold mb-8 leading-tight">Ready to Partner with the Best?</h2>
        <p className="text-xl text-red-100 mb-12 max-w-2xl mx-auto">
          Contact us today for custom quotes, technical specifications, and export availability for your region.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-white text-red-600 px-10 py-5 rounded-full text-xl font-bold hover:bg-gray-100 transition-all transform hover:scale-105">
            Request a Quote
          </button>
          <button className="bg-red-700 text-white border-2 border-red-500 px-10 py-5 rounded-full text-xl font-bold hover:bg-red-800 transition-all">
            WhatsApp Us
          </button>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-gray-950 text-gray-400 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2 mb-6 text-white">
              <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center font-bold">A</div>
              <span className="text-xl font-bold">ARASB TRADING</span>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              Delivering the authentic taste of Iran to tables around the world. Premium agricultural exports since 2010.
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Products</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Apples</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Pistachios</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Saffron</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Dates</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Company</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Certifications</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Sustainability</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Newsletter</h4>
            <p className="text-sm mb-4">Get the latest export market insights.</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Email" className="bg-gray-900 border border-gray-800 rounded-lg px-4 py-2 w-full text-sm outline-none focus:border-red-600" />
              <button className="bg-red-600 text-white p-2 rounded-lg"><ArrowRight size={18} /></button>
            </div>
          </div>
        </div>
        <div className="pt-8 border-t border-gray-900 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
          <p>© 2025 Arasb Trading Company. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
