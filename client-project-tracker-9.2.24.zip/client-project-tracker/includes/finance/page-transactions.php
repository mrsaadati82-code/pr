<?php
if (!defined('ABSPATH')) exit;

function cpttf_tx_person_options($selected = 0){
	$selected = (int)$selected;
	$users = get_users([
		'role__in' => ['customer','subscriber','cptt_expert','administrator'],
		'orderby' => 'display_name',
		'order' => 'ASC',
		'number' => 500,
	]);
	$opts = '<option value="0">— بدون شخص —</option>';
	foreach ($users as $u) {
		$roles = (array)$u->roles;
		$tag = in_array('cptt_expert', $roles, true) ? 'کارشناس' : (in_array('administrator', $roles, true) ? 'مدیر' : 'مشتری/شخص');
		$phone = (string)get_user_meta($u->ID, 'billing_phone', true);
		if ($phone === '') $phone = (string)get_user_meta($u->ID, 'cptt_phone', true);
		if ($phone === '') $phone = (string)get_user_meta($u->ID, 'mobile', true);
		$label = $u->display_name . ' · ' . $tag . ($phone ? (' · ' . $phone) : '');
		$opts .= '<option value="'.(int)$u->ID.'" '.selected($selected, (int)$u->ID, false).'>'.esc_html($label).'</option>';
	}
	return $opts;
}

/**
 * Transactions / Vouchers page — v9.2.20
 * - Shows income + expense + expert_payout as receipt/payment documents
 * - Working filters + search
 * - Reverse document action
 */
function cpttf_render_transactions(){
	global $wpdb;
	$cur = 'ریال';
	$accounts = CPTT_Finance::get_accounts(true);
	$cats_in  = CPTT_Finance::get_categories('income');
	$cats_out = CPTT_Finance::get_categories('expense');

	// Filters
	$f_type    = isset($_GET['ftype'])   ? sanitize_key($_GET['ftype']) : '';
	$f_account = isset($_GET['facc'])    ? (int)$_GET['facc'] : 0;
	$f_cat     = isset($_GET['fcat'])    ? (int)$_GET['fcat'] : 0;
	$f_from    = isset($_GET['ffrom'])   ? sanitize_text_field($_GET['ffrom']) : '';
	$f_to      = isset($_GET['fto'])     ? sanitize_text_field($_GET['fto'])   : '';
	$f_q       = isset($_GET['fq'])      ? sanitize_text_field($_GET['fq'])    : '';
	$f_status  = isset($_GET['fstatus']) ? sanitize_key($_GET['fstatus']) : '';

	// Include expert payouts as payment documents
	$where = ["type IN ('income','expense','expert_payout')"]; $params = [];
	if ($f_type === 'income' || $f_type === 'receipt') {
		$where[] = "type = 'income'";
	} elseif ($f_type === 'expense') {
		$where[] = "type = 'expense'";
	} elseif ($f_type === 'payment' || $f_type === 'expert_payout') {
		$where[] = "type IN ('expense','expert_payout')";
	} elseif ($f_type === 'expert_only') {
		$where[] = "type = 'expert_payout'";
	}
	if ($f_account) { $where[] = 'account_id=%d'; $params[] = $f_account; }
	if ($f_cat)     { $where[] = 'category_id=%d'; $params[] = $f_cat; }
	if ($f_from)    { $where[] = 'date_at >= %d'; $params[] = CPTT_Finance::parse_jalali_local($f_from); }
	if ($f_to)      { $where[] = 'date_at <= %d'; $params[] = CPTT_Finance::parse_jalali_local($f_to . ' 23:59'); }
	if ($f_status === 'posted' || $f_status === 'reversed' || $f_status === 'reversal') {
		// status column may not exist on very old DBs — still safe after upgrade
		$where[] = 'status=%s'; $params[] = $f_status;
	} elseif ($f_status === 'active') {
		$where[] = "(status IS NULL OR status='' OR status='posted')";
	}
	if ($f_q !== '') {
		$like = '%' . $wpdb->esc_like($f_q) . '%';
		$where[] = '(description LIKE %s OR voucher_no LIKE %s OR CAST(id AS CHAR) LIKE %s)';
		$params[] = $like; $params[] = $like; $params[] = $like;
	}

	$sql = "SELECT * FROM " . CPTT_Finance::tbl_ledger() . " WHERE " . implode(' AND ', $where) . " ORDER BY date_at DESC, id DESC LIMIT 500";
	$rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);
	if ($rows === null || $wpdb->last_error) {
		// Fallback for pre-upgrade DBs missing voucher/status columns
		$where2 = ["type IN ('income','expense','expert_payout')"]; $params2 = [];
		if ($f_type === 'income' || $f_type === 'receipt') { $where2[] = "type='income'"; }
		elseif ($f_type === 'expense') { $where2[] = "type='expense'"; }
		elseif (in_array($f_type, ['payment','expert_payout'], true)) { $where2[] = "type IN ('expense','expert_payout')"; }
		elseif ($f_type === 'expert_only') { $where2[] = "type='expert_payout'"; }
		if ($f_account) { $where2[] = 'account_id=%d'; $params2[] = $f_account; }
		if ($f_cat) { $where2[] = 'category_id=%d'; $params2[] = $f_cat; }
		if ($f_from) { $where2[] = 'date_at >= %d'; $params2[] = CPTT_Finance::parse_jalali_local($f_from); }
		if ($f_to) { $where2[] = 'date_at <= %d'; $params2[] = CPTT_Finance::parse_jalali_local($f_to . ' 23:59'); }
		if ($f_q !== '') { $like = '%' . $wpdb->esc_like($f_q) . '%'; $where2[]='description LIKE %s'; $params2[]=$like; }
		$sql2 = "SELECT * FROM " . CPTT_Finance::tbl_ledger() . " WHERE " . implode(' AND ', $where2) . " ORDER BY date_at DESC, id DESC LIMIT 500";
		$rows = $params2 ? $wpdb->get_results($wpdb->prepare($sql2, $params2)) : $wpdb->get_results($sql2);
	}
	if (!is_array($rows)) $rows = [];

	// Totals (matching filter) — count direction so reversals cancel
	$sum_in = 0; $sum_out = 0;
	foreach ($rows as $r) {
		$amt = (float)$r->amount;
		$dir = isset($r->direction) ? (int)$r->direction : (($r->type === 'income') ? 1 : -1);
		if ($dir > 0) $sum_in += $amt; else $sum_out += $amt;
	}

	$new_mode = isset($_GET['new']) ? sanitize_key($_GET['new']) : '';
	$pre_project = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;
	?>
	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--3">
		<div class="cpttf-kpi" style="--c:#16a34a">
			<div class="cpttf-kpi__icon">📥</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع اسناد دریافتی</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_in); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">در محدوده فیلتر</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#ef4444">
			<div class="cpttf-kpi__icon">📤</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">جمع اسناد پرداختی</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_out); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">هزینه + تسویه کارشناس</small></div>
		</div>
		<div class="cpttf-kpi" style="--c:#06b6d4">
			<div class="cpttf-kpi__icon">📊</div>
			<div class="cpttf-kpi__body"><span class="cpttf-kpi__label">خالص</span>
				<strong class="cpttf-kpi__value"><?php echo CPTT_Finance::fmt($sum_in - $sum_out); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">دریافتی − پرداختی</small></div>
		</div>
	</div>

	<section class="cpttf-card">
		<header class="cpttf-card__head cpttf-card__head--actions">
			<div>
				<h2>📄 اسناد دریافتی و پرداختی</h2>
				<small style="color:#64748b;font-size:12px;">درآمد = سند دریافتی · هزینه/تسویه کارشناس = سند پرداختی · امکان برگشت سند</small>
			</div>
			<div class="cpttf-card__actions">
				<button class="cpttf-btn cpttf-btn--primary" data-cpttf-tx="income">+ سند دریافتی</button>
				<button class="cpttf-btn cpttf-btn--danger" data-cpttf-tx="expense">+ سند پرداختی</button>
			</div>
		</header>
		<div class="cpttf-card__body">
			<form class="cpttf-filters" method="get" action="">
				<input type="hidden" name="page" value="cptt-finance-transactions">
				<label><span>جستجو</span>
					<input type="search" name="fq" value="<?php echo esc_attr($f_q); ?>" placeholder="شماره سند، توضیح، شناسه…">
				</label>
				<label><span>نوع سند</span>
					<select name="ftype">
						<option value="">همه</option>
						<option value="receipt" <?php selected($f_type,'receipt'); ?>>📥 دریافتی</option>
						<option value="payment" <?php selected(in_array($f_type,['payment','expense'],true)); ?>>📤 پرداختی (همه)</option>
						<option value="income"  <?php selected($f_type,'income');  ?>>فقط درآمد</option>
						<option value="expense" <?php selected($f_type,'expense'); ?>>فقط هزینه دستی</option>
						<option value="expert_only" <?php selected($f_type,'expert_only'); ?>>فقط تسویه کارشناس</option>
					</select>
				</label>
				<label><span>وضعیت</span>
					<select name="fstatus">
						<option value="">همه</option>
						<option value="active" <?php selected($f_status,'active'); ?>>فعال (posted)</option>
						<option value="posted" <?php selected($f_status,'posted'); ?>>posted</option>
						<option value="reversed" <?php selected($f_status,'reversed'); ?>>برگشت‌خورده</option>
						<option value="reversal" <?php selected($f_status,'reversal'); ?>>سند برگشت</option>
					</select>
				</label>
				<label><span>حساب</span>
					<select name="facc"><option value="0">همه</option>
						<?php foreach ($accounts as $a): ?><option value="<?php echo (int)$a->id; ?>" <?php selected($f_account, $a->id); ?>><?php echo esc_html($a->icon . ' ' . $a->name); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label><span>دسته</span>
					<select name="fcat"><option value="0">همه</option>
						<?php foreach (array_merge($cats_in, $cats_out) as $c): ?><option value="<?php echo (int)$c->id; ?>" <?php selected($f_cat, $c->id); ?>><?php echo esc_html($c->icon . ' ' . $c->name); ?></option><?php endforeach; ?>
					</select>
				</label>
				<label><span>از تاریخ</span><input type="text" class="cpttf-jdate" name="ffrom" value="<?php echo esc_attr($f_from); ?>" placeholder="۱۴۰۳/۰۱/۰۱" autocomplete="off"></label>
				<label><span>تا تاریخ</span><input type="text" class="cpttf-jdate" name="fto"   value="<?php echo esc_attr($f_to); ?>"   placeholder="۱۴۰۳/۱۲/۲۹" autocomplete="off"></label>
				<div class="cpttf-filters__actions">
					<button type="submit" class="cpttf-btn cpttf-btn--primary">اعمال فیلتر</button>
					<a class="cpttf-btn cpttf-btn--ghost" href="<?php echo esc_url(admin_url('admin.php?page=cptt-finance-transactions')); ?>">↺ پاک‌کردن</a>
				</div>
			</form>

			<div class="cpttf-table-wrap" style="margin-top:12px;">
				<table class="cpttf-table">
					<thead>
						<tr>
							<th>شماره سند</th>
							<th>تاریخ</th>
							<th>نوع سند</th>
							<th>حساب</th>
							<th>طرف حساب / توضیح</th>
							<th>واریز</th>
							<th>برداشت</th>
							<th>وضعیت</th>
							<th style="width:150px">عملیات</th>
						</tr>
					</thead>
					<tbody>
					<?php if (empty($rows)): ?>
						<tr><td colspan="9" class="cpttf-empty">هیچ سندی در این محدوده ثبت نشده.</td></tr>
					<?php else: foreach ($rows as $r):
						$acc = CPTT_Finance::get_account($r->account_id);
						$cat = $r->category_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CPTT_Finance::tbl_categories() . " WHERE id=%d", $r->category_id)) : null;
						$dir = isset($r->direction) ? (int)$r->direction : (($r->type === 'income') ? 1 : -1);
						$is_in = $dir > 0;
						$status = (string)($r->status ?? 'posted');
						if ($status === '') $status = 'posted';
						$vno = (string)($r->voucher_no ?? '');
						if ($vno === '') $vno = '#' . (int)$r->id;
						$vlabel = class_exists('CPTT_Finance') ? CPTT_Finance::voucher_label($r) : $r->type;
						$party = '';
						if (!empty($r->expert_id)) {
							$eu = get_user_by('id', (int)$r->expert_id);
							if ($eu) $party = '👤 ' . $eu->display_name;
						} elseif (!empty($r->customer_id)) {
							$cu = get_user_by('id', (int)$r->customer_id);
							if ($cu) $party = '👥 ' . $cu->display_name;
						}
						if (!empty($r->project_id)) {
							$pt = get_the_title((int)$r->project_id);
							if ($pt) $party = trim($party . ($party ? ' · ' : '') . '📁 ' . $pt);
						}
						$can_reverse = ($status === 'posted' || $status === '');
						$status_chip = [
							'posted' => '<span class="cpttf-chip cpttf-chip--in">فعال</span>',
							'reversed' => '<span class="cpttf-chip cpttf-chip--muted">برگشت‌خورده</span>',
							'reversal' => '<span class="cpttf-chip cpttf-chip--warn">سند برگشت</span>',
						];
					?>
						<tr class="<?php echo $status === 'reversed' ? 'is-reversed' : ($status === 'reversal' ? 'is-reversal' : ''); ?>">
							<td><b style="font-family:ui-monospace,monospace;"><?php echo esc_html($vno); ?></b></td>
							<td><?php echo esc_html($r->date_fa); ?></td>
							<td>
								<?php if ($is_in): ?>
									<span class="cpttf-chip cpttf-chip--in"><?php echo esc_html($vlabel); ?></span>
								<?php else: ?>
									<span class="cpttf-chip cpttf-chip--out"><?php echo esc_html($vlabel); ?></span>
								<?php endif; ?>
								<?php if ($cat): ?><div style="margin-top:4px;"><span class="cpttf-tag" style="background:<?php echo esc_attr($cat->color); ?>22;color:<?php echo esc_attr($cat->color); ?>"><?php echo esc_html($cat->icon . ' ' . $cat->name); ?></span></div><?php endif; ?>
							</td>
							<td><?php echo $acc ? esc_html($acc->icon . ' ' . $acc->name) : '—'; ?></td>
							<td>
								<?php if ($party): ?><div style="font-size:12px;font-weight:800;color:#0f172a;"><?php echo esc_html($party); ?></div><?php endif; ?>
								<div style="font-size:12px;color:#64748b;"><?php echo esc_html(wp_trim_words($r->description, 16, '...')); ?></div>
							</td>
							<td class="cpttf-text-success"><?php echo $is_in ? '<b>' . CPTT_Finance::fmt($r->amount) . '</b>' : '—'; ?></td>
							<td class="cpttf-text-danger"><?php echo !$is_in ? '<b>' . CPTT_Finance::fmt($r->amount) . '</b>' : '—'; ?></td>
							<td><?php echo $status_chip[$status] ?? esc_html($status); ?></td>
							<td>
								<div style="display:flex;gap:6px;flex-wrap:wrap;">
									<?php if ($can_reverse): ?>
										<button type="button" class="cpttf-btn cpttf-btn--sm cpttf-btn--warn" data-cpttf-tx-reverse="<?php echo (int)$r->id; ?>" data-voucher="<?php echo esc_attr($vno); ?>">برگشت سند</button>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endforeach; endif; ?>
					</tbody>
				</table>
			</div>
		</div>
	</section>

	<?php // ─── Modal template ─── ?>
	<div class="cpttf-modal" id="cpttf-tx-modal" hidden>
		<div class="cpttf-modal__backdrop" data-cpttf-close></div>
		<div class="cpttf-modal__dialog">
			<header class="cpttf-modal__head">
				<h3 id="cpttf-tx-modal-title">ثبت سند</h3>
				<button class="cpttf-modal__close" data-cpttf-close>×</button>
			</header>
			<form id="cpttf-tx-form" class="cpttf-modal__body">
				<input type="hidden" name="tx_type" id="cpttf-tx-type" value="income">
				<input type="hidden" name="id" value="0">
				<input type="hidden" name="project_id" value="<?php echo (int)$pre_project; ?>">
				<div class="cpttf-form-grid">
					<label><span>تاریخ</span><input type="text" name="date_local" class="cpttf-jdate" placeholder="۱۴۰۳/۰۱/۰۱ ۱۲:۰۰" autocomplete="off"></label>
					<label><span>حساب</span>
						<select name="account_id" required>
							<?php foreach ($accounts as $a): ?><option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option><?php endforeach; ?>
						</select>
					</label>
					<label><span>مبلغ (<?php echo esc_html($cur); ?>)</span><input type="text" inputmode="numeric" name="amount" class="cpttf-money" required></label>
					<label><span>دسته</span>
						<select name="category_id" id="cpttf-tx-cat">
							<option value="0">— بدون دسته —</option>
							<optgroup label="دریافتی / درآمد" data-tx="income">
								<?php foreach ($cats_in as $c): ?><option value="<?php echo (int)$c->id; ?>"><?php echo esc_html($c->icon . ' ' . $c->name); ?></option><?php endforeach; ?>
							</optgroup>
							<optgroup label="پرداختی / هزینه" data-tx="expense">
								<?php foreach ($cats_out as $c): ?><option value="<?php echo (int)$c->id; ?>"><?php echo esc_html($c->icon . ' ' . $c->name); ?></option><?php endforeach; ?>
							</optgroup>
						</select>
					</label>
					<label class="cpttf-full"><span>مشتری / شخص</span>
						<select name="person_id" id="cpttf-tx-person">
							<?php echo cpttf_tx_person_options(0); ?>
						</select>
						<small style="color:#94a3b8;font-size:11px;display:block;margin-top:4px;">برای مشتری در `customer_id` و برای کارشناس در `expert_id` ذخیره می‌شود.</small>
					</label>
					<label class="cpttf-full"><span>توضیحات</span><textarea name="description" rows="2"></textarea></label>
				</div>
			</form>
			<footer class="cpttf-modal__foot">
				<button class="cpttf-btn cpttf-btn--ghost" data-cpttf-close>انصراف</button>
				<button class="cpttf-btn cpttf-btn--primary" data-cpttf-submit="tx">ثبت سند</button>
			</footer>
		</div>
	</div>

	<?php if ($new_mode === 'income' || $new_mode === 'expense'): ?>
	<script>document.addEventListener('DOMContentLoaded', function(){ window.cpttfOpenTx && cpttfOpenTx(<?php echo wp_json_encode($new_mode); ?>); });</script>
	<?php endif; ?>
	<?php
}
