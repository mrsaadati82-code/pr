# WAVE_2_IMPLEMENTATION_NOTES

> نسخه: 8.2.0

---

# چیزهایی که در این Wave هدف گرفته شدند

## 1) مطالبات پروژه از voucher truth

### مشکل
برگشت سند در سند حسابداری ثبت می‌شد، ولی مانده مالی پروژه تغییر نمی‌کرد.

### علت
بخش‌های project مالی هنوز از `_cptt_steps` و منطق عملیاتی زیاد می‌خواندند.

### اصلاح
- `build_receivables()` به snapshot حسابداری پروژه نزدیک‌تر شد
- `build_projects_full()` summaryهای اصلی را از مسیر accounting snapshot می‌گیرد
- دریافت و برگشت دریافتی حالا باید روی مانده پروژه اثر بگذارد

---

## 2) KPIهای ERP از source رسمی‌تر

### مشکل
KPI درآمد و بخشی از dashboard هنوز از mixed-sourceها می‌آمدند.

### اصلاح
برای ERP bootstrap:
- `compute_accounting_kpis()` اضافه شد
- `monthly_series_accounting()` اضافه شد
- `top_customers_accounting()` اضافه شد
- `category_breakdown_accounting()` اضافه شد

و bootstrapهای ERP به این sourceهای جدید وصل شدند.

---

## 3) backfillهای تاریخی در نسخه جدید دوباره اجرا می‌شوند

### علت
با bump نسخه به 8.2.0، syncهای تاریخی version-based دوباره اجرا می‌شوند.

### نتیجه
- historical voucher coverage دوباره بررسی می‌شود
- اگر expense/income تاریخی مسیر رسمی لازم داشته باشند، شانس دیده‌شدن‌شان بیشتر می‌شود

---

## 4) sourceTypeها مشخص‌تر شدند

### اصلاح
بعضی voucherهای عملیاتی sourceType دقیق‌تری گرفتند، مثل:
- `project_quick_pay`
- `expert_payout`
- `expert_manual_payout`
- `installment_receipt`
- `payable_payment`
- `legacy_fin_ledger`
- `legacy_core_ledger`

### هدف
ردیابی و dedupe بهتر در Waveهای بعدی

---

## 5) این Wave چه چیزی را عمداً کامل نمی‌کند؟

- حذف کامل legacy logic
- cutover نهایی همه reportها
- decommission کامل pageهای legacy
- final hardening

این‌ها در Waveهای بعدی ادامه پیدا می‌کنند.

---

**پایان یادداشت Wave 2**
