# PHASE_8_REPORT

> Phase 8 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`, `PHASE_7_REPORT.md`  
> Additional binding decisions: user-final decisions for Phase 7 ambiguities in current conversation  
> Mode: **No code change / No schema change in this turn / Report Cutover Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۸ را به‌صورت گزارش و برنامه‌ی Cutover اجرا کرده‌ام و هیچ کدی را تغییر نداده‌ام.**

یعنی الان:
- هیچ endpointی عوض نشده
- هیچ feature flagی پیاده‌سازی نشده
- هیچ source گزارشی سوییچ نشده
- هیچ UIای تغییر نکرده
- هیچ صفحه‌ای redirect نشده

## 0.2 اما اجرای واقعی این فاز چه می‌خواهد؟

اجرای واقعی Phase 8 حتماً نیاز دارد به:
- تغییر کد backend
- تغییر بعضی contractهای API
- اضافه‌کردن feature flagها
- تغییر source گزارش‌های ERP
- read-only کردن صفحه‌های قدیمی
- تست staging و مقایسه‌ی old/new

### نتیجه عملی
**اجرای واقعی Phase 8 فقط باید روی staging و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 8 — Report Cutover Plan** است و فقط روی این موارد تمرکز دارد:

1. تعیین ترتیب **Cutover گزارش‌ها**
2. طراحی **Backward-Compatible API Responses** در دوره‌ی گذار
3. تعیین **Feature Flag Strategy** برای هر خانواده گزارش
4. تعیین **Acceptance Criteria** برای هر گزارش
5. تعیین **Parallel-Run Strategy** برای مقایسه‌ی قدیم/جدید
6. هم‌راستا کردن Cutover با این تصمیم قطعی که **UI هدف همان پنل حسابداری ERP** است
7. تعیین رفتار صفحه‌های قدیمی در دوره‌ی گذار
8. اعمال تصمیم‌های نهایی کاربر روی ابهام‌های فاز ۷
9. ثبت **Ambiguity Register فاز ۸** برای تصمیم‌گیری قبل از فاز بعد

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) تصمیم‌های قطعی جدید که در Phase 8 لازم‌الاجرا هستند

این تصمیم‌ها از همین لحظه برای طراحی Cutover **binding** هستند.

## 2.1 داده‌های low-confidence
- فقط **archive-only**
- وارد accounting truth جدید نمی‌شوند
- report source رسمی را تغییر نمی‌دهند

## 2.2 جلوگیری از ثبت دوتایی
- deduplication بر اساس:
  - `sourceType + sourceId`

## 2.3 سقف اختلاف مجاز
- **صفر**
- مخصوصاً در گزارش‌های حسابداری رسمی:
  - بدهکار = بستانکار دقیق
  - variance قابل قبول = صفر

## 2.4 فیلدهای مالی `_cptt_steps`
- فقط **پولِ واقعاً جابه‌جا شده** candidate سند حسابداری است
- اعداد صرفاً عملیاتی / برنامه‌ای نباید خودکار وارد voucher truth شوند

## 2.5 جدول‌های اطلاعات پایه
- migration آن‌ها باید **همزمان** انجام شود
- این یعنی Cutover گزارش‌ها بدون readiness داده‌های پایه مجاز نیست

## 2.6 زمان قطع نوشتن جدول‌های قدیمی
- بعد از **Checkpoint 6**

## 2.7 فرم پرداخت مشتری
- در این مهاجرت blocker نیست
- چون محیط فعلی لوکال است

## 2.8 تسویه‌های ناقص قدیمی
- فقط به اندازه‌ی **مبلغ واقعاً پرداختی** map می‌شوند

## 2.9 صفحه‌های قدیمی در تست
- **read-only** می‌مانند
- و باید برچسب واضح **«قدیمی»** داشته باشند

---

# 3) اصل بنیادین Phase 8

## 3.1 هدف Cutover چیست؟

Cutover یعنی اینکه گزارش‌ها کم‌کم از منبع‌های قدیمی/مخلوط جدا شوند و فقط از sourceهای رسمی جدید تغذیه شوند.

## 3.2 هدف Cutover چیست نیست؟

این فاز قرار نیست:
- UI ERP را redesign کند
- دوباره سیستم legacy را تقویت کند
- logic مالی را در frontend نگه دارد

## 3.3 اصل نهایی این فاز

```text
Target UI = ERP Accounting Panel
Target Sources = Voucher / Journal / GL / TB / Official Read Models
Legacy Pages = Temporary Read-Only Compatibility Surfaces
```

---

# 4) محدوده‌ی UI و گزارش‌ها در Phase 8

## 4.1 UI هدف

طبق تصمیم صریح کاربر:
- **رابط کاربری هدف همان پنل حسابداری ERP است**
- یعنی مسیر اصلی و canonical این است:
  - `wp-admin/admin.php?page=cptt-finance-erp`

## 4.2 معنای این تصمیم برای Cutover

یعنی Cutover باید این صفحات/بخش‌ها را هدف بگیرد:
- Documents
- Journal
- General Ledger
- Subsidiary Ledger
- Trial Balance
- Income Statement
- Balance Sheet
- Dashboard KPIs

## 4.3 وضعیت صفحه‌های قدیمی

در دوره‌ی تست و گذار:
- read-only
- با برچسب واضح `قدیمی`
- نه صاحب حقیقت
- نه مرجع نهایی برای تطبیق حسابداری

---

# 5) پیش‌نیازهای Cutover

## 5.1 Cutover فقط بعد از این شرط‌ها مجاز است

### شرط 1
Voucher truth باید audit شده باشد.

### شرط 2
Journal و GL فیزیکی باید ساخته شده باشند.

### شرط 3
full rebuild از روی voucherها باید انجام و validate شده باشد.

### شرط 4
historical migration ruleها باید مشخص شده باشند.

### شرط 5
migration master dataهای critical باید همزمان آماده باشند.

### شرط 6
Checkpoint 6 باید passed باشد.

### شرط 7
بعد از CP-6، write جدول‌های legacy باید freeze شود.

## 5.2 Rule مهم

بدون freeze نویسنده‌های قدیمی بعد از CP-6، Cutover گزارش‌ها ریسک drift دارد و نباید انجام شود.

---

# 6) ترتیب رسمی Cutover گزارش‌ها

مطابق Roadmap، ترتیب رسمی Cutover این است:

1. Documents
2. Journal
3. General Ledger
4. Subsidiary Ledger
5. Trial Balance
6. Income Statement
7. Balance Sheet
8. Dashboard KPIs

## 6.1 چرا این ترتیب درست است؟

چون هر گزارش به گزارش/لایه قبل از خودش وابسته است:

```text
Documents
↓
Journal
↓
GL
↓
TB
↓
P&L / BS
↓
Dashboard
```

اگر این ترتیب برعکس شود، reportهای بالادستی روی sourceهای ناپایدار می‌نشینند.

---

# 7) Cutover Wave Plan

## 7.1 Wave 0 — Readiness Wave

### هدف
آماده‌سازی قبل از هر سوییچ.

### باید انجام شده باشد
- master data migration readiness complete
- Journal/GL physical tables آماده
- rebuild از voucherها موفق
- CP-6 passed
- legacy write freeze applied
- legacy pages marked read-only / `قدیمی`

### خروجی
- system is cutover-ready

---

## 7.2 Wave 1 — Documents Cutover

### گزارش هدف
- Documents / اسناد حسابداری

### source فعلی
- voucher payload mixed with legacy virtual logic

### source target
- `Voucher + VoucherRow` رسمی و تمیز

### هدف Wave
- حذف dependence بر synthetic/virtual document semantics
- تثبیت اینکه ERP documents فقط از voucher truth می‌آیند

---

## 7.3 Wave 2 — Journal Cutover

### گزارش هدف
- Journal / دفتر روزنامه

### source فعلی
- frontend flattening روی vouchers payload

### source target
- `{$wpdb->prefix}cptt_erp_journal`

### هدف Wave
- UI دیگر خودش flatten نکند
- دفتر روزنامه از جدول فیزیکی Journal تغذیه شود

---

## 7.4 Wave 3 — General Ledger Cutover

### گزارش هدف
- دفتر کل

### source فعلی
- client-side aggregation از voucher rows

### source target
- `{$wpdb->prefix}cptt_erp_gl`

### هدف Wave
- running balance و account movement از GL فیزیکی بیاید

---

## 7.5 Wave 4 — Subsidiary Ledger Cutover

### گزارش هدف
- دفتر معین

### source target
- `GL + dimensions`

### هدف Wave
- سوییچ کامل از roll-up client-side به dimension-aware GL query

---

## 7.6 Wave 5 — Trial Balance Cutover

### گزارش هدف
- Trial Balance / تراز آزمایشی

### source target
- `TrialBalanceReadModel` مشتق از GL

### هدف Wave
- حذف محاسبه مستقیم از voucher rows در frontend

---

## 7.7 Wave 6 — Income Statement Cutover

### گزارش هدف
- صورت سود و زیان

### source target
- `IncomeStatementReadModel` مشتق از TB

### هدف Wave
- حذف formulaهای raw prefix-based در frontend
- استفاده از semantic `accountNature`

---

## 7.8 Wave 7 — Balance Sheet Cutover

### گزارش هدف
- ترازنامه

### source target
- `BalanceSheetReadModel` مشتق از TB

### هدف Wave
- equation رسمی assets = liabilities + equity بر پایه TB/GL

---

## 7.9 Wave 8 — Dashboard KPI Cutover

### گزارش هدف
- dashboard cards / KPIها

### source target
- official reporting read models only

### هدف Wave
- dashboard دیگر از `_cptt_steps`، `fin_ledger` یا mixed payloadها عدد نگیرد

---

# 8) Backward-Compatible API Response Strategy

## 8.1 اصل کلی

در دوره‌ی گذار، responseها باید تا حد ممکن طوری طراحی شوند که:
- ERP UI فعلی نشکند
- legacy read-only pages اگر موقتاً زنده‌اند بتوانند response را بخوانند
- در عین حال source رسمی جدید وارد سیستم شود

## 8.2 اصل ساده

```text
Keep old response shape where possible
Add new metadata in non-breaking way
Move source under the hood first
```

## 8.3 Response Compatibility Rules

### Rule 1
نام فیلدهای اصلی فیلتر و pagination تا حد ممکن حفظ شوند.

### Rule 2
metadata جدید به شکل add-on اضافه شود، نه breaking change.

### Rule 3
source layer در metadata مشخص شود.

### Rule 4
legacy pageها اگر موقتاً response را می‌خوانند، فقط read-only باشند.

## 8.4 Metadataهای جدید پیشنهادی

در responseهای جدید این فیلدهای metadata مفهومی باید وجود داشته باشند:
- `sourceLayer`
- `generatedAt`
- `asOf`
- `featureVersion`
- `cutoverMode`
- `isLegacyCompatible`

## 8.5 Documents Compatibility

### Policy
- response shape نزدیک به document list فعلی بماند
- rows و totals از source رسمی بیاید
- legacy virtual voucherها از source نهایی حذف شوند

## 8.6 Journal Compatibility

### Policy
- اگر ERP UI فعلی انتظار line array دارد، همان line array حفظ شود
- ولی منبع آن `Journal table` باشد

## 8.7 GL / Subsidiary Compatibility

### Policy
- opening/entries/closing structure حفظ شود
- ولی backend دیگر frontend را مجبور به aggregation نکند

## 8.8 TB / P&L / BS Compatibility

### Policy
- response باید آماده‌ی render باشد
- frontend نباید خودش فرمول‌ها را اعمال کند

## 8.9 Dashboard Compatibility

### Policy
- dashboard response باید KPI-ready باشد
- source هر KPI باید در metadata مشخص باشد

---

# 9) Feature Flag Strategy

## 9.1 اصل کلی

هر report باید feature flag مستقل داشته باشد تا:
- بتوانیم مرحله‌ای cutover کنیم
- rollback گزارش به گزارش داشته باشیم
- big-bang cutover نداشته باشیم

## 9.2 Feature Flagهای مفهومی پیشنهادی

| Flag | هدف |
|---|---|
| `cpttf_reports_documents_v2` | Documents از source رسمی جدید |
| `cpttf_reports_journal_v2` | Journal از جدول فیزیکی Journal |
| `cpttf_reports_gl_v2` | GL از جدول فیزیکی GL |
| `cpttf_reports_subsidiary_v2` | Subsidiary از GL + dimensions |
| `cpttf_reports_tb_v2` | Trial Balance از TB read model |
| `cpttf_reports_pl_v2` | P&L از statement read model |
| `cpttf_reports_bs_v2` | Balance Sheet از statement read model |
| `cpttf_dashboard_v2` | Dashboard از reporting layer رسمی |
| `cpttf_legacy_pages_readonly` | صفحه‌های قدیمی فقط-خواندنی شوند |
| `cpttf_legacy_pages_old_badge` | برچسب `قدیمی` روی legacy pages |

## 9.3 Rule مهم

feature flagها باید:
- قابل خاموش/روشن شدن باشند
- scoped باشند
- گزارش به گزارش rollback بدهند
- وابستگی‌شان روشن باشد

## 9.4 Dependency Rule بین Flagها

### مثال
- `Journal v2` بدون readiness `Documents/voucher truth` نباید فعال شود
- `TB v2` بدون `GL v2` نباید فعال شود
- `Dashboard v2` بدون statements/read models نباید فعال شود

---

# 10) Acceptance Criteria برای هر گزارش

## 10.1 اصل کلی

با تصمیم قطعی کاربر:
- **سقف اختلاف مجاز = صفر**

بنابراین acceptance گزارش‌های رسمی باید exact باشد، نه تقریبی.

---

## 10.2 Documents Acceptance

### باید برقرار باشد
- document count explainable باشد
- totals from voucher rows exact باشد
- no synthetic-only document in official mode
- status filtering درست کار کند

### acceptance rule
- variance = 0

---

## 10.3 Journal Acceptance

### باید برقرار باشد
- line count with official journal source explainable باشد
- journal debit total == posted voucher debit total
- journal credit total == posted voucher credit total
- debit == credit exact

### acceptance rule
- variance = 0

---

## 10.4 General Ledger Acceptance

### باید برقرار باشد
- GL debit total == Journal debit total
- GL credit total == Journal credit total
- running balances deterministic باشند

### acceptance rule
- variance = 0

---

## 10.5 Subsidiary Ledger Acceptance

### باید برقرار باشد
- dimension filtering درست باشد
- ending balances with GL reconcile شوند
- party/project/cost center slicing deterministic باشد

### acceptance rule
- variance = 0

---

## 10.6 Trial Balance Acceptance

### باید برقرار باشد
- TB debit total == TB credit total
- rows from GL aggregation derive شوند
- exact equality برقرار باشد

### acceptance rule
- variance = 0

---

## 10.7 Income Statement Acceptance

### باید برقرار باشد
- revenue/expenditure/profit with TB reconcile شوند
- no client-side formula dependency باقی نماند
- official formula بر پایه `accountNature` باشد

### acceptance rule
- variance = 0

---

## 10.8 Balance Sheet Acceptance

### باید برقرار باشد
- assets == liabilities + equity دقیق
- balances from TB derive شوند
- no legacy source dependency

### acceptance rule
- variance = 0

---

## 10.9 Dashboard Acceptance

### باید برقرار باشد
- هر KPI source رسمی داشته باشد
- هر KPI با report متناظر reconcile شود
- project/accounting KPIs مخلوط و مبهم نباشند

### acceptance rule
- variance = 0 نسبت به source report رسمی

---

# 11) Parallel-Run Strategy

## 11.1 معنی ساده

Parallel-run یعنی مدتی old و new را کنار هم می‌سنجیم، قبل از اینکه old را کنار بگذاریم.

## 11.2 هدف

- پیدا کردن اختلاف‌ها
- مطمئن شدن از صفر بودن variance
- جلوگیری از شکستن UI هدف

## 11.3 Rule مهم

parallel-run باید در **staging** انجام شود و نتیجه‌اش عددی و مستند باشد.

## 11.4 Parallel-Run Waves

### Parallel Run A — Documents
old documents vs new documents source

### Parallel Run B — Journal
old frontend-derived journal vs physical journal

### Parallel Run C — GL / Subsidiary
old client-side ledgers vs GL-driven ledgers

### Parallel Run D — TB / P&L / BS
old frontend formulas vs official reporting layer

### Parallel Run E — Dashboard
old KPI logic vs new KPI logic

## 11.5 Parallel-Run Output Artifacts

برای هر موج باید این خروجی‌ها ثبت شوند:
- report scope
- totals old
- totals new
- variance
- cause of variance if any
- decision:
  - pass
  - block
  - review required

## 11.6 Rule با توجه به تصمیم کاربر

چون variance مجاز صفر است:
- اگر اختلاف وجود دارد، گزارش pass نشده
- نه در staging
- نه در cutover

---

# 12) رفتار صفحه‌های قدیمی در دوره‌ی گذار

## 12.1 تصمیم قطعی

صفحه‌های قدیمی در تست باید:
- فقط-خواندنی باشند
- برچسب `قدیمی` داشته باشند

## 12.2 معنی این تصمیم

### مجاز هستند
- برای مقایسه و sanity-check دیده شوند
- برای کاربران تستی مرور شوند

### مجاز نیستند
- owner truth باشند
- write مالی جدید انجام دهند
- معیار نهایی پذیرش accounting reports باشند

## 12.3 Rule برای Legacy Pages

```text
Legacy Pages = Read-Only + Old Badge + Non-Authoritative
```

## 12.4 نتیجه برای UI هدف

کاربر نهایی باید کم‌کم به ERP panel عادت کند و report sourceها آنجا تثبیت شوند.

---

# 13) نقش `_cptt_steps` در Cutover گزارش‌ها

## 13.1 تصمیم قطعی

فقط **پول واقعاً جابه‌جا شده** می‌تواند candidate سند حسابداری باشد.

## 13.2 نتیجه برای Reports

گزارش‌های رسمی زیر نباید از planned numbers در `_cptt_steps` تغذیه شوند:
- Journal
- GL
- TB
- P&L
- BS
- official dashboard KPIs

## 13.3 جایی که `_cptt_steps` هنوز ممکن است دیده شود

فقط در:
- operational screens
- project workflow views
- legacy read-only comparisons
- project snapshot reconciliation context

## 13.4 Rule مهم

وجود `cost` یا `remain` در stepها به‌تنهایی به معنی این نیست که باید در accounting reports دیده شود.  
فقط چیزی که واقعاً voucher truth دارد وارد accounting chain می‌شود.

---

# 14) Master Data Simultaneous Migration Impact

## 14.1 تصمیم قطعی

کاربر تصمیم گرفته که جدول‌های اطلاعات پایه **همزمان** منتقل شوند.

## 14.2 اثر این تصمیم روی Phase 8

قبل از Cutover گزارش‌ها باید readiness این‌ها تأیید شود:
- COA
- Fiscal Years
- Locks
- Cost Centers
- Companies
- Branches
- Currency-related critical master data if needed for report scope

## 14.3 Rule مهم

Cutover reportها بدون readiness master dataها مجاز نیست، چون report sourceها بدون master context ناقص می‌شوند.

---

# 15) Legacy Writer Freeze Impact

## 15.1 تصمیم قطعی

قطع write جدول‌های قدیمی بعد از **Checkpoint 6** انجام می‌شود.

## 15.2 اثر این تصمیم روی Phase 8

Phase 8 report cutover باید فرض کند:
- after CP-6 old ledger writers frozen هستند
- no new accounting truth comes from legacy ledgers
- from that point onward drift should stop

## 15.3 Rule مهم

اگر قبل از freeze کامل، report source جدید live شود، comparison بی‌اعتبار می‌شود.  
پس cutover رسمی reportها باید بعد از freeze باشد.

---

# 16) Report-by-Report Cutover Matrix

| Report | Current Source | Target Source | Flag | Parallel Run Required | Acceptance | Rollback |
|---|---|---|---|---|---|---|
| Documents | voucher payload + possible legacy merge | official Voucher/VoucherRow | `cpttf_reports_documents_v2` | بله | exact | fallback to old documents source |
| Journal | frontend flattening | physical Journal table | `cpttf_reports_journal_v2` | بله | exact | fallback to old journal path |
| General Ledger | client-side aggregation | physical GL table | `cpttf_reports_gl_v2` | بله | exact | fallback to old GL path |
| Subsidiary Ledger | client-side aggregation | GL + dimensions | `cpttf_reports_subsidiary_v2` | بله | exact | fallback to old subsidiary path |
| Trial Balance | frontend aggregation | TB read model from GL | `cpttf_reports_tb_v2` | بله | exact | fallback to old TB path |
| Income Statement | frontend formula | statement read model from TB | `cpttf_reports_pl_v2` | بله | exact | fallback to old P&L path |
| Balance Sheet | frontend formula | statement read model from TB | `cpttf_reports_bs_v2` | بله | exact | fallback to old BS path |
| Dashboard KPI | mixed/legacy logic | official reporting read models | `cpttf_dashboard_v2` | بله | exact | fallback to old dashboard path |

---

# 17) Rollback Strategy برای Report Cutover

## 17.1 اصل کلی

Rollback باید **report-by-report** باشد، نه اینکه کل سیستم با هم عقب برود.

## 17.2 Rollback Rule

اگر گزارشی fail شد:
- همان flag خاموش شود
- report به source قبلی برگردد
- discrepancy artifact ثبت شود
- root cause قبل از cutover دوباره بررسی شود

## 17.3 Rollback Levels

### Level 1
فقط یک report rollback شود

### Level 2
یک خانواده report rollback شود
مثلاً:
- Journal + GL + Subsidiary

### Level 3
کل reporting cutover wave rollback شود

## 17.4 Rule مهم

Rollback نباید با patch دستی روی data انجام شود.  
Rollback source path باید controlled و flag-based باشد.

---

# 18) ارتباط Phase 8 با فازهای بعد

## 18.1 ارتباط با Phase 9

Phase 8 فقط cutover گزارش‌ها را طراحی می‌کند.  
Phase 9 باید UI contractها را بیشتر formalize کند، اما چون تصمیم کاربر روشن است، محور UI همچنان ERP panel می‌ماند.

## 18.2 ارتباط با Phase 10

بعد از موفقیت report cutover:
- خیلی از pageهای legacy می‌توانند وارد مسیر decommission شوند
- چون role آن‌ها فقط read-only compatibility بوده است

---

# 19) روش تست معماری Phase 8

## 19.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا ترتیب cutover گزارش‌ها روشن شده؟
2. آیا target UI = ERP panel در طرح حفظ شده؟
3. آیا backward-compatible response strategy مشخص شده؟
4. آیا feature flagها تعریف شده‌اند؟
5. آیا acceptance criteria برای هر گزارش exact تعریف شده؟
6. آیا parallel-run strategy روشن شده؟
7. آیا رفتار صفحه‌های قدیمی مشخص شده؟
8. آیا اثر freeze بعد از CP-6 در نظر گرفته شده؟
9. آیا اثر master data simultaneous migration در نظر گرفته شده؟
10. آیا ambiguityهای فاز ۸ صریح لیست شده‌اند؟

## 19.2 سناریوهای تست پیشنهادی

- Documents old/new compare
- Journal old/new compare
- GL old/new compare
- Subsidiary old/new compare
- TB old/new compare
- P&L old/new compare
- BS old/new compare
- Dashboard KPI old/new compare
- legacy pages read-only badge verification
- ERP panel end-to-end report rendering verification

---

# 20) ارزیابی انجام Taskهای Phase 8 نسبت به Roadmap

## 20.1 Taskهای Phase 8 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 8 شامل این موارد بود:
- تعیین cutover order برای reportها
- طراحی backward-compatible API responses during transition
- تعیین feature flag strategy per report
- تعریف acceptance criteria per report
- تعریف parallel-run strategy برای compare قدیم/جدید

## 20.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| cutover order گزارش‌ها | ✅ انجام شد |
| backward-compatible API response strategy | ✅ انجام شد |
| feature flag strategy | ✅ انجام شد |
| acceptance criteria per report | ✅ انجام شد |
| parallel-run strategy | ✅ انجام شد |
| اعمال تصمیم‌های نهایی کاربر | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 20.3 Definition of Done Phase 8

Phase 8 زمانی Done تلقی می‌شود که:
1. cutover plan برای همه reportهای اصلی وجود داشته باشد ✅
2. acceptance rule هر report روشن باشد ✅
3. feature flag و rollback strategy مشخص شده باشد ✅
4. legacy read-only strategy روشن شده باشد ✅
5. review ambiguityهای باز قبل از اجرا انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ریزی cutover**، Phase 8 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی** هنوز نیازمند تصمیم روی چند ambiguity اجرایی و operational rollout detail است.

---

# 21) Ambiguity Register فاز ۸

> این بخش باید قبل از اجرای واقعی Cutover یا قبل از فاز بعدی مرور شود.

## 21.1 آیا export/print هر گزارش همزمان با cutover همان گزارش سوییچ شود یا یک موج بعد؟

### توضیح ساده
مثلاً وقتی Journal جدید را live می‌کنیم، چاپ و خروجی Excel آن هم همان لحظه از source جدید بیاید یا بعداً؟

### وضعیت
**نیاز به تصمیم**

---

## 21.2 آیا Dashboard Cutover فقط بعد از موفقیت کامل P&L و BS انجام شود یا بعضی KPIها زودتر قابل انتقال‌اند؟

### توضیح ساده
بعضی کارت‌های داشبورد شاید زودتر آماده باشند، بعضی‌ها نه.

### وضعیت
**نیاز به تصمیم**

---

## 21.3 اگر ERP UI فعلی برای بعضی گزارش‌ها هنوز فرض client-side داشته باشد، آیا response adapter کافی است یا UI patch کوچک لازم می‌شود؟

### توضیح ساده
ممکن است بعضی صفحه‌های ERP فعلی هنوز انتظار داشته باشند خودشان جمع بزنند.

### وضعیت
**نیاز به تصمیم اجرایی / فنی**

---

## 21.4 آیا legacy read-only pages در staging فقط برای تیم دیده شوند یا برای همه ادمین‌ها؟

### توضیح ساده
باید معلوم شود صفحه‌های قدیمی در تست برای چه کسانی visible باشند.

### وضعیت
**نیاز به تصمیم**

---

## 21.5 آیا در اولین cutover statementها summary-only باشند یا account-detail/full-tree هم همان موج منتقل شود؟

### توضیح ساده
صورت سود و زیان و ترازنامه می‌توانند ساده‌تر یا با جزئیات کامل بیایند.

### وضعیت
**نیاز به تصمیم**

---

## 21.6 اگر بعضی KPIهای dashboard operational nature داشته باشند نه accounting nature، دقیقاً در کدام surface بمانند؟

### توضیح ساده
بعضی کارت‌ها شاید مالی رسمی نباشند و بیشتر مدیریتی/عملیاتی باشند.

### وضعیت
**نیاز به تصمیم**

---

## 21.7 آیا برچسب `قدیمی` فقط در UI کافی است یا باید در response/API metadata هم منعکس شود؟

### توضیح ساده
برای شفافیت بیشتر شاید لازم باشد API هم بگوید این صفحه/خروجی legacy است.

### وضعیت
**نیاز به تصمیم**

---

# 22) جمع‌بندی نهایی Phase 8

مهم‌ترین خروجی Phase 8 این است که از اینجا به بعد، انتقال گزارش‌ها نباید بی‌برنامه و یک‌باره انجام شود.

### نتیجه‌های کلیدی
- ترتیب رسمی cutover گزارش‌ها مشخص شد
- UI هدف ERP panel تثبیت شد
- response compatibility strategy تعریف شد
- feature flagها report-by-report تعریف شدند
- acceptance criteria با variance صفر تعیین شد
- parallel-run strategy طراحی شد
- صفحه‌های قدیمی به حالت read-only با برچسب `قدیمی` محدود شدند
- اثر freeze بعد از CP-6 و migration همزمان master dataها در طرح لحاظ شد

### اصل نهایی این فاز

```text
Cut over reports one by one.
Keep ERP as the target UI.
Accept zero variance only.
```

و به زبان ساده‌تر:

```text
گزارش‌ها را یکی‌یکی منتقل می‌کنیم،
پنل ERP مقصد نهایی می‌ماند،
و فقط وقتی اختلاف صفر باشد سوییچ را قبول می‌کنیم.
```

---

**پایان گزارش Phase 8**
