# PHASE_2_REPORT

> Phase 2 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`  
> Mode: **No code change / No behavior change / Service & Repository Blueprint only**

---

# 0) هدف این گزارش

این سند، شروع اجرایی **Phase 2 — Service & Repository Blueprint** است و فقط روی این موارد تمرکز دارد:

1. تعریف **Service Catalog** نهایی
2. تعریف **Repository Catalog** نهایی
3. تعیین **مالک هر use case مالی**
4. تعیین **مرز تراکنش (Transaction Boundary)** برای هر use case
5. تعیین **Contract معماری** برای serviceها و repositoryها
6. تعیین **سیاست idempotency** برای رویدادها و عملیات‌های مالی
7. تعیین **سیاست traceability** برای `sourceType/sourceId` و زنجیره‌ی اسناد
8. مشخص‌کردن dependencyهای مجاز و غیرمجاز بین لایه‌ها
9. ثبت ambiguityها و تصمیم‌های باز که باید در Phase 3 و بعد از آن نهایی شوند

> این سند عمداً هیچ تغییری در کد، schema، query، migration یا رفتار runtime ایجاد نمی‌کند.

---

# 1) وضعیت شروع Phase 2

## 1.1 مبنای شروع

Phase 2 بر اساس این artefactها ادامه پیدا می‌کند:
- `ACCOUNTING_SYSTEM_ANALYSIS.md`
- `ERP_ARCHITECTURE.md`
- `ERP_REFACTOR_ROADMAP.md`
- `PHASE_0_REPORT.md`
- `PHASE_1_REPORT.md`

## 1.2 وابستگی به Phase 1

طبق Roadmap، Phase 2 وابسته به Phase 1 است.  
با توجه به اینکه در `PHASE_1_REPORT.md` مدل‌های canonical، relation map، state machineها و dimension model مشخص شده‌اند، این Phase 2 آن زبان دامنه‌ای را مبنا قرار می‌دهد.

## 1.3 وضعیت نسخه و زیپ

این artefact صرفاً مستنداتی است و هیچ تغییر کدی در افزونه ایجاد نمی‌کند؛ بنابراین در این مرحله:
- version bump انجام نشده
- zip نصبی جدید ساخته نشده

---

# 2) اصول معماری Service Layer و Repository Layer

## 2.1 اصل جداسازی مسئولیت

در معماری هدف، هر use case مالی باید سه لایه‌ی مجزا داشته باشد:

```text
Application Service
↓
Domain / Accounting Engine
↓
Repository Layer
```

### نتیجه
- Service مسئول **orchestration** است
- Domain/Engine مسئول **rule و accounting logic** است
- Repository مسئول **storage access** است

## 2.2 اصل ممنوعیت اختلاط

### Service نباید:
- SQL مستقیم بنویسد
- منطق گزارش‌گیری انجام دهد
- منطق UI انجام دهد
- چند مفهوم دامنه‌ای نامرتبط را بدون boundary مشخص مخلوط کند

### Repository نباید:
- سود و زیان محاسبه کند
- Trial Balance بسازد
- dashboard logic بسازد
- workflow business action را orchestrate کند

### UI نباید:
- voucher بسازد
- ledger posting انجام دهد
- محاسبات مالی رسمی انجام دهد

## 2.3 اصل Voucher-First در سطح سرویس

در Phase 2، تمام serviceها باید با این اصل canonical شوند:

> هر use case مالی یا خودش مستقیماً Voucher می‌سازد،  
> یا به سرویسی ختم می‌شود که Voucher را می‌سازد و post می‌کند.

## 2.4 اصل Explicit Owner

هر use case باید دقیقاً **یک service owner** داشته باشد.  
هیچ use case مالی نباید بین چند کلاس پراکنده و بدون owner بماند.

## 2.5 اصل Explicit Repository Ownership

هر aggregate یا read model باید دقیقاً **یک repository owner** داشته باشد.  
خواندن و نوشتن پراکنده روی `$wpdb`, `get_option`, `get_post_meta` در معماری نهایی قابل قبول نیست.

---

# 3) طبقه‌بندی Serviceها در معماری هدف

## 3.1 دسته‌بندی اصلی

Serviceهای معماری هدف در Phase 2 به چهار دسته تقسیم می‌شوند:

### A) Voucher Lifecycle Services
- `VoucherApplicationService`
- `VoucherApprovalService`
- `VoucherPostingService`
- `VoucherReversalService`
- `VoucherLifecycleService`

### B) Business Accounting Services
- `CustomerReceiptService`
- `ExpertSettlementService`
- `TreasuryTransactionService`
- `TreasuryTransferService`
- `PayableService`
- `PayablePaymentService`
- `InstallmentPlanService`
- `InstallmentReceiptService`
- `ChequeAccountingService`
- `InvoiceAccountingService`
- `FiscalYearClosingService`

### C) Reporting / Read Services
- `JournalReportService`
- `GeneralLedgerReportService`
- `SubsidiaryLedgerReportService`
- `TrialBalanceReportService`
- `IncomeStatementReportService`
- `BalanceSheetReportService`
- `CashFlowReportService`
- `AgingReportService`
- `DashboardFinancialReadService`
- `ProjectFinancialReadService`
- `PartyFinancialReadService`

### D) Cross-Cutting / Policy Services
- `AccountingMappingResolver`
- `FiscalLockPolicyService`
- `IdempotencyPolicyService`
- `AuditTrailService`
- `TraceabilityPolicyService`
- `DimensionResolverService`

> دسته D در Roadmap به‌عنوان نام نهایی صریح نشده بود، اما برای قابل‌اجرا بودن service contracts در معماری هدف، وجود این policy serviceها لازم است.

---

# 4) Service Catalog نهایی

## 4.1 VoucherApplicationService

### نقش
مالک use caseهای «ساخت/ویرایش/ذخیره پیش‌نویس سند».

### Owner Use Cases
- Create Draft Voucher
- Update Draft Voucher
- Save Voucher Rows
- Submit Voucher For Approval

### Aggregateهای تحت مالکیت
- `Voucher`
- `VoucherRow`

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `AccountRepository`
- `FiscalYearRepository`
- `FiscalLockRepository`
- `AuditLogRepository`

### Engine/Policy dependencyهای اصلی
- `AccountingMappingResolver`
- `FiscalLockPolicyService`
- `DimensionResolverService`
- `AuditTrailService`

### Contract سطح بالا
**Input:**
- voucher header
- voucher rows
- actor
- request metadata

**Output:**
- persisted draft voucher id
- voucherNo/voucherCode
- validation result
- current status

### مجاز است
- draft ایجاد کند
- draft را ویرایش کند
- rowها را validate اولیه کند
- voucher را برای approval submit کند

### مجاز نیست
- Journal بسازد
- General Ledger بسازد
- Trial Balance یا report refresh نهایی انجام دهد
- سند را بدون lifecycle مشخص post کند

---

## 4.2 VoucherApprovalService

### نقش
مالک workflow تأیید سند.

### Owner Use Cases
- Accountant Approval
- Manager Approval
- CEO Approval (در صورت فعال بودن policy)
- Reject / Return to Draft (نیاز به بررسی بیشتر)

### Aggregateهای تحت مالکیت
- `Voucher`

### Repository dependencyهای اصلی
- `VoucherRepository`
- `AuditLogRepository`

### Policy dependencyهای اصلی
- `FiscalLockPolicyService`
- `AuditTrailService`
- `TraceabilityPolicyService`

### Contract سطح بالا
**Input:**
- voucherId
- approvalAction
- approver
- note?

**Output:**
- updated voucher status
- approval chain snapshot

### مجاز است
- status سند را در workflow approval جابه‌جا کند
- approval metadata ثبت کند

### مجاز نیست
- reversal ایجاد کند
- GL posting انجام دهد، مگر از طریق `VoucherPostingService`

### نکته
وجود مرحله‌ی CEO approval در field level دیده می‌شود، اما status machine صریح آن در وضعیت فعلی **نیاز به بررسی بیشتر** دارد.

---

## 4.3 VoucherPostingService

### نقش
مالک use case «Post Voucher» و حلقه‌ی اتصال سند به Journal و GL.

### Owner Use Cases
- Finalize / Post Voucher
- Rebuild accounting projections for posted voucher
- Trigger report read-model refresh marker

### Aggregateهای تحت مالکیت
- `Voucher`
- `JournalEntry`
- `GeneralLedgerEntry`

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `JournalRepository`
- `GeneralLedgerRepository`
- `AuditLogRepository`

### Engine dependencyهای اصلی
- `FiscalLockPolicyService`
- `AccountingMappingResolver`
- `DimensionResolverService`
- `AuditTrailService`

### Contract سطح بالا
**Input:**
- voucherId
- actor
- post context

**Output:**
- posted voucher snapshot
- journal write summary
- general ledger write summary
- report refresh token / projection marker

### مجاز است
- voucher eligibility را چک کند
- posted status را اعمال کند
- journal entries ایجاد کند
- general ledger entries ایجاد کند
- traceability chain را کامل کند

### مجاز نیست
- business action جدید خلق کند
- payment/settlement logic را خارج از voucher context محاسبه کند

### اهمیت معماری
این service مهم‌ترین owner Phase 3 است و Phase 2 فقط contract آن را تثبیت می‌کند.

---

## 4.4 VoucherReversalService

### نقش
مالک reversal رسمی اسناد.

### Owner Use Cases
- Reverse Voucher
- Link reversal voucher to original
- Preserve audit trail and chain of causation

### Aggregateهای تحت مالکیت
- `Voucher`
- `VoucherRow`
- `JournalEntry`
- `GeneralLedgerEntry`

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `JournalRepository`
- `GeneralLedgerRepository`
- `AuditLogRepository`

### Policy dependencyهای اصلی
- `FiscalLockPolicyService`
- `TraceabilityPolicyService`
- `AuditTrailService`

### Contract سطح بالا
**Input:**
- originalVoucherId
- reversalReason
- actor
- reversalDate

**Output:**
- reversal voucher id
- link to original voucher
- posting summary

### مجاز است
- reversing voucher بسازد
- rows معکوس ایجاد کند
- reversal chain را ثبت کند

### مجاز نیست
- original voucher را silently delete کند
- history را پاک کند

---

## 4.5 VoucherLifecycleService

### نقش
مالک عملیات lifecycle غیرحسابداری مستقیم روی سند.

### Owner Use Cases
- Delete Draft Voucher
- Archive Voucher (اگر policy وجود داشته باشد)
- Unfinalize Voucher (در صورت policy مجاز)

### Aggregateهای تحت مالکیت
- `Voucher`

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `AuditLogRepository`

### Policy dependencyهای اصلی
- `FiscalLockPolicyService`
- `AuditTrailService`

### Contract سطح بالا
**Input:**
- voucherId
- action
- actor
- reason

**Output:**
- updated voucher state

### نکته
رفتار `unfinalize` در معماری نهایی باید به policy مستقل در Phase 3 متصل شود. در Phase 2 فقط owner مشخص می‌شود.

---

## 4.6 CustomerReceiptService

### نقش
مالک use caseهای «دریافت از مشتری» و تبدیل آن به accounting action.

### Owner Use Cases
- Register Customer Receipt
- Apply receipt to project/customer
- Create RV voucher

### Aggregateهای تحت مالکیت
- `Voucher`
- `VoucherRow`
- `Party`
- `ProjectFinancialSnapshot` (غیرمستقیم / read-side)

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `PartyRepository`
- `AccountRepository`
- `ProjectFinancialSnapshotRepository`
- `AuditLogRepository`

### External/legacy interaction
- `Project` / `ProjectStepOperationalState` updates در صورت نیاز عملیاتی
- Payment receipt workflow integration

### Contract سطح بالا
**Input:**
- customer/party reference
- amount
- treasury account
- project context?
- receipt method
- actor

**Output:**
- business receipt result
- created voucher id
- posting result
- traceability reference

### مجاز است
- receipt را در domain ثبت کند
- accounting mapping resolve کند
- voucher RV بسازد

### مجاز نیست
- receivable KPI را مستقیم update کند بدون posting
- dashboard را bypass کند

---

## 4.7 ExpertSettlementService

### نقش
مالک use caseهای «تسویه کارشناس / پرداخت مرحله‌ای / پرداخت دستی کارشناس».

### Owner Use Cases
- Register Expert Settlement
- Register Manual Expert Payment
- Create PV voucher for expert payout

### Aggregateهای تحت مالکیت
- `Voucher`
- `VoucherRow`
- `Party`
- `Payable` یا expert payable projection
- `ProjectFinancialSnapshot` (غیرمستقیم)

### Repository dependencyهای اصلی
- `VoucherRepository`
- `VoucherRowRepository`
- `PartyRepository`
- `PayableRepository`
- `AccountRepository`
- `AuditLogRepository`

### External/legacy interaction
- `_cptt_steps` operational updates
- legacy settlement history during transition

### Contract سطح بالا
**Input:**
- expert/party reference
- amount
- project/step context
- settlement type
- actor

**Output:**
- settlement result
- payable movement result
- created voucher id

### ریسک معماری
این service در وضعیت فعلی بیشترین برخورد را با `_cptt_steps`, `wp_cptt_ledger` و `wp_cptt_fin_ledger` دارد؛ بنابراین Phase 5 و 6 شدیداً به این سرویس وابسته‌اند.

---

## 4.8 TreasuryTransactionService

### نقش
مالک ثبت واریز/برداشت/درآمد/هزینه مبتنی بر خزانه.

### Owner Use Cases
- Treasury Deposit
- Treasury Withdraw
- Direct Income
- Direct Expense

### Aggregateهای تحت مالکیت
- `TreasuryAccount`
- `Voucher`
- `VoucherRow`

### Repository dependencyهای اصلی
- `TreasuryAccountRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- treasuryAccountId
- transactionType
- amount
- counterAccount or category mapping
- actor
- project/party/costCenter? optional

**Output:**
- treasury transaction result
- created voucher id
- posting result

### مجاز نیست
- finance ledger legacy را به‌عنوان SoT نهایی تلقی کند
- category breakdown report را مستقیم update کند

---

## 4.9 TreasuryTransferService

### نقش
مالک انتقال بین دو حساب خزانه.

### Owner Use Cases
- Transfer Between Treasury Accounts
- Create TV voucher

### Aggregateهای تحت مالکیت
- `TreasuryAccount`
- `Voucher`
- `VoucherRow`

### Repository dependencyهای اصلی
- `TreasuryAccountRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- fromTreasuryAccountId
- toTreasuryAccountId
- amount
- transferDate
- actor

**Output:**
- transfer result
- created voucher id
- posting result

### قاعده‌ی معماری
انتقال خزانه باید accounting-neutral باشد از نظر net treasury total، اما باید movement کامل و traceable ایجاد کند.

---

## 4.10 PayableService

### نقش
مالک ایجاد/ویرایش/مشاهده business state بدهی.

### Owner Use Cases
- Create Payable
- Update Payable
- Read Payable state
- Link payable to party/project

### Aggregateهای تحت مالکیت
- `Payable`
- `Party`

### Repository dependencyهای اصلی
- `PayableRepository`
- `PartyRepository`
- `ProjectFinancialSnapshotRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- party reference
- amount
- due date
- project?
- description
- actor

**Output:**
- payable id
- payable status

### نکته
این سرویس لزوماً payment را انجام نمی‌دهد؛ payment owner آن سرویس جداگانه است.

---

## 4.11 PayablePaymentService

### نقش
مالک use case پرداخت بدهی.

### Owner Use Cases
- Pay Payable
- Partially Pay Payable
- Create PV voucher for payable payment

### Aggregateهای تحت مالکیت
- `Payable`
- `Voucher`
- `VoucherRow`
- `TreasuryAccount`

### Repository dependencyهای اصلی
- `PayableRepository`
- `TreasuryAccountRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- payableId
- treasuryAccountId
- amount
- paymentDate
- actor

**Output:**
- payable updated state
- created voucher id
- payment summary

---

## 4.12 InstallmentPlanService

### نقش
مالک ساخت و مدیریت برنامه قسط.

### Owner Use Cases
- Create Installment Plan
- Update Installment Plan
- Generate Installment Rows

### Aggregateهای تحت مالکیت
- `InstallmentPlan`
- `InstallmentRow`
- `Party`

### Repository dependencyهای اصلی
- `InstallmentPlanRepository`
- `InstallmentRowRepository`
- `PartyRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- customer/party reference
- totalAmount
- count
- intervalDays
- firstDueDate
- actor

**Output:**
- installment plan id
- generated row summary

### مجاز نیست
- receipt accounting انجام دهد؛ آن use case متعلق به `InstallmentReceiptService` است

---

## 4.13 InstallmentReceiptService

### نقش
مالک دریافت قسط و تبدیل آن به accounting entry.

### Owner Use Cases
- Receive Installment
- Mark installment row paid/partial
- Create RV voucher

### Aggregateهای تحت مالکیت
- `InstallmentPlan`
- `InstallmentRow`
- `Voucher`
- `VoucherRow`

### Repository dependencyهای اصلی
- `InstallmentPlanRepository`
- `InstallmentRowRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- installmentRowId
- amount
- treasuryAccountId
- actor

**Output:**
- updated installment state
- created voucher id
- receipt result

---

## 4.14 ChequeAccountingService

### نقش
مالک ثبت و lifecycle accounting چک‌های دریافتی و پرداختی.

### Owner Use Cases
- Register Receivable Cheque
- Register Payable Cheque
- Move cheque through lifecycle
- Create related voucher(s) when accounting effect is recognized

### Aggregateهای تحت مالکیت
- `Cheque`
- `Voucher`
- `VoucherRow`
- `Party`
- `TreasuryAccount`

### Repository dependencyهای اصلی
- `ChequeRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `PartyRepository`
- `TreasuryAccountRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- cheque data
- lifecycle action
- actor

**Output:**
- updated cheque state
- created voucher id(s) if applicable

### نکته
نقطه‌ی دقیق recognition accounting برای بعضی state transitionهای cheque در وضعیت فعلی **نیاز به بررسی بیشتر** دارد و باید در Phase 3 نهایی شود.

---

## 4.15 InvoiceAccountingService

### نقش
مالک ارتباط فاکتور با accounting document.

### Owner Use Cases
- Create Invoice
- Update Invoice
- Convert Invoice to Voucher
- Link Invoice to Receivable/Revenue

### Aggregateهای تحت مالکیت
- `Invoice`
- `InvoiceRow`
- `Voucher`
- `VoucherRow`
- `Party`

### Repository dependencyهای اصلی
- `InvoiceRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `PartyRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- invoice header
- invoice rows
- conversion action
- actor

**Output:**
- invoice id
- voucher id?
- accounting linkage summary

---

## 4.16 FiscalYearClosingService

### نقش
مالک عملیات preview close / close execute / open/close linkage.

### Owner Use Cases
- Preview Fiscal Close
- Execute Fiscal Close
- Create Closing Voucher (CV)
- Create Opening Voucher (OV)
- Lock/Reopen Fiscal Period

### Aggregateهای تحت مالکیت
- `FiscalYear`
- `FiscalPeriodLock`
- `Voucher`
- `VoucherRow`
- `JournalEntry`
- `GeneralLedgerEntry`

### Repository dependencyهای اصلی
- `FiscalYearRepository`
- `FiscalLockRepository`
- `VoucherRepository`
- `VoucherRowRepository`
- `JournalRepository`
- `GeneralLedgerRepository`
- `AccountRepository`
- `AuditLogRepository`

### Contract سطح بالا
**Input:**
- fiscalYearId
- action (`previewClose`, `executeClose`, `reopen`)
- actor

**Output:**
- close summary
- created voucher ids (`CV`, `OV`)
- lock status

### حساسیت
این service شدیدترین transaction boundary مالی را دارد و باید در Phase 3 با دقت formalize شود.

---

# 5) Reporting / Read Service Catalog

> این serviceها write owner نیستند، اما برای کامل بودن blueprint باید در Phase 2 contract سطح بالا داشته باشند.

## 5.1 JournalReportService
- Source: `JournalEntry`
- Filters: date range, status, project, party, cost center, fiscalYear
- Output: journal lines + totals
- مجاز نیست: write کردن voucher یا journal

## 5.2 GeneralLedgerReportService
- Source: `GeneralLedgerEntry`
- Output: account movements + running balances
- مجاز نیست: source data را mutate کند

## 5.3 SubsidiaryLedgerReportService
- Source: `GeneralLedgerEntry` + dimensions
- Output: subsidiary/account-dimension ledgers

## 5.4 TrialBalanceReportService
- Source: `GeneralLedgerEntry`
- Output: `TrialBalanceRow`

## 5.5 IncomeStatementReportService
- Source: `TrialBalanceRow`
- Output: P&L

## 5.6 BalanceSheetReportService
- Source: `TrialBalanceRow`
- Output: balance sheet

## 5.7 CashFlowReportService
- Source: posted entries + cash account classification
- Output: cash flow report

## 5.8 AgingReportService
- Source: receivable/payable balances + due references
- Output: aging rows

## 5.9 DashboardFinancialReadService
- Source: reporting outputs only
- Output: dashboard KPIs

## 5.10 ProjectFinancialReadService
- Source target: accounting/reporting layer
- Output: project-level financial snapshot
- Note: جایگزین منطق‌های تکراری `_cptt_steps`-based در فازهای بعد

## 5.11 PartyFinancialReadService
- Source target: GL + party dimensions + payables/installments/cheques linkage
- Output: party statements / receivable / payable views

---

# 6) Repository Catalog نهایی

## 6.1 قاعده‌ی اصلی Repositoryها

هر repository باید فقط مسئول یک aggregate یا یک read model مشخص باشد.  
Repositoryها باید interface/contract داشته باشند، حتی اگر implementation نهایی بعداً روی table، option، join view یا adapter قرار بگیرد.

## 6.2 Write Repositoryها

### VoucherRepository
**مالک:** `Voucher`  
**مسئولیت:**
- create/update/find/delete draft voucher
- status transitions persistence
- sourceType/sourceId tracing persistence

### VoucherRowRepository
**مالک:** `VoucherRow`  
**مسئولیت:**
- insert/update/delete voucher rows
- load rows by voucherId

### JournalRepository
**مالک:** `JournalEntry`  
**مسئولیت:**
- append/read journal entries
- load by voucherId / account / dimensions / date

### GeneralLedgerRepository
**مالک:** `GeneralLedgerEntry`  
**مسئولیت:**
- append/read GL entries
- running balance retrieval strategy
- account/date/dimension slicing

### FiscalYearRepository
**مالک:** `FiscalYear`  
**مسئولیت:**
- create/update/find fiscal year
- status changes (`OPEN/CLOSED`)

### FiscalLockRepository
**مالک:** `FiscalPeriodLock`  
**مسئولیت:**
- create/update/read period locks
- find lock by date/fiscal year

### AccountRepository
**مالک:** `Account`  
**مسئولیت:**
- load chart of accounts
- resolve account by id/code
- parent tree traversal support

### TreasuryAccountRepository
**مالک:** `TreasuryAccount`  
**مسئولیت:**
- load treasury accounts
- treasury-to-account mapping
- active/inactive treasury accounts

### CostCenterRepository
**مالک:** `CostCenter`  
**مسئولیت:**
- load cost centers
- resolve by id/code/type

### PartyRepository
**مالک:** `Party`  
**مسئولیت:**
- resolve party by user, free-text, or canonical id
- maintain party registry abstraction

### CurrencyRateRepository
**مالک:** `CurrencyRate`  
**مسئولیت:**
- load rates by date/pair
- resolve active rate

### InvoiceRepository
**مالک:** `Invoice`, `InvoiceRow`  
**مسئولیت:**
- create/update/find invoice
- load invoice rows
- invoice↔voucher linkage

### ChequeRepository
**مالک:** `Cheque`  
**مسئولیت:**
- create/update/find cheque
- state transition persistence

### PayableRepository
**مالک:** `Payable`  
**مسئولیت:**
- create/update/find payable
- paid amount persistence
- status recalculation persistence

### InstallmentPlanRepository
**مالک:** `InstallmentPlan`  
**مسئولیت:**
- create/update/find installment plan

### InstallmentRowRepository
**مالک:** `InstallmentRow`  
**مسئولیت:**
- create/update/find installment rows
- row-level payment state persistence

### AuditLogRepository
**مالک:** `AuditLog`  
**مسئولیت:**
- append audit records
- read audit history by entity/user/action

---

## 6.3 Read / Projection Repositoryها

### ProjectFinancialSnapshotRepository
**مالک:** `ProjectFinancialSnapshot`  
**نکته:** read model only

### TrialBalanceRepository
**مالک:** `TrialBalanceRow`  
**نکته:** در معماری فعلی می‌تواند derived/query-only باشد؛ materialization نهایی نیاز به بررسی بیشتر دارد

### IncomeStatementRepository
**مالک:** `IncomeStatementRow`  
**نکته:** query/projection repository

### BalanceSheetRepository
**مالک:** `BalanceSheetRow`  
**نکته:** query/projection repository

### DashboardFinancialSnapshotRepository
**مالک:** dashboard snapshots/read models  
**نکته:** read-side only

### PartyFinancialReadRepository
**مالک:** party statement/read models  
**نکته:** read-side only

---

## 6.4 Repository Name Alignment

برای جلوگیری از دوگانگی نام‌ها، در این سند نام‌های زیر canonical هستند:

| Roadmap name | Canonical name in Phase 2 |
|---|---|
| `LockRepository` | `FiscalLockRepository` |
| `TreasuryRepository` | `TreasuryAccountRepository` |
| `InstallmentRepository` | `InstallmentPlanRepository` + `InstallmentRowRepository` |
| `AuditRepository` | `AuditLogRepository` |

---

# 7) Contract Rules برای Repositoryها

## 7.1 Repositoryها باید چه چیزهایی را تضمین کنند؟

1. **Identity resolution**
2. **Storage isolation**
3. **Consistent load/save contract**
4. **No hidden business logic**
5. **Traceable failures**

## 7.2 Repositoryها نباید چه کارهایی انجام دهند؟

- approval workflow تصمیم بگیرند
- debit/credit balancing rule را تعیین کنند
- voucher type را حدس بزنند
- سود و زیان را محاسبه کنند
- balance sheet بسازند
- sourceType/sourceId را invent کنند

## 7.3 Repository Output Contract

هر repository باید حداقل بتواند این contractها را پوشش دهد:
- `findById`
- `save`
- `delete` یا equivalent lifecycle action
- `findByFilters`
- `existsByUniqueBusinessKey` (در صورت نیاز idempotency)

> این‌ها contract مفهومی هستند و در این سند intentionally به syntax یا code تبدیل نمی‌شوند.

---

# 8) Service Contract Blueprint

## 8.1 ساختار عمومی Contract برای همه serviceها

هر service contract در معماری نهایی باید این اجزا را داشته باشد:

1. **Command Name**
2. **Actor**
3. **Input Model**
4. **Preconditions**
5. **Validation Rules**
6. **Repositories Used**
7. **Accounting Side Effects**
8. **Audit Requirements**
9. **Idempotency Rule**
10. **Output Model**
11. **Failure Modes**
12. **Transaction Boundary**

## 8.2 نمونه قرارداد مفهومی: CreateDraftVoucher

| بخش | تعریف |
|---|---|
| Command | `CreateDraftVoucher` |
| Owner | `VoucherApplicationService` |
| Preconditions | fiscal year exists, date valid, accounts resolvable |
| Validation | rows balanced, accounts active, dimensions valid |
| Writes | `Voucher`, `VoucherRow`, `AuditLog` |
| No Write | `Journal`, `GeneralLedger` |
| Output | draft voucher snapshot |
| Transaction Boundary | header + rows + audit in one unit |

## 8.3 نمونه قرارداد مفهومی: PostVoucher

| بخش | تعریف |
|---|---|
| Command | `PostVoucher` |
| Owner | `VoucherPostingService` |
| Preconditions | voucher exists, status eligible, fiscal period open |
| Validation | debit==credit, accounts valid, traceability complete |
| Writes | `Voucher`, `JournalEntry`, `GeneralLedgerEntry`, `AuditLog` |
| Output | posted voucher summary |
| Transaction Boundary | status + journal + GL + audit in one unit |

## 8.4 نمونه قرارداد مفهومی: RegisterCustomerReceipt

| بخش | تعریف |
|---|---|
| Command | `RegisterCustomerReceipt` |
| Owner | `CustomerReceiptService` |
| Preconditions | party exists/resolvable, treasury valid, amount > 0 |
| Writes | operational receipt context + `Voucher` + `VoucherRow` + `AuditLog` |
| Accounting Effect | create RV voucher |
| Output | receipt summary + voucher ref |
| Transaction Boundary | business receipt + accounting linkage + audit |

---

# 9) Transaction Boundary Matrix

## 9.1 قاعده‌ی کلی

هر use case مالی باید یک مرز تراکنش شفاف داشته باشد.  
در WordPress/PHP ممکن است atomicity فنی کامل در همه storageها نیازمند طراحی بیشتر باشد، اما از منظر معماری، boundary باید از همین Phase 2 صریح شود.

## 9.2 ماتریس مرز تراکنش‌ها

| Use Case | Service Owner | Write Scope | Boundary Rule |
|---|---|---|---|
| Create Draft Voucher | `VoucherApplicationService` | `Voucher` + `VoucherRow` + `AuditLog` | باید یک واحد منطقی واحد باشد |
| Update Draft Voucher | `VoucherApplicationService` | `Voucher` + `VoucherRow` + `AuditLog` | save draft باید atomic logical unit باشد |
| Approve Voucher | `VoucherApprovalService` | `Voucher` + `AuditLog` | status transition باید traceable باشد |
| Post Voucher | `VoucherPostingService` | `Voucher` + `JournalEntry` + `GeneralLedgerEntry` + `AuditLog` | posting باید واحد حسابداری واحد باشد |
| Reverse Voucher | `VoucherReversalService` | reversal `Voucher` + reversal `Rows` + `Journal` + `GL` + `AuditLog` | reversal chain باید شکست‌ناپذیر باشد |
| Delete Draft Voucher | `VoucherLifecycleService` | `Voucher` + `VoucherRow` + `AuditLog` | فقط روی draft مجاز |
| Customer Receipt | `CustomerReceiptService` | business receipt context + `Voucher` + `Rows` + `AuditLog` | business and accounting state باید converge کنند |
| Expert Settlement | `ExpertSettlementService` | settlement context + payable effect + `Voucher` + `Rows` + `AuditLog` | settlement و accounting split نباید diverge شوند |
| Treasury Deposit/Withdraw | `TreasuryTransactionService` | treasury context + `Voucher` + `Rows` + `AuditLog` | treasury event و voucher باید linked باشند |
| Treasury Transfer | `TreasuryTransferService` | transfer context + `Voucher` + `Rows` + `AuditLog` | from/to movement باید inseparable باشد |
| Create Payable | `PayableService` | `Payable` + `AuditLog` | business debt creation unit |
| Pay Payable | `PayablePaymentService` | `Payable` + treasury context + `Voucher` + `Rows` + `AuditLog` | payable state و accounting payment باید همگرا باشند |
| Create Installment Plan | `InstallmentPlanService` | `InstallmentPlan` + `InstallmentRow` + `AuditLog` | plan creation واحد باشد |
| Receive Installment | `InstallmentReceiptService` | `InstallmentRow` + `Voucher` + `Rows` + `AuditLog` | receipt state و accounting receipt باید linked باشند |
| Cheque Lifecycle Action | `ChequeAccountingService` | `Cheque` + optional `Voucher` + `Rows` + `AuditLog` | بسته به recognition point |
| Invoice to Voucher | `InvoiceAccountingService` | `Invoice` + `Voucher` + `Rows` + `AuditLog` | linkage باید traceable باشد |
| Fiscal Close Execute | `FiscalYearClosingService` | `FiscalYear` + `Lock` + `CV/OV Voucher` + `Rows` + `Journal` + `GL` + `AuditLog` | شدیدترین boundary |

## 9.3 ممنوعیت Transaction Boundary Ambiguity

معماری هدف اجازه نمی‌دهد:
- یک service فقط بخشی از writeها را انجام دهد و بقیه را به hookهای پنهان واگذار کند
- یک business action بدون transaction owner چند storage موازی را تغییر دهد
- traceability بعداً با heuristic matching بازسازی شود

---

# 10) Idempotency Policy

## 10.1 چرا idempotency لازم است؟

در سیستم مالی، عملیات تکراری می‌توانند باعث این خطاها شوند:
- سند تکراری
- دریافت تکراری
- پرداخت تکراری
- جابه‌جایی تکراری بین خزانه‌ها
- ثبت چندباره اسناد اتوماتیک از یک event واحد

## 10.2 قاعده‌ی canonical

هر operation مالی که ممکن است از:
- retry شبکه
- refresh UI
- cron
- webhook
- observer / hook
- کاربر دوبار کلیک‌کننده

تکرار شود، باید idempotency policy صریح داشته باشد.

## 10.3 منابع Idempotency Key

### A) Manual UI Commands
- `requestId`
- `clientCommandId`
- `actorId + timestamp bucket + business fingerprint`

### B) Domain Events / Automatic Flows
- `sourceType + sourceId + eventAction`

### C) External Integrations
- `providerEventId`
- `webhookDeliveryId`
- `importRowFingerprint`

## 10.4 Idempotency Rule Matrix

| Use Case | Idempotency Key پیشنهادی |
|---|---|
| Create Draft Voucher | `clientCommandId` |
| Post Voucher | `voucherId + action=post` |
| Reverse Voucher | `originalVoucherId + action=reverse` |
| Customer Receipt | `sourceType=receipt + sourceId` |
| Expert Settlement | `sourceType=expert_settlement + sourceId` |
| Treasury Deposit/Withdraw | `sourceType=treasury_tx + sourceId` |
| Treasury Transfer | `sourceType=treasury_transfer + sourceId` |
| Payable Payment | `sourceType=payable_payment + sourceId` |
| Installment Receipt | `sourceType=installment_receipt + sourceId` |
| Cheque Action | `sourceType=cheque_action + sourceId + action` |
| Invoice To Voucher | `sourceType=invoice + sourceId + action=to_voucher` |
| Fiscal Close Execute | `fiscalYearId + action=close_execute` |

## 10.5 Repository Support for Idempotency

Repository layer باید بتواند این نوع پرسش‌ها را پشتیبانی کند:
- آیا برای این business key قبلاً voucher ثبت شده؟
- آیا این sourceType/sourceId قبلاً post شده؟
- آیا این reversal قبلاً ایجاد شده؟

## 10.6 نکته‌ی مهم

در وضعیت فعلی، بخشی از همگام‌سازی از hookها و observerها می‌آید؛ بنابراین idempotency در فازهای بعد باید برای sync/event-based paths نیز اجباری شود.

---

# 11) Traceability Policy

## 11.1 اصل معماری

هر عدد مالی در dashboard، report یا statement باید در نهایت قابل ردیابی به این زنجیره باشد:

```text
Business Action
↓
Service Command
↓
Voucher
↓
VoucherRow
↓
JournalEntry
↓
GeneralLedgerEntry
↓
Report Row
```

## 11.2 فیلدهای Traceability Canonical

برای هر posted voucher حداقل این فیلدها باید قابل resolve باشند:
- `sourceType`
- `sourceId`
- `voucherType`
- `createdBy`
- `createdAt`
- `postedAt`
- `isAutoGenerated`
- `reversedVoucherId?`
- `fiscalYearId`
- `companyId`
- `branchId`

## 11.3 Traceability در سطح Row

برای هر `VoucherRow` باید حداقل این ابعاد قابل resolve باشند:
- `accountId`
- `projectId?`
- `partyId?`
- `partyRole?`
- `costCenterId?`
- `description`

## 11.4 Traceability در سطح Integration

اگر event از integration بیاید، فیلدهای زیر مطلوب هستند:
- `correlationId`
- `causationId`
- `externalProvider`
- `externalEventId`

> این فیلدها در storage فعلی لزوماً موجود نیستند، اما در contract معماری target لازم‌اند.

## 11.5 Traceability Rule Matrix

| سطح | باید به چه چیزی وصل شود |
|---|---|
| Dashboard KPI | Report row / read model |
| Report row | `GeneralLedgerEntry` یا `TrialBalanceRow` |
| Trial Balance row | `GeneralLedgerEntry` |
| GL entry | `JournalEntry` |
| Journal entry | `VoucherRow` |
| Voucher | `sourceType/sourceId` |
| sourceType/sourceId | business action / external trigger |

---

# 12) Dependency Rules بین Serviceها و Repositoryها

## 12.1 الگوی dependency مجاز

```text
Presentation
↓
Application Service
↓
Domain / Policy / Accounting Engine
↓
Repository
↓
Persistence
```

## 12.2 Dependencyهای مجاز

### مجاز است
- `VoucherApplicationService` → `VoucherRepository`
- `CustomerReceiptService` → `VoucherPostingService` یا posting policy
- `TrialBalanceReportService` → `GeneralLedgerRepository`
- `DashboardFinancialReadService` → reporting services/read repositories

### غیرمجاز است
- UI → Repository مستقیم
- Repository → UI
- Repository → Repository orchestration برای business workflow
- Report Service → mutate کردن voucher/ledger
- Legacy hook chain → owner service را دور بزند

## 12.3 Service-to-Service Rule

یک service فقط در این صورت می‌تواند service دیگر را صدا بزند که:
1. owner use case اصلی همچنان روشن بماند
2. circular dependency ایجاد نشود
3. orchestration ambiguity ایجاد نشود

### مثال مجاز
- `CustomerReceiptService` می‌تواند از posting contract استفاده کند

### مثال غیرمجاز
- `VoucherPostingService` برود و خودش business logic payable/receipt را تصمیم بگیرد

---

# 13) Use Case Ownership Matrix

| Use Case | Service Owner | Secondary Dependencies |
|---|---|---|
| Create Draft Voucher | `VoucherApplicationService` | `AccountRepository`, `FiscalLockPolicyService` |
| Update Draft Voucher | `VoucherApplicationService` | same |
| Submit For Approval | `VoucherApplicationService` | `VoucherApprovalService` policy integration |
| Approve Voucher | `VoucherApprovalService` | `AuditTrailService` |
| Post Voucher | `VoucherPostingService` | `JournalRepository`, `GeneralLedgerRepository` |
| Reverse Voucher | `VoucherReversalService` | `VoucherPostingService` logic/policy alignment |
| Delete Draft Voucher | `VoucherLifecycleService` | `AuditTrailService` |
| Unfinalize Voucher | `VoucherLifecycleService` | `FiscalLockPolicyService` |
| Register Customer Receipt | `CustomerReceiptService` | treasury/party/account mapping |
| Register Expert Settlement | `ExpertSettlementService` | payable/project/party mapping |
| Treasury Deposit/Withdraw | `TreasuryTransactionService` | treasury-account mapping |
| Treasury Transfer | `TreasuryTransferService` | treasury-account mapping |
| Create Payable | `PayableService` | party/project context |
| Pay Payable | `PayablePaymentService` | treasury + voucher posting |
| Create Installment Plan | `InstallmentPlanService` | party/project context |
| Receive Installment | `InstallmentReceiptService` | treasury + voucher posting |
| Cheque Registration/Action | `ChequeAccountingService` | party/treasury/voucher integration |
| Invoice To Voucher | `InvoiceAccountingService` | party/revenue/receivable mapping |
| Fiscal Close/Reopen | `FiscalYearClosingService` | GL/TB/account mapping |

---

# 14) Cross-Cutting Policy Services

## 14.1 AccountingMappingResolver

### نقش
تبدیل business event به account mapping رسمی.

### مثال‌ها
- customer receipt → receivable + treasury
- expert settlement → payable + treasury
- payable payment → supplier payable + treasury
- installment receipt → installment receivable + treasury

### نکته
این سرویس repository نیست؛ rule/policy service است.

---

## 14.2 FiscalLockPolicyService

### نقش
بررسی مجاز بودن write مالی با توجه به سال مالی و قفل دوره.

### باید enforce کند
- period open?
- fiscal year valid?
- close/reopen policy valid?

---

## 14.3 AuditTrailService

### نقش
استانداردسازی نوشتن audit records.

### باید ثبت کند
- actor
- actionType
- entityType
- entityId
- before/after snapshot
- createdAt

---

## 14.4 TraceabilityPolicyService

### نقش
تضمین اینکه هر voucher posted دارای source trace کامل باشد.

### باید enforce کند
- `sourceType` خالی نباشد
- `sourceId` خالی نباشد
- reversal linkage معتبر باشد
- correlation chain در صورت نیاز ثبت شود

---

## 14.5 DimensionResolverService

### نقش
resolve کردن dimensionهای row/header:
- project
- party
- cost center
- branch/company
- fiscal year

### دلیل نیاز
برای جلوگیری از duplicate logic در Serviceهای مختلف.

---

## 14.6 IdempotencyPolicyService

### نقش
تضمین non-duplication برای commandهای مالی.

### باید پاسخ دهد
- آیا این command قبلاً اعمال شده؟
- آیا voucher متناظر قبلاً ایجاد شده؟
- آیا retry مجاز است؟

---

# 15) Anti-Pattern Guardrails در Phase 2

## 15.1 Service Explosion Guardrail

### ریسک
تعداد سرویس‌ها زیاد شود اما مسئولیت‌ها نامشخص بماند.

### قاعده
هر سرویس باید:
- یک family از use caseها را own کند
- خروجی و boundary روشن داشته باشد
- aggregate owner روشن داشته باشد

## 15.2 God Service Guardrail

### ریسک
یک سرویس همه‌چیز را انجام دهد، مثلاً `FinanceService`.

### قاعده
Serviceهای generic و مبهم نباید owner دامنه شوند.

## 15.3 Repository-as-Service Guardrail

### ریسک
Repository شروع کند business logic اجرا کردن.

### قاعده
Repository فقط persistence contract است.

## 15.4 UI-Driven Workflow Guardrail

### ریسک
Workflow مالی در UI تعریف شود.

### قاعده
UI فقط command صادر می‌کند؛ تصمیم lifecycle در serviceهاست.

## 15.5 Hook-Orchestration Guardrail

### ریسک
orchestration اصلی همچنان در hook chainهای پنهان بماند.

### قاعده
hookها در معماری نهایی فقط adapter/integration trigger هستند، نه transaction owner.

---

# 16) Ambiguity Register برای Phase 2

## 16.1 JournalRepository persistence strategy
- آیا `JournalEntry` باید physical table داشته باشد؟
- یا derived repository کافی است؟
- **نتیجه:** نیاز به بررسی بیشتر در Phase 3

## 16.2 GeneralLedgerRepository persistence strategy
- آیا GL باید persisted append-only table داشته باشد؟
- یا derived read model کافی است؟
- **نتیجه:** نیاز به بررسی بیشتر در Phase 3

## 16.3 Party canonical identity strategy
- user-backed party و non-user-backed party چگونه unify شوند؟
- **نتیجه:** نیاز به بررسی بیشتر

## 16.4 Payment receipt operational boundary
- آیا receipt approval و accounting posting باید یک service باشند یا دو service با orchestration واحد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 16.5 Expert payable modeling
- expert settlement باید مستقیماً روی `Payable` model بنشیند یا expert-payable projection مستقل داشته باشد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 16.6 Cheque recognition points
- در کدام transition از cheque باید voucher ساخته شود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 16.7 Unfinalize policy
- سند finalized تا کجا و با چه محدودیتی می‌تواند unfinalize شود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 16.8 Multi-currency depth
- exchange rate در header کافی است یا row-level support لازم می‌شود؟
- **نتیجه:** نیاز به بررسی بیشتر

---

# 17) روش تست معماری Phase 2

## 17.1 Review Checklist

برای پذیرش این فاز باید این سوال‌ها پاسخ مثبت بگیرند:

1. آیا هر use case مالی service owner دارد؟
2. آیا هر aggregate owner repository دارد؟
3. آیا transaction boundary برای هر use case روشن است؟
4. آیا idempotency policy برای eventهای تکرارشونده تعریف شده؟
5. آیا traceability chain از business action تا report row تعریف شده؟
6. آیا dependencyهای غیرمجاز مشخص شده‌اند؟
7. آیا ambiguityها صریح ثبت شده‌اند؟

## 17.2 سناریوهای review معماری

### سناریو A — ثبت سند دستی
- service owner: `VoucherApplicationService`
- approval owner: `VoucherApprovalService`
- posting owner: `VoucherPostingService`

### سناریو B — دریافت مشتری
- service owner: `CustomerReceiptService`
- traceability: `sourceType=receipt`
- accounting effect: RV

### سناریو C — پرداخت کارشناس
- service owner: `ExpertSettlementService`
- accounting effect: PV

### سناریو D — انتقال خزانه
- service owner: `TreasuryTransferService`
- accounting effect: TV

### سناریو E — بستن سال مالی
- service owner: `FiscalYearClosingService`
- highest transaction boundary

---

# 18) ارزیابی انجام Taskهای Phase 2 نسبت به Roadmap

## 18.1 Taskهای Phase 2 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 2 شامل این موارد بود:
- تعریف Service Catalog نهایی
- تعریف Repository Catalog نهایی
- طراحی contract هر service و repository
- تعیین transaction boundary برای هر use case
- تعیین خط‌مشی idempotency
- تعیین خط‌مشی traceability

## 18.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| Service Catalog نهایی | ✅ انجام شد |
| Repository Catalog نهایی | ✅ انجام شد |
| Contract هر service | ✅ در سطح معماری انجام شد |
| Contract هر repository | ✅ در سطح معماری انجام شد |
| Transaction Boundaryها | ✅ انجام شد |
| Idempotency Policy | ✅ انجام شد |
| Traceability Policy | ✅ انجام شد |
| Ambiguity Register | ✅ انجام شد |

## 18.3 Definition of Done Phase 2

Phase 2 زمانی Done تلقی می‌شود که:
1. همه use caseهای مالی owner service داشته باشند ✅
2. همه aggregateهای اصلی repository owner داشته باشند ✅
3. transaction boundary هر use case ثبت شده باشد ✅
4. idempotency policy برای commandهای مالی تعریف شده باشد ✅
5. traceability policy برای voucher chains مشخص شده باشد ✅
6. review معماری/کسب‌وکار روی catalogها انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری**، Phase 2 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **تصویب نهایی اجرایی** هنوز نیازمند review تصمیم‌های ambiguity و alignment با فاز 3 است.

---

# 19) خروجی مورد انتظار برای Phase 3

Phase 3 باید مستقیماً بر اساس همین سند ادامه پیدا کند و این موارد را formalize کند:

1. Posting Pipeline نهایی
2. Draft vs Posted semantics
3. Journal generation policy
4. General Ledger generation policy
5. Reversal policy نهایی
6. Fiscal lock behavior در pipeline
7. Dimension propagation rules
8. Sequence استاندارد هر business action تا posting

## 19.1 وابستگی مستقیم Phase 3 به این سند
- owner serviceهای use caseها مشخص شد
- repository boundaryها مشخص شد
- idempotency و traceability سیاست‌گذاری شد
- transaction boundaryها تعریف شد
- dependencyهای مجاز/غیرمجاز روشن شد

---

# 20) جمع‌بندی نهایی Phase 2

مهم‌ترین خروجی Phase 2 این است که از این نقطه به بعد، هیچ use case مالی نباید «بی‌صاحب» تلقی شود.

### نتیجه‌های کلیدی
- هر عملیات مالی service owner مشخص دارد
- هر aggregate و read model repository owner مشخص دارد
- transaction boundaryها از حالت مبهم خارج شدند
- idempotency و traceability به‌عنوان الزام معماری رسمی شدند
- hook-based orchestration به‌عنوان anti-pattern شناسایی و محدود شد
- service layer و repository layer از هم تفکیک شدند

### جمع‌بندی نهایی
از این مرحله به بعد، معماری باید با این اصل ادامه پیدا کند:

```text
One Use Case
↓
One Service Owner
↓
One Transaction Boundary
↓
One Traceable Voucher Path
```

---

**پایان گزارش Phase 2**
