# WAVE_2_HOTFIX_8.5.7 — hash-refresh قطعی + reverse دقیق + رفرش خودکار بعد از write

> نسخه: **8.5.7** — تاریخ: 1405/04/18

## سه گزارش کاربر

1. **همه‌ی تب‌ها** (نه فقط ۳ تای سفارشی) هنگام refresh به داشبورد می‌روند
2. **سند برگشتی transfer قدیمی** هنوز موجودی را اصلاح نکرده
3. **بعد از انتقال جدید** سند تا refresh نمی‌آید، و بعد از reverse هم موجودی برنمی‌گردد

## اصلاحات ریشه‌ای

### 🎯 مسئله ۱: hash-refresh — روش قطعی از طریق patch باندل

روش‌های قبلی (findTabButton + click simulation + expand group) fragile بود چون:
- text matching حساس به فرمت
- روی موبایل sidebar بسته
- گروه‌های collapsed
- timing با mount شدن بندل

**راه‌حل قطعی v8.5.7:** به بندل patch می‌زنیم تا `setCurrentTab` React state directly on `window` expose شود:

```js
// در Pj (root component):
o.useEffect(()=>{
    window.__cpttErpSetTab = p;         // setCurrentTab
    window.__cpttErpCurrentTab = u;     // currentTab
}, [u, p]);
```

حالا در extras.js فقط `window.__cpttErpSetTab('cheques')` را صدا می‌زنیم — بندل دقیقاً همان چیزی می‌کند که با کلیک روی sidebar انجام می‌داد (شامل باز کردن گروه). ۱۰۰٪ قابل اعتماد است.

هم‌چنین برای hash tracking از polling ساده استفاده می‌کنیم: هر ۲۰۰ms مقدار `window.__cpttErpCurrentTab` را چک می‌کنیم؛ اگر عوض شد، hash را به‌روزرسانی می‌کنیم. سبک و درست.

### 🎯 مسئله ۲: سند برگشتی قدیمی

**علت مربوط به transferهای قدیمی:** `refId` در فرمت قبلی synthetic بود (`f * 1000000 + t`)، پس با هیچ ردیف واقعی در fin_ledger match نمی‌شد. تابع reverse نمی‌توانست ردیف اصلی را پیدا کند.

**اصلاح در ajax_treasury_transfer:** ابتدا fin_ledger rows می‌سازیم، سپس `refId = out_id` (id واقعی) در voucher قرار می‌گیرد. برای transferهای قدیمی که هنوز synthetic refId دارند، fallback query بر اساس `account_id + amount + نزدیکترین date` جفت را پیدا می‌کند و فقط یکی reverse می‌کند (نه همه).

**راهنمایی برای موجودی فعلی که قبلاً transfer اشتباهی داشتی که مجبور شدی manually reverse کنی:** موجودی الآن که با انتقال معکوس دستی درست شده، **نگهش دار** — سند برگشتی خودکار الآن روی transferهای جدید کار می‌کند. اگر بخواهی داده‌ی قدیمی cleanup شود، سند برگشتی قبلی که کار نکرد را (اگر می‌شود) به state DRAFT برگردان و حذف کن (یا صرفاً در توضیحاتش یادداشتی بگذار).

### 🎯 مسئله ۳: سند تازه بدون refresh نمی‌آمد + reverse خالی می‌ماند

**علت:** بعد از AJAX write ما، بندل React از state cache شده استفاده می‌کند. rerender این تب مشکل را حل نمی‌کند چون داده‌ی زیرین (`vouchers`, `treasuryAccounts`, ...) در Context تازه نشده.

**اصلاح:** بندل patched حالا `refreshAll` (که همان `bootstrap fetch` است) را روی `window.__cpttErpRefreshAll` قرار می‌دهد:

```js
Il = async () => { vt() && await lt() };
window.__cpttErpRefreshAll = Il;
```

در `ajaxPost` بعد از هر write موفق، این را صدا می‌زنیم. نتیجه:
- انتقال جدید → سند بلافاصله در «اسناد حسابداری» ظاهر می‌شود
- reverse voucher → موجودی حساب‌ها بلافاصله در «صندوق‌ها و حساب‌ها» به‌روز می‌شود
- ledger و همه گزارش‌ها همگام می‌شوند

## فایل‌های تغییریافته

| فایل | تغییر |
|---|---|
| `assets/finance-ui/app.js` | patch: expose `__cpttErpSetTab`، `__cpttErpCurrentTab`، `__cpttErpRefreshAll` روی window |
| `assets/js/cptt-erp-extras.js` | استفاده مستقیم از React state via window handles، polling برای hash sync، رفرش خودکار بعد از هر AJAX write |
| `includes/class-cptt-finance-erp.php` | `ajax_treasury_transfer`: ابتدا fin_ledger سپس voucher با `refId = out_id`؛ `reverse_treasury_fin_ledger_effects` با فرمت جدید + fallback برای فرمت قدیمی |
| `client-project-tracker.php` | بامپ نسخه به 8.5.7 |

## پس از نصب

1. **رفرش:** هر تب که رویش هستی، F5 بزن → همان تب باقی می‌ماند ✓
2. **انتقال جدید:** ثبت کن → بدون رفرش، «اسناد حسابداری» را ببین → سند TV باید باشد ✓
3. **برگشت انتقال جدید:** روی سند «برگشت» بزن → بدون رفرش موجودی حساب‌ها اصلاح می‌شود ✓

اگر مورد ۳ برای transferهای **قدیم‌تر از v8.5.7** کار نکرد، به این دلیل است که آنها refId synthetic دارند. راه دستی: یک انتقال معکوس ثبت کن (که هم موجودی درست می‌شود و هم سند TV جدید ثبت می‌گردد).
