# PHASE_3_REPORT

> Phase 3 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`  
> Mode: **No code change / No behavior change / Voucher-First Posting Pipeline Design only**

---

# 0) هدف این گزارش

این سند، شروع اجرایی **Phase 3 — Voucher-First Posting Pipeline Design** است و فقط روی این موارد تمرکز دارد:

1. تعریف **Posting Pipeline** رسمی و استاندارد
2. تعیین تفاوت دقیق **Draft Voucher** و **Posted/Finalized Voucher**
3. تعریف جایگاه رسمی **Journal**
4. تعریف جایگاه رسمی **General Ledger**
5. تعیین سیاست **Reversal**
6. تعیین سیاست **Unfinalize / Reopen**
7. تعیین سیاست **Fiscal Period Locking** در طول pipeline
8. تعیین سیاست **Dimension Propagation**
9. تعیین sequence استاندارد برای use caseهای اصلی مالی
10. ثبت ambiguityها و تصمیم‌های باز برای فازهای بعدی

> این سند عمداً هیچ تغییری در کد، schema، query، migration یا رفتار runtime ایجاد نمی‌کند.

---

# 1) وضعیت شروع Phase 3

## 1.1 مبنای شروع

Phase 3 بر اساس این artefactها ادامه پیدا می‌کند:
- `ACCOUNTING_SYSTEM_ANALYSIS.md`
- `ERP_ARCHITECTURE.md`
- `ERP_REFACTOR_ROADMAP.md`
- `PHASE_0_REPORT.md`
- `PHASE_1_REPORT.md`
- `PHASE_2_REPORT.md`

## 1.2 وابستگی به Phase 2

طبق Roadmap، Phase 3 وابسته به Phase 2 است.  
از آنجا که در `PHASE_2_REPORT.md` این موارد مشخص شده‌اند:
- service owner هر use case
- repository owner هر aggregate
- transaction boundaryها
- idempotency policy
- traceability policy

این Phase 3 می‌تواند pipeline واقعی target architecture را روی همان foundation تعریف کند.

## 1.3 وضعیت نسخه و زیپ

این artefact صرفاً مستنداتی است و هیچ تغییر کدی در افزونه ایجاد نمی‌کند؛ بنابراین در این مرحله:
- version bump انجام نشده
- zip نصبی جدید ساخته نشده

---

# 2) اصل بنیادین Posting Pipeline

## 2.1 اصل اصلی

در معماری هدف، **تمام رویدادهای مالی باید از یک مسیر استاندارد عبور کنند**:

```text
Business Action
↓
Application Service
↓
Accounting Mapping Resolution
↓
Voucher Draft
↓
Validation
↓
Approval (if required)
↓
Posting
↓
Journal
↓
General Ledger
↓
Trial Balance
↓
Financial Statements / Read Models
```

## 2.2 قاعده‌ی طلایی

هیچ رویداد مالی مجاز نیست:
- مستقیم report را تغییر دهد
- مستقیم dashboard را تغییر دهد
- مستقیم Journal بسازد بدون Voucher
- مستقیم GL بسازد بدون Voucher
- مستقیم receivable/payable final state بسازد بدون accounting posting

## 2.3 معیار پذیرش معماری

Pipeline زمانی استاندارد تلقی می‌شود که:
1. هر event فقط **یک مسیر حسابداری رسمی** داشته باشد
2. هر سند posted قابل ردیابی به `sourceType/sourceId` باشد
3. هر row journal قابل ردیابی به `VoucherRow` باشد
4. هر GL entry قابل ردیابی به Journal/Voucher باشد
5. هر گزارش فقط از خروجی‌های رسمی pipeline تغذیه شود

---

# 3) تعریف رسمی Pipeline Stages

## 3.1 نمای کلی مراحل

Pipeline استاندارد در Phase 3 به 10 مرحله canonical شکسته می‌شود:

1. `Command Acceptance`
2. `Business Context Resolution`
3. `Accounting Mapping Resolution`
4. `Draft Voucher Construction`
5. `Draft Validation`
6. `Approval Workflow`
7. `Posting Authorization`
8. `Journal Generation`
9. `General Ledger Generation`
10. `Reporting Projection Refresh Trigger`

## 3.2 مرحله 1 — Command Acceptance

### ورودی
- command از UI / API / cron / hook adapter / integration

### مسئول
- service owner use case

### خروجی
- command canonicalized
- actor resolved
- idempotency key resolved

### قواعد
- command باید owner service مشخص داشته باشد
- actor باید قابل resolve باشد
- تکراری بودن command باید بررسی شود

---

## 3.3 مرحله 2 — Business Context Resolution

### هدف
resolve کردن context عملیاتی قبل از ساخت سند.

### مثال‌ها
- customer receipt → customer / project / treasury account
- expert settlement → expert / step / project / amount
- payable payment → payable / treasury account / party
- installment receipt → installment row / customer / project

### مسئول
- use-case service مربوطه

### خروجی
- business context canonical

---

## 3.4 مرحله 3 — Accounting Mapping Resolution

### هدف
تبدیل business context به mapping حسابداری.

### مسئول
- `AccountingMappingResolver`

### خروجی
- debit account(s)
- credit account(s)
- voucher type
- dimension hints

### نکته
هر use case مالی باید در این مرحله تعیین کند که:
- این event از نظر حسابداری چه ماهیتی دارد
- در کدام حساب‌ها ثبت می‌شود
- چه dimensionهایی باید روی rowها propagate شوند

---

## 3.5 مرحله 4 — Draft Voucher Construction

### هدف
ساخت `Voucher` و `VoucherRow` در وضعیت draft یا pre-post state.

### مسئول
- `VoucherApplicationService` یا business service مربوطه

### خروجی
- voucher header
- voucher rows
- source trace fields
- lifecycle metadata

### نکته
در معماری هدف، حتی اسناد auto-generated نیز باید از همین مرحله عبور کنند؛ فقط UI-originated manual نیستند.

---

## 3.6 مرحله 5 — Draft Validation

### هدف
بررسی صحت حسابداری و دامنه‌ای سند قبل از posting.

### انواع validation
- debit == credit
- account valid
- account active
- dimensions valid
- fiscal year valid
- period unlocked
- amount positive/allowed
- duplicate prevention
- source trace completeness

### مسئول
- `VoucherApplicationService`
- `VoucherPostingService`
- policy services

---

## 3.7 مرحله 6 — Approval Workflow

### هدف
اعمال workflow approval در صورت نیاز business/policy.

### حالت‌ها
- manual voucher ممکن است approval chain داشته باشد
- بعضی auto-generated vouchers ممکن است bypass policy خاص داشته باشند
- bypass rules در وضعیت فعلی **نیاز به بررسی بیشتر** دارند

### مسئول
- `VoucherApprovalService`

---

## 3.8 مرحله 7 — Posting Authorization

### هدف
آخرین checkpoint قبل از ایجاد آثار حسابداری رسمی.

### مسئول
- `VoucherPostingService`

### باید بررسی کند
- سند eligible برای posting هست؟
- approvalهای لازم کامل‌اند؟
- fiscal period هنوز باز است؟
- reversal/unfinalize conflict ندارد؟
- idempotent duplicate posting رخ نداده؟

---

## 3.9 مرحله 8 — Journal Generation

### هدف
تبدیل posted voucher rows به `JournalEntry`های رسمی.

### مسئول
- `VoucherPostingService`
- `JournalRepository`

### قاعده
در مدل canonical فعلی:
- هر `VoucherRow` ↔ یک `JournalEntry`
- Journal مدل مشتق‌شده از posted rows است

---

## 3.10 مرحله 9 — General Ledger Generation

### هدف
تولید `GeneralLedgerEntry`ها به‌عنوان لایه‌ی رسمی مانده‌گیری.

### مسئول
- `VoucherPostingService`
- `GeneralLedgerRepository`

### قاعده
- GL فقط از Journal / Posted VoucherRows ساخته می‌شود
- GL محل رسمی محاسبه مانده حساب‌هاست

---

## 3.11 مرحله 10 — Reporting Projection Refresh Trigger

### هدف
اعلام اینکه read modelها و report layer باید بر اساس posting جدید refresh شوند.

### خروجی‌های هدف
- Trial Balance
- Income Statement
- Balance Sheet
- Cash Flow
- Aging
- Dashboard Financial Snapshot
- Project Financial Snapshot
- Party Financial Views

### نکته
در Phase 3 فقط trigger/contract طراحی می‌شود؛ strategy نهایی materialization در Phase 4 formalize خواهد شد.

---

# 4) Draft Voucher vs Posted/Finalized Voucher

## 4.1 تعریف Draft Voucher

`Draft Voucher` سندی است که:
- ساخته شده ولی هنوز مرجع نهایی reportهای رسمی نیست
- هنوز Journal/GL نهایی برای آن تثبیت نشده
- ممکن است edit/delete شود طبق policy
- ممکن است approval chain را طی نکرده باشد

## 4.2 تعریف Posted/Finalized Voucher

`Posted/Finalized Voucher` سندی است که:
- validation نهایی را گذرانده
- approvalهای لازم را دریافت کرده یا bypass policy معتبر دارد
- در period مجاز ثبت شده
- آثار حسابداری رسمی آن در Journal و GL ایجاد شده
- باید منبع reportهای رسمی باشد

## 4.3 قاعده‌ی canonical فعلی

با توجه به تحلیل فعلی پروژه:
- `FINALIZED` نزدیک‌ترین معادل posted است
- status مستقل `POSTED` در کد فعلی **نامشخص** است

### نتیجه Phase 3
تا وقتی status machine رسمی جدید طراحی و پیاده‌سازی نشده، در معماری target این قاعده مرجع است:

```text
FINALIZED = Posted Accounting State
```

## 4.4 جدول مقایسه

| ویژگی | Draft Voucher | Posted/Finalized Voucher |
|---|---|---|
| editable | بله، طبق policy | خیر، مگر unfinalize policy مجاز |
| deletable | بله، طبق policy | خیر |
| report source رسمی | خیر | بله |
| journal generation | خیر | بله |
| GL generation | خیر | بله |
| trial balance impact | خیر | بله |
| P&L / BS impact | خیر | بله |
| reversal required for correction | خیر | بله، در حالت استاندارد |

## 4.5 قاعده‌ی اصلاح سند

در معماری هدف:
- **سند Draft** با edit/delete اصلاح می‌شود
- **سند Posted/Finalized** با reversal یا unfinalize policy اصلاح می‌شود

---

# 5) تعریف رسمی Journal

## 5.1 جایگاه Journal در معماری هدف

`Journal` باید به‌عنوان **اولین لایه‌ی رسمی بعد از posting** شناخته شود.

### تعریف canonical
`JournalEntry` = تجلی posted accounting line در دفتر روزنامه

## 5.2 رابطه با Voucher

در وضعیت canonical فعلی:

```text
Voucher 1 → N VoucherRow
VoucherRow 1 ↔ 1 JournalEntry
```

## 5.3 قواعد رسمی Journal

1. Journal فقط از `Posted VoucherRow` ساخته می‌شود
2. Journal نباید freehand و مستقل از voucher باشد
3. Journal باید تاریخ posting، حساب، بدهکار، بستانکار و dimensions را حفظ کند
4. Journal باید traceable به `voucherId` و `voucherRowId` باشد

## 5.4 Journal materialization strategy

در مورد اینکه Journal باید table فیزیکی باشد یا derived store:
- **نیاز به بررسی بیشتر**
- اما در هر حالت، contract دامنه‌ای آن باید رسمی و پایدار باشد

## 5.5 نتیجه Phase 3

حتی اگر Journal فیزیکی نشود، معماری target باید آن را به‌عنوان یک **accounting model صریح** بپذیرد، نه صرفاً UI flattening.

---

# 6) تعریف رسمی General Ledger

## 6.1 جایگاه GL در معماری هدف

`GeneralLedgerEntry` باید به‌عنوان **موتور رسمی مانده‌گیری حسابداری** تعریف شود.

## 6.2 رابطه با Journal

در canonical model فعلی:

```text
JournalEntry 1 ↔ 1 GeneralLedgerEntry
```

> این نسبت در سطح design فعلی 1↔1 در نظر گرفته شده، مگر اینکه در پیاده‌سازی بعدی نیاز به granularity متفاوت ایجاد شود.

## 6.3 وظایف GL

GL باید مبنای رسمی این موارد باشد:
- account running balance
- account closing balance
- subsidiary slicing by dimensions
- trial balance base
- receivable/payable balances
- treasury-linked accounting balances

## 6.4 قواعد رسمی GL

1. GL فقط از Journal یا Posted VoucherRows ساخته می‌شود
2. GL باید append-oriented و traceable باشد
3. GL نباید از `_cptt_steps` یا legacy ledgerها تغذیه شود
4. تمام مانده‌های رسمی حسابداری باید از GL بیایند

## 6.5 GL materialization strategy

اینکه GL باید persisted physical table باشد یا derived append model:
- **نیاز به بررسی بیشتر**
- اما از منظر معماری، GL باید **source رسمی report balance-based** باشد

---

# 7) Validation Stack در Posting Pipeline

## 7.1 دسته‌بندی Validationها

Validationهای pipeline به 6 دسته تقسیم می‌شوند:

1. Command Validation
2. Business Validation
3. Accounting Validation
4. Master Data Validation
5. Fiscal Validation
6. Trace/Idempotency Validation

## 7.2 Command Validation

### موارد
- command shape معتبر است
- actor قابل resolve است
- request duplicate غیرمجاز نیست

## 7.3 Business Validation

### نمونه‌ها
- payable موجود است و amount مجاز دارد
- installment row قابل دریافت است
- expert settlement روی step معتبر اعمال می‌شود
- invoice قابل تبدیل به voucher است

## 7.4 Accounting Validation

### موارد
- debit == credit
- rows empty نیستند
- amountها منفی نیستند مگر policy خاص
- voucherType با business action سازگار است
- reversal voucher با original سازگار است

## 7.5 Master Data Validation

### موارد
- account exists
- account active
- treasury account valid
- cost center valid
- party resolvable
- fiscal year exists

## 7.6 Fiscal Validation

### موارد
- posting date در fiscal year معتبر است
- period قفل نیست
- close/reopen policy نقض نشده

## 7.7 Trace/Idempotency Validation

### موارد
- `sourceType` وجود دارد
- `sourceId` وجود دارد
- duplicate posting برای همان business key رخ نداده
- reversal قبلاً برای همان original به‌صورت conflict ایجاد نشده

---

# 8) Approval Workflow در Pipeline

## 8.1 اصل کلی

Approval workflow باید **پیش از posting نهایی** کامل شود، مگر در مواردی که policy معافیت داشته باشد.

## 8.2 مسیر canonical فعلی

بر اساس Phase 1:

```text
DRAFT
↓
ACCOUNTANT_APPROVED
↓
MANAGER_APPROVED
↓
FINALIZED
```

## 8.3 Approval와 Posting

در معماری target، `FINALIZED` باید فقط وقتی اعمال شود که posting authorization موفق باشد.

### نتیجه
approval chain نباید فقط status ظاهری باشد؛ باید به posting pipeline متصل شود.

## 8.4 Auto-generated voucherها

در مورد اینکه آیا اسناد auto-generated باید همه مراحل approval را طی کنند یا نه:
- **نیاز به بررسی بیشتر**
- فعلاً فقط این rule تثبیت می‌شود که bypass اگر وجود دارد، باید **policy-driven و audit-traceable** باشد

---

# 9) Reversal Policy

## 9.1 اصل معماری

اصلاح سند posted باید به‌صورت استاندارد از مسیر **Reversal** انجام شود، نه delete/edit خاموش.

## 9.2 تعریف Reversal

`Reversal` یعنی:
- ایجاد یک Voucher جدید
- با rowهایی که اثر حسابداری original را خنثی می‌کنند
- با linkage صریح به original voucher

## 9.3 قواعد Reversal

1. original voucher نباید silently حذف شود
2. reversing voucher باید traceable به original باشد
3. reversal باید audit trail کامل داشته باشد
4. reversal باید از fiscal/lock policy عبور کند
5. reversal نیز باید Journal و GL رسمی خود را داشته باشد

## 9.4 مدل رابطه

```text
Original Voucher
↓ linked by reversedVoucherId / reversal linkage
Reversal Voucher
```

## 9.5 Reversal Date Policy

در مورد اینکه reversal باید:
- در همان تاریخ باشد
- در تاریخ روز باشد
- یا در اولین period باز بعدی باشد

وضعیت فعلی: **نیاز به بررسی بیشتر**

## 9.6 Reversal vs Unfinalize

### Reversal
- مسیر استاندارد و audit-safe برای سند posted

### Unfinalize
- یک policy استثنایی/کنترلی
- نباید مسیر اصلی اصلاح اسناد باشد

---

# 10) Unfinalize / Reopen Policy

## 10.1 اصل کلی

`Unfinalize` باید در معماری نهایی یک action استثنایی و policy-driven باشد، نه رفتار پیش‌فرض روزمره.

## 10.2 موارد مجاز احتمالی

فقط در صورت وجود policy معتبر، مثلاً:
- سند در همان period باز است
- downstream close/reports هنوز lock نشده‌اند
- نقش کاربر مجاز است
- سند reversal نشده است

## 10.3 موارد غیرمجاز احتمالی

- period بسته شده
- fiscal year close انجام شده
- voucher مبنای زنجیره‌های بعدی شده
- audit policy اجازه نمی‌دهد

## 10.4 نتیجه Phase 3

`Unfinalize` به‌عنوان service owner در Phase 2 مشخص شده، اما rule نهایی آن هنوز:
- **نیاز به بررسی بیشتر**

### با این حال، قاعده‌ی معماری این فاز روشن است:
- Unfinalize باید **استثنا** باشد
- Reversal باید **قاعده‌ی پیش‌فرض اصلاح سند posted** باشد

---

# 11) Fiscal Period Locking Policy در Pipeline

## 11.1 اصل اصلی

هیچ write مالی posted نباید در period قفل‌شده انجام شود.

## 11.2 نقاط enforce شدن lock

Lock policy باید حداقل در این نقاط enforce شود:
- create draft? بستگی به policy، نیاز به بررسی بیشتر
- update draft? بستگی به policy، نیاز به بررسی بیشتر
- approval before post
- posting
- reversal
- unfinalize
- fiscal close / reopen

## 11.3 قاعده‌ی حداقلی Phase 3

در این فاز این قواعد تثبیت می‌شوند:
1. posting در period lock ممنوع است
2. reversal در period lock ممنوع است مگر policy خاص بازگشایی وجود داشته باشد
3. fiscal close باید periodهای مربوطه را lock کند
4. reopen باید lock state را صریح و audit-traceable تغییر دهد

## 11.4 Lock Check Contract

هر service مرتبط با posting باید قبل از write نهایی بتواند این سوال را بپرسد:

```text
Is this accounting date allowed for posting under current fiscal lock policy?
```

### owner policy
- `FiscalLockPolicyService`

---

# 12) Dimension Propagation Policy

## 12.1 اصل کلی

Dimensionها باید از business context به voucher و سپس به journal و GL **به‌صورت deterministic** propagate شوند.

## 12.2 Dimensionهای canonical

### Header-level
- `companyId`
- `branchId`
- `fiscalYearId`
- `currencyCode`
- `exchangeRate`
- `sourceType`
- `sourceId`

### Row-level
- `projectId`
- `partyId`
- `partyRole`
- `costCenterId`

## 12.3 قاعده‌ی propagation

```text
Business Context
↓
Voucher Header / Voucher Rows
↓
JournalEntry.dimensions
↓
GeneralLedgerEntry.dimensions
↓
Report Filters / Segmentations
```

## 12.4 Rules

1. header dimensions باید روی همه rowهای مربوطه قابل resolve باشند
2. row dimensions نباید در Journal/GL گم شوند
3. dimensionها attribute هستند، نه source جایگزین حقیقت
4. reportها باید از dimensionها برای slicing استفاده کنند، نه محاسبه از sourceهای موازی

## 12.5 Mapping rules

### customer/expert → party
در target:
- `customerId` / `expertId` باید به `partyId + partyRole` canonical شوند

### project
- اگر event project-bound باشد، `projectId` باید propagate شود
- اگر event project-bound نباشد، `projectId` خالی مجاز است

### cost center
- بسته به business action یا mapping، optional/required می‌شود
- rule دقیق required بودن برای همه use caseها: **نیاز به بررسی بیشتر**

---

# 13) Sequence استاندارد برای use caseهای اصلی

## 13.1 سناریو A — ثبت سند دستی

```text
User
↓
VoucherApplicationService.createDraft()
↓
Draft Validation
↓
VoucherApprovalService.approve() [if workflow enabled]
↓
VoucherPostingService.post()
↓
JournalRepository.append()
↓
GeneralLedgerRepository.append()
↓
Report Refresh Trigger
```

### Voucher Type
- معمولاً `JV`

### نکته
در این سناریو business context ساده‌تر است و mapping بیشتر user-selected است.

---

## 13.2 سناریو B — دریافت از مشتری

```text
Business Command: Register Customer Receipt
↓
CustomerReceiptService
↓
Resolve party/project/treasury context
↓
AccountingMappingResolver
↓
Construct RV Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Receivable/Project/Dashboard read model refresh trigger
```

### Voucher Type
- `RV`

### حداقل dimensions مورد انتظار
- `partyId`
- `partyRole=customer`
- `projectId?`
- `costCenterId?`

---

## 13.3 سناریو C — تسویه کارشناس

```text
Business Command: Register Expert Settlement
↓
ExpertSettlementService
↓
Resolve expert/project/step/payable context
↓
AccountingMappingResolver
↓
Construct PV Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Expert payable / project read model refresh trigger
```

### Voucher Type
- `PV`

### dimensions مورد انتظار
- `partyId`
- `partyRole=expert`
- `projectId`
- `costCenterId?`

---

## 13.4 سناریو D — پرداخت بدهی

```text
Business Command: Pay Payable
↓
PayablePaymentService
↓
Resolve payable/party/treasury context
↓
AccountingMappingResolver
↓
Construct PV Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Payable read model refresh trigger
```

### Voucher Type
- `PV`

---

## 13.5 سناریو E — دریافت قسط

```text
Business Command: Receive Installment
↓
InstallmentReceiptService
↓
Resolve installment/customer/project/treasury context
↓
AccountingMappingResolver
↓
Construct RV Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Installment / receivable read model refresh trigger
```

### Voucher Type
- `RV`

---

## 13.6 سناریو F — انتقال خزانه

```text
Business Command: Treasury Transfer
↓
TreasuryTransferService
↓
Resolve from/to treasury accounts
↓
AccountingMappingResolver
↓
Construct TV Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Treasury read model refresh trigger
```

### Voucher Type
- `TV`

### نکته
از نظر accounting، این سناریو نباید net balance کل خزانه را تغییر دهد؛ فقط ترکیب حساب‌ها را تغییر می‌دهد.

---

## 13.7 سناریو G — درآمد/هزینه مستقیم خزانه

```text
Business Command: Treasury Income/Expense
↓
TreasuryTransactionService
↓
Resolve treasury + counter account mapping
↓
Construct RV/PV or domain-mapped voucher
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Cash flow / P&L refresh trigger
```

### Voucher Type
- بسته به mapping: `RV` یا `PV` یا معادل policy-driven
- rule دقیق برای همه حالت‌ها: **نیاز به بررسی بیشتر**

---

## 13.8 سناریو H — فاکتور به سند

```text
Business Command: Invoice To Voucher
↓
InvoiceAccountingService
↓
Resolve invoice/customer/project/revenue mapping
↓
Construct Voucher Draft
↓
Validate
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Invoice linkage + receivable/report refresh trigger
```

### Voucher Type
- بسته به recognition policy: **نیاز به بررسی بیشتر**

---

## 13.9 سناریو I — بستن سال مالی

```text
Business Command: Execute Fiscal Close
↓
FiscalYearClosingService
↓
Resolve fiscal year + balances + retained earnings mapping
↓
Construct CV/OV Draft(s)
↓
Validate
↓
Post CV/OV
↓
Journal
↓
General Ledger
↓
Lock periods / update fiscal year status
↓
Refresh statement-level read models
```

### Voucher Type
- `CV`
- `OV`

### نکته
این سناریو شدیدترین transaction boundary را دارد و نیازمند کنترل بیشتر در فازهای بعدی است.

---

# 14) Idempotency در Posting Pipeline

## 14.1 اصل کلی

posting باید idempotent باشد.  
یعنی retry یک command نباید باعث ایجاد چند voucher posted برای یک business action شود.

## 14.2 نقاط enforce

Idempotency باید حداقل در این نقاط enforce شود:
- business command acceptance
- before draft creation for auto-generated flows
- before posting
- before reversal
- before fiscal close execute

## 14.3 Business Key Rule

Pipeline باید بتواند تشخیص دهد:

```text
Have we already created/post this voucher for this sourceType/sourceId/action?
```

## 14.4 نمونه‌ها

| Use Case | canonical business key |
|---|---|
| customer receipt | `receipt:{sourceId}` |
| expert settlement | `expert_settlement:{sourceId}` |
| payable payment | `payable_payment:{sourceId}` |
| installment receipt | `installment_receipt:{sourceId}` |
| treasury transfer | `treasury_transfer:{sourceId}` |
| reversal | `reverse:{originalVoucherId}` |
| fiscal close | `fiscal_close:{fiscalYearId}` |

---

# 15) Traceability در Pipeline

## 15.1 اصل trace chain

Pipeline باید این chain را حفظ کند:

```text
Command
↓
Service Owner
↓
Voucher
↓
VoucherRow
↓
JournalEntry
↓
GeneralLedgerEntry
↓
Report / KPI
```

## 15.2 Traceability Required Fields

### در Voucher
- `sourceType`
- `sourceId`
- `voucherType`
- `isAutoGenerated`
- `createdBy`
- `createdAt`
- `postedAt`
- `fiscalYearId`

### در VoucherRow / Journal / GL
- `accountId`
- `projectId?`
- `partyId?`
- `partyRole?`
- `costCenterId?`

## 15.3 Reversal Traceability

Reversal باید این chain را نیز داشته باشد:

```text
Original Voucher
↕
Reversal Voucher
```

و این رابطه نباید heuristic یا حدسی باشد.

---

# 16) Failure Handling و Rollback Logic در Pipeline Design

## 16.1 اصل طراحی

اگر posting در هر مرحله شکست بخورد، سیستم نباید state نیمه‌تمام و غیرقابل‌ردیابی تولید کند.

## 16.2 failure classes

### A) قبل از ساخت draft
- command rejected
- no accounting state

### B) بعد از ساخت draft و قبل از posting
- draft می‌ماند یا reject می‌شود
- no journal / no GL

### C) حین posting
- باید atomic logical failure تلقی شود
- voucher نباید posted محسوب شود مگر journal/GL chain معتبر شده باشد

### D) بعد از posting و قبل از report refresh
- accounting state معتبر است
- reporting lag ممکن است وجود داشته باشد
- report refresh باید recoverable باشد

## 16.3 Rollback Rule

در فاز design این قاعده تثبیت می‌شود:
- rollback واقعی برای سند posted نباید از طریق delete خاموش انجام شود
- rollback business effect باید از طریق reversal یا controlled unfinalize انجام شود

---

# 17) Policy Matrix برای Voucher Typeها

## 17.1 Voucher Type Canonical Meanings

| Voucher Type | معنای canonical |
|---|---|
| `JV` | Journal Voucher / سند عمومی |
| `RV` | Receipt Voucher / سند دریافت |
| `PV` | Payment Voucher / سند پرداخت |
| `TV` | Transfer Voucher / سند انتقال |
| `CV` | Closing Voucher / سند اختتامیه |
| `OV` | Opening Voucher / سند افتتاحیه |

## 17.2 Mapping نمونه‌ی use caseها

| Use Case | Voucher Type target |
|---|---|
| Manual accounting document | `JV` |
| Customer receipt | `RV` |
| Installment receipt | `RV` |
| Treasury deposit of business receipt | `RV` |
| Expert settlement | `PV` |
| Payable payment | `PV` |
| Treasury withdrawal / expense | `PV` |
| Treasury transfer | `TV` |
| Fiscal close | `CV` |
| Fiscal opening | `OV` |
| Invoice to voucher | نیاز به بررسی بیشتر |

---

# 18) Ambiguity Register برای Phase 3

## 18.1 Journal physical persistence
- آیا Journal باید table رسمی جدا داشته باشد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.2 GL physical persistence
- آیا General Ledger باید table append-only رسمی داشته باشد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.3 Auto-generated voucher approval bypass
- کدام auto vouchers approval chain را bypass می‌کنند؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.4 Exact posting state naming
- آیا `FINALIZED` کافی است یا `POSTED` status رسمی جدا لازم است؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.5 Reversal date rule
- reversal date policy دقیق چیست؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.6 Unfinalize strictness
- تا چه حد unfinalize باید محدود یا ممنوع شود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.7 Invoice recognition policy
- invoice در چه لحظه‌ای به accounting effect رسمی تبدیل می‌شود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.8 Direct income/expense voucher typing rule
- برای همه transaction typeها type دقیق سند باید چگونه استاندارد شود؟
- **نتیجه:** نیاز به بررسی بیشتر

## 18.9 Cost center requiredness
- آیا cost center برای همه postingها optional است یا بعضی use caseها required؟
- **نتیجه:** نیاز به بررسی بیشتر

---

# 19) روش تست معماری Phase 3

## 19.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا pipeline رسمی end-to-end تعریف شده است؟
2. آیا Draft و Posted به‌وضوح از هم جدا شده‌اند؟
3. آیا جایگاه Journal و GL رسمی شده است؟
4. آیا reversal policy مشخص شده است؟
5. آیا unfinalize به‌عنوان exception تعریف شده است؟
6. آیا fiscal lock enforcement pointها مشخص شده‌اند؟
7. آیا dimension propagation rule ثبت شده است؟
8. آیا sequence use caseهای اصلی تعریف شده است؟
9. آیا idempotency و traceability به pipeline متصل شده‌اند؟
10. آیا ambiguityها صریح ثبت شده‌اند؟

## 19.2 Walkthrough سناریوها

باید روی این سناریوها walkthrough معماری انجام شود:
- ثبت سند دستی
- دریافت مشتری
- تسویه کارشناس
- پرداخت بدهی
- دریافت قسط
- انتقال خزانه
- درآمد/هزینه مستقیم
- فاکتور به سند
- بستن سال مالی

---

# 20) ارزیابی انجام Taskهای Phase 3 نسبت به Roadmap

## 20.1 Taskهای Phase 3 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 3 شامل این موارد بود:
- تعریف مراحل رسمی pipeline
- تعیین تفاوت Draft vs Posted Voucher
- تعریف Journal به‌عنوان read/store model رسمی
- تعریف General Ledger به‌عنوان ledger حسابداری نهایی
- تعریف policy رسمی برای reversals
- تعریف policy رسمی برای unfinalize/reopen behavior
- تعریف policy رسمی برای fiscal period locking
- تعریف policy رسمی برای dimension propagation

## 20.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| تعریف مراحل رسمی pipeline | ✅ انجام شد |
| تعیین Draft vs Posted | ✅ انجام شد |
| تعریف جایگاه رسمی Journal | ✅ انجام شد |
| تعریف جایگاه رسمی GL | ✅ انجام شد |
| policy رسمی reversals | ✅ انجام شد |
| policy unfinalize/reopen | ✅ در سطح معماری انجام شد |
| policy fiscal locking | ✅ انجام شد |
| policy dimension propagation | ✅ انجام شد |
| sequence use caseهای اصلی | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 20.3 Definition of Done Phase 3

Phase 3 زمانی Done تلقی می‌شود که:
1. برای هر event مالی یک sequence استاندارد از business action تا posting تعریف شده باشد ✅
2. جایگاه رسمی Journal و GL مشخص شده باشد ✅
3. تفاوت Draft و Posted روشن شده باشد ✅
4. reversal/unfinalize/lock rules ثبت شده باشند ✅
5. dimension propagation rules ثبت شده باشند ✅
6. review معماری/کسب‌وکار روی ambiguityهای باز انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری**، Phase 3 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **تصویب نهایی اجرایی** هنوز نیازمند review بعضی policy decisionها در مورد materialization، approval bypass و lifecycle details است.

---

# 21) خروجی مورد انتظار برای Phase 4

Phase 4 باید مستقیماً بر اساس همین سند ادامه پیدا کند و این موارد را formalize کند:

1. source رسمی هر report
2. read model strategy
3. snapshot vs on-demand policy
4. API contracts گزارش‌ها
5. caching policy
6. reconciliation rules بین reportها
7. فرمول‌های رسمی report layer بر پایه GL/TB

## 21.1 وابستگی مستقیم Phase 4 به این سند
- posting pipeline رسمی شد
- Journal و GL source chain رسمی شدند
- report refresh trigger concept تعریف شد
- dimension propagation مشخص شد
- posted accounting source برای reportها تثبیت شد

---

# 22) جمع‌بندی نهایی Phase 3

مهم‌ترین خروجی Phase 3 این است که از این نقطه به بعد، معماری نباید رویداد مالی را مستقیماً به گزارش یا dashboard وصل کند.

### نتیجه‌های کلیدی
- posting pipeline رسمی end-to-end تعریف شد
- Draft و Posted/Finalized از هم جدا شدند
- Journal به‌عنوان لایه رسمی بعد از posting تعریف شد
- General Ledger به‌عنوان موتور رسمی مانده‌گیری تعریف شد
- reversal به‌عنوان مسیر استاندارد اصلاح سند posted تثبیت شد
- unfinalize به‌عنوان استثنا و نه قاعده تعریف شد
- fiscal lock و dimension propagation وارد pipeline رسمی شدند

### اصل نهایی این فاز

```text
No Financial Truth Without Posting
```

و به زبان عملیاتی:

```text
One Business Event
↓
One Voucher Path
↓
One Posting Decision
↓
One Journal/GL Chain
↓
One Reporting Truth
```

---

**پایان گزارش Phase 3**
