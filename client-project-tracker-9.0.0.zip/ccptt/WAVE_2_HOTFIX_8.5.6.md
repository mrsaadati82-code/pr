# WAVE_2_HOTFIX_8.5.6 — رفع hash-refresh و برگشت واقعی موجودی

> نسخه: **8.5.6** — تاریخ: 1405/04/18

## دو گزارش کاربر

1. **رفرش روی تب‌های سفارشی → می‌رود به داشبورد** (به‌جای همان تب)
2. **برگشت voucher انتقال، موجودی حساب را اصلاح نمی‌کند** — voucher جدیدی با debit/credit swapped ثبت می‌شود ولی fin_ledger (که موجودی حساب از آن می‌آید) دست‌نخورده باقی می‌ماند.

## اصلاحات

### 🔧 مسئله ۱: hash-refresh نمی‌رفت به تب

**علت:** تب‌های `treasury/transfers/cashflow/ledger_view/cheques/payables` در گروه «خزانه‌داری» قرار دارند. `useState({..., treasury: ih.includes(i), ...})` نشان می‌دهد این گروه فقط وقتی باز است که `currentTab` یکی از اعضای این گروه باشد. اما هنگام refresh، `currentTab = 'dashboard'` است پس گروه **بسته** است، و `findTabButton('treasury')` هیچ element قابل clickی پیدا نمی‌کند (چون children hidden است).

`income_expense` مستقل است ولی مسئله‌ی دیگری داشت: `isTabActive()` وجود نداشت پس interval بی‌هدف retry می‌کرد.

**اصلاح در extras.js:**

**الف)** نگاشت `TAB_GROUP` که برای هر تب، label گروه پدر آن را نگه می‌دارد.

**ب)** `activateTabById()` اول چک می‌کند اگر تب مورد نظر visible نیست، `findGroupButton()` گروه پدر را پیدا و کلیک می‌کند تا باز شود. سپس در فراخوانی بعدی interval، تب پیدا و کلیک می‌شود.

**ج)** `isTabActive()` جدید — بررسی می‌کند آیا تب مورد نظر واقعاً فعال است (برای تب‌های سفارشی از `[data-slot]` و برای بقیه از active class در sidebar). با این:
- interval بعد از موفقیت واقعی stop می‌شود
- اگر تب از قبل فعال بود، هیچ کاری نمی‌کند
- retry تا ۱۵ ثانیه به‌جای ۱۰ ثانیه

### 💰 مسئله ۲: برگشت voucher موجودی را اصلاح نمی‌کرد

**علت (کشف مهم):** معماری فعلی برای treasury operations دو مسیر موازی می‌نویسد:
- **voucher** (accounting) → در `wp_cptt_erp_vouchers`
- **fin_ledger** (treasury balance source) → در `wp_cptt_fin_ledger` با `ref_type=erp_treasury_transfer_out/in`, `erp_ie`, `erp_treasury_deposit`, `erp_treasury_withdraw`

`ajax_voucher_reverse` → `gen_reverse_voucher` → فقط voucher جدید با debit/credit swapped می‌سازد. `apply_reverse_business_effects()` بعدش صدا زده می‌شود ولی **فقط برای `project_receipt` منطق داشت**. برای transfer/deposit/withdraw/ie هیچ compensating row در fin_ledger ثبت نمی‌شد → موجودی حساب اصلاح نمی‌شد.

**اصلاح در `class-cptt-finance-erp.php`:**

تابع جدید `reverse_treasury_fin_ledger_effects($voucher)` که در `apply_reverse_business_effects` صدا زده می‌شود:

1. **تشخیص نوع** از `refType`/`sourceType` voucher:
   - `treasury_transfer` → rows با ref_type `erp_treasury_transfer_out/in`
   - `treasury_deposit` → `erp_treasury_deposit`
   - `treasury_withdraw` → `erp_treasury_withdraw`
   - `erp_ie` / income / expense → `erp_ie`

2. **پیدا کردن rows اصلی**:
   - transfer: از `refId = f*1000000+t` مقادیر `f` و `t` را استخراج، rows با amount و account مطابق را پیدا
   - بقیه: مستقیم از `refId` که همان `fin_ledger.id` است

3. **idempotence guard**: قبل از insert compensating row، چک می‌کنیم آیا از قبل row معکوس با `linked_id = original.id` و `ref_type = 'erp_reverse_' + original.ref_type` وجود دارد. اگر بله، skip (تا reverse مکرر double نشود).

4. **Insert compensating row** با:
   - همان `account_id` و `amount`
   - `direction = -1 * original.direction` (flip)
   - `type = original.type + '_reverse'`
   - `ref_type = 'erp_reverse_' + original.ref_type`
   - `linked_id = original.id`
   - description شروع با «برگشت:»

با این، موجودی حساب (`SUM(direction * amount)` روی fin_ledger) به‌طور کامل به حالت قبل بازمی‌گردد.

## فایل‌های تغییریافته

| فایل | تغییر |
|---|---|
| `includes/class-cptt-finance-erp.php` | `apply_reverse_business_effects()` حالا `reverse_treasury_fin_ledger_effects()` را هم صدا می‌زند؛ تابع جدید idempotent با شناسایی خودکار نوع treasury operation |
| `assets/js/cptt-erp-extras.js` | `TAB_GROUP` map، `findGroupButton()`, `activateTabById()` اول گروه را باز می‌کند، `isTabActive()` جدید برای stop شرطی interval |
| `client-project-tracker.php` | بامپ نسخه به 8.5.6 |

## چه چیزی خراب نشد

- ✅ syntax check کل فایل‌های اصلاح‌شده
- ✅ منطق idempotent: reverse مکرر یک voucher دو بار جبران نمی‌کند (linked_id + ref_type check)
- ✅ سایر مسیرهای reverse (project_receipt, settlement_reverse) دست‌نخورده
- ✅ فقط توابع خودمان تغییر کردند — بقیه‌ی voucher/ledger stack دست‌نخورد

## بعد از نصب

**برای اصلاح موجودی اشتباه فعلی:**
1. برو به «اسناد حسابداری»
2. sند برگشتی قبلی که ثبت کرده بودی (که کار نکرد) را **حذف کن** (اگر می‌شود)
3. دوباره روی سند اصلی transfer «برگشت سند» بزن
4. یا اگر حذف ممکن نیست، مستقیم یک انتقال جدید در جهت معکوس ثبت کن (`t{مقصد اشتباه} → t{مبدا اصلی}` با همان مبلغ)

**برای refresh:** فقط F5 بزن روی تب treasury/transfers/income_expense — باید همان تب باقی بماند.
