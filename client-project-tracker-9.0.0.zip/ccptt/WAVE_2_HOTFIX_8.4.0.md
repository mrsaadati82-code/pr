# WAVE_2_HOTFIX_8.4.0 — رفع ریشه‌ای E-1 (تاریخ و اعداد فارسی/انگلیسی)

> نسخه: **8.4.0**
> نوع: تغییر بزرگ (فاز عبور از باگ E-1 — رقم وسط +۱)
> تاریخ: 1405/04/17

---

## 🎯 هدف

باگ E-1 که در نسخه‌ی 8.3.2 کشف و ثبت شد، به‌طور **ریشه‌ای و غیرمخرب** حل شود
— بدون این‌که هیچ دیتای قبلی خراب شود یا نیاز به migration دیتابیس باشد.
همچنین:
- تمام فیلدهای تاریخ در همه‌جای افزونه (منوی وردپرس، پنل کارشناس، پنل ERP،
  فرم‌های frontend) datepicker شمسی داشته باشند.
- تمام فیلدهای تاریخ و عدد/مبلغ، **هم ارقام فارسی و هم انگلیسی** را قبول
  کنند و درست محاسبه شوند.

## 🔬 ریشه‌ی واقعی مشکل (که در 8.3.2 کشف شد)

سه لایه‌ی به‌هم‌گره‌خورده:

1. **باگ regex در `fa_today()`/`fa_date_of()`**
   الگوی `\d` در PCRE ارقام فارسی را match نمی‌کند، پس این توابع روی خروجی
   `jalali_datetime()` (که همیشه فارسی است) fail می‌کردند و رشته‌ی «تاریخ
   + ساعت» را برمی‌گرداندند.

2. **مقایسه‌ی رشته‌ای اشتباه در `fa_date_cmp()`**
   وقتی «تاریخ» (`14050105`) با «تاریخ+ساعت» (`14041229 2359` → strip →
   `140412292359`) مقایسه می‌شد، طول متفاوت رشته‌ها به نتیجه‌ی اشتباه
   منتهی می‌شد.

3. **ناهماهنگی ورودی کاربر**
   ارقامی که در فرم‌ها تایپ می‌شدند گاه فارسی گاه انگلیسی بودند و بدون
   normalize مرکزی مستقیم در دیتابیس ذخیره می‌شدند. مقایسه‌های سمت
   جاوااسکریپت (`>` یا `localeCompare`) با ارقام فارسی هم رفتار
   غیرمنتظره داشت.

## 🛠️ راه‌حل ریشه‌ای (۶ لایه، هر لایه غیرمخرب)

### لایه ۱ — کلاس مرکزی `CPTT_Date_Utils` (فایل جدید)
**فایل:** `includes/class-cptt-date-utils.php`

تنها منبع حقیقت برای:
- `to_en_digits`, `to_fa_digits` — تبدیل ارقام
- `to_canonical_date($s)` — هر رشته → `YYYY/MM/DD` انگلیسی
- `to_canonical_datetime($s)` — هر رشته → `YYYY/MM/DD HH:MM` انگلیسی
- `date_cmp($a,$b)` — مقایسه‌ی امن بر اساس `YYYYMMDD` عددی
- `date_key`, `datetime_key` — کلید مقایسه‌ی integer
- `today`, `date_of`, `datetime_of` — جالالی‌ها با ارقام انگلیسی
- `jalali_to_timestamp` — تبدیل هر فرمت جالالی به timestamp
- `parse_amount` — عدد از هر ورودی (فارسی/عربی/انگلیسی، با کاما/نقطه/فاصله)

### لایه ۲ — Normalize خودکار روی `$_POST`
**فایل:** `client-project-tracker.php`

قبل از هر AJAX handler، هوک `plugins_loaded` صدا زده می‌شود که:
- فقط کلیدهایی که «شبیه تاریخ یا عدد» هستند را از فارسی/عربی به انگلیسی
  تبدیل می‌کند (مثل `date`, `amount`, `cost`, `deadline`, `due`, ...)
- فیلدهای متنی (`title`, `description`, ...) دست‌نخورده می‌مانند تا محتوای
  فارسی خراب نشود.

**نتیجه:** هر handler موجود (بدون تغییر یک خط کد در آن‌ها) اعداد و
تاریخ‌های canonical دریافت می‌کند.

### لایه ۳ — تعمیر توابع buggy در ERP
**فایل:** `includes/class-cptt-finance-erp.php`

- `fa_today()` → به `CPTT_Date_Utils::today()` تفویض شد
- `fa_date_of($ts)` → به `CPTT_Date_Utils::date_of()` تفویض شد
- `fa_date_cmp($a,$b)` → به `CPTT_Date_Utils::date_cmp()` تفویض شد
  (fallback داخلی هم اصلاح شد که regex ابتدای رشته `\d{4}[\/\-\.]\d{1,2}...`
  را روی هر رشته پیدا کند، نه اول رشته‌ی خام)
- `fa_to_gregorian_ts($s)` → به `jalali_to_timestamp()` تفویض شد
  (قبلاً اگر ساعت داشت silent fallback به `now` می‌کرد)
- `to_en_digits`, `normalize_amount_input` → به کلاس مرکزی تفویض شدند

### لایه ۴ — توابع canonical در `CPTT_Core`
**فایل:** `includes/class-cptt-core.php`

دو تابع خواهر اضافه شدند (بدون شکستن سازگاری):
- `jalali_datetime_en($ts)` — تاریخ+ساعت با ارقام **انگلیسی**
- `jalali_date_en($ts)` — فقط تاریخ با ارقام **انگلیسی**
- `to_english_digits` → تفویض به کلاس مرکزی (پوشش کامل‌تر ارقام)

تابع اصلی `jalali_datetime($ts)` **بدون تغییر** ماند (برگرداندن ارقام
فارسی، برای نمایش UI که رفتار قدیمی می‌خواهد).

### لایه ۵ — اسکریپت مرکزی سمت کاربر
**فایل جدید:** `assets/js/cptt-input-normalize.js` (بدون jQuery)

روی هر صفحه (admin + frontend + ERP) لود می‌شود و:

1. **datepicker شمسی** روی هر input که یکی از این‌ها داشته باشد:
   - کلاس `cptt-jalali-datetime` یا `cptt-jalali-date`
   - attribute `data-cptt-date` یا `data-cptt-datetime`
   - placeholder/name شامل کلمات «تاریخ»، «مهلت»، «deadline»، ...

2. **auto-format مبلغ** روی هر input با کلاس `cptt-currency-input` یا
   `cptt-num-format` یا `data-cptt-amount`.

3. **Interceptor سراسری fetch + XMLHttpRequest:**
   - **قبل از ارسال:** بدنه‌ی FormData/URLSearchParams/form-encoded برای
     کلیدهای تاریخ/مبلغ به فرمت canonical تبدیل می‌شود.
   - **بعد از دریافت:** پاسخ JSON برای کلیدهایی که شبیه تاریخ هستند
     (`*_fa`, `date`, `due`, `startDate`, ...) به فرمت canonical
     normalize می‌شود تا مقایسه‌های داخل کد React (که source اصلی
     در دسترس نیست) روی داده‌ی یک‌دست انجام شود.

4. **preSubmit form-encoded:** قبل از submit یک `<form>`، همه‌ی تاریخ‌ها
   و اعداد تبدیل و بعد از submit مقدار نمایشی برگردانده می‌شود.

5. **MutationObserver:** برای پنل React که DOM را dynamic می‌سازد، هر
   input تازه‌واردی خودکار binding می‌گیرد.

### لایه ۶ — CSS datepicker
**فایل جدید:** `assets/css/cptt-datepicker.css`

طراحی minimal و RTL، با پشتیبانی خودکار از حالت dark (وقتی داخل پنل ERP یا
theme dark است).

### Enqueue شدن روی همه‌جا

در `client-project-tracker.php`:
- `admin_enqueue_scripts` priority 5
- `wp_enqueue_scripts` priority 5
- `admin_print_scripts/styles` priority 10000 (برای پنل ERP که dequeue تهاجمی
  دارد)

در `class-cptt-finance-erp.php`:
- در `enqueue_assets()` قبل از `cpttf-erp-app` (به‌عنوان dependency)
- در `dequeue_3rd_party_assets()` به whitelist اضافه شد
  (`cptt-input-normalize` و `cptt-datepicker`)

## 🛡️ چرا این تغییر غیرمخرب است

| نکته | تضمین |
|---|---|
| هیچ سطر SQL/migration اجرا نمی‌شود | تغییری در DB وجود ندارد |
| داده‌های قدیمی کثیف (با ساعت، ارقام فارسی) | در زمان مقایسه/نمایش با توابع جدید normalize می‌شوند |
| تابع `jalali_datetime` قدیمی حفظ شد | همه‌ی جاهایی که از آن استفاده می‌کنند بدون تغییر کار می‌کنند |
| فیلدهای متنی POST (description, title, note, …) | دست نمی‌خورند (heuristic hardcoded) |
| اسکریپت client فقط input هایی که ملاک را دارند normalize می‌کند | textarea و input های متنی دست‌نخورده |
| interceptor JSON response فقط کلیدهای date/amount را می‌شناسد | متن‌ها دست نمی‌خورند |

## 📊 تست‌های موفق (PHP)

```
OK  to_canonical_date(۱۴۰۵/۰۱/۰۵) => 1405/01/05
OK  to_canonical_date(۱۴۰۴/۱۲/۲۹ ۲۳:۵۹) => 1404/12/29    ← باگ اصلی حل شد
OK  cmp(1405/01/05, 1404/12/29 23:59) = 1                  ← باگ E-1 حل شد
OK  cmp(۱۴۰۴/۱۲/۲۹ ۲۳:۵۹, 1405/01/05) = -1
OK  cmp(1405/01/05, ۱۴۰۵/۰۱/۰۵) = 0
OK  parse_amount(۱۲۳,۴۵۶) = 123456
OK  parse_amount(۱۲۳٬۴۵۶) = 123456
OK  parse_amount(۱۲۳ ۴۵۶) = 123456
```

**normalize_post_digits_in_place:**
- `date: ۱۴۰۵/۰۱/۰۵` → `1405/01/05` ✅
- `amount: ۱۲۳,۴۵۶` → `123,456` ✅
- `description: این یک توضیح فارسی است ۱۲۳` → **دست‌نخورده** ✅
- `nested.due_date: ۱۴۰۴/۱۲/۲۹` → `1404/12/29` ✅ (recursion صحیح)

## 📁 فایل‌های تغییریافته/اضافه‌شده

**جدید:**
- `includes/class-cptt-date-utils.php` (کلاس مرکزی — منبع حقیقت)
- `assets/js/cptt-input-normalize.js` (اسکریپت client)
- `assets/css/cptt-datepicker.css` (استایل datepicker)
- `WAVE_2_HOTFIX_8.4.0.md` (این فایل)

**تغییریافته:**
- `client-project-tracker.php` — نسخه به 8.4.0، include کلاس مرکزی،
  هوک normalize روی POST، enqueue asset ها
- `includes/class-cptt-core.php` — دو تابع canonical اضافه شد
- `includes/class-cptt-finance-erp.php` — ۵ تابع تعمیر/تفویض شد،
  whitelist دیکیو به‌روز شد، dependency به app.js اضافه شد
- `README.md` — یادداشت نسخه 8.4.0

## 🎯 نتیجه — چه‌کارهایی از این پس درست کار می‌کنند

- ✅ مقایسه‌های تاریخ در ۸۱ محل `class-cptt-finance-erp.php`
- ✅ گزارش Aging (C-1 خود به خود حل شد — چون به E-1 وابسته بود)
- ✅ فیلتر بازه‌ی تاریخی لیست اسناد در React
- ✅ ذخیره‌ی تاریخ در `settle_at_fa` و مشابه
- ✅ Datepicker شمسی روی هر input تاریخ (شامل تب «اسناد حسابداری» React)
- ✅ فیلد مبلغ در تسویه‌ی کارشناسان: می‌توانی «۱۲۳,۴۵۶» یا «123456» تایپ
  کنی — هر دو درست محاسبه می‌شوند

## 🚦 چیزی که بعد از این نسخه لازم است

- **C-2** — گزارش cash-view جداگانه (قابلیت جدید)
- **D-1** — تجمیع همه‌ی صفحات مالی زیر پنل React واحد (نیازمند بازسازی
  source React — Wave 4/5)
- **A-1/A-2/A-3** — Wave 3 و Wave 4 نقشه‌ی راه بزرگ (Journal/GL cutover)

C-1 که قبلاً باز بود، **با حل E-1 خودکار حل شد** ✅
