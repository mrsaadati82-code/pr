# ERP_REFACTOR_ROADMAP

> Roadmap اجرایی بازطراحی و یکپارچه‌سازی سیستم حسابداری ERP  
> مبنا: `ACCOUNTING_SYSTEM_ANALYSIS.md` و `ERP_ARCHITECTURE.md`  
> نوع سند: **Execution Roadmap / Refactor Program Plan**  
> وضعیت: **بدون تغییر کد — صرفاً برنامه‌ی اجرایی**

---

# 0) هدف کلان Roadmap

هدف این Roadmap، انتقال سیستم از وضعیت فعلی:

```text
Multi-Source Financial State
+ Duplicate Calculation Logic
+ Client-Side Reporting
+ Dual Ledger
```

به وضعیت هدف:

```text
Voucher-First Architecture
+ Single Source of Truth
+ Unified Posting Pipeline
+ Server-Side Deterministic Reports
```

این Roadmap به‌صورت **فازی** طراحی شده تا:
- ریسک تغییرات مالی کنترل شود
- قابلیت Rollback در هر فاز وجود داشته باشد
- سیستم در طول مسیر قابل استفاده بماند
- مهاجرت از Legacy به Target Architecture بدون شکست ناگهانی انجام شود

---

# 1) استراتژی اجرای کلان

## 1.1 اصل اجرا

ترتیب اجرای فازها باید این‌گونه باشد:

1. **ایمن‌سازی و مشاهده‌پذیری**
2. **تعریف ساختار هدف و read modelها**
3. **ایجاد لایه‌های جدید در کنار لایه‌های فعلی**
4. **مهاجرت تدریجی مصرف‌کننده‌ها**
5. **خاموش‌کردن مسیرهای Legacy**
6. **پاکسازی نهایی**

## 1.2 قاعده‌ی کلیدی

در طول اجرای Roadmap:
- هیچ فاز نباید بدون امکان rollback وارد production شود
- هیچ فاز نباید هم‌زمان **storage migration + behavior migration + UI migration** را با هم انجام دهد
- هر فاز باید فقط **یک دسته مسئولیت** را جابه‌جا کند

---

# Phase 0 — Baseline, Freeze, Observability

## هدف
ایجاد baseline فنی و حسابداری قبل از هر refactor، قفل‌کردن دامنه تغییرات، و فراهم‌کردن مشاهده‌پذیری برای مقایسه قبل/بعد.

## Task ها
- تهیه snapshot از وضعیت فعلی داده‌های مالی:
  - vouchers
  - voucher rows
  - finance ledger
  - core ledger
  - project `_cptt_steps`
  - fiscal years / locks / COA / cost centers
- تعریف matrix تطبیق برای گزارش‌ها:
  - Documents vs Journal
  - Trial Balance totals
  - P&L totals
  - Balance Sheet equation
  - Receivables total
  - Expert payable total
- مستندسازی دقیق statusهای فعلی، eventها، hookها و API surface
- شناسایی همه entry pointهای مالی
- تعیین scope freeze برای فایل‌های مالی در بازه refactor
- فعال‌سازی logging / audit / trace بیشتر برای عملیات‌های مالی (در سطح plan، نه لزوماً implementation فوری)
- تعریف شاخص‌های سنجش موفقیت refactor

## پیش‌نیاز
- فایل‌های تحلیل (`ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`)
- دسترسی به staging و دیتای واقعی تست

## ریسک
- baseline ناقص → مقایسه بعدی بی‌اعتبار می‌شود
- نداشتن snapshot صحیح → rollback پرریسک می‌شود

## روش تست
- اجرای سناریوهای نمونه و ثبت خروجی همه گزارش‌های اصلی
- ثبت اعداد baseline برای:
  - جمع بدهکار/بستانکار
  - سود/زیان
  - دارایی/بدهی/سرمایه
  - موجودی خزانه
  - مطالبات

## Definition of Done
- baseline کامل قبل از refactor ثبت شده باشد
- inventory همه مسیرهای مالی تایید شده باشد
- KPIهای مقایسه‌ای قبل/بعد تعریف شده باشند

## Rollback Plan
- چون Phase 0 تغییری در رفتار سیستم ایجاد نمی‌کند، rollback صرفاً حذف artefactهای غیرضروری است

## زمان تقریبی
- 2 تا 4 روز

## وابستگی‌ها
- بدون وابستگی به فازهای دیگر

---

# Phase 1 — Domain Canonicalization

## هدف
تعریف canonical domain model و mapping صریح بین مدل‌های فعلی و مدل‌های هدف.

## Task ها
- تعریف مدل‌های نهایی دامنه:
  - Voucher
  - VoucherRow
  - JournalEntry
  - GeneralLedgerEntry
  - TrialBalanceRow
  - FiscalYear
  - FiscalPeriodLock
  - TreasuryAccount
  - Party
  - CostCenter
  - CurrencyRate
  - Payable
  - InstallmentPlan / Row
  - Cheque
  - Invoice
- تعیین canonical field names برای هر مدل
- تعیین state machine رسمی برای:
  - Voucher
  - FiscalYear
  - Payable
  - Installment
  - Cheque
  - Invoice
- تعریف relation map رسمی بین مدل‌ها
- تعریف dimension model رسمی:
  - project
  - party
  - cost center
  - branch/company
- تعریف policy برای account type / account nature
- تعیین migration mapping از مدل‌های فعلی به canonical models

## پیش‌نیاز
- تکمیل Phase 0

## ریسک
- اشتباه در canonical mapping باعث refactor نادرست downstream می‌شود
- عدم اجماع روی معنای برخی مدل‌ها (مثل ledger) روند را متوقف می‌کند

## روش تست
- review معماری با جدول mapping مدل فعلی → مدل هدف
- تأیید رسمی اینکه هر data element دقیقاً به کدام aggregate نهایی تعلق دارد

## Definition of Done
- مدل نهایی دامنه و relation map نهایی تصویب شده باشد
- ambiguityهای اصلی مدل‌ها رفع یا با برچسب «نامشخص» بسته شده باشند

## Rollback Plan
- بازگشت به نسخه قبلی سند domain mapping؛ چون هنوز code behavior تغییر نکرده

## زمان تقریبی
- 3 تا 5 روز

## وابستگی‌ها
- Phase 0

---

# Phase 2 — Service & Repository Blueprint

## هدف
طراحی لایه‌های Application Service و Repository به‌صورت رسمی، قبل از هر جابه‌جایی رفتار.

## Task ها
- تعریف Service Catalog نهایی:
  - VoucherApplicationService
  - VoucherApprovalService
  - VoucherPostingService
  - VoucherReversalService
  - CustomerReceiptService
  - ExpertSettlementService
  - TreasuryTransactionService
  - TreasuryTransferService
  - PayableService
  - PayablePaymentService
  - InstallmentPlanService
  - InstallmentReceiptService
  - ChequeAccountingService
  - InvoiceAccountingService
  - FiscalYearClosingService
- تعریف Repository Catalog نهایی:
  - VoucherRepository
  - VoucherRowRepository
  - JournalRepository
  - GeneralLedgerRepository
  - FiscalYearRepository
  - LockRepository
  - TreasuryRepository
  - PartyRepository
  - CostCenterRepository
  - CurrencyRateRepository
  - AuditRepository
  - InvoiceRepository
  - ChequeRepository
  - PayableRepository
  - InstallmentRepository
- طراحی contract هر service و repository
- تعیین transaction boundary برای هر use case
- تعیین خط‌مشی idempotency برای eventهای مالی
- تعیین خط‌مشی traceability برای sourceType/sourceId

## پیش‌نیاز
- Phase 1

## ریسک
- طراحی serviceهای بیش از حد درشت یا بیش از حد ریز
- مخلوط شدن application service و domain logic

## روش تست
- review روی sequence diagram هر use case مالی
- بررسی اینکه هیچ use case بدون service مالک نمانده باشد

## Definition of Done
- تمام use caseهای مالی service owner داشته باشند
- تمام storage accessها repository owner داشته باشند
- transaction boundary هر use case تعریف شده باشد

## Rollback Plan
- بازگشت به draft قبلی service catalog

## زمان تقریبی
- 2 تا 4 روز

## وابستگی‌ها
- Phase 1

---

# Phase 3 — Voucher-First Posting Pipeline Design

## هدف
طراحی نهایی Posting Pipeline که هسته‌ی refactor است.

## Task ها
- تعریف مراحل رسمی pipeline:
  - draft creation
  - validation
  - persistence
  - approval workflow
  - posting
  - journal generation
  - general ledger generation
  - trial balance update
  - report read model update
- تعیین تفاوت Draft vs Posted Voucher
- تعریف Journal به‌عنوان read/store model رسمی
- تعریف General Ledger به‌عنوان ledger حسابداری نهایی
- تعریف policy رسمی برای reversals
- تعریف policy رسمی برای unfinalize/reopen behavior
- تعریف policy رسمی برای fiscal period locking در pipeline
- تعریف policy رسمی برای dimension propagation

## پیش‌نیاز
- Phase 2

## ریسک
- اگر Posting Pipeline خوب طراحی نشود، تمام فازهای بعدی ناپایدار می‌شوند
- conflict با behaviorهای legacy

## روش تست
- walkthrough سناریوهای کلیدی:
  - ثبت سند دستی
  - دریافت مشتری
  - پرداخت کارشناس
  - پرداخت بدهی
  - دریافت قسط
  - انتقال خزانه
  - بستن سال مالی

## Definition of Done
- برای هر event مالی، یک sequence استاندارد از Business Action تا Posting تعریف شده باشد
- هیچ event مالی بدون path مشخص باقی نمانده باشد

## Rollback Plan
- بازگشت به design draft قبلی pipeline

## زمان تقریبی
- 3 تا 5 روز

## وابستگی‌ها
- Phase 2

---

# Phase 4 — Reporting Architecture Redesign

## هدف
طراحی نهایی لایه گزارش‌گیری server-side deterministic و حذف dependence بر client-side calculations.

## Task ها
- تعریف source رسمی هر report:
  - Documents → Voucher/VoucherRows
  - Journal → JournalEntries
  - General Ledger → GeneralLedgerEntries
  - Subsidiary Ledger → GL + dimensions
  - Trial Balance → TrialBalance
  - Income Statement → TrialBalance
  - Balance Sheet → TrialBalance
  - Cash Flow → posted entries + cash accounts
  - Aging → GL + due refs
  - Dashboard → Reporting Read Models
- تعریف read modelهای لازم
- تعیین snapshot strategy یا on-demand strategy برای reportها
- طراحی API contract برای report services
- طراحی caching policy برای report layer
- تعریف reconciliation rules بین reports
- تعریف official formulas for:
  - revenue
  - expense
  - profit
  - assets
  - liabilities
  - equity

## پیش‌نیاز
- Phase 3

## ریسک
- اگر report sourceها به‌درستی تفکیک نشوند، دوباره divergence ایجاد می‌شود
- انتخاب اشتباه بین snapshot/on-demand می‌تواند performance را خراب کند

## روش تست
- matrix validation:
  - Journal totals == Voucher posted totals
  - Trial Balance debit == credit
  - Income Statement = revenues - expenses
  - Balance Sheet assets == liabilities + equity
  - Dashboard numbers == report layer outputs

## Definition of Done
- هر report فقط یک source رسمی داشته باشد
- تمام فرمول‌ها و dependency chain رسمی شده باشند

## Rollback Plan
- بازگشت به report contract draft قبلی؛ بدون تغییر کد اجرایی

## زمان تقریبی
- 4 تا 6 روز

## وابستگی‌ها
- Phase 3

---

# Phase 5 — Legacy Boundary Isolation

## هدف
جداسازی مفهومی bounded contextهای Legacy و ERP قبل از حذف تدریجی Legacy logic.

## Task ها
- شناسایی دقیق تمام entry pointهای legacy:
  - `class-cptt-finance.php`
  - `class-cptt-admin.php` accounting actions
  - `class-cptt-payment.php` financial writes
  - `class-cptt-expert.php` project financial writes
- دسته‌بندی هر entry point به یکی از وضعیت‌های زیر:
  - Keep temporarily
  - Wrap and adapt
  - Replace
  - Remove
- تعریف Anti-Corruption Layer بین legacy modules و target accounting services
- تعیین اینکه کدام legacy flows باید فقط adapter شوند
- تعیین اینکه کدام legacy storageها transitional هستند

## پیش‌نیاز
- Phase 4

## ریسک
- عدم isolate کردن legacy boundaries باعث merge آشوبناک می‌شود
- حذف زودهنگام legacy behavior باعث شکستن جریان‌های عملیاتی می‌شود

## روش تست
- inventory-based review
- اطمینان از اینکه هر flow legacy یک destination در target architecture دارد

## Definition of Done
- هیچ بخش legacy «بی‌وضعیت» باقی نمانده باشد
- همه جریان‌های legacy یکی از 4 وضعیت lifecycle را گرفته باشند

## Rollback Plan
- بازگشت به classification قبلی boundaries

## زمان تقریبی
- 2 تا 4 روز

## وابستگی‌ها
- Phase 4

---

# Phase 6 — Unified Ledger Strategy

## هدف
تصمیم‌گیری و طراحی دقیق برای حذف Dual Ledger و رسیدن به ledger نهایی واحد.

## Task ها
- تحلیل دو ledger فعلی:
  - `wp_cptt_fin_ledger`
  - `wp_cptt_ledger`
- تعیین مدل نهایی:
  - آیا General Ledger نهایی خود ledger رسمی است؟
  - یا Unified Event Ledger جداگانه نیاز داریم؟
- طراحی migration path برای historical rows
- طراحی traceability link بین legacy ledger rows و vouchers
- طراحی policy برای source event store vs accounting ledger
- تعیین fate نهایی هر ledger:
  - Merge
  - Archive
  - Deprecate
  - Replace

## پیش‌نیاز
- Phase 5

## ریسک
- انتخاب مدل نادرست برای ledger باعث refactor بسیار پرهزینه بعدی می‌شود
- داده‌های تاریخی بدون mapping دقیق ممکن است از دست بروند یا غیرقابل‌ردیابی شوند

## روش تست
- mapping verification برای event types:
  - income
  - expense
  - transfer
  - payout
  - installment
  - payable
  - cheque
  - card receipt
- اطمینان از اینکه هر event قدیمی معادل accounting identity دارد

## Definition of Done
- dual ledger target state نهایی تصویب شده باشد
- migration mapping برای هر event type وجود داشته باشد

## Rollback Plan
- rollback به وضعیت design-only؛ چون migration هنوز اجرایی نشده

## زمان تقریبی
- 3 تا 5 روز

## وابستگی‌ها
- Phase 5

---

# Phase 7 — Data Migration Plan

## هدف
طراحی plan کامل migration داده برای حرکت از state فعلی به معماری نهایی.

## Task ها
- طراحی migration streamها:
  - `_cptt_steps` → project financial read models / vouchers if needed
  - `cptt_fin_ledger` → unified target state
  - `cptt_ledger` → unified target state
  - options → tables (where required)
- تعیین migration mode:
  - one-time historical migration
  - incremental sync window
  - dual-write transition
- طراحی checkpoints migration
- تعریف reconciliation scripts/queries (در سطح plan)
- تعیین migration order برای وابستگی‌های داده‌ای
- تعریف freeze windows و cutover windows

## پیش‌نیاز
- Phase 6

## ریسک
- migration order اشتباه → report inconsistency
- dual-write بدون governance → data drift
- options/table mismatch during transition

## روش تست
- dry-run migration on staging
- compare pre/post numbers for:
  - total receivables
  - total payables
  - treasury balances
  - trial balance totals
  - P&L
  - balance sheet equation

## Definition of Done
- migration plan for each data source documented
- cutover strategy approved
- reconciliation checklist approved

## Rollback Plan
- staging rollback to snapshots
- production rollback by disabling migrated read path and restoring baseline snapshots

## زمان تقریبی
- 4 تا 7 روز

## وابستگی‌ها
- Phase 6

---

# Phase 8 — Report Cutover Plan

## هدف
طراحی برنامه‌ی انتقال گزارش‌ها از client-side / mixed-source به report layer استاندارد.

## Task ها
- تعیین cutover order برای reportها:
  1. Documents
  2. Journal
  3. General Ledger
  4. Subsidiary Ledger
  5. Trial Balance
  6. Income Statement
  7. Balance Sheet
  8. Dashboard KPIs
- طراحی backward-compatible API responses during transition
- تعیین feature flag strategy per report
- تعریف acceptance criteria per report
- تعریف parallel-run strategy برای compare قدیم/جدید

## پیش‌نیاز
- Phase 7

## ریسک
- cutover یک‌جای همه reportها بسیار پرخطر است
- client-side UI ممکن است assumptionهای قدیمی داشته باشد

## روش تست
- parallel run old report vs new report
- variance check per report
- manual accounting review on sample datasets

## Definition of Done
- cutover plan for every report approved
- feature flags and validation process مشخص شده باشد

## Rollback Plan
- report-by-report fallback to old rendering path
- no big-bang cutover

## زمان تقریبی
- 3 تا 5 روز

## وابستگی‌ها
- Phase 7

---

# Phase 9 — UI Refactor Plan

## هدف
طراحی refactor رابط ERP برای مصرف read modelهای جدید و حذف accounting logic از frontend.

## Task ها
- شناسایی همه بخش‌های UI که محاسبه مالی می‌کنند
- تعریف contractهای جدید UI برای:
  - Documents page
  - Journal page
  - GL page
  - Subsidiary Ledger page
  - Trial Balance page
  - P&L page
  - Balance Sheet page
  - Dashboard cards
- طراحی plan حذف synthetic/virtual voucher generation از frontend
- طراحی plan حذف client-side formulas
- تعیین تغییرات مورد نیاز در filters و pagination contracts
- تعیین migration plan برای bundle minified فعلی → source-managed UI layer

## پیش‌نیاز
- Phase 8

## ریسک
- چون frontend فعلی bundle minified است، refactor UI بدون source structure منظم سخت است
- اگر backend contracts نهایی نشده باشند، UI refactor زودهنگام باعث دوباره‌کاری می‌شود

## روش تست
- contract tests بین UI و API responses
- visual regression test
- cross-report consistency checks in UI

## Definition of Done
- frontend target contracts مشخص شده باشند
- هیچ report page نیازمند client-side accounting logic نباشد

## Rollback Plan
- fallback to old UI screens under feature flags
- keep old routes available during transition

## زمان تقریبی
- 4 تا 6 روز

## وابستگی‌ها
- Phase 8

---

# Phase 10 — Legacy Decommission Plan

## هدف
برنامه‌ریزی برای بازنشستگی بخش‌های legacy بدون از دست رفتن behavior ضروری.

## Task ها
- تعیین لیست بخش‌هایی که باید حذف کامل شوند:
  - synthetic voucher generation در frontend
  - report client-side calculation
  - dual ledger read paths
- تعیین لیست بخش‌هایی که باید archive شوند:
  - بعضی صفحات legacy finance
  - بعضی fallback readers
- تعیین لیست بخش‌هایی که باید redirect شوند:
  - legacy pages → ERP canonical pages
- تعیین deprecation timeline
- تعیین communication plan برای users/admins

## پیش‌نیاز
- Phase 9

## ریسک
- حذف زودهنگام legacy screens → operational disruption
- حذف fallbackها قبل از تثبیت report layer → broken accounting UX

## روش تست
- verify no active flow depends on legacy component
- usage analysis / access logs / user acceptance on staging

## Definition of Done
- decommission map کامل برای هر component legacy موجود باشد
- هیچ dependency ناشناخته روی legacy paths باقی نمانده باشد

## Rollback Plan
- keep legacy features behind disabled-but-restorable flags
- restore old routes if cutover fails

## زمان تقریبی
- 2 تا 4 روز

## وابستگی‌ها
- Phase 9

---

# Phase 11 — Integration & Externalization Plan

## هدف
هماهنگ‌سازی integrationها (Webhook/API/Notification/Import/Print/Cron) با معماری نهایی.

## Task ها
- تعیین مسیر نهایی Webhook events از posting pipeline
- تعیین contract نهایی REST API فقط روی read modelهای رسمی
- تعیین policy اعلان‌ها از event bus واحد
- تعیین Import strategy:
  - import to voucher
  - import to operational draft
  - import validation rules
- تعیین Print strategy:
  - print from report layer, not ad-hoc aggregation
- تعیین Cron strategy:
  - recurring → voucher pipeline
  - reminders → read models

## پیش‌نیاز
- Phase 10

## ریسک
- integrationها اگر زودتر migrate شوند، ممکن است روی مدل نیمه‌کاره سوار شوند
- webhook consumers به schemaهای قدیمی وابسته باشند

## روش تست
- API response comparison
- webhook payload verification
- import dry-run scenarios
- print reconciliation with reports

## Definition of Done
- integration layer فقط از canonical services/read models تغذیه شود
- هیچ integration مسیر داده‌ی موازی نسازد

## Rollback Plan
- versioned API/webhook contracts
- keep old integration adapters during migration window

## زمان تقریبی
- 3 تا 5 روز

## وابستگی‌ها
- Phase 10

---

# Phase 12 — Final Cutover & Hardening

## هدف
آماده‌سازی برای cutover نهایی، hardening معماری، و بستن refactor program.

## Task ها
- نهایی‌کردن feature flag removals
- freeze final data migration window
- اجرای reconciliation final
- اجرای performance review
- اجرای accounting audit review
- اجرای regression test کامل
- نهایی‌سازی runbookهای production support
- نهایی‌سازی operational manuals

## پیش‌نیاز
- Phase 11

## ریسک
- discrepancy final reconciliation
- missing edge case in historical data
- final cutover pressure

## روش تست
- Full financial regression
- Month-end / year-end scenario tests
- sample posting tests for all business actions
- compare all KPIs and reports against approved baseline

## Definition of Done
- تمام گزارش‌های اصلی فقط از source استاندارد تغذیه شوند
- dual ledger semantics بسته شده باشد
- frontend accounting logic حذف شده باشد
- Single Source of Truth برقرار شده باشد
- audit trail و traceability کامل باشد

## Rollback Plan
- rollback به phase-gated stable release previous to final cutover
- restore DB snapshot if final migration fails
- re-enable old report path by feature flag if discrepancy critical باشد

## زمان تقریبی
- 5 تا 8 روز

## وابستگی‌ها
- Phase 11

---

# 2) Dependency Matrix بین فازها

| Phase | وابسته به |
|---|---|
| Phase 0 | — |
| Phase 1 | Phase 0 |
| Phase 2 | Phase 1 |
| Phase 3 | Phase 2 |
| Phase 4 | Phase 3 |
| Phase 5 | Phase 4 |
| Phase 6 | Phase 5 |
| Phase 7 | Phase 6 |
| Phase 8 | Phase 7 |
| Phase 9 | Phase 8 |
| Phase 10 | Phase 9 |
| Phase 11 | Phase 10 |
| Phase 12 | Phase 11 |

---

# 3) تخمین زمانی کل برنامه

| فاز | زمان تقریبی |
|---|---|
| Phase 0 | 2–4 روز |
| Phase 1 | 3–5 روز |
| Phase 2 | 2–4 روز |
| Phase 3 | 3–5 روز |
| Phase 4 | 4–6 روز |
| Phase 5 | 2–4 روز |
| Phase 6 | 3–5 روز |
| Phase 7 | 4–7 روز |
| Phase 8 | 3–5 روز |
| Phase 9 | 4–6 روز |
| Phase 10 | 2–4 روز |
| Phase 11 | 3–5 روز |
| Phase 12 | 5–8 روز |

## جمع کل تقریبی
- **40 تا 68 روز کاری**

> این تخمین بسته به کیفیت دیتای تاریخی، وضعیت source frontend، و سطح test automation می‌تواند کمتر یا بیشتر شود.

---

# 4) اولویت‌بندی اجرایی

## 4.1 اگر برنامه باید کوتاه‌تر و iterative اجرا شود
اولویت توصیه‌شده:

### موج اول (معماری پایه)
- Phase 0
- Phase 1
- Phase 2
- Phase 3
- Phase 4

### موج دوم (legacy isolation + ledger strategy)
- Phase 5
- Phase 6
- Phase 7

### موج سوم (report cutover + UI)
- Phase 8
- Phase 9
- Phase 10

### موج چهارم (integration + final hardening)
- Phase 11
- Phase 12

---

# 5) Definition of Success کل برنامه

کل برنامه زمانی موفق تلقی می‌شود که:

1. هر رویداد مالی فقط یک مسیر رسمی داشته باشد
2. هر گزارش فقط یک source رسمی داشته باشد
3. Voucher First architecture برقرار شده باشد
4. Journal/GL/TB/P&L/BS deterministic باشند
5. dashboard از report layer تغذیه شود
6. dual ledger از بین رفته باشد یا isolation کامل شده باشد
7. client-side financial calculation حذف شده باشد
8. synthetic voucher در UI حذف شده باشد
9. traceability هر عدد از dashboard تا voucher برقرار باشد
10. rollback در هر phase ممکن و مستند باشد

---

# 6) Definition of Failure کل برنامه

برنامه شکست‌خورده تلقی می‌شود اگر:

- هنوز چند SoT موازی باقی بماند
- reportها همچنان از چند منبع مختلف تغذیه شوند
- ledgerهای موازی بدون governance باقی بمانند
- UI همچنان محاسبات حسابداری انجام دهد
- migration data بدون reconciliation نهایی انجام شود
- final cutover بدون feature flag / rollback plan اجرا شود

---

# 7) نتیجه‌گیری نهایی

این Roadmap عمداً از **Phase 0** شروع شده، چون مشکل پروژه فقط فنی نیست؛
مشکل اصلی، **معماری داده و مرجع حقیقت** است.

بنابراین هر تلاش برای Fix موضعی بدون طی این Roadmap، احتمالاً فقط:
- پیچیدگی را بیشتر می‌کند
- منطق‌های موازی جدید می‌سازد
- اختلاف reportها را پنهان می‌کند، نه حل

### نتیجه
بهترین مسیر، اجرای مرحله‌ای این برنامه است تا پروژه به این معماری برسد:

```text
One Business Event
↓
One Voucher
↓
One Posting Pipeline
↓
One Reporting Truth
```

---

**پایان Roadmap**
