# WAVE_2_HOTFIX_8.5.1 — رفع باگ خزانه‌داری + معماری یکپارچه‌ی ERP

> نسخه: **8.5.1** — هات‌فیکس روی 8.5.0
> تاریخ: 1405/04/17

## 🐞 گزارش کاربر (۳ مسئله)

1. **جریان نقدی در پیشخوان WP اضافه شد.** کاربر می‌خواهد همه چیز داخل پنل ERP باشد.
2. صفحات **«صندوق‌ها و حساب‌ها»** و **«انتقال بین حساب‌ها»** در پنل ERP سفید می‌شوند.
3. خطای console: `Uncaught ReferenceError: hh is not defined`

## 🔍 ریشه‌ی باگ‌ها

### باگ ۱: صفحات سفید + خطای `hh is not defined`
از **interceptor JSON response** که در 8.4.0 اضافه کرده بودم می‌آمد. آن
interceptor پاسخ‌های JSON را قبل از رسیدن به React normalize می‌کرد
(کلیدهای شبیه تاریخ را تبدیل می‌کرد). این کار برای بعضی response ها امن
بود، ولی در تب‌های خزانه‌داری، کد React انتظار فرمت خاصی از یک فیلد را
داشت (احتمالاً یک فیلد که شامل ساعت `hh` بود) — و interceptor فرمت را
شکسته بود.

### باگ ۲: منو در پیشخوان WP
تصمیم اولیه اشتباه بود. طبق درخواست کاربر «همه چیز داخل ERP» باید حفظ
شود. اما چون source اصلی React در دسترس نیست، تنها راه بدون بازسازی
Wave 4، **iframe در modal** از داخل پنل ERP است.

## ✅ اصلاح‌ها

### الف) حذف کامل response interceptor
**فایل:** `assets/js/cptt-input-normalize.js`

هم در fetch و هم در XMLHttpRequest، بخش «normalize پاسخ» به‌طور کامل حذف
شد. **فقط outgoing (بدنه‌ی درخواست) نرمالایز می‌ماند**. دلایل امن بودن این:
- سرور خودش POSTها را با `CPTT_Date_Utils::normalize_post_digits_in_place`
  نرمالایز می‌کند (defense in depth حفظ شد)
- کد React از ابتدا با ارقام فارسی/انگلیسی هر دو کار می‌کرد
- E-1 اصلی سمت سرور با `fa_date_cmp` فیکس شده — نیازی به نرمالایز
  سمت client نیست

**تضمین:** خطای `hh is not defined` و صفحات سفید از بین می‌روند، و
همه‌ی جاهایی که در 8.4.x کار می‌کردند همچنان کار می‌کنند.

### ب) حذف منوی پیشخوان WP + راه‌اندازی modal داخل ERP
**فایل:** `includes/class-cptt-finance.php`

منو در پیشخوان `add_submenu_page('cptt-finance', ...)` به
`add_submenu_page(null, ...)` تغییر کرد — یعنی صفحه ثبت می‌ماند
(deep-link و iframe کار می‌کنند) ولی در منوی سایدبار WP دیده نمی‌شود.

**فایل جدید:** `assets/js/cptt-erp-extras.js`

یک اسکریپت مستقل (وانیلا JS، بدون jQuery) که فقط در صفحه‌ی ERP لود
می‌شود و:
- یک دکمه‌ی شناور **«💵 جریان نقدی»** در گوشه‌ی راست-پایین صفحه اضافه
  می‌کند (چپ-پایین برای دکمه‌ی «🐞 دیباگ» ذخیره است)
- با کلیک، یک modal تمام‌صفحه با iframe به آدرس
  `admin.php?page=cptt-finance-cashflow&embed=1` باز می‌شود
- دکمه‌های modal: **↻ به‌روزرسانی**، **↗ تب جدید**، **× بستن** (Esc هم کار می‌کند)

**فایل:** `includes/finance/page-cashflow.php` — بدون تغییر منطق

**فایل:** `includes/class-cptt-finance.php` — متد `render_cashflow_page`
حالا اگر `?embed=1` باشد، صفحه را بدون shell وردپرس/افزونه render
می‌کند (خالص برای iframe).

### ج) enqueue و whitelist
**فایل:** `includes/class-cptt-finance-erp.php`
- `cpttf-erp-extras` بعد از `cpttf-erp-app` در ERP enqueue می‌شود
- (پیشوند `cpttf-erp-` از قبل در whitelist `dequeue_3rd_party_assets` بود، پس نیاز به تغییر whitelist نیست)
- URL cashflow در `data-cptt-cashflow-url` روی `<body>` در `admin_footer` گذاشته می‌شود

## 🎨 UX نهایی

بعد از نصب 8.5.1:

- ✅ در پیشخوان WP → منوی «💰 مالی» → **دیگر «💵 جریان نقدی» نیست**
- ✅ پنل ERP باز می‌شود → **در گوشه‌ی راست-پایین یک دکمه‌ی سبز «💵 جریان نقدی»** ظاهر می‌شود
- ✅ کلیک → modal تمام‌صفحه با iframe → گزارش جریان نقدی داخل ERP باز می‌شود
- ✅ Esc یا کلیک روی backdrop یا دکمه‌ی «×» → بسته می‌شود
- ✅ تب‌های خزانه‌داری و انتقال بین حساب‌ها → **دیگر سفید نمی‌شوند**
- ✅ خطای `hh is not defined` → **رفع شد**

## 📁 فایل‌های تغییریافته/جدید

**جدید:**
- `assets/js/cptt-erp-extras.js` (FAB + modal launcher)

**تغییریافته:**
- `client-project-tracker.php` — بامپ نسخه به 8.5.1
- `assets/js/cptt-input-normalize.js` — حذف response interceptor
- `includes/class-cptt-finance.php` — منو از پیشخوان مخفی شد + پشتیبانی `?embed=1`
- `includes/class-cptt-finance-erp.php` — enqueue extras.js

## 🛡️ چه چیزی خراب نشد

- ✅ input normalizer + datepicker شمسی + ورودی فارسی/انگلیسی (v8.4.x) — همه فعال
- ✅ نمایش ساعت audit-trail در اسناد/تسویه/... (v8.4.1) — فعال
- ✅ E-1 فیکس تاریخ سمت سرور — فعال
- ✅ خود صفحه‌ی cashflow (v8.5.0) — بدون تغییر منطق، فقط از داخل ERP باز می‌شود
- ✅ هیچ داده‌ای در دیتابیس تغییر نکرد
