<?php
/**
 * page-cashflow.php — v8.5.0
 *
 * گزارش «جریان نقدی» (Cash Flow / Cash-View)
 * ═══════════════════════════════════════════
 *
 * این گزارش، **در کنار** (نه به جای) گزارش‌های استاندارد سود و زیان،
 * فقط «پول واقعی که وارد یا خارج شده» را نشان می‌دهد — نه تعهدات
 * آینده و نه accrual های حسابداری استاندارد.
 *
 * منابع داده (فقط خواندن، هیچ نوشتنی):
 *   • wp_cptt_fin_ledger  → درآمد/هزینه/تسویه‌های ثبت‌شده در ledger
 *   • wp_cptt_erp_cheques → چک‌های وصول‌شده (status=collected) و پرداخت‌شده (status=paid)
 *   • wp_cptt_erp_installments/installment_rows → اقساط دریافت‌شده
 *
 * چه چیزی *در* گزارش می‌آید:
 *   IN (ورودی نقد):
 *     - چک‌های وصول‌شده (تاریخ = تاریخ وصول)
 *     - اقساط پرداخت‌شده (تاریخ = تاریخ پرداخت)
 *     - درآمدهای دستی از ledger (type=income)
 *   OUT (خروجی نقد):
 *     - چک‌های پرداخت‌شده (تاریخ = تاریخ پرداخت)
 *     - هزینه‌های دستی از ledger (type=expense)
 *     - تسویه‌ی کارشناسان از ledger (type=expert_payout)
 *
 * چه چیزی *در* گزارش نمی‌آید (عمداً):
 *   × چک‌های صادرشده که هنوز نقد نشده‌اند
 *   × اقساط پرداخت‌نشده
 *   × مطالبات باز
 *   × سند حسابداری استاندارد بدون رخداد نقدی
 *
 * غیرمخرب: این فایل کاملاً read-only است. هیچ جدولی تغییر نمی‌کند.
 */

if (!defined('ABSPATH')) exit;

function cpttf_render_cashflow(){
	global $wpdb;
	$cur = class_exists('CPTT_Finance') ? CPTT_Finance::currency_label() : 'تومان';

	// ─── Filters ─────────────────────────────────────────
	$f_from    = isset($_GET['ffrom'])   ? sanitize_text_field((string)$_GET['ffrom']) : '';
	$f_to      = isset($_GET['fto'])     ? sanitize_text_field((string)$_GET['fto'])   : '';
	$f_account = isset($_GET['facc'])    ? (int)$_GET['facc'] : 0;
	$f_group   = isset($_GET['fgroup'])  ? sanitize_key((string)$_GET['fgroup']) : 'day';
	if (!in_array($f_group, ['day','week','month'], true)) $f_group = 'day';

	// normalize + timestamps
	if (class_exists('CPTT_Date_Utils')) {
		$f_from = CPTT_Date_Utils::to_canonical_date($f_from);
		$f_to   = CPTT_Date_Utils::to_canonical_date($f_to);
	}
	$ts_from = 0; $ts_to = 0;
	if ($f_from !== '' && class_exists('CPTT_Finance')) $ts_from = (int) CPTT_Finance::parse_jalali_local($f_from);
	if ($f_to   !== '' && class_exists('CPTT_Finance')) $ts_to   = (int) CPTT_Finance::parse_jalali_local($f_to . ' 23:59');

	// ─── Collect cash events ─────────────────────────────
	$events = cpttf_cashflow_collect_events($ts_from, $ts_to, $f_account);

	// ─── Totals ──────────────────────────────────────────
	$sum_in = 0; $sum_out = 0;
	foreach ($events as $e) {
		if ($e['direction'] > 0) $sum_in  += (float)$e['amount'];
		else                     $sum_out += (float)$e['amount'];
	}
	$net = $sum_in - $sum_out;

	// ─── Grouped series (for chart-like table) ───────────
	$series = cpttf_cashflow_group_by_period($events, $f_group);

	// ─── Accounts for filter ─────────────────────────────
	$accounts = class_exists('CPTT_Finance') ? CPTT_Finance::get_accounts(true) : [];

	$fmt = function($n){
		return class_exists('CPTT_Finance') ? CPTT_Finance::fmt($n) : number_format((float)$n);
	};
	$fa_num = function($n){
		return class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits((string)$n) : (string)$n;
	};
	?>

	<div class="cpttf-grid cpttf-grid--kpis cpttf-grid--3">
		<div class="cpttf-kpi" style="--c:#16a34a">
			<div class="cpttf-kpi__icon">⬇️</div>
			<div class="cpttf-kpi__body">
				<span class="cpttf-kpi__label">جمع ورودی نقد</span>
				<strong class="cpttf-kpi__value"><?php echo $fmt($sum_in); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">در محدوده فیلتر</small>
			</div>
		</div>
		<div class="cpttf-kpi" style="--c:#ef4444">
			<div class="cpttf-kpi__icon">⬆️</div>
			<div class="cpttf-kpi__body">
				<span class="cpttf-kpi__label">جمع خروجی نقد</span>
				<strong class="cpttf-kpi__value"><?php echo $fmt($sum_out); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub">در محدوده فیلتر</small>
			</div>
		</div>
		<div class="cpttf-kpi" style="--c:<?php echo $net >= 0 ? '#0ea5e9' : '#f59e0b'; ?>">
			<div class="cpttf-kpi__icon">📊</div>
			<div class="cpttf-kpi__body">
				<span class="cpttf-kpi__label">جریان نقدی خالص</span>
				<strong class="cpttf-kpi__value"><?php echo $fmt($net); ?> <small><?php echo esc_html($cur); ?></small></strong>
				<small class="cpttf-kpi__sub"><?php echo $net >= 0 ? 'مثبت — ورودی بیش از خروجی' : 'منفی — خروجی بیش از ورودی'; ?></small>
			</div>
		</div>
	</div>

	<div class="cpttf-card" style="margin-top:16px;">
		<div class="cpttf-card__head" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
			<div>
				<strong>ℹ️ درباره‌ی این گزارش</strong>
			</div>
		</div>
		<div class="cpttf-card__body" style="font-size:13px;line-height:1.9;color:#475569;">
			این گزارش <b>فقط رخدادهای نقدی واقعی</b> را نشان می‌دهد — یعنی چک‌هایی که واقعاً وصول/پرداخت شده‌اند، اقساط پرداخت‌شده،
			و درآمد/هزینه/تسویه‌های ثبت‌شده در دفتر مالی. <b>چک‌های صادرشده‌ی هنوز نقدنشده</b>، <b>اقساط آینده</b>، و <b>مطالبات باز</b>
			در این نما ظاهر نمی‌شوند. برای دیدن تعهدات آینده به «مطالبات مشتریان» یا «چک‌ها» در پنل ERP مراجعه کنید.
		</div>
	</div>

	<!-- Filters ─────────────────────────────────────────── -->
	<form method="get" class="cpttf-card" style="margin-top:16px;">
		<div class="cpttf-card__head"><strong>🔎 فیلتر</strong></div>
		<div class="cpttf-card__body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
			<input type="hidden" name="page" value="cptt-finance-cashflow">
			<label>از تاریخ
				<input type="text" name="ffrom" value="<?php echo esc_attr($f_from); ?>" class="cptt-jalali-date" placeholder="۱۴۰۵/۰۱/۰۱" data-cptt-date>
			</label>
			<label>تا تاریخ
				<input type="text" name="fto" value="<?php echo esc_attr($f_to); ?>" class="cptt-jalali-date" placeholder="۱۴۰۵/۱۲/۲۹" data-cptt-date>
			</label>
			<label>حساب خزانه
				<select name="facc">
					<option value="0">— همه حساب‌ها —</option>
					<?php foreach ($accounts as $a): ?>
						<option value="<?php echo (int)$a->id; ?>" <?php selected($f_account, (int)$a->id); ?>>
							<?php echo esc_html($a->icon . ' ' . $a->name); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>گروه‌بندی
				<select name="fgroup">
					<option value="day"   <?php selected($f_group, 'day');   ?>>روزانه</option>
					<option value="week"  <?php selected($f_group, 'week');  ?>>هفتگی</option>
					<option value="month" <?php selected($f_group, 'month'); ?>>ماهانه</option>
				</select>
			</label>
			<div style="display:flex;align-items:end;gap:8px;">
				<button type="submit" class="button button-primary">اعمال فیلتر</button>
				<a href="?page=cptt-finance-cashflow" class="button">پاک کردن</a>
			</div>
		</div>
	</form>

	<!-- Grouped series ─────────────────────────────────── -->
	<div class="cpttf-card" style="margin-top:16px;">
		<div class="cpttf-card__head">
			<strong>📅 جریان نقدی <?php echo $f_group === 'day' ? 'روزانه' : ($f_group === 'week' ? 'هفتگی' : 'ماهانه'); ?></strong>
			<span style="color:#64748b;font-size:12px;margin-inline-start:8px;">
				(<?php echo $fa_num(count($series)); ?> بازه)
			</span>
		</div>
		<div class="cpttf-card__body" style="padding:0;">
			<?php if (empty($series)): ?>
				<div style="padding:40px;text-align:center;color:#94a3b8;">
					<div style="font-size:48px;">📭</div>
					<div style="margin-top:10px;">هیچ رخداد نقدی در بازه‌ی انتخابی یافت نشد.</div>
				</div>
			<?php else: ?>
				<table class="wp-list-table widefat striped" style="border:none;">
					<thead>
						<tr>
							<th style="width:140px;">بازه</th>
							<th style="text-align:end;color:#16a34a;">ورودی</th>
							<th style="text-align:end;color:#ef4444;">خروجی</th>
							<th style="text-align:end;">خالص</th>
							<th style="text-align:end;">موجودی تجمعی</th>
							<th style="width:140px;">تعداد رخداد</th>
							<th style="width:auto;">نمای بصری</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$running = 0;
					$max_abs = 1;
					foreach ($series as $row) $max_abs = max($max_abs, abs($row['net']), $row['in'], $row['out']);
					foreach ($series as $row):
						$running += $row['net'];
						$in_pct  = round(($row['in']  / $max_abs) * 100);
						$out_pct = round(($row['out'] / $max_abs) * 100);
					?>
						<tr>
							<td><strong><?php echo esc_html($row['label']); ?></strong></td>
							<td style="text-align:end;color:#16a34a;font-weight:600;"><?php echo $fmt($row['in']); ?></td>
							<td style="text-align:end;color:#ef4444;font-weight:600;"><?php echo $fmt($row['out']); ?></td>
							<td style="text-align:end;color:<?php echo $row['net']>=0?'#0ea5e9':'#f59e0b'; ?>;font-weight:700;">
								<?php echo $fmt($row['net']); ?>
							</td>
							<td style="text-align:end;color:<?php echo $running>=0?'#0ea5e9':'#f59e0b'; ?>;font-weight:600;">
								<?php echo $fmt($running); ?>
							</td>
							<td><?php echo $fa_num($row['count']); ?></td>
							<td>
								<div style="display:flex;gap:2px;height:14px;align-items:center;">
									<div style="height:100%;width:<?php echo $in_pct; ?>%;background:#16a34a;border-radius:3px;" title="ورودی"></div>
									<div style="height:100%;width:<?php echo $out_pct; ?>%;background:#ef4444;border-radius:3px;" title="خروجی"></div>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</div>

	<!-- Event details ──────────────────────────────────── -->
	<div class="cpttf-card" style="margin-top:16px;">
		<div class="cpttf-card__head">
			<strong>📋 جزئیات رخدادهای نقدی</strong>
			<span style="color:#64748b;font-size:12px;margin-inline-start:8px;">
				(مجموع <?php echo $fa_num(count($events)); ?> ردیف)
			</span>
		</div>
		<div class="cpttf-card__body" style="padding:0;" data-cptt-paginate="25">
			<?php if (empty($events)): ?>
				<div style="padding:40px;text-align:center;color:#94a3b8;">
					<div style="font-size:48px;">📭</div>
					<div style="margin-top:10px;">هیچ رخداد نقدی در بازه‌ی انتخابی یافت نشد.</div>
				</div>
			<?php else: ?>
				<table class="wp-list-table widefat striped" style="border:none;">
					<thead>
						<tr>
							<th style="width:110px;">تاریخ</th>
							<th style="width:80px;">ساعت</th>
							<th style="width:90px;">نوع</th>
							<th>منبع/شرح</th>
							<th style="width:120px;">حساب</th>
							<th style="width:130px;text-align:end;">مبلغ</th>
						</tr>
					</thead>
					<tbody>
					<?php $shown = 0; foreach ($events as $e): if (++$shown > 500) break; ?>
						<tr>
							<td dir="ltr" style="text-align:right;font-family:monospace;"><?php echo esc_html($e['date']); ?></td>
							<td dir="ltr" style="text-align:right;font-family:monospace;color:#64748b;font-size:11px;">
								<?php echo esc_html($e['time'] ?? ''); ?>
							</td>
							<td>
								<span style="padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600;background:<?php
									echo $e['direction'] > 0 ? '#dcfce7' : '#fee2e2';
								?>;color:<?php
									echo $e['direction'] > 0 ? '#166534' : '#991b1b';
								?>;">
									<?php echo esc_html($e['source_label']); ?>
								</span>
							</td>
							<td>
								<div><?php echo esc_html($e['description']); ?></div>
								<?php if (!empty($e['party_name'])): ?>
									<div style="color:#64748b;font-size:11px;margin-top:2px;">👤 <?php echo esc_html($e['party_name']); ?></div>
								<?php endif; ?>
							</td>
							<td style="color:#64748b;font-size:12px;"><?php echo esc_html($e['account_name']); ?></td>
							<td style="text-align:end;font-weight:700;color:<?php echo $e['direction'] > 0 ? '#16a34a' : '#ef4444'; ?>;">
								<?php echo $e['direction'] > 0 ? '+ ' : '- '; ?><?php echo $fmt(abs($e['amount'])); ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</div>

	<style>
		.cpttf-card { background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 1px 3px rgba(15,23,42,.04); }
		.cpttf-card__head { padding:14px 18px;border-bottom:1px solid #f1f5f9;font-size:13px; }
		.cpttf-card__body { padding:16px 18px; }
		.cpttf-card__body table.wp-list-table th,
		.cpttf-card__body table.wp-list-table td { padding:10px 14px; }
	</style>
	<?php
}


/**
 * Collect all cash events from cheques, installments, and ledger.
 *
 * @param int $ts_from  0 = no lower bound
 * @param int $ts_to    0 = no upper bound
 * @param int $account  0 = all treasury accounts
 * @return array of event dicts, sorted by date DESC
 */
function cpttf_cashflow_collect_events($ts_from, $ts_to, $account) {
	global $wpdb;
	$events = [];

	// helper: convert Jalali "YYYY/MM/DD" (or with time) → unix ts
	$fa_to_ts = function($s) {
		if (!$s) return 0;
		if (class_exists('CPTT_Date_Utils')) {
			$ts = CPTT_Date_Utils::jalali_to_timestamp((string)$s);
			if ($ts) return $ts;
		}
		if (class_exists('CPTT_Finance')) return (int) CPTT_Finance::parse_jalali_local((string)$s);
		return 0;
	};
	$in_range = function($ts) use ($ts_from, $ts_to) {
		if ($ts_from && $ts < $ts_from) return false;
		if ($ts_to   && $ts > $ts_to)   return false;
		return true;
	};

	// ─── 1) Ledger events (income, expense, expert_payout, manual) ─────
	if (class_exists('CPTT_Finance')) {
		$tbl = CPTT_Finance::tbl_ledger();
		$sql = "SELECT * FROM $tbl WHERE type IN ('income','expense','manual','expert_payout')";
		$params = [];
		if ($account) { $sql .= ' AND account_id=%d'; $params[] = $account; }
		if ($ts_from) { $sql .= ' AND date_at >= %d'; $params[] = $ts_from; }
		if ($ts_to)   { $sql .= ' AND date_at <= %d'; $params[] = $ts_to; }
		$sql .= ' ORDER BY date_at DESC LIMIT 2000';
		$rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);
		$acc_map = cpttf_cashflow_account_names();
		foreach ((array)$rows as $r) {
			$type = (string)$r->type;
			$dir  = (int)$r->direction;
			$label = 'دستی';
			if ($type === 'income')         $label = 'درآمد';
			elseif ($type === 'expense')    $label = 'هزینه';
			elseif ($type === 'expert_payout') $label = 'تسویه کارشناس';
			$events[] = [
				'ts'           => (int)$r->date_at,
				'date'         => cpttf_cashflow_fa_date((int)$r->date_at),
				'time'         => cpttf_cashflow_fa_time((int)$r->date_at),
				'direction'    => $dir > 0 ? 1 : -1,
				'amount'       => (float)$r->amount,
				'source_type'  => 'ledger',
				'source_label' => $label,
				'description'  => (string)$r->description ?: '—',
				'party_name'   => '',
				'account_id'   => (int)$r->account_id,
				'account_name' => $acc_map[(int)$r->account_id] ?? '—',
			];
		}
	}

	// ─── 2) Cheques (collected = IN, paid = OUT) ────────────────────────
	// جدول cptt_erp_cheques ستون‌های واقعی:
	//   id, kind, number, sayyadi, bank, branch, amount,
	//   issue_date (str), due_date (str), party_*, project_id,
	//   treasury_account_id (str: "t{id}"), status, description,
	//   attachment_id, created_at_fa (str), created_at (int)
	// ⚠️ ستون updated_at وجود ندارد؛ تاریخ نقد شدن را از due_date (تاریخ سررسید
	// که همان زمان نقد رخداده) می‌گیریم؛ اگر خالی بود، از issue_date؛ اگر نبود از created_at.
	$tbl_ch = $wpdb->prefix . 'cptt_erp_cheques';
	if ((int)$wpdb->get_var("SHOW TABLES LIKE '$tbl_ch'")) {
		$rows = $wpdb->get_results("SELECT * FROM $tbl_ch WHERE status IN ('collected','paid') LIMIT 2000");
		foreach ((array)$rows as $c) {
			$cash_ts = $fa_to_ts((string)($c->due_date ?? ''));
			if ($cash_ts <= 0) $cash_ts = $fa_to_ts((string)($c->issue_date ?? ''));
			if ($cash_ts <= 0) $cash_ts = (int)($c->created_at ?? 0);
			if ($cash_ts <= 0) continue;
			if (!$in_range($cash_ts)) continue;
			$acc_id_raw = (string)($c->treasury_account_id ?? '');
			$acc_id = 0;
			if (preg_match('/^t?(\d+)$/', $acc_id_raw, $m)) $acc_id = (int)$m[1];
			if ($account && $acc_id !== $account) continue;
			$is_in = ((string)$c->status === 'collected');
			$acc_name = cpttf_cashflow_account_names()[$acc_id] ?? '—';
			$events[] = [
				'ts'           => $cash_ts,
				'date'         => cpttf_cashflow_fa_date($cash_ts),
				'time'         => cpttf_cashflow_fa_time($cash_ts),
				'direction'    => $is_in ? 1 : -1,
				'amount'       => (float)$c->amount,
				'source_type'  => 'cheque',
				'source_label' => $is_in ? 'چک وصول‌شده' : 'چک پرداخت‌شده',
				'description'  => 'چک شماره ' . (string)($c->number ?? '—') . ' (' . (string)($c->bank ?? '—') . ')',
				'party_name'   => (string)($c->party_name ?? ''),
				'account_id'   => $acc_id,
				'account_name' => $acc_name,
			];
		}
	}

	// ─── 3) Installments (paid rows) ───────────────────────────────────
	// جدول cptt_erp_installment_rows ستون‌های واقعی:
	//   id, plan_id, no, due_date (str), amount, paid_amount, paid_date (str), status
	// (بدون paid_at timestamp) — پس از paid_date استفاده می‌کنیم.
	// جدول cptt_erp_installments header آن‌جا ستون customer_name/party_name دارد.
	$tbl_ip  = $wpdb->prefix . 'cptt_erp_installments';
	$tbl_ipr = $wpdb->prefix . 'cptt_erp_installment_rows';
	if ((int)$wpdb->get_var("SHOW TABLES LIKE '$tbl_ipr'")) {
		// تلاش برای join با header — ممکن است ستون نام مشتری موجود نباشد در
		// نسخه‌های قدیمی. با یک SELECT ایمن ابتدا ستون‌ها را کشف می‌کنیم.
		$plan_cols = [];
		if ((int)$wpdb->get_var("SHOW TABLES LIKE '$tbl_ip'")) {
			$plan_cols = $wpdb->get_col("SHOW COLUMNS FROM $tbl_ip");
		}
		$name_col = in_array('customer_name', $plan_cols, true) ? 'customer_name'
					: (in_array('party_name', $plan_cols, true) ? 'party_name'
					: (in_array('title', $plan_cols, true) ? 'title' : ''));
		$title_col = in_array('title', $plan_cols, true) ? 'title' : $name_col;
		$sel_extra = '';
		if ($name_col)  $sel_extra .= ", p.$name_col AS party_name";
		if ($title_col && $title_col !== $name_col) $sel_extra .= ", p.$title_col AS plan_title";
		$sql = "SELECT r.*$sel_extra FROM $tbl_ipr r"
			. ($name_col ? " LEFT JOIN $tbl_ip p ON p.id = r.plan_id" : "")
			. " WHERE r.paid_amount > 0 LIMIT 2000";
		$rows = $wpdb->get_results($sql);
		foreach ((array)$rows as $r) {
			$paid_date_str = (string)($r->paid_date ?? '');
			$cash_ts = $paid_date_str !== '' ? $fa_to_ts($paid_date_str) : 0;
			if ($cash_ts <= 0) $cash_ts = $fa_to_ts((string)($r->due_date ?? ''));
			if ($cash_ts <= 0) continue;
			if (!$in_range($cash_ts)) continue;
			// اقساط به یک حساب خزانه‌ی خاص متصل نیستند — اگر کاربر فیلتر حساب
			// گذاشت، اقساط را نشان نمی‌دهیم (چون نمی‌توانیم بگوییم به کدام
			// حساب واریز شد).
			if ($account) continue;
			$party = isset($r->party_name) ? (string)$r->party_name : '';
			$plan_title = isset($r->plan_title) ? (string)$r->plan_title : ($party ?: 'برنامه‌ی قسط');
			$events[] = [
				'ts'           => $cash_ts,
				'date'         => cpttf_cashflow_fa_date($cash_ts),
				'time'         => cpttf_cashflow_fa_time($cash_ts),
				'direction'    => 1,
				'amount'       => (float)$r->paid_amount,
				'source_type'  => 'installment',
				'source_label' => 'قسط دریافتی',
				'description'  => $plan_title . ' — قسط شماره ' . (int)($r->no ?? 0),
				'party_name'   => $party,
				'account_id'   => 0,
				'account_name' => '—',
			];
		}
	}

	// ─── Sort by ts DESC ────────────────────────────────────────────────
	usort($events, function($a, $b){ return ((int)$b['ts']) <=> ((int)$a['ts']); });
	return $events;
}


/**
 * Group cash events by day/week/month.
 */
function cpttf_cashflow_group_by_period($events, $group){
	$buckets = [];
	foreach ($events as $e) {
		$ts = (int)$e['ts'];
		if ($ts <= 0) continue;
		$key = ''; $label = '';
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'gregorian_to_jalali')) {
			$dt = new DateTime('@' . $ts);
			$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
			$gy = (int)$dt->format('Y'); $gm = (int)$dt->format('n'); $gd = (int)$dt->format('j');
			[$jy, $jm, $jd] = CPTT_Core::gregorian_to_jalali($gy, $gm, $gd);
			if ($group === 'day') {
				$key = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
				$label = class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits($key) : $key;
			} elseif ($group === 'month') {
				$key = sprintf('%04d/%02d', $jy, $jm);
				$months = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
				$label = ($months[$jm - 1] ?? '?') . ' ' . (class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits((string)$jy) : (string)$jy);
			} else { // week
				// هفته: شنبه شروع، جمعه پایان (تقویم ایران)
				$dow = (int)$dt->format('w'); // 0=Sun..6=Sat
				$offset = ($dow + 1) % 7;     // ش=0, ی=1, ..., ج=6
				$dt_start = clone $dt;
				$dt_start->modify('-' . $offset . ' day');
				$dt_end   = clone $dt_start;
				$dt_end->modify('+6 day');
				$key = $dt_start->format('Y-m-d');
				[$sy, $sm, $sd] = CPTT_Core::gregorian_to_jalali((int)$dt_start->format('Y'), (int)$dt_start->format('n'), (int)$dt_start->format('j'));
				[$ey, $em, $ed] = CPTT_Core::gregorian_to_jalali((int)$dt_end->format('Y'), (int)$dt_end->format('n'), (int)$dt_end->format('j'));
				$wk_s = sprintf('%02d/%02d', $sm, $sd);
				$wk_e = sprintf('%02d/%02d', $em, $ed);
				$label = 'هفته ' . (class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits($wk_s.' – '.$wk_e) : $wk_s.' – '.$wk_e);
			}
		} else {
			$key = date('Y-m-d', $ts);
			$label = $key;
		}
		if (!isset($buckets[$key])) $buckets[$key] = ['label'=>$label, 'in'=>0.0, 'out'=>0.0, 'net'=>0.0, 'count'=>0, 'sort_ts'=>$ts];
		if ($e['direction'] > 0) $buckets[$key]['in']  += (float)$e['amount'];
		else                     $buckets[$key]['out'] += (float)$e['amount'];
		$buckets[$key]['count']++;
		$buckets[$key]['sort_ts'] = max($buckets[$key]['sort_ts'], $ts);
	}
	foreach ($buckets as &$b) $b['net'] = $b['in'] - $b['out'];
	unset($b);
	uasort($buckets, function($a, $b){ return $b['sort_ts'] <=> $a['sort_ts']; });
	return array_values($buckets);
}


/**
 * Cache-friendly account name lookup.
 */
function cpttf_cashflow_account_names(){
	static $map = null;
	if ($map !== null) return $map;
	$map = [];
	if (class_exists('CPTT_Finance')) {
		foreach (CPTT_Finance::get_accounts(true) as $a) {
			$map[(int)$a->id] = (string)$a->name;
		}
	}
	return $map;
}


/** Return Jalali date (canonical + FA digits): "۱۴۰۵/۰۴/۱۷". */
function cpttf_cashflow_fa_date($ts){
	if (!$ts) return '—';
	if (class_exists('CPTT_Date_Utils')) {
		return CPTT_Date_Utils::to_fa_digits(CPTT_Date_Utils::date_of((int)$ts));
	}
	return date('Y/m/d', (int)$ts);
}
function cpttf_cashflow_fa_time($ts){
	if (!$ts) return '';
	try {
		$dt = new DateTime('@' . (int)$ts);
		$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
		$out = $dt->format('H:i');
		return class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits($out) : $out;
	} catch (Exception $e) { return ''; }
}
