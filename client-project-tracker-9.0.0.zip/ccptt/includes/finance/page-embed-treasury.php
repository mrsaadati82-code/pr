<?php
/**
 * page-embed-treasury.php — v8.5.4
 *
 * صفحه‌های embed برای پنل ERP.
 *
 * فلسفه‌ی طراحی:
 *   - از همان کلاس‌های CSS اصلی پنل (cptt-card, cptt-btn-primary,
 *     cptt-input, cptt-select, cptt-table, cptt-pill*, cptt-filterbar,
 *     cptt-label) استفاده می‌کنیم تا ظاهر ۱۰۰٪ یکپارچه با بقیه‌ی تب‌های
 *     ERP باشد.
 *   - ساختار: SectionHeader → Filters → KPIs → Table
 *     شبیه دقیقاً bt() → nl() → xe() → cptt-table در باندل React
 *   - دکمه‌های عملیاتی داخل خود صفحه با modal (بدون رفتن به پیشخوان WP)
 *   - همه فرم‌ها با data-cptt-erp-form که extras.js آن‌ها را با AJAX ارسال می‌کند
 */
if (!defined('ABSPATH')) exit;

// ═══════════════════════════════════════════════════════════════════
//  HELPERS (فقط داخل embed استفاده می‌شوند)
// ═══════════════════════════════════════════════════════════════════

function _cpttf_embed_fmt($n){
	return class_exists('CPTT_Finance') ? CPTT_Finance::fmt($n) : number_format((float)$n);
}
function _cpttf_embed_fa_n($n){
	return class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits((string)$n) : (string)$n;
}
function _cpttf_embed_fa_date($ts){
	if (!$ts) return '—';
	if (class_exists('CPTT_Date_Utils')) return CPTT_Date_Utils::to_fa_digits(CPTT_Date_Utils::date_of((int)$ts));
	return date('Y/m/d', (int)$ts);
}
function _cpttf_embed_fa_time($ts){
	if (!$ts) return '';
	try {
		$dt = new DateTime('@' . (int)$ts);
		$dt->setTimezone(new DateTimeZone('Asia/Tehran'));
		return class_exists('CPTT_Date_Utils') ? CPTT_Date_Utils::to_fa_digits($dt->format('H:i')) : $dt->format('H:i');
	} catch (Exception $e) { return ''; }
}

/**
 * Section header — شبیه bt() در باندل React.
 */
function _cpttf_embed_section_header($icon, $title, $subtitle = '', $actions_html = '') {
	?>
	<div class="flex items-center justify-between flex-wrap gap-3">
		<div class="flex items-center gap-3">
			<div class="w-11 h-11 rounded-2xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center" style="font-size:22px;">
				<?php echo $icon; ?>
			</div>
			<div>
				<h2 class="text-base font-bold text-slate-800" style="margin:0;line-height:1.3;"><?php echo esc_html($title); ?></h2>
				<?php if ($subtitle): ?>
				<p class="text-xs text-slate-500" style="margin:2px 0 0;"><?php echo esc_html($subtitle); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php if ($actions_html): ?>
		<div class="flex items-center gap-2 flex-wrap"><?php echo $actions_html; ?></div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * KPI card — شبیه xe() در باندل React.
 * $color: indigo, emerald, rose, amber, cyan, purple
 */
function _cpttf_embed_kpi($label, $value, $sub = '', $color = 'indigo', $icon = '') {
	?>
	<div class="cptt-card cptt-card-pad hover:shadow-md transition-shadow">
		<div class="flex items-start justify-between gap-2">
			<div class="min-w-0" style="flex:1;">
				<div class="text-[10px] font-medium text-slate-500 flex items-center gap-1"><?php echo esc_html($label); ?></div>
				<div class="text-xl font-bold text-slate-800 mt-1" style="line-height:1.2;"><?php echo $value; ?></div>
				<?php if ($sub): ?>
				<div class="text-[10px] text-slate-400 mt-1"><?php echo esc_html($sub); ?></div>
				<?php endif; ?>
			</div>
			<?php if ($icon): ?>
			<div class="w-10 h-10 rounded-xl bg-<?php echo esc_attr($color); ?>-500/10 text-<?php echo esc_attr($color); ?>-600 flex items-center justify-center flex-shrink-0" style="font-size:20px;">
				<?php echo $icon; ?>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/**
 * Pill (colored badge) — شبیه cptt-pill-* در باندل.
 */
function _cpttf_embed_pill($text, $variant = 'neutral') {
	echo '<span class="cptt-pill cptt-pill-' . esc_attr($variant) . '">' . esc_html($text) . '</span>';
}

/**
 * Empty state
 */
function _cpttf_embed_empty($icon, $title, $desc = '', $action_html = '') {
	?>
	<div class="bg-white border border-dashed border-slate-300 rounded-2xl p-10 md:p-12 text-center">
		<div class="text-slate-300 mb-3 flex justify-center" style="font-size:48px;line-height:1;"><?php echo $icon; ?></div>
		<h3 class="text-sm md:text-base font-bold text-slate-700 mb-1" style="margin:0 0 4px;"><?php echo esc_html($title); ?></h3>
		<?php if ($desc): ?>
		<p class="text-xs text-slate-500" style="margin:0 0 12px;"><?php echo esc_html($desc); ?></p>
		<?php endif; ?>
		<?php if ($action_html): ?>
		<div style="margin-top:14px;"><?php echo $action_html; ?></div>
		<?php endif; ?>
	</div>
	<?php
}


// ═══════════════════════════════════════════════════════════════════
//  🏦 TREASURY — صندوق‌ها و حساب‌ها
// ═══════════════════════════════════════════════════════════════════

function cpttf_render_embed_treasury(){
	$cur = class_exists('CPTT_Finance') ? CPTT_Finance::currency_label() : 'تومان';
	$accs = class_exists('CPTT_Finance') ? CPTT_Finance::get_accounts(true) : [];

	// Totals
	$total = 0; $bank_count = 0; $cash_count = 0;
	foreach ($accs as $a) {
		$total += (float) CPTT_Finance::account_balance((int)$a->id);
		if (($a->type ?? '') === 'bank') $bank_count++; else $cash_count++;
	}
	?>
	<div class="space-y-5" style="display:flex;flex-direction:column;gap:20px;">

		<?php
		$actions = '<button type="button" class="cptt-btn cptt-btn-primary" data-cptt-action="treasury-add">'
			. '<span>➕</span> افزودن حساب</button>';
		_cpttf_embed_section_header('🏦', 'صندوق‌ها و حساب‌های خزانه', 'مدیریت بانک‌ها و صندوق‌های نقدی', $actions);
		?>

		<div class="grid grid-cols-1 md:grid-cols-3 gap-3" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
			<?php
			_cpttf_embed_kpi('مجموع موجودی', _cpttf_embed_fmt($total) . ' <small class="text-slate-400 text-[10px]">' . esc_html($cur) . '</small>', 'همه‌ی حساب‌ها', 'indigo', '💰');
			_cpttf_embed_kpi('حساب بانکی', _cpttf_embed_fa_n($bank_count), 'حساب فعال', 'cyan', '🏦');
			_cpttf_embed_kpi('صندوق نقدی', _cpttf_embed_fa_n($cash_count), 'صندوق فعال', 'amber', '💵');
			?>
		</div>

		<div class="cptt-card">
			<div class="cptt-table-wrap" data-cptt-paginate="20">
				<?php if (empty($accs)): ?>
					<?php _cpttf_embed_empty('🏦', 'هنوز حسابی ثبت نکرده‌اید',
						'برای شروع، اولین حساب بانکی یا صندوق خود را اضافه کنید.',
						'<button type="button" class="cptt-btn cptt-btn-primary" data-cptt-action="treasury-add">➕ افزودن اولین حساب</button>'); ?>
				<?php else: ?>
					<table class="cptt-table">
						<thead>
							<tr>
								<th style="text-align:start;">حساب</th>
								<th style="text-align:start;">نوع</th>
								<th style="text-align:start;">شماره حساب</th>
								<th style="text-align:start;">شبا</th>
								<th style="text-align:end;">موجودی</th>
								<th style="text-align:start;">وضعیت</th>
								<th style="text-align:end;">عملیات</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($accs as $a):
							$bal = (float) CPTT_Finance::account_balance((int)$a->id);
							$is_bank = ($a->type === 'bank');
						?>
							<tr>
								<td>
									<div class="flex items-center gap-2">
										<span style="font-size:18px;line-height:1;"><?php echo esc_html($a->icon ?: '🏦'); ?></span>
										<strong class="text-slate-800"><?php echo esc_html($a->name); ?></strong>
									</div>
								</td>
								<td><?php _cpttf_embed_pill($is_bank ? 'بانکی' : 'نقدی', $is_bank ? 'info' : 'warning'); ?></td>
								<td dir="ltr" style="text-align:start;font-family:monospace;color:#64748b;font-size:12px;"><?php echo esc_html($a->account_number ?: '—'); ?></td>
								<td dir="ltr" style="text-align:start;font-family:monospace;color:#64748b;font-size:11px;"><?php echo esc_html($a->iban ?: '—'); ?></td>
								<td style="text-align:end;font-weight:700;color:<?php echo $bal >= 0 ? '#059669' : '#e11d48'; ?>;"><?php echo _cpttf_embed_fmt($bal); ?></td>
								<td>
									<?php if ((int)$a->status): _cpttf_embed_pill('فعال', 'success');
									else: _cpttf_embed_pill('غیرفعال', 'neutral'); endif; ?>
								</td>
								<td style="text-align:end;">
									<div class="flex items-center gap-1" style="justify-content:flex-end;">
										<button type="button" class="cptt-btn cptt-btn-ghost cptt-btn-sm"
												data-cptt-action="treasury-edit"
												data-id="<?php echo (int)$a->id; ?>"
												data-name="<?php echo esc_attr($a->name); ?>"
												data-type="<?php echo esc_attr($a->type); ?>"
												data-icon="<?php echo esc_attr($a->icon); ?>"
												data-account-number="<?php echo esc_attr($a->account_number); ?>"
												data-iban="<?php echo esc_attr($a->iban); ?>"
												data-status="<?php echo (int)$a->status; ?>">
											✎ ویرایش
										</button>
										<button type="button" class="cptt-btn cptt-btn-ghost cptt-btn-sm" style="color:#e11d48;"
												data-cptt-action="treasury-delete"
												data-id="<?php echo (int)$a->id; ?>"
												data-name="<?php echo esc_attr($a->name); ?>">
											🗑
										</button>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php _cpttf_embed_treasury_modal_template(); ?>
	<?php
}

function _cpttf_embed_treasury_modal_template(){
	// Modal template — extras.js آن را باز/بسته می‌کند
	?>
	<template id="cptt-tpl-treasury-form">
		<form data-cptt-erp-form="treasury_save">
			<div class="grid grid-cols-1 md:grid-cols-2 gap-3" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
				<div>
					<label class="cptt-label">نام حساب <span class="text-rose-500">*</span></label>
					<input type="text" name="name" class="cptt-input" required placeholder="مثلاً: بانک ملت شعبه مرکزی">
				</div>
				<div>
					<label class="cptt-label">نوع <span class="text-rose-500">*</span></label>
					<select name="type" class="cptt-select" required>
						<option value="bank">🏦 حساب بانکی</option>
						<option value="cash">💵 صندوق نقدی</option>
					</select>
				</div>
				<div>
					<label class="cptt-label">آیکن (اختیاری)</label>
					<input type="text" name="icon" class="cptt-input" placeholder="🏦 🏛 💳 💰 💵" maxlength="4">
				</div>
				<div>
					<label class="cptt-label">وضعیت</label>
					<select name="status" class="cptt-select">
						<option value="1">فعال</option>
						<option value="0">غیرفعال</option>
					</select>
				</div>
				<div>
					<label class="cptt-label">شماره حساب (اختیاری)</label>
					<input type="text" name="account_number" class="cptt-input" placeholder="0123456789">
				</div>
				<div>
					<label class="cptt-label">شبا / IBAN (اختیاری)</label>
					<input type="text" name="iban" class="cptt-input" placeholder="IR000000000000000000000000">
				</div>
			</div>
			<input type="hidden" name="id" value="">
		</form>
	</template>
	<?php
}


// ═══════════════════════════════════════════════════════════════════
//  🔁 TRANSFERS — انتقال بین حساب‌ها
// ═══════════════════════════════════════════════════════════════════

function cpttf_render_embed_transfers(){
	$cur = class_exists('CPTT_Finance') ? CPTT_Finance::currency_label() : 'تومان';
	$accs = class_exists('CPTT_Finance') ? CPTT_Finance::get_accounts(true) : [];
	global $wpdb;

	// آخرین انتقال‌ها
	$rows = [];
	if (class_exists('CPTT_Finance')) {
		$tbl = CPTT_Finance::tbl_ledger();
		$rows = $wpdb->get_results("SELECT * FROM $tbl WHERE type IN ('transfer_in','transfer_out') ORDER BY date_at DESC LIMIT 500");
	}
	$pairs = [];
	foreach ((array)$rows as $r) {
		$id1 = (int)$r->id; $id2 = (int)($r->linked_id ?: $r->id);
		$key = min($id1, $id2) . '_' . max($id1, $id2);
		if (!isset($pairs[$key])) $pairs[$key] = ['out'=>null, 'in'=>null, 'ts'=>0];
		if ($r->type === 'transfer_out') $pairs[$key]['out'] = $r;
		else                              $pairs[$key]['in']  = $r;
		$pairs[$key]['ts'] = max($pairs[$key]['ts'], (int)$r->date_at);
	}
	uasort($pairs, function($a, $b){ return $b['ts'] <=> $a['ts']; });
	$pairs = array_values($pairs);
	$count = count($pairs);
	$total = 0;
	foreach ($pairs as $p) if ($p['out']) $total += (float)$p['out']->amount;

	$acc_map = [];
	foreach ($accs as $a) $acc_map[(int)$a->id] = $a;
	?>
	<div class="space-y-5" style="display:flex;flex-direction:column;gap:20px;">

		<?php
		$actions = '<button type="button" class="cptt-btn cptt-btn-primary" data-cptt-action="transfer-add">'
			. '<span>🔁</span> ثبت انتقال جدید</button>';
		_cpttf_embed_section_header('🔁', 'انتقال بین حساب‌ها', 'جابجایی وجه بین صندوق‌ها و حساب‌های خزانه', $actions);
		?>

		<div class="grid grid-cols-1 md:grid-cols-3 gap-3" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
			<?php
			_cpttf_embed_kpi('تعداد انتقال', _cpttf_embed_fa_n($count), 'مجموع تاریخچه', 'indigo', '🔁');
			_cpttf_embed_kpi('مجموع منتقل‌شده', _cpttf_embed_fmt($total) . ' <small class="text-slate-400 text-[10px]">' . esc_html($cur) . '</small>', 'همه‌ی زمان', 'cyan', '💸');
			_cpttf_embed_kpi('حساب‌های فعال', _cpttf_embed_fa_n(count($accs)), 'قابل انتقال', 'emerald', '🏦');
			?>
		</div>

		<div class="cptt-card">
			<div class="cptt-table-wrap" data-cptt-paginate="20">
				<?php if (empty($pairs)): ?>
					<?php _cpttf_embed_empty('🔁', 'هنوز انتقالی ثبت نکرده‌اید',
						'اولین انتقال بین دو حساب خود را ثبت کنید.',
						'<button type="button" class="cptt-btn cptt-btn-primary" data-cptt-action="transfer-add">➕ ثبت اولین انتقال</button>'); ?>
				<?php else: ?>
					<table class="cptt-table">
						<thead>
							<tr>
								<th style="text-align:start;width:110px;">تاریخ</th>
								<th style="text-align:start;width:70px;">ساعت</th>
								<th style="text-align:start;">از حساب</th>
								<th style="text-align:start;">به حساب</th>
								<th style="text-align:end;">مبلغ</th>
								<th style="text-align:start;">توضیحات</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($pairs as $p):
							if (!$p['out'] || !$p['in']) continue;
							$from_a = $acc_map[(int)$p['out']->account_id] ?? null;
							$to_a   = $acc_map[(int)$p['in']->account_id]  ?? null;
						?>
							<tr>
								<td dir="ltr" style="text-align:start;font-family:monospace;"><?php echo esc_html(_cpttf_embed_fa_date((int)$p['out']->date_at)); ?></td>
								<td dir="ltr" style="text-align:start;font-family:monospace;color:#94a3b8;font-size:11px;"><?php echo esc_html(_cpttf_embed_fa_time((int)$p['out']->date_at)); ?></td>
								<td>
									<div class="flex items-center gap-2">
										<span><?php echo esc_html($from_a ? ($from_a->icon ?: '🏦') : '?'); ?></span>
										<strong class="text-slate-800"><?php echo esc_html($from_a ? $from_a->name : '—'); ?></strong>
									</div>
								</td>
								<td>
									<div class="flex items-center gap-2">
										<span style="color:#94a3b8;">←</span>
										<span><?php echo esc_html($to_a ? ($to_a->icon ?: '🏦') : '?'); ?></span>
										<strong class="text-slate-800"><?php echo esc_html($to_a ? $to_a->name : '—'); ?></strong>
									</div>
								</td>
								<td style="text-align:end;font-weight:700;color:#0f172a;"><?php echo _cpttf_embed_fmt((float)$p['out']->amount); ?></td>
								<td style="color:#64748b;font-size:12px;"><?php echo esc_html($p['out']->description ?: '—'); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php
	// balance data برای هر حساب — در client استفاده می‌شود
	$acc_balances = [];
	foreach ($accs as $a) {
		$acc_balances[(int)$a->id] = [
			'name'    => (string)($a->icon ? $a->icon . ' ' : '') . $a->name,
			'balance' => (float) CPTT_Finance::account_balance((int)$a->id),
		];
	}
	?>
	<template id="cptt-tpl-transfer-form">
		<form data-cptt-erp-form="treasury_transfer" data-cptt-transfer-form
			  data-accounts="<?php echo esc_attr(wp_json_encode($acc_balances, JSON_UNESCAPED_UNICODE)); ?>">
			<div class="grid grid-cols-1 md:grid-cols-2 gap-3" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
				<div>
					<label class="cptt-label">از حساب <span class="text-rose-500">*</span></label>
					<select name="from_id" class="cptt-select" required data-cptt-balance-select="from">
						<option value="">— انتخاب کنید —</option>
						<?php foreach ($accs as $a):
							$b = (float) CPTT_Finance::account_balance((int)$a->id);
						?>
						<option value="<?php echo (int)$a->id; ?>" data-balance="<?php echo esc_attr($b); ?>">
							<?php echo esc_html($a->icon . ' ' . $a->name); ?> — موجودی: <?php echo _cpttf_embed_fmt($b); ?>
						</option>
						<?php endforeach; ?>
					</select>
					<div class="cptt-erp-balance-hint" data-cptt-balance-hint="from" style="display:none;"></div>
				</div>
				<div>
					<label class="cptt-label">به حساب <span class="text-rose-500">*</span></label>
					<select name="to_id" class="cptt-select" required data-cptt-balance-select="to">
						<option value="">— انتخاب کنید —</option>
						<?php foreach ($accs as $a):
							$b = (float) CPTT_Finance::account_balance((int)$a->id);
						?>
						<option value="<?php echo (int)$a->id; ?>" data-balance="<?php echo esc_attr($b); ?>">
							<?php echo esc_html($a->icon . ' ' . $a->name); ?> — موجودی: <?php echo _cpttf_embed_fmt($b); ?>
						</option>
						<?php endforeach; ?>
					</select>
					<div class="cptt-erp-balance-hint" data-cptt-balance-hint="to" style="display:none;"></div>
				</div>
				<div>
					<label class="cptt-label">مبلغ <span class="text-rose-500">*</span></label>
					<input type="text" name="amount" class="cptt-input cptt-input-num" required placeholder="0" data-cptt-amount data-cptt-transfer-amount>
					<div class="cptt-erp-balance-hint" data-cptt-transfer-remainder style="display:none;"></div>
				</div>
				<div>
					<label class="cptt-label">تاریخ</label>
					<input type="text" name="date_local" class="cptt-input cptt-jalali-date" data-cptt-date placeholder="امروز">
				</div>
				<div style="grid-column:1/-1;">
					<label class="cptt-label">توضیحات (اختیاری)</label>
					<input type="text" name="note" class="cptt-input" placeholder="توضیح انتقال...">
				</div>
			</div>
		</form>
	</template>
	<?php
}


// ═══════════════════════════════════════════════════════════════════
//  💵 TRANSACTIONS — درآمد و هزینه
// ═══════════════════════════════════════════════════════════════════

function cpttf_render_embed_transactions(){
	global $wpdb;
	$cur = class_exists('CPTT_Finance') ? CPTT_Finance::currency_label() : 'تومان';
	$accs = class_exists('CPTT_Finance') ? CPTT_Finance::get_accounts(true) : [];
	$cats_in  = class_exists('CPTT_Finance') ? CPTT_Finance::get_categories('income')  : [];
	$cats_out = class_exists('CPTT_Finance') ? CPTT_Finance::get_categories('expense') : [];

	// Filters
	$f_type    = isset($_GET['ftype']) ? sanitize_key($_GET['ftype']) : '';
	$f_account = isset($_GET['facc'])  ? (int)$_GET['facc'] : 0;
	$f_from    = isset($_GET['ffrom']) ? sanitize_text_field($_GET['ffrom']) : '';
	$f_to      = isset($_GET['fto'])   ? sanitize_text_field($_GET['fto'])   : '';
	if (class_exists('CPTT_Date_Utils')) {
		$f_from = CPTT_Date_Utils::to_canonical_date($f_from);
		$f_to   = CPTT_Date_Utils::to_canonical_date($f_to);
	}
	$where = ["type IN ('income','expense')"]; $params = [];
	if ($f_type === 'income' || $f_type === 'expense') { $where[] = 'type=%s'; $params[] = $f_type; }
	if ($f_account) { $where[] = 'account_id=%d'; $params[] = $f_account; }
	if ($f_from && class_exists('CPTT_Finance')) { $where[] = 'date_at >= %d'; $params[] = (int)CPTT_Finance::parse_jalali_local($f_from); }
	if ($f_to   && class_exists('CPTT_Finance')) { $where[] = 'date_at <= %d'; $params[] = (int)CPTT_Finance::parse_jalali_local($f_to . ' 23:59'); }
	$rows = [];
	if (class_exists('CPTT_Finance')) {
		$sql = "SELECT * FROM " . CPTT_Finance::tbl_ledger() . " WHERE " . implode(' AND ', $where) . " ORDER BY date_at DESC LIMIT 1000";
		$rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params)) : $wpdb->get_results($sql);
	}
	$sum_in = 0; $sum_out = 0;
	foreach ($rows as $r) {
		if ($r->type === 'income')  $sum_in  += (float)$r->amount;
		if ($r->type === 'expense') $sum_out += (float)$r->amount;
	}
	$acc_map = [];
	foreach ($accs as $a) $acc_map[(int)$a->id] = $a;
	$cat_map = [];
	foreach (array_merge((array)$cats_in, (array)$cats_out) as $c) $cat_map[(int)$c->id] = $c;
	?>
	<div class="space-y-5" style="display:flex;flex-direction:column;gap:20px;">

		<?php
		$actions = '<button type="button" class="cptt-btn cptt-btn-success" data-cptt-action="ie-add" data-type="income">'
			. '<span>💵</span> ثبت درآمد</button>'
			. ' <button type="button" class="cptt-btn cptt-btn-danger" data-cptt-action="ie-add" data-type="expense">'
			. '<span>📤</span> ثبت هزینه</button>';
		_cpttf_embed_section_header('💸', 'درآمدها و هزینه‌ها', 'ثبت دستی تراکنش‌های نقدی', $actions);
		?>

		<div class="grid grid-cols-1 md:grid-cols-3 gap-3" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
			<?php
			_cpttf_embed_kpi('جمع درآمد', _cpttf_embed_fmt($sum_in) . ' <small class="text-slate-400 text-[10px]">' . esc_html($cur) . '</small>', 'در محدوده فیلتر', 'emerald', '💵');
			_cpttf_embed_kpi('جمع هزینه', _cpttf_embed_fmt($sum_out) . ' <small class="text-slate-400 text-[10px]">' . esc_html($cur) . '</small>', 'در محدوده فیلتر', 'rose', '📤');
			$net = $sum_in - $sum_out;
			_cpttf_embed_kpi('خالص', _cpttf_embed_fmt($net) . ' <small class="text-slate-400 text-[10px]">' . esc_html($cur) . '</small>', ($net >= 0 ? 'مثبت' : 'منفی'), ($net >= 0 ? 'cyan' : 'amber'), '📊');
			?>
		</div>

		<div class="cptt-card cptt-filter-card">
			<form method="get" class="cptt-filterbar">
				<input type="hidden" name="page" value="cptt-finance-transactions">
				<input type="hidden" name="embed" value="1">
				<div>
					<label class="cptt-label">نوع</label>
					<select name="ftype" class="cptt-select">
						<option value="">— همه —</option>
						<option value="income" <?php selected($f_type, 'income'); ?>>💵 درآمد</option>
						<option value="expense" <?php selected($f_type, 'expense'); ?>>📤 هزینه</option>
					</select>
				</div>
				<div>
					<label class="cptt-label">حساب</label>
					<select name="facc" class="cptt-select">
						<option value="0">— همه —</option>
						<?php foreach ($accs as $a): ?>
						<option value="<?php echo (int)$a->id; ?>" <?php selected($f_account, (int)$a->id); ?>><?php echo esc_html($a->icon . ' ' . $a->name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div>
					<label class="cptt-label">از تاریخ</label>
					<input type="text" name="ffrom" value="<?php echo esc_attr($f_from); ?>" class="cptt-input cptt-jalali-date" data-cptt-date placeholder="۱۴۰۵/۰۱/۰۱">
				</div>
				<div>
					<label class="cptt-label">تا تاریخ</label>
					<input type="text" name="fto" value="<?php echo esc_attr($f_to); ?>" class="cptt-input cptt-jalali-date" data-cptt-date placeholder="۱۴۰۵/۱۲/۲۹">
				</div>
				<div class="cptt-filter-actions">
					<button type="submit" class="cptt-btn cptt-btn-primary">اعمال فیلتر</button>
					<button type="button" class="cptt-btn cptt-btn-ghost" data-cptt-action="ie-reset-filter">پاک کردن</button>
				</div>
			</form>
		</div>

		<div class="cptt-card">
			<div class="cptt-table-wrap" data-cptt-paginate="25">
				<?php if (empty($rows)): ?>
					<?php _cpttf_embed_empty('📭', 'تراکنشی یافت نشد',
						'در بازه‌ی انتخابی هیچ درآمد یا هزینه‌ای ثبت نشده.',
						'<button type="button" class="cptt-btn cptt-btn-success" data-cptt-action="ie-add" data-type="income">➕ ثبت درآمد</button>'); ?>
				<?php else: ?>
					<table class="cptt-table">
						<thead>
							<tr>
								<th style="text-align:start;width:110px;">تاریخ</th>
								<th style="text-align:start;width:70px;">ساعت</th>
								<th style="text-align:start;width:80px;">نوع</th>
								<th style="text-align:start;">شرح</th>
								<th style="text-align:start;">دسته</th>
								<th style="text-align:start;">حساب</th>
								<th style="text-align:end;">مبلغ</th>
								<th style="text-align:end;width:100px;">عملیات</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($rows as $r):
							$is_in = $r->type === 'income';
							$acc = $acc_map[(int)$r->account_id] ?? null;
							$cat = isset($cat_map[(int)$r->category_id]) ? $cat_map[(int)$r->category_id] : null;
						?>
							<tr>
								<td dir="ltr" style="text-align:start;font-family:monospace;"><?php echo esc_html(_cpttf_embed_fa_date((int)$r->date_at)); ?></td>
								<td dir="ltr" style="text-align:start;font-family:monospace;color:#94a3b8;font-size:11px;"><?php echo esc_html(_cpttf_embed_fa_time((int)$r->date_at)); ?></td>
								<td><?php _cpttf_embed_pill($is_in ? 'درآمد' : 'هزینه', $is_in ? 'success' : 'danger'); ?></td>
								<td style="color:#334155;"><?php echo esc_html($r->description ?: '—'); ?></td>
								<td style="color:#64748b;font-size:12px;"><?php echo $cat ? esc_html($cat->name) : '—'; ?></td>
								<td style="color:#64748b;font-size:12px;">
									<?php if ($acc): ?><span><?php echo esc_html($acc->icon . ' ' . $acc->name); ?></span>
									<?php else: ?>—<?php endif; ?>
								</td>
								<td style="text-align:end;font-weight:700;color:<?php echo $is_in ? '#059669' : '#e11d48'; ?>;">
									<?php echo $is_in ? '+ ' : '- '; ?><?php echo _cpttf_embed_fmt((float)$r->amount); ?>
								</td>
								<td style="text-align:end;">
									<button type="button" class="cptt-btn cptt-btn-ghost cptt-btn-sm" style="color:#e11d48;"
											data-cptt-action="ie-delete"
											data-id="<?php echo (int)$r->id; ?>"
											data-desc="<?php echo esc_attr($r->description ?: '—'); ?>">
										🗑
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<template id="cptt-tpl-ie-form-income">
		<form data-cptt-erp-form="ie_save">
			<input type="hidden" name="type" value="income">
			<div class="grid grid-cols-1 md:grid-cols-2 gap-3" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
				<div>
					<label class="cptt-label">مبلغ <span class="text-rose-500">*</span></label>
					<input type="text" name="amount" class="cptt-input cptt-input-num" required placeholder="0" data-cptt-amount>
				</div>
				<div>
					<label class="cptt-label">حساب واریز <span class="text-rose-500">*</span></label>
					<select name="account_id" class="cptt-select" required>
						<option value="">— انتخاب —</option>
						<?php foreach ($accs as $a): ?>
						<option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div>
					<label class="cptt-label">تاریخ</label>
					<input type="text" name="date_local" class="cptt-input cptt-jalali-date" data-cptt-date placeholder="امروز">
				</div>
				<div>
					<label class="cptt-label">دسته</label>
					<select name="category_id" class="cptt-select">
						<option value="0">— بدون دسته —</option>
						<?php foreach ($cats_in as $c): ?>
						<option value="<?php echo (int)$c->id; ?>"><?php echo esc_html($c->name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div style="grid-column:1/-1;">
					<label class="cptt-label">شرح <span class="text-rose-500">*</span></label>
					<input type="text" name="description" class="cptt-input" required placeholder="مثلاً: دریافت وجه از مشتری">
				</div>
			</div>
		</form>
	</template>

	<template id="cptt-tpl-ie-form-expense">
		<form data-cptt-erp-form="ie_save">
			<input type="hidden" name="type" value="expense">
			<div class="grid grid-cols-1 md:grid-cols-2 gap-3" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
				<div>
					<label class="cptt-label">مبلغ <span class="text-rose-500">*</span></label>
					<input type="text" name="amount" class="cptt-input cptt-input-num" required placeholder="0" data-cptt-amount>
				</div>
				<div>
					<label class="cptt-label">حساب برداشت <span class="text-rose-500">*</span></label>
					<select name="account_id" class="cptt-select" required>
						<option value="">— انتخاب —</option>
						<?php foreach ($accs as $a): ?>
						<option value="<?php echo (int)$a->id; ?>"><?php echo esc_html($a->icon . ' ' . $a->name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div>
					<label class="cptt-label">تاریخ</label>
					<input type="text" name="date_local" class="cptt-input cptt-jalali-date" data-cptt-date placeholder="امروز">
				</div>
				<div>
					<label class="cptt-label">دسته</label>
					<select name="category_id" class="cptt-select">
						<option value="0">— بدون دسته —</option>
						<?php foreach ($cats_out as $c): ?>
						<option value="<?php echo (int)$c->id; ?>"><?php echo esc_html($c->name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div style="grid-column:1/-1;">
					<label class="cptt-label">شرح <span class="text-rose-500">*</span></label>
					<input type="text" name="description" class="cptt-input" required placeholder="مثلاً: پرداخت اجاره">
				</div>
			</div>
		</form>
	</template>
	<?php
}
