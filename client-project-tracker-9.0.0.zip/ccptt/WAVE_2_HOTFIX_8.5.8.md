# WAVE_2_HOTFIX_8.5.8 — رفع نهایی hash-refresh (race condition)

> نسخه: **8.5.8**

## گزارش کاربر

بعد از v8.5.7، رفرش هنوز به داشبورد می‌رفت (روی همه‌ی تب‌ها).

## علت واقعی (race condition)

سناریوی page load:

1. کاربر روی تب `cheques` است → URL: `?page=cptt-finance-erp#tab=cheques`
2. F5 → صفحه reload می‌شود
3. بندل React load می‌شود → `Pj` mount → `useState("dashboard")` → `currentTab = "dashboard"`
4. `useEffect` اجرا می‌شود → `window.__cpttErpCurrentTab = "dashboard"` + `window.__cpttErpSetTab = p`
5. `extras.js/boot()` اجرا می‌شود:
    - **`bindSidebarClickTracking()`** — polling شروع می‌شود که `window.__cpttErpCurrentTab` را چک کند
    - **`restoreTabFromHash()`** — `readHashTab() === "cheques"` → می‌خواهد `setTab("cheques")` صدا بزند

مشکل اصلی: **polling سریع‌تر می‌بیند** که `cur = "dashboard"` (state پیش‌فرض بندل) → `updateHash("dashboard")` → **hash کاربر (`#tab=cheques`) overwrite می‌شود!**

سپس `restoreTabFromHash` اجرا می‌شود ولی hash دیگر `"dashboard"` است → early-return می‌کند → کاربر روی dashboard می‌ماند.

## اصلاح

**در `bindSidebarClickTracking`:**

```js
var initialHash = readHashTab();
var lastSeen = initialHash || null;
var bootProtection = !!initialHash;
setTimeout(function(){ bootProtection = false; }, 5000);

setInterval(function(){
    var cur = window.__cpttErpCurrentTab;
    if (cur === lastSeen) return;
    // در ۵ ثانیه اول پس از load، اگر cur=dashboard است و کاربر hash
    // دیگری داشت، صبر می‌کنیم تا restoreTabFromHash کار کند.
    if (bootProtection && cur === 'dashboard' && lastSeen !== 'dashboard') return;
    lastSeen = cur;
    updateHash(cur);
}, 250);
```

**در `boot`:**
- `restoreTabFromHash()` بلافاصله صدا زده می‌شود (بدون setTimeout 500ms)
- polling در `bindSidebarClickTracking` هم بلافاصله شروع می‌شود ولی با guard

**در `restoreTabFromHash`:**
- polling interval کاهش یافت به 100ms (سریع‌تر پیدا می‌کند)
- بعد از موفقیت verify سپس stop می‌شود

## نتیجه

- ✅ F5 روی هر تب → همان تب باقی می‌ماند
- ✅ کلیک روی تب دیگر → hash update می‌شود
- ✅ Back/Forward مرورگر همچنان کار می‌کند

## فایل تغییریافته

- `assets/js/cptt-erp-extras.js` (فقط race condition fix — بقیه چیزها همان v8.5.7)
- `client-project-tracker.php` (بامپ نسخه)
