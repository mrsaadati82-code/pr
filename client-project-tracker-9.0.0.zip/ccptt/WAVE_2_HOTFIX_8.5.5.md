# WAVE_2_HOTFIX_8.5.5 — چهار رفع‌مشکل برای تب‌های سفارشی

> نسخه: **8.5.5** — تاریخ: 1405/04/17

## گزارش کاربر

1. **جابجایی بین تب‌های سفارشی کار نمی‌کند** — کلیک از treasury به transfers → آدرس عوض ولی صفحه همان می‌ماند. باید اول به تبی «خارج از این ۳ تا» بروم و برگردم.
2. **مدال‌ها و input‌ها فونت و ظاهر متفاوت** با پنل دارند.
3. **در انتقال:** موجودی حساب مبدأ نمایش داده نمی‌شود.
4. **باگ مهم:** انتقال با مبلغی **بیشتر از موجودی** بدون خطا ثبت می‌شود؛ و در اسناد حسابداری هیچ سندی برای این انتقال ثبت نشده.

## اصلاحات

### 🔧 مشکل ۱: تغییر تب بین سه تب سفارشی

**علت:** React برای هر تب یک `<div>` می‌سازد که همه‌ی type/tag یکسان دارند. React بدون `key` منحصربه‌فرد **همان DOM element را reuse می‌کند** — فقط attributes را update می‌کند. نتیجه:
- `document.querySelector('[data-slot="treasury"]')` همان element قبلی را برمی‌گرداند
- `_cpttInit = true` هنوز روی آن است → extras.js آن را «قبلاً init شده» می‌بیند و load دوباره نمی‌کند
- بنابراین محتوای قبلی روی صفحه می‌ماند

**اصلاح (دولایه):**

**الف)** به هر JSX slot **React key منحصربه‌فرد** اضافه شد:
```js
l.jsx("div", {id:"cptt-treasury-slot", ...}, "cptt-slot-treasury")
```
با key متفاوت، React مجبور می‌شود element قبلی را unmount و element جدید mount کند.

**ب)** در extras.js از `WeakSet` برای init tracking استفاده شد، و **اگر element خالی شود** (بعد از تغییر تب و mount مجدد)، دوباره reload می‌شود:
```js
var isEmpty = slot.children.length === 0 && slot.textContent.trim() === '';
if (wasInit && !isEmpty) continue;  // skip فقط اگر init شده و پر است
```

### 🎨 مشکل ۲: فونت و ظاهر مدال

**علت:** مدال در `<body>` رندر می‌شد (خارج از `.cptt-erp-slot`)، پس فونت پنل ERP (`Dana`) به آن ارث نمی‌رسید. فیلدها استایل native داشتند.

**اصلاح:** CSS اختصاصی مدال بازنویسی شد:
- `font-family: "Dana", "Vazirmatn", Tahoma` روی overlay و همه‌ی children
- `.cptt-erp-modal .cptt-input` / `.cptt-select` / `.cptt-textarea` — دقیقاً همان استایل input های پنل (border-radius 0.9rem، padding 0.65rem 1rem، border 1.5px slate-200، focus ring indigo)
- `.cptt-erp-modal .cptt-select` — SVG chevron کاستوم مثل ERP
- `.cptt-erp-modal .cptt-btn-primary/danger/ghost` — دقیقاً هم‌رنگ ERP (indigo #4f46e5، rose #e11d48)
- `.cptt-input-num` با `font-variant-numeric: tabular-nums`
- `.cptt-label` با font-size 0.75rem و font-weight 600

### 💰 مشکل ۳: نمایش موجودی حساب در select

**اصلاح در `page-embed-treasury.php`:**
- هر `<option>` حالا `data-balance` و **متن آن شامل موجودی** است:
  ```
  🏦 بانک ملت — موجودی: 103,000,000
  ```
- زیر هر select یک `.cptt-erp-balance-hint` که بعد از انتخاب نشان می‌دهد:
  «موجودی فعلی: **۱۰۳,۰۰۰,۰۰۰** تومان»
- زیر فیلد مبلغ یک hint دیگر:
  - **مانده پس از انتقال:** ۳,۰۰۰,۰۰۰ تومان (سبز)
  - **⚠️ کسری موجودی:** ۲۹۷,۰۰۰,۰۰۰ تومان (قرمز)

**بایندینگ real-time در extras.js (`bindTransferBalanceHints`):**
- هر change روی select یا input amount → refresh
- محاسبه‌ی remainder = balance − amount
- اگر منفی شد، hint قرمز می‌شود

### 🛡️ مشکل ۴: انتقال بیشتر از موجودی + سند ثبت نشدن

**اصلاح‌های دولایه (defense-in-depth):**

**سمت سرور** — در `ajax_treasury_transfer` قبل از هر کاری:
```php
$from_balance = (float) CPTT_Finance::account_balance($f);
if ($amt > $from_balance + 0.005) {
    wp_send_json_error(sprintf(
        'موجودی حساب مبدأ کافی نیست. موجودی فعلی: %s تومان، مبلغ درخواستی: %s تومان',
        number_format($from_balance),
        number_format($amt)
    ), 400);
}
```

**سمت کاربر** — در `actTransferAdd` قبل از AJAX:
```js
if (fromAcc && amount > fromAcc.balance + 0.005) {
    toast('موجودی حساب مبدأ کافی نیست (' + formatNum(fromAcc.balance) + ' تومان)', 'error');
    return { close: false };
}
```

**دیگر بار treasury cache invalidation** — بعد از موفقیت انتقال، اسلات treasury هم reset می‌شود تا موجودی به‌روز شود.

### راجع به «سند ثبت نشده»

بررسی کد نشان می‌دهد `ajax_treasury_transfer` هم `ledger_insert` و هم `gen_voucher` را با `status = FINALIZED` صدا می‌زند. **اما** ممکن بود دلیل عدم نمایش سند این باشد که:
- انتقال با مبلغ نامعتبر رد شده بود
- یا سند ساخته شده ولی cache پنل بروز نشده بود

با اصلاح بالا (balance check + treasury cache invalidation)، این حالت‌ها پوشش داده می‌شوند. اگر بعد از این نسخه هم سند ثبت نشد، لطفاً از Debug button (🐞 گوشه پایین چپ ERP) لاگ کامل درخواست/پاسخ را برای من بفرست.

## فایل‌های تغییریافته

| فایل | تغییر |
|---|---|
| `assets/finance-ui/app.js` | patch: React key منحصربه‌فرد برای هر slot (۴ substitution) |
| `assets/js/cptt-erp-extras.js` | WeakSet-based init tracking، CSS مدال با فونت Dana و کلاس‌های cptt-*، bindTransferBalanceHints، client balance guard |
| `includes/finance/page-embed-treasury.php` | template transfer با موجودی در option و balance hint |
| `includes/class-cptt-finance-erp.php` | balance check در ajax_treasury_transfer |
| `client-project-tracker.php` | بامپ نسخه به 8.5.5 |

## ایمنی

- ✅ syntax check همه فایل‌ها
- ✅ Balance check سمت سرور (اصلی) + سمت کاربر (UX)
- ✅ دیتای دیتابیس بدون تغییر schema
- ✅ سایر تب‌های پنل دست‌نخورده
