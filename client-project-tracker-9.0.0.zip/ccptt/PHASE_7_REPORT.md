# PHASE_7_REPORT

> Phase 7 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`, `PHASE_1_REPORT.md`, `PHASE_2_REPORT.md`, `PHASE_3_REPORT.md`, `PHASE_4_REPORT.md`, `PHASE_5_REPORT.md`, `PHASE_6_REPORT.md`  
> Additional binding decisions: user-approved architecture decisions in current conversation  
> Mode: **No code change / No schema change in this turn / Data Migration Plan only**

---

# 0) اعلام صریح قبل از شروع

## 0.1 پاسخ کوتاه و ساده

**در این نوبت فقط فاز ۷ را به‌صورت گزارش و برنامه‌ی مهاجرت اجرا کرده‌ام و هیچ کدی را تغییر نداده‌ام.**

یعنی الان:
- هیچ جدول جدیدی ساخته نشده
- هیچ migrationی اجرا نشده
- هیچ داده‌ای جابه‌جا نشده
- هیچ cutoverی انجام نشده
- هیچ UIای تغییر نکرده

## 0.2 اما اجرای واقعی این فاز چه می‌خواهد؟

اجرای واقعی Phase 7 دیگر فقط «نقشه» نیست و حتماً نیاز دارد به:
- تغییر کد
- تغییر schema
- ایجاد جدول‌های جدید Journal و GL
- اجرای migration روی staging
- backup کامل قبل از هر اجرا
- dry-run و reconciliation
- rollback plan واقعی و تست‌شده

### نتیجه عملی
**اجرای واقعی Phase 7 باید فقط روی staging و با backup کامل انجام شود.**

---

# 1) هدف این گزارش

این سند، شروع اجرایی **Phase 7 — Data Migration Plan** است و فقط روی این موارد تمرکز دارد:

1. طراحی **migration stream**های اصلی
2. تعیین **migration mode** برای هر stream
3. تعیین **migration order** بر اساس وابستگی داده‌ها
4. تعریف **checkpoint**های migration
5. تعریف **freeze window** و **cutover window**
6. تعریف **reconciliation checklist** و query/artifactهای کنترلی در سطح plan
7. تعریف **rollback plan** در سطح migration
8. تعیین strategy برای historical data
9. هم‌راستا نگه داشتن migration با این تصمیم قطعی که **UI نهایی همان ERP Accounting Panel** است
10. ثبت **Ambiguity Register فاز ۷** برای تصمیم‌گیری قبل از اجرا و قبل از فاز ۸

> این سند عمداً هیچ تغییری در کد، schema، query اجرایی، migration واقعی یا رفتار runtime ایجاد نمی‌کند.

---

# 2) پیش‌فرض‌های قطعی که Phase 7 روی آن‌ها بنا می‌شود

## 2.1 SoT اصلی حسابداری
تنها مرجع حقیقت حسابداری:
- `Voucher`
- `VoucherRow`

## 2.2 Journal و GL
- هر دو **جدول فیزیکی واقعی** هستند
- هر دو **projection / read model** هستند
- هر دو باید **از روی vouchers قابل rebuild** باشند
- هر دو **append-only** هستند

## 2.3 مسیر رسمی write
write رسمی حسابداری فقط از این chain می‌گذرد:

```text
Business Action
↓
Voucher / VoucherRow
↓
Posting
↓
Journal
↓
General Ledger
```

## 2.4 legacy ledgerها
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`

این دو در target architecture:
- SoT نیستند
- ledger رسمی نهایی نیستند
- فقط historical / transitional / migration input هستند

## 2.5 ERP UI target
- UI هدف باید همان **پنل حسابداری ERP** بماند
- migration باید در خدمت این UI باشد
- migration نباید پروژه را به سمت UIهای legacy برگرداند

---

# 3) سوال اصلی Phase 7

## 3.1 مسئله‌ای که باید حل شود

حالا که در Phase 6 معلوم شد:
- دو ledger قدیمی نباید source نهایی حسابداری باشند
- GL جدید ledger رسمی مانده‌هاست
- Journal و GL باید از روی vouchers ساخته شوند

Phase 7 باید پاسخ دهد:

> **چطور از وضعیت فعلی به آن وضعیت هدف برسیم بدون اینکه داده‌های قدیمی گم شوند یا گزارش‌ها خراب شوند؟**

## 3.2 پاسخ کلی این فاز

پاسخ کوتاه این Phase این است:

```text
1) اول ساختار جدید را آماده می‌کنیم
2) بعد projectionهای جدید را از voucherها می‌سازیم
3) بعد داده‌های legacy را دسته‌بندی می‌کنیم
4) فقط آن بخش از legacy که واقعاً باید وارد accounting truth شود به voucher تبدیل می‌شود
5) بعد Journal/GL دوباره rebuild می‌شوند
6) بعد writeهای legacy freeze می‌شوند
7) بعد UI ERP روی chain جدید می‌نشیند
```

---

# 4) Migration Principles

## 4.1 اصل صفر — No Big Bang Without Checkpoints
هیچ migration نباید یک‌باره و بدون checkpoint انجام شود.

## 4.2 اصل یک — Voucher First Even In Migration
حتی migration هم باید از منطق Voucher-First پیروی کند.

### یعنی
- نباید rowهای legacy را مستقیم به GL بنویسیم
- نباید rowهای legacy را مستقیم به Journal بنویسیم
- اگر historical accounting truth ناقص است، باید اول voucher truth تکمیل شود

## 4.3 اصل دو — Rebuild, Not Patch
راه رسمی repair این است:
- rebuild / reproject از روی vouchers

نه:
- patch دستی روی GL
- patch دستی روی Journal
- sync حدسی از ledgerهای قدیمی

## 4.4 اصل سه — Minimal Parallel Truth
در migration باید تا جای ممکن از هم‌زمان نگه‌داشتن چند truth موازی جلوگیری شود.

## 4.5 اصل چهار — UI Target Must Stay ERP
در طول migration، مقصد نهایی read و report باید همان ERP panel باشد.

## 4.6 اصل پنج — Historical Data Needs Classification
همه‌ی داده‌های قدیمی ارزش یکسان ندارند.

هر row historical باید یکی از این fateها را بگیرد:
1. already covered by voucher
2. needs voucher reconstruction
3. archive only
4. manual review required

---

# 5) Migration Streamهای اصلی

## 5.1 نمای کلی

Migration برنامه‌ریزی‌شده در این فاز به 7 stream اصلی تقسیم می‌شود:

1. **Stream A — Voucher Truth Stabilization**
2. **Stream B — Physical Journal / GL Projection Build**
3. **Stream C — `wp_cptt_fin_ledger` Historical Migration**
4. **Stream D — `wp_cptt_ledger` Historical Migration**
5. **Stream E — `_cptt_steps` Operational Alignment**
6. **Stream F — Option-Based Master Data Transition Planning**
7. **Stream G — Cutover & Freeze Control Stream**

---

## 5.2 Stream A — Voucher Truth Stabilization

### هدف
اطمینان از اینکه voucher truth فعلی:
- قابل اتکاست
- traceable است
- پایه‌ی rebuild Journal/GL می‌تواند باشد

### دامنه
- `wp_cptt_erp_vouchers`
- `wp_cptt_erp_voucher_rows`

### کارها
- inventory کامل voucher statusها
- inventory کامل voucher typeها
- تشخیص voucherهای `FINALIZED`
- بررسی completeness فیلدهای trace:
  - `sourceType`
  - `sourceId`
  - `isAutoGenerated`
  - `fiscalYearId`
- بررسی تعادل rowها (`debit == credit`)
- شناسایی voucherهای مشکوک/ناقص قبل از build projection

### خروجی
- baseline voucher quality report
- لیست voucherهای سالم برای projection build
- لیست voucherهای ناقص برای review

### نکته مهم
بدون این stream، ساخت Journal/GL جدید پرریسک است.

---

## 5.3 Stream B — Physical Journal / GL Projection Build

### هدف
ساخت projectionهای جدید از روی voucher truth.

### دامنه target
- `{$wpdb->prefix}cptt_erp_journal`
- `{$wpdb->prefix}cptt_erp_gl`

### کارها
- ایجاد schema version plan
- ایجاد migration plan با `dbDelta()`
- تعریف full rebuild process
- تعریف incremental rebuild / reproject process
- تعریف append-only guarantees
- ساخت initial full projection از voucherهای موجود

### خروجی
- physical Journal plan
- physical GL plan
- rebuild/reproject plan
- validation outputs برای totals و counts

### نکته مهم
این stream **history legacy را حل نمی‌کند**؛ فقط target projection layer را ایجاد می‌کند.

---

## 5.4 Stream C — `wp_cptt_fin_ledger` Historical Migration

### هدف
تعیین تکلیف historical rowهای `wp_cptt_fin_ledger`.

### کارها
- classification by legacy type
- mapping to business identity
- detection of already-covered voucher rows
- rule for voucher reconstruction when missing
- archive-only classification for non-accounting noise

### دسته‌های محتمل
- income inflow
- expense outflow
- treasury transfer
- payable payment movement
- installment receipt movement
- category-only analytics rows
- noise/history rows

### خروجی
- fin_ledger mapping catalog
- row classification matrix
- missing-voucher reconstruction queue
- archive-only queue

---

## 5.5 Stream D — `wp_cptt_ledger` Historical Migration

### هدف
تعیین تکلیف historical rowهای `wp_cptt_ledger`.

### کارها
- classification by row type
- mapping expert settlement / manual payout / customer payment / online payment
- detection of already-covered voucher rows
- reconstruction rules where needed
- archive-only rule برای activity-like rows

### خروجی
- core ledger mapping catalog
- row classification matrix
- missing-voucher reconstruction queue
- archive-only queue

---

## 5.6 Stream E — `_cptt_steps` Operational Alignment

### هدف
جدا کردن نقش operational `_cptt_steps` از نقش report/accounting truth.

### کارها
- inventory financial fields داخل `_cptt_steps`
- شناسایی کدام مقادیر فقط operational هستند
- شناسایی کدام مقادیر باید با accounting read models reconcile شوند
- تعریف strategy برای project financial snapshot
- تعریف strategy برای dirty-flag / sync signal / explicit command boundary

### خروجی
- `_cptt_steps` migration boundary report
- project snapshot derivation plan
- operational-only vs accounting-relevant field classification

### نکته مهم
در این stream قرار نیست `_cptt_steps` حذف شود.  
فقط قرار است نقش آن محدود و شفاف شود.

---

## 5.7 Stream F — Option-Based Master Data Transition Planning

### هدف
تعیین اینکه کدام option-based master dataها در همین موج لازم‌اند و کدام‌ها deferred می‌شوند.

### دامنه
- `cpttf_erp_coa_nodes`
- `cpttf_erp_fiscal_years`
- `cpttf_erp_locks`
- `cpttf_erp_cost_centers`
- `cpttf_erp_companies`
- `cpttf_erp_branches`
- `cpttf_erp_currency_rates`

### اصل پیشنهادی
برای کم‌کردن ریسک، migration accounting cutover نباید هم‌زمان با migration همه master dataها انجام شود.

### نتیجه پیشنهادی این فاز
- master dataهای critical برای posting/reporting inventory شوند
- migration فیزیکی همه optionها در همین wave اجباری نیست
- اگر migration آن‌ها لازم باشد، باید جدا و مرحله‌ای انجام شود

---

## 5.8 Stream G — Cutover & Freeze Control Stream

### هدف
کنترل مرحله‌ای freezeها و switchها.

### کارها
- تعریف write freeze windowها
- تعریف read cutover windowها
- تعریف legacy writer shutdown order
- تعریف rollback gates
- تعریف execution checkpoints

### خروجی
- migration calendar draft
- freeze matrix
- checkpoint matrix

---

# 6) Migration Mode برای هر Stream

## 6.1 سه mode اصلی

در Roadmap خواسته شده بود modeها مشخص شوند:
- `one-time historical migration`
- `incremental sync window`
- `dual-write transition`

## 6.2 سیاست کلی این Phase

### توصیه‌ی اصلی
در این پروژه باید **dual-write را تا حد ممکن کم کنیم**.

چرا؟
چون dual-write در سیستم مالی خیلی زود data drift می‌سازد.

### بنابراین
- mode پیش‌فرض: **one-time migration + controlled incremental window**
- dual-write فقط اگر واقعاً unavoidable باشد، آن هم زمان‌دار و محدود

---

## 6.3 Mode Matrix

| Stream | Mode پیشنهادی | دلیل |
|---|---|---|
| Stream A — Voucher Truth Stabilization | one-time audit + incremental cleanup window | vouchers already SoT هستند |
| Stream B — Journal/GL build | one-time full rebuild + recurring rebuild capability | projection layer است |
| Stream C — `wp_cptt_fin_ledger` | one-time historical migration | legacy accounting writer نباید زنده بماند |
| Stream D — `wp_cptt_ledger` | one-time historical migration | همان دلیل بالا |
| Stream E — `_cptt_steps` | incremental sync window | operational state هنوز زنده است |
| Stream F — option masters | phased/deferred migration | برای کاهش ریسک |
| Stream G — cutover/freeze | staged rollout | برای rollback و کنترل ریسک |

---

## 6.4 One-Time Historical Migration Mode

### مناسب برای
- ledgerهای legacy
- backfill historical voucher truth
- initial projection build

### ویژگی‌ها
- snapshot baseline
- migration dry-run
- reviewed execution
- reconciliation
- close/freeze step

---

## 6.5 Incremental Sync Window Mode

### مناسب برای
- `_cptt_steps`
- بعضی operational contexts که هنوز کاملاً decouple نشده‌اند

### تعریف
یک بازه‌ی موقت که در آن:
- operational data هنوز زنده است
- accounting truth باید با command رسمی یا signal کنترل شود
- drift باید monitor شود

### نکته
این mode نباید دائمی شود.

---

## 6.6 Dual-Write Transition Mode

### سیاست این سند
**در این پروژه dual-write باید policy استثنایی باشد، نه حالت عادی.**

### اگر جایی لازم شد
فقط برای compatibility کوتاه‌مدت و با این محدودیت‌ها:
1. time-boxed
2. traceable
3. monitored
4. reversible
5. never for Journal/GL direct write

### Rule مهم
Journal و GL هرگز محل dual-write business truth نیستند.  
آن‌ها فقط projection rebuild/posting output هستند.

---

# 7) Migration Order بر اساس وابستگی‌ها

## 7.1 اصل کلی

ترتیب migration باید طوری باشد که:
- اول source truth روشن شود
- بعد projection ساخته شود
- بعد historical gaps پر شوند
- بعد legacy writeها freeze شوند
- بعد read cutover رخ دهد

## 7.2 ترتیب پیشنهادی مرحله‌ای

### Stage 0 — Backup + Baseline Lock
قبل از هر چیز:
- full DB backup
- baseline file manifest lock
- report screenshots / metric snapshot
- execution runbook finalization

### Stage 1 — Master Context Snapshot
snapshot از:
- COA
- fiscal years
- locks
- treasury accounts
- party-related essentials
- cost centers

### Stage 2 — Voucher Truth Audit
- audit روی vouchers/rows
- identification of broken/incomplete rows
- final posted set identification

### Stage 3 — Physical Journal/GL Deployment (empty/controlled)
- schema deployment plan
- initial empty structure
- no legacy cutover yet

### Stage 4 — First Full Rebuild From Existing Vouchers
- build Journal from existing posted vouchers
- build GL from existing posted vouchers
- run reconciliation between voucher totals and projections

### Stage 5 — Historical Legacy Classification
- classify `wp_cptt_fin_ledger`
- classify `wp_cptt_ledger`
- detect coverage by existing vouchers

### Stage 6 — Historical Voucher Reconstruction
- create migration plan for missing accounting truth
- build missing historical vouchers where approved
- mark archive-only records

### Stage 7 — Second Full Rebuild From Completed Voucher Truth
- rebuild Journal
- rebuild GL
- verify reports and balances

### Stage 8 — Legacy Write Freeze
- freeze `wp_cptt_ledger` as accounting writer
- freeze `wp_cptt_fin_ledger` as accounting writer
- keep only archive/compatibility role

### Stage 9 — ERP Read Cutover Preparation
- prepare ERP panel reads from new chain
- no redesign of UI
- only source switch

### Stage 10 — Report Cutover Handover To Phase 8
- final handoff to dedicated report cutover plan

---

# 8) Checkpoint Matrix

## 8.1 هدف Checkpointها

Checkpoint یعنی نقطه‌ای که قبل از رفتن به مرحله بعد، باید مکث کنیم و مطمئن شویم اعداد و داده‌ها درست هستند.

## 8.2 ماتریس Checkpointها

| Checkpoint | نام | هدف | اگر fail شد چه می‌شود؟ |
|---|---|---|---|
| CP-0 | Baseline Locked | backup + baseline metrics | migration شروع نمی‌شود |
| CP-1 | Voucher Audit Passed | voucher truth usable باشد | issue list و repair/review |
| CP-2 | Projection Schema Ready | Journal/GL schema آماده باشد | deploy متوقف می‌شود |
| CP-3 | First Rebuild Valid | voucher → journal/gl totals match | rebuild/debug before continue |
| CP-4 | Legacy Classification Approved | fin_ledger/core_ledger دسته‌بندی شوند | no historical migration |
| CP-5 | Historical Mapping Approved | reconstruction rules approved | no voucher backfill |
| CP-6 | Second Rebuild Valid | completed vouchers → projections consistent | no freeze/cutover |
| CP-7 | Legacy Write Freeze Confirmed | old ledgers no longer accounting writers | no report cutover |
| CP-8 | ERP Read Source Ready | ERP panel can read canonical projections | no UI cutover |
| CP-9 | Final Reconciliation Passed | reports and balances reconcile | no production promotion |

## 8.3 Rule مهم

هیچ checkpointی نباید فقط «ظاهراً اوکی» باشد.  
هر checkpoint باید عدد و گزارش قابل ثبت داشته باشد.

---

# 9) Freeze Window Design

## 9.1 معنی ساده Freeze Window

Freeze window یعنی یک بازه که در آن بعضی کارها را موقتاً ممنوع می‌کنیم تا migration امن انجام شود.

## 9.2 انواع Freeze در این پروژه

### A) Code Freeze
در بازه migration نباید تغییرات unrelated وارد شود.

### B) Schema Freeze
در طول migration نباید schemaهای مالی هم‌زمان از چند مسیر تغییر کنند.

### C) Financial Write Freeze
برای بعضی مسیرها موقتاً write متوقف می‌شود.

### D) Legacy Writer Freeze
write به ledgerهای قدیمی قطع می‌شود.

### E) Report Cutover Freeze
در زمان تعویض source گزارش‌ها نباید هم‌زمان flowهای جدید اضافه شوند.

---

## 9.3 Freeze Matrix

| Freeze Type | روی چه چیزی اعمال می‌شود | زمان پیشنهادی |
|---|---|---|
| Code Freeze | فایل‌های مالی/ERP | قبل از اجرای staging migration |
| Schema Freeze | جداول و migration scripts مالی | از شروع migration تا پایان validation |
| Legacy Writer Freeze 1 | `wp_cptt_ledger` accounting writes | بعد از CP-6 |
| Legacy Writer Freeze 2 | `wp_cptt_fin_ledger` accounting writes | بعد از CP-6 یا CP-7 |
| Report Source Freeze | sourceهای legacy report | نزدیک handoff به Phase 8 |

## 9.4 Freeze Rule مهم

freeze باید:
- کوتاه باشد
- مستند باشد
- rollback-ready باشد
- به کاربر نهایی کمترین اختلال را بدهد

---

# 10) Cutover Window Design

## 10.1 معنی ساده

Cutover window یعنی بازه‌ای که سیستم از مسیر قدیمی به مسیر جدید سوییچ می‌کند.

## 10.2 Cutoverهای این برنامه

### Cutover 1 — Projection Cutover
ساخت Journal/GL جدید از روی vouchers

### Cutover 2 — Historical Truth Completion Cutover
تکمیل voucher truth historical و rebuild مجدد

### Cutover 3 — Legacy Write Freeze Cutover
قطع نقش accounting writer برای ledgerهای قدیمی

### Cutover 4 — ERP Read Source Cutover
اتصال ERP panel به sourceهای رسمی جدید

## 10.3 ترتیب پیشنهادی

```text
Projection Cutover
↓
Historical Truth Completion
↓
Legacy Write Freeze
↓
ERP Read Source Cutover
```

## 10.4 Rule مهم

در این پروژه **big-bang cutover** توصیه نمی‌شود.  
یعنی همه چیز نباید در یک شب یک‌جا عوض شود.

---

# 11) Reconciliation Plan

## 11.1 هدف

بعد از هر migration wave باید مطمئن شویم:
- چیزی گم نشده
- چیزی دوبار حساب نشده
- reports با accounting chain سازگارند

## 11.2 سه لایه Reconciliation

### Layer A — Source Integrity Reconciliation
روی vouchers/rows

### Layer B — Projection Reconciliation
بین vouchers ↔ Journal ↔ GL ↔ TB

### Layer C — Business View Reconciliation
بین accounting layer و business-facing views مثل receivable, payable, treasury, project snapshot

---

## 11.3 Reconciliation Metrics

| Metric | Source |
|---|---|
| total finalized vouchers | voucher table |
| total voucher rows for finalized vouchers | voucher rows |
| voucher debit total | voucher rows |
| voucher credit total | voucher rows |
| journal line count | journal table |
| journal debit total | journal table |
| journal credit total | journal table |
| GL line count | GL table |
| GL debit total | GL table |
| GL credit total | GL table |
| TB debit total | TB projection |
| TB credit total | TB projection |
| P&L revenue | statement projection |
| P&L expense | statement projection |
| BS assets | statement projection |
| BS liabilities | statement projection |
| BS equity | statement projection |
| receivable total | receivable read model |
| payable total | payable read model |
| treasury total | treasury read model / GL cash accounts |
| unmatched legacy rows | migration mapping artifacts |
| duplicate business keys | voucher/source trace audit |

---

## 11.4 Reconciliation Rules

### Rule 1
`voucher debit total == voucher credit total`

### Rule 2
`journal debit total == voucher debit total`

### Rule 3
`journal credit total == voucher credit total`

### Rule 4
`GL debit total == journal debit total`

### Rule 5
`GL credit total == journal credit total`

### Rule 6
`TB debit total == TB credit total`

### Rule 7
`P&L = revenue - expense`

### Rule 8
`BS assets == liabilities + equity`

### Rule 9
ERP dashboard KPIs باید با report layer outputs reconcile شوند

### Rule 10
هر row legacy که migrated شده باید mapping artifact داشته باشد

---

# 12) Query / Script Artifacts در سطح Plan

> طبق محدودیت این پروژه، اینجا query اجرایی نوشته نمی‌شود؛ فقط artifactهای لازم در سطح plan تعریف می‌شوند.

## 12.1 Artifactهای لازم برای Source Audit
- Voucher Status Distribution Report
- Voucher Trace Completeness Report
- Voucher Balance Integrity Report
- Voucher Type Distribution Report

## 12.2 Artifactهای لازم برای Projection Audit
- Journal Coverage Report
- GL Coverage Report
- Voucher-to-Journal Count Match Report
- Journal-to-GL Amount Match Report
- Trial Balance Equality Report

## 12.3 Artifactهای لازم برای Legacy Classification
- `fin_ledger` Type Classification Report
- `core_ledger` Type Classification Report
- Already-Covered Detection Report
- Unmapped Legacy Rows Report
- Low-Confidence Mapping Review Queue

## 12.4 Artifactهای لازم برای Business Reconciliation
- Receivable Comparison Report
- Payable Comparison Report
- Treasury Comparison Report
- Project Snapshot Comparison Report
- Party Balance Comparison Report

---

# 13) Historical Migration Rules

## 13.1 Rule A — Already Covered Rows
اگر یک row legacy با اطمینان کافی در voucher truth موجود پوشش داده شده باشد:
- voucher جدید ساخته نمی‌شود
- row legacy فقط archive/reference می‌ماند

## 13.2 Rule B — Recoverable Accounting Rows
اگر row legacy accounting meaning روشن داشته باشد ولی voucher معادل نداشته باشد:
- candidate for voucher reconstruction است
- نه direct GL write
- نه direct Journal write

## 13.3 Rule C — Archive Only Rows
اگر row legacy فقط history/analytics/operational noise باشد:
- archive-only
- وارد accounting truth جدید نمی‌شود

## 13.4 Rule D — Ambiguous Rows
اگر confidence پایین باشد:
- manual review queue
- یا archive-only
- default policy دقیق هنوز نیازمند تصمیم است

## 13.5 Rule E — No Silent Duplication
هیچ row historical نباید بدون deduplication دقیق دوباره به voucher truth وارد شود.

---

# 14) `_cptt_steps` Migration Plan در سطح معماری

## 14.1 هدف

در این Phase قرار نیست `_cptt_steps` را حذف کنیم.  
هدف این است که نقش آن در migration روشن شود.

## 14.2 سه نقش جداگانه

### نقش 1 — Operational Workflow State
- بماند
- حذف فوری نشود

### نقش 2 — Legacy Financial Calculation Input
- باید حذف تدریجی شود
- دیگر source نهایی report نباشد

### نقش 3 — Historical Financial Evidence
- اگر لازم باشد، فقط برای reconciliation و context استفاده شود

## 14.3 Rule مهم

در migration نباید این اشتباه رخ دهد:
- هر عدد داخل `_cptt_steps` را خودکار به voucher تبدیل کنیم

چرا؟
چون بعضی فیلدها فقط operational هستند، نه accounting truth.

## 14.4 Strategy پیشنهادی

- `_cptt_steps` اول classification شود
- فقط آن بخش‌هایی که financial business meaning قطعی دارند وارد review شوند
- project financial snapshots در نهایت از accounting/reporting layer مشتق شوند

---

# 15) Option-Based Masters Migration Policy

## 15.1 اصل کلی

Migration data نباید هم‌زمان با همه migrationهای master data قاطی شود، مگر جایی که dependency سخت وجود دارد.

## 15.2 Hard Dependencies

این‌ها برای posting/reporting حیاتی‌اند و باید حداقل snapshot معتبر داشته باشند:
- COA
- FiscalYear
- Locks
- Treasury Accounts
- Cost Centers

## 15.3 Soft Dependencies

این‌ها می‌توانند deferred یا مرحله‌ای باشند:
- Companies/Branches advanced shapes
- Currency rate deep models
- Permissions/meta configها

## 15.4 نتیجه Phase 7

در migration accounting cutover:
- hard dependency master data باید controlled و snapshot-ready باشد
- full relocation of all options to tables می‌تواند phase-separated باشد

---

# 16) Rollback Plan برای Migration

## 16.1 اصل کلی

Rollback باید قبل از اجرا طراحی شود، نه بعد از شکست.

## 16.2 Rollback Levels

### Level 0 — Abort Before Mutation
اگر قبل از schema/data mutation fail شد:
- run متوقف می‌شود
- no-op rollback

### Level 1 — Projection Rollback
اگر Journal/GL build مشکل داشت:
- source truth هنوز vouchers است
- projections drop/rebuild یا discard می‌شوند
- old reports temporarily remain

### Level 2 — Historical Backfill Rollback
اگر voucher reconstruction issue داشت:
- backfilled vouchers باید قابل شناسایی و rollback/reversal strategy داشته باشند
- checkpoint restore لازم است

### Level 3 — Legacy Freeze Rollback
اگر بعد از freeze old writers مشکل رخ داد:
- rollback باید بتواند compatibility path را موقتاً برگرداند
- فقط در staging یا gated rollout توصیه می‌شود

### Level 4 — Full Staging Restore
اگر discrepancy جدی بود:
- full DB restore from snapshot
- revert feature flags/read paths

## 16.3 Rollback Artifacts Required
- DB snapshot before each major wave
- migration execution log
- list of generated backfill voucher ids
- list of affected legacy row ids
- projection rebuild log
- reconciliation failure report

## 16.4 Rule مهم

Rollback نباید با patch دستی و فوری روی GL انجام شود.  
مسیر رسمی rollback باید یا:
- restore snapshot
- یا rebuild from valid voucher truth

باشد.

---

# 17) Staging Dry-Run Strategy

## 17.1 چرا staging dry-run اجباری است؟

چون این migration:
- historical data را درگیر می‌کند
- ledgers قدیمی را از role اصلی خارج می‌کند
- projectionهای جدید می‌سازد
- report chain را تغییر می‌دهد

## 17.2 Dry-Run Waves

### Dry-Run Wave 1
- فقط voucher audit
- فقط projection build از vouchers
- no historical backfill

### Dry-Run Wave 2
- classification of legacy rows
- mapping reports
- no irreversible cutover

### Dry-Run Wave 3
- selected historical voucher reconstruction on staging
- rebuild projections
- full reconciliation

### Dry-Run Wave 4
- simulated legacy write freeze
- simulated ERP read cutover
- user acceptance on ERP UI

## 17.3 Acceptance Criteria روی staging
- no unexpected debit/credit mismatch
- no duplicate migrated receipts/payments
- no unexplained drop in receivable/payable totals
- ERP reports open and reconcile
- legacy pages اگر موقتاً فعال‌اند، clearly non-authoritative باشند

---

# 18) ارتباط فاز ۷ با ERP UI

## 18.1 تصمیم قطعی

UI نهایی باید همان پنل حسابداری ERP بماند.

## 18.2 نتیجه مهاجرت برای UI

migration plan باید طوری طراحی شود که در نهایت:
- `Documents` در ERP panel از voucher truth تغذیه شود
- `Journal` در ERP panel از table فیزیکی Journal تغذیه شود
- `GL/Subsidiary` در ERP panel از table فیزیکی GL تغذیه شود
- `TB/P&L/BS` در ERP panel از chain جدید تغذیه شوند

## 18.3 Rule مهم

Phase 7 هیچ migration planی برای بازگرداندن مرکز ثقل UI به legacy pages نمی‌دهد.

### به زبان ساده
هدف این نیست که سیستم قدیمی را قوی‌تر کنیم.  
هدف این است که **ERP panel فعلی** را روی داده‌ی درست بنشانیم.

---

# 19) روش تست معماری Phase 7

## 19.1 Review Checklist

برای پذیرش این Phase باید این سوال‌ها پاسخ روشن داشته باشند:

1. آیا migration streamها مشخص شده‌اند؟
2. آیا mode هر stream روشن شده؟
3. آیا migration order بر اساس dependency مشخص شده؟
4. آیا checkpointها تعریف شده‌اند؟
5. آیا freeze windowها و cutover windowها تعریف شده‌اند؟
6. آیا reconciliation rules و artifacts مشخص شده‌اند؟
7. آیا rollback levels تعریف شده‌اند؟
8. آیا staging dry-run strategy مشخص شده؟
9. آیا نقش ERP UI در migration روشن شده؟
10. آیا ambiguityهای فاز ۷ صریح لیست شده‌اند؟

## 19.2 سناریوهای dry-run پیشنهادی

- projection build only
- customer receipt historical mapping
- expert payout historical mapping
- treasury transfer mapping
- payable payment mapping
- installment receipt mapping
- project snapshot comparison
- ERP journal/gl/tb/p&l/bs reconciliation

---

# 20) ارزیابی انجام Taskهای Phase 7 نسبت به Roadmap

## 20.1 Taskهای Phase 7 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 7 شامل این موارد بود:
- طراحی migration streamها
- تعیین migration mode
- طراحی checkpoints migration
- تعریف reconciliation scripts/queries در سطح plan
- تعیین migration order
- تعریف freeze windows و cutover windows

## 20.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| migration streamها | ✅ انجام شد |
| migration mode | ✅ انجام شد |
| checkpoints | ✅ انجام شد |
| reconciliation artifacts at plan level | ✅ انجام شد |
| migration order | ✅ انجام شد |
| freeze windows | ✅ انجام شد |
| cutover windows | ✅ انجام شد |
| rollback plan | ✅ انجام شد |
| staging dry-run strategy | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 20.3 Definition of Done Phase 7

Phase 7 زمانی Done تلقی می‌شود که:
1. migration plan برای هر data source مشخص شده باشد ✅
2. cutover strategy مشخص شده باشد ✅
3. reconciliation checklist مشخص شده باشد ✅
4. rollback structure تعریف شده باشد ✅
5. review تصمیم‌های ambiguity قبل از اجرا انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری و برنامه‌ریزی مهاجرت**، Phase 7 در این artefact **شروع و تدوین شده است**؛  
اما از منظر **اجرای واقعی** هنوز نیازمند تصمیم روی چند ambiguity حساس historical data و acceptance thresholds است.

---

# 21) Ambiguity Register فاز ۷

> طبق درخواست‌های قبلی، این بخش باید جدا و واضح بماند تا قبل از اجرای واقعی یا قبل از فاز ۸ تصمیم‌گیری شوند.

## 21.1 default policy برای rowهای low-confidence چیست؟

### توضیح ساده
اگر برای بعضی داده‌های قدیمی مطمئن نباشیم دقیقاً باید به چه voucherی تبدیل شوند، باید تصمیم بگیریم:
- manual review؟
- archive-only؟
- suspense voucher؟

### وضعیت
**نیاز به تصمیم**

---

## 21.2 rule دقیق deduplication بین historical payments و voucherهای موجود چیست؟

### توضیح ساده
باید دقیق معلوم شود از کجا بفهمیم یک پرداخت قدیمی قبلاً وارد voucherها شده یا نه.

### وضعیت
**نیاز به تصمیم دقیق اجرایی**

---

## 21.3 آیا برای migration historical از rowهای ambiguous باید سقف پذیرش variance تعیین شود؟

### توضیح ساده
ممکن است آخر migration چند اختلاف کوچک یا مشکوک بماند. باید معلوم شود:
- صفر اختلاف لازم است؟
- یا تا یک حد مشخص قابل قبول است؟

### وضعیت
**نیاز به تصمیم**

---

## 21.4 `_cptt_steps` fieldهای مالی کدام‌ها باید فقط reconcile شوند و کدام‌ها candidate ساخت voucher تاریخی باشند؟

### توضیح ساده
نباید همه اعداد داخل stepها را کورکورانه به سند تبدیل کنیم.

### وضعیت
**نیاز به تصمیم**

---

## 21.5 آیا migration option-based master dataهای critical هم‌زمان با accounting cutover انجام شود یا در موج جدا؟

### توضیح ساده
مثل COA و Fiscal Year و Locks. باید معلوم شود:
- همین موج؟
- یا بعداً در موج جدا؟

### وضعیت
**نیاز به تصمیم اجرایی**

---

## 21.6 freeze write برای `wp_cptt_ledger` و `wp_cptt_fin_ledger` دقیقاً قبل از کدام cutover wave انجام شود؟

### توضیح ساده
باید زمان دقیق قطع write این دو جدول مشخص شود.

### وضعیت
**نیاز به تصمیم اجرایی**

---

## 21.7 آیا public payment intake در زمان migration باز بماند یا موقتاً محدود شود؟

### توضیح ساده
اگر هم‌زمان مشتری‌ها پرداخت کنند، migration حساس‌تر می‌شود. باید معلوم شود:
- باز بماند؟
- محدود شود؟
- maintenance window بخورد؟

### وضعیت
**نیاز به تصمیم**

---

## 21.8 project/expert partial settlementهای تاریخی با چه rule دقیق business-approved map شوند؟

### توضیح ساده
بعضی تسویه‌های قدیمی ممکن است چندبخشی یا ناقص بوده باشند.

### وضعیت
**نیاز به تصمیم**

---

## 21.9 آیا legacy read pageها در طول dry-run صرفاً read-only بمانند یا از همان staging مرحله‌ای خاموش شوند؟

### توضیح ساده
باید تصمیم بگیریم در dry-run، صفحه‌های قدیمی هنوز دیده شوند یا نه.

### وضعیت
**نیاز به تصمیم**

---

# 22) جمع‌بندی نهایی Phase 7

مهم‌ترین خروجی Phase 7 این است که از اینجا به بعد، migration دیگر نباید به شکل کلی و مبهم دیده شود.

### نتیجه‌های کلیدی
- migration streamهای اصلی مشخص شدند
- mode هر stream تعیین شد
- migration order مرحله‌ای مشخص شد
- checkpointها تعریف شدند
- freeze و cutover windowها طراحی شدند
- reconciliation artifacts و rollback levels تعریف شدند
- staging dry-run strategy مشخص شد
- migration با UI هدف ERP هم‌راستا نگه داشته شد

### اصل نهایی این فاز

```text
Migrate truth carefully.
Rebuild projections deterministically.
Cut over gradually.
```

و به زبان ساده‌تر:

```text
اول حقیقت حسابداری را با دقت کامل می‌کنیم،
بعد projectionها را از نو می‌سازیم،
بعد آرام و مرحله‌ای سوییچ می‌کنیم.
```

---

**پایان گزارش Phase 7**
