# WAVE_2_HOTFIX_8.5.3 — کارت پیام → صفحات واقعی + hash routing + pagination

> نسخه: **8.5.3**
> تاریخ: 1405/04/17

## 🎯 سه خواسته‌ی کاربر

1. UI پنل و لیست‌ها بهتر شود؛ لیست‌های طولانی صفحه‌بندی داشته باشند
2. تب‌های «درآمد و هزینه»، «صندوق‌ها و حساب‌ها»، «انتقال بین حساب‌ها»
   به‌جای «کارت پیام» محتوای واقعی نشان دهند
3. هنگام refresh در همان تب باقی بماند (بدون reload بین تب‌ها)

## ✅ اصلاحات

### الف) اتصال ۳ تب خزانه‌داری به محتوای واقعی

باگ کرش (`hh is not defined`, `gj is not defined`) در باندل React از قبل
بود چون کامپوننت‌های Treasury/IncomeExpense در build گم شده‌اند. در
8.5.2 با EmptyState fallback جایگزین‌شان کردیم. حالا در 8.5.3 با
**صفحه‌های PHP اختصاصی embed** جایگزین کردیم:

**فایل جدید:** `includes/finance/page-embed-treasury.php`

سه تابع render مینیمال، مستقل، بدون نیاز به JS خارجی:
- `cpttf_render_embed_treasury()` — لیست حساب‌های خزانه + KPI (موجودی، تعداد بانکی، تعداد نقدی) + دکمه‌ی «افزودن/ویرایش» که به صفحه‌ی full-page WordPress هدایت می‌کند
- `cpttf_render_embed_transfers()` — لیست انتقال‌های اخیر (از جدول ledger با `type=transfer_in/out` که به‌صورت pair نمایش داده می‌شوند) + KPI (تعداد و مجموع) + دکمه‌ی «ثبت انتقال جدید»
- `cpttf_render_embed_transactions()` — لیست درآمد/هزینه با فیلتر (نوع، حساب، بازه‌ی تاریخ با datepicker شمسی) + KPI + دکمه‌های «ثبت درآمد/هزینه»

**نکته:** برای عملیات‌های پیچیده (ثبت/ویرایش/حذف که نیاز به فرم و AJAX
دارند)، دکمه‌ها به **صفحه‌ی WordPress full-page** با `target="_top"`
هدایت می‌کنند. این تصمیم آگاهانه است — چون JS این عملیات‌ها روی selector
های خاصی گره خورده که در embed reliably reinitialize نمی‌شود.

### ب) Persistent tab via URL hash

**در `cptt-erp-extras.js`:**

- **On tab click:** آدرس URL با `#tab=XXX` update می‌شود (بدون reload)
- **On page load / refresh:** hash خوانده می‌شود و روی دکمه‌ی sidebar
  متناظر خودکار کلیک می‌شود
- **On browser back/forward:** `hashchange` event شنیده می‌شود
- **On sidebar click detection:** delegated listener که متن دکمه‌ی
  کلیک‌شده را با یک نگاشت `TAB_LABELS` (fa → id) match می‌کند و
  hash را update می‌کند
- **Retry با interval:** بعد از load چند بار تلاش می‌کند (تا ۱۰ ثانیه)
  چون sidebar بندل React زمان mount می‌خواهد

### ج) Pagination عمومی برای لیست‌های طولانی

**در `cptt-erp-extras.js`:** یک تابع `applyPagination(root)` که روی هر
کانتینر با `data-cptt-paginate="N"` عمل می‌کند:
- ۲۵ ردیف در هر صفحه (قابل تنظیم)
- کنترل‌های: «« ‹ ۱ ۲ ۳ ... › »»
- شمارنده: «نمایش ۱–۲۵ از ۱۲۳»
- header جدول sticky، wrapper با max-height
- شماره صفحات با ارقام فارسی

**اعمال شده روی:**
- جدول جزئیات cashflow (500 رخداد → صفحه‌بندی به ۲۵ تایی)
- جدول تراکنش‌های embed-transactions (تا 1000 رخداد)
- (کافی است `data-cptt-paginate="25"` به هر card body اضافه شود)

### د) UI بهتر و هماهنگ

CSS اختصاصی `.cptt-erp-slot` بازنویسی شد:
- KPI با gradient border-inline-start و hover lift effect
- کارت‌های سفید با box-shadow لطیف
- دکمه‌های primary با gradient بنفش
- جدول با sticky header و striped rows
- input های با focus ring
- badge های رنگی برای نوع/وضعیت
- اسکرول‌بار زیبا

### ه) helper `_maybe_embed` مشترک

در `class-cptt-finance.php`: قبلاً هر صفحه سه بار همان منطق را داشت.
حالا یک متد خصوصی `_maybe_embed($render_fn)` که همه‌ی صفحات از آن
استفاده می‌کنند. برای treasury/transactions در حالت embed، به توابع
مینیمال `cpttf_render_embed_*` رد می‌شود (نه توابع کامل که نیاز به JS
دارند).

## 📁 فایل‌های تغییریافته/جدید

| فایل | تغییر |
|---|---|
| **جدید** `includes/finance/page-embed-treasury.php` | ۳ تابع render مینیمال |
| `assets/finance-ui/app.js` | patch: fallback هوشمند برای treasury/transfers/income_expense → slot با data-slot |
| `assets/js/cptt-erp-extras.js` | بازنویسی: چند slot handling + hash routing + generic pagination |
| `includes/class-cptt-finance.php` | helper _maybe_embed مشترک + هدایت به embed توابع |
| `includes/class-cptt-finance-erp.php` | data-cpttAdminUrl attribute روی body |
| `includes/finance/page-cashflow.php` | استفاده از data-cptt-paginate عمومی |
| `client-project-tracker.php` | بامپ نسخه به 8.5.3 |

## 🎯 UX نهایی

### تب‌ها در سایدبار ERP:

**گروه خزانه‌داری:**
- ✅ **صندوق‌ها و حساب‌ها** → لیست حساب‌ها با موجودی + KPI؛ دکمه‌ی افزودن به صفحه‌ی کامل WP
- ✅ **انتقال بین حساب‌ها** → لیست انتقال‌های اخیر جفت‌شده؛ دکمه‌ی ثبت به صفحه‌ی کامل WP
- ✅ **گردش حساب یکپارچه** (بدون تغییر — از قبل کار می‌کرد)
- ✅ **💵 جریان نقدی (Cash-View)** → گزارش کامل با فیلتر، KPI، جریان تجمعی، جدول جزئیات با pagination
- ✅ **درآمدها و هزینه‌ها** (در گروه بالاتر) → لیست با فیلتر، KPI، pagination

### حفظ تب هنگام refresh:
- ✅ رفتن به یک تب → URL می‌شود `?page=cptt-finance-erp#tab=cheques`
- ✅ F5 → همان تب دوباره فعال می‌شود
- ✅ کلیک روی تب دیگر → hash update می‌شود، بدون reload

### Pagination:
- ✅ لیست‌های بیش از ۲۵ ردیف → کنترل‌های صفحه‌بندی زیر جدول
- ✅ header جدول sticky (هنگام اسکرول در بالای container ثابت می‌ماند)
- ✅ ارقام فارسی

## 🛡️ ایمنی

- ✅ syntax check همه ۶ فایل PHP + ۳ فایل JS
- ✅ دیتای دیتابیس بدون تغییر
- ✅ صفحات WP اصلی (treasury, transactions) دست‌نخورده — فقط در حالت embed مسیر متفاوت می‌رود
- ✅ E-1 fix + audit-trail ساعت + datepicker شمسی همه فعال
- ✅ کاربر برای عملیات نوشتنی (add/edit/delete) به صفحه‌ی کامل WP هدایت می‌شود که کاملاً تست‌شده است

## 💡 پاسخ به سوال کاربر: این تب‌ها چه کاربردی دارند؟

| تب | کاربرد |
|---|---|
| **درآمدها و هزینه‌ها** | ثبت **دستی** رخدادهای نقدی که به فاکتور/پروژه گره نیست (مثل اجاره، اینترنت، درآمد فرعی). ذخیره در `wp_cptt_fin_ledger` |
| **صندوق‌ها و حساب‌ها** | مدیریت حساب‌های خزانه (بانک، صندوق نقدی، ارزی): افزودن/ویرایش/غیرفعال‌سازی، دیدن موجودی |
| **انتقال بین حساب‌ها** | جابجایی پول بین دو حساب خزانه (مثلاً صندوق → بانک): sender + receiver + مبلغ → دو رکورد ledger |
| **مراکز درآمد و هزینه** | Cost Centers — دسته‌بندی مدیریتی برای حسابداری داخلی (شعبه، دپارتمان، ...) که به هزینه‌ها/درآمدها تخصیص می‌گیرد و گزارش‌ها را قابل فیلتر می‌کند |
