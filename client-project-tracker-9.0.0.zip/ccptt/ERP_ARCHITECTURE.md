# ERP_ARCHITECTURE

> مرجع طراحی معماری نهایی سیستم حسابداری ERP  
> مبنا: `ACCOUNTING_SYSTEM_ANALYSIS.md`  
> وضعیت: **طراحی معماری هدف (Target Architecture)**  
> نوع سند: **Architecture Blueprint / Audit-Grade Accounting Design**

---

# 0) هدف این سند

این سند، **معماری استاندارد نهایی** سیستم حسابداری ERP را تعریف می‌کند؛ نه وضعیت موجود کد را.  
بنابراین این فایل پاسخ می‌دهد که:

- سیستم حسابداری **باید** چگونه طراحی شود
- هر داده **باید** فقط از کجا بیاید
- هر گزارش **باید** فقط از کدام منبع تغذیه شود
- چه بخش‌های Legacy باید حذف شوند
- چه بخش‌هایی باید Merge شوند
- چه بخش‌هایی باید Rewrite شوند
- چه قوانین معماری باید بر کل پروژه حاکم باشند

این سند **هیچ کدی ارائه نمی‌دهد** و صرفاً طراحی معماری نهایی را مشخص می‌کند.

---

# 1) معماری استاندارد نرم‌افزار

## 1.1 اصل بنیادین

معماری نهایی باید بر این اصل بنا شود:

> **تمام رویدادهای مالی ابتدا باید به سند حسابداری استاندارد (Voucher) تبدیل شوند،**  
> و تمام گزارش‌های حسابداری فقط از لایه‌های مشتق‌شده از Voucher تغذیه شوند.

یعنی:

- Business Action هرگز نباید مستقیماً گزارش را تغییر دهد
- Business Action هرگز نباید چند مسیر محاسبه‌ی موازی ایجاد کند
- Ledger و Journal باید محصول ثبت سند باشند، نه مسیر مستقل موازی
- Dashboard باید فقط مصرف‌کننده‌ی لایه‌های حسابداری نهایی باشد

---

## 1.2 لایه‌های معماری استاندارد

معماری هدف باید شامل 7 لایه‌ی مشخص باشد:

```text
1. Presentation Layer
2. Application Layer
3. Domain Layer
4. Accounting Engine Layer
5. Persistence Layer
6. Reporting Layer
7. Integration Layer
```

### 1) Presentation Layer
شامل همه‌ی ورودی/خروجی‌های کاربر:
- ERP UI
- صفحات legacy (در آینده یا حذف یا فقط redirect)
- API public
- Print Views

**وظیفه:**
- دریافت ورودی
- نمایش خروجی
- بدون محاسبه‌ی مالی
- بدون منطق حسابداری

### 2) Application Layer
شامل Use Caseها:
- Create Voucher
- Approve Voucher
- Register Customer Payment
- Register Expert Settlement
- Create Payable
- Pay Payable
- Create Installment
- Receive Installment
- Transfer Treasury
- Close Fiscal Year

**وظیفه:**
- orchestration
- اجرای سناریو
- فراخوانی serviceها
- transaction boundary

### 3) Domain Layer
شامل مدل‌های دامنه:
- Voucher
- VoucherRow
- Account
- FiscalYear
- CostCenter
- Party
- ProjectFinancialState
- TreasuryAccount
- InstallmentPlan
- Payable
- Cheque
- Invoice

**وظیفه:**
- تعریف قواعد دامنه
- invariantها
- وضعیت‌ها
- روابط

### 4) Accounting Engine Layer
هسته‌ی اصلی حسابداری:
- Validation Engine
- Posting Engine
- Journal Builder
- Ledger Builder
- Trial Balance Builder
- P&L Builder
- Balance Sheet Builder
- Fiscal Closing Engine

**وظیفه:**
- تبدیل Business Event به accounting entry
- تضمین دوبل‌انتری
- تولید registerها و report datasets

### 5) Persistence Layer
شامل Repositoryها و Data Accessها

**وظیفه:**
- خواندن و نوشتن داده از جداول/ذخیره‌سازی
- بدون منطق report
- بدون منطق UI

### 6) Reporting Layer
شامل Query Serviceها و read modelها:
- JournalReportService
- GeneralLedgerReportService
- SubsidiaryLedgerReportService
- TrialBalanceReportService
- IncomeStatementReportService
- BalanceSheetReportService
- CashFlowReportService
- AgingReportService

**وظیفه:**
- تهیه‌ی خروجی تحلیلی فقط از data source استاندارد

### 7) Integration Layer
شامل:
- Webhook
- REST API
- Notifications
- Bale/SMS
- Import/Export
- Cron

**وظیفه:**
- مصرف/ارسال داده خارج از هسته حسابداری
- بدون ایجاد مسیر موازی داده

---

# 2) نمودار کامل جریان داده

## 2.1 جریان استاندارد اصلی

```text
Business Action
↓
Application Service
↓
Domain Validation
↓
Voucher
↓
Voucher Rows
↓
Journal
↓
General Ledger
↓
Trial Balance
↓
Income Statement
↓
Balance Sheet
↓
Dashboard
```

## 2.2 نسخه‌ی تفصیلی‌تر

```text
User / External Trigger
↓
Command / Use Case
↓
Application Service
↓
Business Rule Validation
↓
Accounting Mapping Resolution
↓
Create Voucher Draft
↓
Validate Voucher Rows
  - debit == credit
  - period open
  - fiscal year valid
  - accounts active
  - dimensions valid
↓
Persist Voucher
↓
Persist Voucher Rows
↓
Post Voucher
↓
Create Journal Entries
↓
Post to General Ledger
↓
Update Trial Balance Snapshot / Read Model
↓
Compute Report Read Models
  - Journal
  - General Ledger
  - Subsidiary Ledger
  - Trial Balance
  - Income Statement
  - Balance Sheet
↓
Serve Dashboard / Reports / Print / API
```

## 2.3 قاعده‌ی طلایی جریان

### هر Business Action فقط یک راه مجاز دارد:

```text
Business Action
→ Voucher
→ Ledger/Reports
```

و این راه‌های زیر **غیرمجاز** هستند:

```text
Business Action → Report مستقیم
Business Action → Dashboard مستقیم
Business Action → Journal مستقیم بدون Voucher
Business Action → Ledger مستقل بدون Voucher
Business Action → چند جدول موازی بدون مرجع حسابداری واحد
```

---

# 3) Single Source of Truth برای تمام داده‌ها

## 3.1 اصل کلی SoT

در معماری نهایی، **هر مفهوم فقط یک مرجع اصلی** خواهد داشت.

---

## 3.2 جدول SoT نهایی

| مفهوم | Single Source of Truth نهایی |
|---|---|
| سند حسابداری | `Voucher` |
| ردیف سند | `VoucherRow` |
| دفتر روزنامه | Derived فقط از `VoucherRow` |
| دفتر کل | Derived فقط از `Journal` یا مستقیم از `Posted VoucherRow` |
| دفتر معین | Derived فقط از `General Ledger` |
| تراز آزمایشی | Derived فقط از `General Ledger` |
| صورت سود و زیان | Derived فقط از `Trial Balance` |
| ترازنامه | Derived فقط از `Trial Balance` |
| مانده حساب CoA | `General Ledger` |
| حساب خزانه | `TreasuryAccount` + Ledger Posting |
| مطالبات مشتری | `General Ledger` در حساب Receivable |
| بدهی به کارشناس | `General Ledger` در حساب Expert Payable |
| بدهی به تامین‌کننده | `General Ledger` در حساب Payable |
| وضعیت مالی پروژه | **Read Model مشتق‌شده از Voucher/Ledger**، نه `_cptt_steps` |
| سال مالی | `FiscalYear` |
| قفل دوره | `FiscalPeriodLock` |
| مرکز هزینه | `CostCenter` |
| شخص حسابداری | `Party` |
| نرخ ارز | `CurrencyRate` |
| KPIهای مالی داشبورد | فقط از Reporting Layer |

---

## 3.3 SoT های غیرمجاز در معماری نهایی

این‌ها نباید مرجع اصلی بمانند:

- `_cptt_steps` برای reportهای مالی نهایی
- `wp_cptt_fin_ledger` به‌عنوان ledger موازی مستقل از voucher
- `wp_cptt_ledger` برای تاریخچه‌ای که معادل voucher ندارد
- محاسبه‌ی مستقیم reportها در frontend
- synthetic / virtual voucher به‌عنوان منبع دائمی
- option arrays برای مدل‌های مالی حساس

---

# 4) تعیین مسئول هر بخش

## 4.1 تفکیک مسئولیت (Responsibility Matrix)

| بخش | مسئول اصلی |
|---|---|
| UI / Screens | Presentation Layer |
| Orchestration عملیات | Application Services |
| قواعد حسابداری | Accounting Engine |
| قواعد دامنه | Domain Models |
| ذخیره‌سازی | Repositories |
| گزارش‌ها | Reporting Services |
| اعلان/کرون/API | Integration Layer |

---

## 4.2 مسئول هر عملیات مهم

| عملیات | مسئول |
|---|---|
| ثبت سند دستی | VoucherApplicationService |
| تأیید سند | VoucherApprovalService |
| برگشت سند | VoucherReversalService |
| بازکردن سند | VoucherLifecycleService |
| دریافت از مشتری | CustomerReceiptService |
| تسویه کارشناس | ExpertSettlementService |
| ثبت درآمد/هزینه | TreasuryTransactionService |
| انتقال بین حساب‌ها | TreasuryTransferService |
| ثبت بدهی | PayableService |
| پرداخت بدهی | PayablePaymentService |
| ایجاد قسط | InstallmentPlanService |
| دریافت قسط | InstallmentReceiptService |
| ثبت/وصول/پرداخت چک | ChequeAccountingService |
| بستن سال مالی | FiscalYearClosingService |
| تولید دفتر روزنامه | JournalReportService |
| تولید دفتر کل | GeneralLedgerReportService |
| تولید دفتر معین | SubsidiaryLedgerReportService |
| تولید تراز آزمایشی | TrialBalanceReportService |
| تولید سود و زیان | IncomeStatementReportService |
| تولید ترازنامه | BalanceSheetReportService |
| KPI داشبورد | DashboardFinancialReadService |

---

# 5) Service Layer های نهایی

## 5.1 Application Services

### VoucherApplicationService
وظایف:
- create draft voucher
- update voucher
- save voucher rows
- submit for approval

### VoucherApprovalService
وظایف:
- accountant approval
- manager approval
- ceo approval
- finalize posting permission

### VoucherPostingService
وظایف:
- validate posted voucher
- generate Journal
- post to General Ledger
- trigger report refresh

### VoucherReversalService
وظایف:
- generate reversing voucher
- link to original voucher
- preserve audit trail

### VoucherLifecycleService
وظایف:
- delete draft
- unfinalize if allowed
- archive if policy exists

---

## 5.2 Financial Business Services

### CustomerReceiptService
- ثبت دریافت مشتری
- اعمال به پروژه در صورت وجود
- تولید Voucher نوع RV
- ثبت Party dimension

### ExpertSettlementService
- تسویه مرحله/کارشناس
- تولید Voucher نوع PV
- ثبت payable movement

### TreasuryTransactionService
- واریز
- برداشت
- درآمد/هزینه cash-based
- ایجاد voucher متناظر

### TreasuryTransferService
- انتقال بین دو حساب خزانه
- تولید TV

### PayableService
- ایجاد/ویرایش بدهی
- read model بدهی

### PayablePaymentService
- پرداخت بدهی
- تولید PV

### InstallmentPlanService
- ایجاد برنامه قسط
- schedule rows

### InstallmentReceiptService
- دریافت قسط
- تولید RV

### ChequeAccountingService
- ثبت چک دریافتی/پرداختی
- تغییر وضعیت چک
- تولید اسناد متناظر
- ثبت حرکت خزانه در صورت نیاز

### InvoiceAccountingService
- ثبت فاکتور
- تبدیل فاکتور به سند
- اتصال فاکتور به receivable/revenue

### FiscalYearClosingService
- preview close
- create CV
- create OV
- lock fiscal period

---

## 5.3 Reporting Services

### JournalReportService
- source: Posted VoucherRows
- output: Journal lines

### GeneralLedgerReportService
- source: Journal / Posted VoucherRows
- output: account movements + running balance

### SubsidiaryLedgerReportService
- source: General Ledger + dimensions

### TrialBalanceReportService
- source: General Ledger

### IncomeStatementReportService
- source: Trial Balance

### BalanceSheetReportService
- source: Trial Balance

### CashFlowReportService
- source: Posted VoucherRows tagged with cash accounts

### AgingReportService
- source: General Ledger receivable/payable balances + due references

### DashboardFinancialReadService
- source: Reporting Services only

---

# 6) Repository های نهایی

## 6.1 Repositoryهای اصلی

| Repository | وظیفه |
|---|---|
| `VoucherRepository` | CRUD سند |
| `VoucherRowRepository` | CRUD ردیف سند |
| `JournalRepository` | ثبت/خواندن دفتر روزنامه |
| `GeneralLedgerRepository` | ثبت/خواندن دفتر کل |
| `FiscalYearRepository` | سال مالی |
| `FiscalLockRepository` | قفل دوره |
| `AccountRepository` | Chart of Accounts |
| `TreasuryAccountRepository` | حساب‌های خزانه |
| `CostCenterRepository` | مراکز هزینه |
| `PartyRepository` | مشتری/کارشناس/تامین‌کننده |
| `CurrencyRateRepository` | نرخ ارز |
| `InvoiceRepository` | فاکتور |
| `ChequeRepository` | چک |
| `PayableRepository` | بدهی |
| `InstallmentPlanRepository` | برنامه قسط |
| `InstallmentRowRepository` | ردیف‌های قسط |
| `ProjectFinancialSnapshotRepository` | فقط Read Model، نه SoT |
| `AuditLogRepository` | audit trail |

---

## 6.2 Repositoryهایی که نباید وجود داشته باشند یا باید محدود شوند

| Repository/Pattern نامطلوب | دلیل |
|---|---|
| Repository مستقیم روی `_cptt_steps` برای report مالی نهایی | `_cptt_steps` باید operational source باشد، نه report SoT |
| repository موازی برای `cptt_fin_ledger` و `cptt_ledger` بدون همسان‌سازی | dual ledger anti-pattern |
| OptionRepository برای مدل‌های مالی اصلی | weak consistency |

---

# 7) مدل‌های داده‌ی نهایی

## 7.1 مدل‌های اصلی دامنه

### Account
- id
- code
- name
- level
- parentId
- accountNature (`asset/liability/equity/revenue/expense`)
- postingAllowed
- active

### Voucher
- id
- voucherNo
- voucherCode
- voucherType
- fiscalYearId
- date
- description
- status
- sourceType
- sourceId
- createdBy
- approvedByAccountant
- approvedByManager
- approvedByCEO
- postedAt
- reversedVoucherId
- isAutoGenerated

### VoucherRow
- id
- voucherId
- rowNo
- accountId
- debit
- credit
- description
- projectId?
- costCenterId?
- partyId?
- currencyId?
- exchangeRate?

### JournalEntry
- id
- voucherId
- rowId
- postingDate
- accountId
- debit
- credit
- dimensions

### GeneralLedgerEntry
- id
- journalEntryId
- accountId
- debit
- credit
- runningBalance
- fiscalYearId
- periodKey
- dimensions

### TrialBalanceRow
- accountId
- debit
- credit
- closingBalance

### IncomeStatementRow
- accountId
- category
- amount

### BalanceSheetRow
- accountId
- group
- amount

### FiscalYear
- id
- name
- startDate
- endDate
- status

### FiscalPeriodLock
- id
- fiscalYearId
- startDate
- endDate
- isLocked
- lockedBy

### TreasuryAccount
- id
- name
- type
- iban
- cardNumber
- active
- linkedCoaAccountId

### CostCenter
- id
- name
- code
- type
- budget
- active

### Party
- id
- partyType (`customer/expert/supplier/contractor/other`)
- refUserId?
- displayName
- taxId?
- phone?
- active

### ProjectFinancialSnapshot (Read Model only)
- projectId
- billed
- collected
- customerOutstanding
- expertOutstanding
- expertPaid
- grossProfit
- netProfit?

### Currency
- id/code
- displayName
- decimals
- active

### CurrencyRate
- id
- baseCurrency
- quoteCurrency
- rate
- effectiveDate

### Payable
- id
- partyId
- amount
- paidAmount
- dueDate
- status

### InstallmentPlan
- id
- customerId
- totalAmount
- installmentCount
- intervalDays
- firstDueDate

### InstallmentRow
- id
- planId
- no
- dueDate
- amount
- paidAmount
- status

### Cheque
- id
- chequeType
- treasuryAccountId
- amount
- dueDate
- status
- partyId

### Invoice
- id
- number
- type
- customerId
- projectId?
- subtotal
- discount
- tax
- total
- status
- voucherId?

---

# 8) مسیر استاندارد ثبت سند

## 8.1 سناریوی دستی

```text
UI Form
↓
VoucherApplicationService.createDraft()
↓
Voucher Domain Validation
↓
VoucherRepository.save()
↓
VoucherApprovalService.approve() [if workflow step]
↓
VoucherPostingService.post()
↓
JournalRepository.append()
↓
GeneralLedgerRepository.append()
↓
TrialBalanceReadModel.refresh()
↓
ReportingLayer.refreshViews()
↓
DashboardFinancialReadService.refresh()
```

## 8.2 سناریوی خودکار

```text
Business Action
↓
Relevant Application Service
↓
Resolve accounting mapping
↓
Generate Voucher
↓
Persist Voucher
↓
Post Voucher
↓
Journal
↓
General Ledger
↓
Report Read Models
```

## 8.3 قاعده‌ی معماری

### هیچ event مالی نباید این مسیر را دور بزند.

به‌صورت رسمی ممنوع است:
- update مستقیم dashboard
- insert مستقیم در ledger بدون voucher
- update مستقیم receivable/payable report state بدون posting
- synthetic voucher در UI

---

# 9) مسیر استاندارد تولید گزارش‌ها

## 9.1 مسیر پایه

```text
Posted Voucher
↓
Journal Entries
↓
General Ledger Entries
↓
Trial Balance
↓
Financial Statements
↓
Dashboard / Analytics / Print / API
```

## 9.2 ترتیب وابستگی گزارش‌ها

| گزارش | باید از چه چیزی ساخته شود |
|---|---|
| اسناد حسابداری | Voucher + VoucherRows |
| دفتر روزنامه | Posted VoucherRows / Journal Entries |
| دفتر کل | General Ledger |
| دفتر معین | General Ledger + dimensions |
| تراز آزمایشی | Trial Balance |
| صورت سود و زیان | Trial Balance |
| ترازنامه | Trial Balance |
| Cash Flow | Posted VoucherRows + cash-account classification |
| Aging | General Ledger + due references |
| Dashboard KPI | Reporting Layer outputs |

---

# 10) هر گزارش فقط باید از کدام منبع تغذیه شود؟

## 10.1 جدول قطعی منبع تغذیه

| گزارش | منبع مجاز |
|---|---|
| اسناد حسابداری | `Voucher`, `VoucherRow` |
| دفتر روزنامه | `JournalEntry` یا `Posted VoucherRow` |
| دفتر کل | `GeneralLedgerEntry` |
| دفتر معین | `GeneralLedgerEntry` + `Party/Project/CostCenter` dimensions |
| تراز آزمایشی | `TrialBalanceRow` |
| صورت سود و زیان | `TrialBalanceRow` |
| ترازنامه | `TrialBalanceRow` |
| جریان نقد | `GeneralLedgerEntry` + cash account classification |
| مطالبات مشتریان | `GeneralLedgerEntry` روی حساب Receivable |
| بدهی کارشناسان | `GeneralLedgerEntry` روی حساب Expert Payable |
| بدهی تامین‌کنندگان | `GeneralLedgerEntry` روی حساب Payable |
| KPI درآمد | `IncomeStatementReportService` |
| KPI سود | `IncomeStatementReportService` |
| KPI موجودی خزانه | `GeneralLedgerEntry` یا TreasuryBalanceReadModel |
| KPI مطالبات | ReceivableReadModel مشتق از GL |

## 10.2 منابع غیرمجاز برای گزارش نهایی

این‌ها نباید منبع نهایی report شوند:
- `_cptt_steps`
- `wp_cptt_fin_ledger` به‌تنهایی
- `wp_cptt_ledger` به‌تنهایی
- synthetic vouchers در UI
- direct client-side aggregation روی payloadهای heterogenous

---

# 11) چه بخش‌های Legacy باید حذف شوند؟

## 11.1 حذف کامل در معماری هدف

### 1) مسیر موازی `wp_cptt_ledger` به‌عنوان ledger مالی
- باید یا migrate شود یا فقط به history/archive تبدیل شود
- نباید منبع محاسبات مالی نهایی باقی بماند

### 2) مسیر موازی `wp_cptt_fin_ledger` به‌عنوان accounting ledger مستقل از voucher
- اگر حفظ می‌شود، باید فقط **Operational Treasury Event Store** باشد
- نباید منبع نهایی reportهای حسابداری اصلی باشد

### 3) synthetic / virtual voucher generation در frontend
- باید کاملاً حذف شود
- UI نباید سند حسابداری بسازد

### 4) client-side financial report calculation
- برای reportهای اصلی باید حذف شود
- frontend فقط presenter باشد

### 5) option-based storage برای domain-critical accounting models
باید به‌تدریج حذف شود برای:
- COA
- FiscalYear
- Locks
- CostCenters
- Companies/Branches (در صورت رشد domain)

---

# 12) چه بخش‌هایی باید Merge شوند؟

## 12.1 Ledger Merge

### باید Merge شوند:
- `wp_cptt_fin_ledger`
- `wp_cptt_ledger`

### نتیجه نهایی:
یک **Unified Ledger Event Store** یا حذف کامل مفهوم ledger event store موازی و اتکا فقط به:
- Voucher
- Journal
- General Ledger

---

## 12.2 Project Financial Logic Merge

باید Merge شوند:
- `project_financial_data()`
- `project_remaining()`
- `build_receivables()`
- `compute_kpis()` (بخش project-based)
- `build_projects_full()`
- `get_project_financial_snapshot()`

### نتیجه نهایی:
یک سرویس واحد:
- `ProjectFinancialReadService`

---

## 12.3 Profit Logic Merge

باید Merge شوند:
- gross profit logic
- voucher-based profit logic
- monthly net logic

### نتیجه نهایی:
- `GrossProfitService` (اگر نیاز عملیاتی وجود دارد)
- `IncomeStatementReportService` (برای سود حسابداری رسمی)

و هر Dashboard KPI باید صریحاً مشخص کند از کدام یک استفاده می‌کند.

---

## 12.4 Party Financial Views Merge

باید Merge شوند:
- customer receivables
- payable views
- expert settlement balances
- party statements

### نتیجه نهایی:
یک `PartyFinancialReadService`

---

# 13) چه بخش‌هایی باید Rewrite شوند؟

## 13.1 Report UI Layer

### باید Rewrite شود:
- Journal UI logic
- General Ledger UI logic
- Subsidiary Ledger UI logic
- Trial Balance UI logic
- Income Statement UI logic
- Balance Sheet UI logic

**هدف:**
frontend فقط read model مصرف کند، نه خودش محاسبه کند.

---

## 13.2 Voucher Posting Engine

اگر posting امروز فقط insert voucher/rows است و reportها مستقیم rows را می‌خوانند، لازم است یک posting pipeline رسمی تعریف شود:
- Draft Voucher
- Posted Voucher
- JournalEntry generation
- GeneralLedgerEntry generation
- Report snapshots/read models

این بخش باید Rewrite مفهومی شود.

---

## 13.3 Fiscal Architecture Storage

مدل‌های مالی حساس که در option هستند، بهتر است Rewrite شوند به table-backed models:
- FiscalYear
- PeriodLock
- COA
- CostCenter
- Mapping

---

## 13.4 Payment / Receipt accounting integration

جریان payment receipt approval باید Rewrite شود تا مستقیم به Voucher pipeline وصل شود.

---

## 13.5 Notification/Integration consistency layer

بخش‌های اعلان مالی باید Rewrite شوند تا از event bus واحد استفاده کنند.

---

# 14) قوانین معماری پروژه

## قانون 1 — Voucher First
هر رویداد مالی باید ابتدا به Voucher تبدیل شود.

## قانون 2 — No Report Without Posting
هیچ report مالی نباید از data raw عملیاتی مستقیم تولید شود مگر read model رسمی آن domain.

## قانون 3 — One Truth Per Concept
هر مفهوم فقط یک SoT دارد.

## قانون 4 — Frontend Is Not Accounting Engine
frontend هرگز نباید report مالی محاسبه کند.

## قانون 5 — Journal Is Derived, Not Freehand
Journal باید فقط از Posted VoucherRows ساخته شود.

## قانون 6 — General Ledger Is The Accounting Balance Engine
تمام مانده‌های حسابداری باید از General Ledger بیایند.

## قانون 7 — Trial Balance Is The Base of Statements
P&L و Balance Sheet فقط از Trial Balance بیایند.

## قانون 8 — Dimensions Are Attributes, Not Alternative Sources
Project / Party / CostCenter باید dimension باشند، نه منبع داده‌ی موازی.

## قانون 9 — No Option Arrays For Core Financial State
مدل‌های مالی اصلی table-backed باشند.

## قانون 10 — Every Financial Write Has Audit
هر write مالی باید audit trail داشته باشد.

## قانون 11 — Every Posted Voucher Must Be Traceable
هر Voucher باید sourceType/sourceId یا equivalent domain link داشته باشد.

## قانون 12 — Business Reality and Accounting Reality Must Converge
Operational project/payment state باید از طریق voucher posting به accounting state همگرا شود.

## قانون 13 — No Synthetic UI-Only Accounting Objects
هیچ سند حسابداری فقط در UI وجود نداشته باشد.

## قانون 14 — Status Machine Must Be Explicit
وضعیت‌ها باید برای هر aggregate root صریح و مستند باشند.

## قانون 15 — Reporting Layer Must Be Deterministic
یک input ثابت باید همیشه یک output مالی ثابت بدهد.

---

# 15) Anti Pattern های موجود

## 15.1 Multi-Source Truth
یک مفهوم مالی از چند جا محاسبه می‌شود.

## 15.2 Dual Ledger
وجود دو ledger موازی بدون مرجع رسمی واحد.

## 15.3 UI-Side Accounting Logic
محاسبه‌ی report در frontend.

## 15.4 Synthetic Voucher in Presentation Layer
ساخت object حسابداری در UI.

## 15.5 Prefix-Based Semantic Accounting
وابستگی منطق report به first digit account code.

## 15.6 Option-as-Database Anti Pattern
نگهداری state مالی مهم در `wp_options`.

## 15.7 Domain Leakage
منطق حسابداری در Admin UI / Expert UI / Payment UI پراکنده شده است.

## 15.8 Transaction Boundary Ambiguity
روشن نیست مرز تراکنش مالی دقیقاً در کدام لایه بسته می‌شود.

## 15.9 Heuristic Matching Between Ledger and Voucher
match کردن بر اساس amount/project/person به‌جای relation صریح.

## 15.10 Duplicate Calculation Functions
محاسبات مالی مشابه در چند فایل/کلاس.

## 15.11 Mixed Operational and Accounting Semantics
مثلاً `_cptt_steps` هم workflow project است، هم financial state source.

## 15.12 Read Model Built On Raw Mutable State
Dashboard/KPI از داده‌ی عملیاتی mutable مستقیم می‌خوانند.

## 15.13 Legacy and ERP Coexistence Without Bounded Context Isolation
Legacy finance و ERP finance همزیستی دارند ولی boundary صریح ندارند.

## 15.14 Missing Explicit Journal Aggregate
Journal به‌عنوان aggregate/read model رسمی تعریف نشده است.

## 15.15 Missing Repository Abstraction
دسترسی به داده پراکنده و مستقیم است.

---

# 16) معماری استاندارد پیشنهادی نهایی (نسخه فشرده)

```text
[Presentation Layer]
ERP UI / Admin UI / API / Print
↓
[Application Layer]
VoucherApplicationService
TreasuryTransactionService
CustomerReceiptService
ExpertSettlementService
PayableService
InstallmentReceiptService
ChequeAccountingService
InvoiceAccountingService
FiscalYearClosingService
↓
[Domain Layer]
Voucher / VoucherRow / Account / Party / TreasuryAccount /
CostCenter / FiscalYear / Lock / Invoice / Cheque / Payable / InstallmentPlan
↓
[Accounting Engine]
Validation Engine
Posting Engine
Journal Builder
General Ledger Builder
Trial Balance Builder
Statement Builders
↓
[Persistence Layer]
Repositories
↓
[Reporting Layer]
JournalReportService
GeneralLedgerReportService
SubsidiaryLedgerReportService
TrialBalanceReportService
IncomeStatementReportService
BalanceSheetReportService
DashboardFinancialReadService
↓
[Integration Layer]
Webhook / REST / Notifications / Import / Export / Cron
```

---

# 17) جمع‌بندی نهایی

معماری نهایی باید سیستم را از این وضعیت:

```text
Multiple Sources → Multiple Calculations → Multiple Financial Truths
```

به این وضعیت منتقل کند:

```text
One Business Event → One Voucher → One Posting Pipeline → One Reporting Truth
```

و این، معیار اصلی پذیرش معماری نهایی خواهد بود.

---

**پایان سند معماری**
