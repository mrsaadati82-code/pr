# WAVE_2_HOTFIX_8.5.2 — تب واقعی «💵 جریان نقدی» + رفع باگ ساختاری hh/gj

> نسخه: **8.5.2**
> تاریخ: 1405/04/17

## 🎯 دو مسئله‌ی کاربر

1. تب‌های «صندوق‌ها و حساب‌ها»، «انتقال بین حساب‌ها»، «درآمدها و هزینه‌ها»
   سفید می‌شوند + خطای `Uncaught ReferenceError: hh is not defined`
2. جریان نقدی باید یک **تب واقعی در سایدبار ERP** باشد (نه دکمه‌ی
   شناور یا iframe)، با ظاهری هماهنگ با بقیه‌ی پنل

## 🔍 ریشه‌یابی مسئله ۱ (تحقیق دقیق)

با اسکن کامل `assets/finance-ui/app.js` مشخص شد که این باگ **قبل از
هر تغییری که من کرده‌ام** در باندل وجود داشته — از همان نسخه‌ی 8.3.2
که کاربر داد. سه identifier در باندل **استفاده می‌شوند ولی هیچ‌جا
تعریف نشده‌اند**:

```
case"treasury":return l.jsx(hh,{});           ← hh تعریف نشده
case"transfers":return l.jsx(hh,{...});       ← hh تعریف نشده
case"income_expense":return l.jsx(gj,{});     ← gj تعریف نشده
```

این نتیجه‌ی build ناقص React است (کامپوننت‌های Treasury و
IncomeExpense از bundle حذف/گم شده‌اند). چون source اصلی React در
دسترس نیست، این تب‌ها بدون بازسازی Wave 4 قابل احیا نیستند.

## ✅ راه‌حل‌ها

### الف) Patch مستقیم باندل React برای رفع کرش

با یک substitution محدود در `assets/finance-ui/app.js`:

```js
// قبل: case"treasury":return l.jsx(hh,{});
// بعد: case"treasury":return l.jsx(Ye,{title:"صندوق‌ها و حساب‌ها",
//                          description:"این بخش در باندل فعلی موجود نیست..."});
```

`Ye` یک EmptyState component است که در همان scope موجود است. این جایگزین:
- **کرش را حذف می‌کند** — به‌جای سفید شدن، یک کارت با پیام مفید نشان می‌دهد
- **کاربر را راهنمایی می‌کند** به سمت تب جدید «💵 جریان نقدی»
- **بقیه‌ی پنل ERP دست‌نخورده می‌ماند**

سه substitution انجام شد (treasury, transfers, income_expense).

### ب) تب واقعی «جریان نقدی» در سایدبار ERP

سه patch اضافی در `app.js`:

1. **آیتم منو در sidebar** — در گروه «خزانه‌داری»، بعد از «گردش حساب یکپارچه»:
   ```
   {id:"cashflow",label:"جریان نقدی (Cash-View)"}
   ```

2. **case جدید در switch رندر** — قبل از `default:`:
   ```js
   case"cashflow":return l.jsx("div",{id:"cptt-cashflow-slot",className:"cptt-cashflow-slot"});
   ```
   یعنی وقتی این تب فعال است، یک `<div>` خالی رندر می‌شود.

3. **بارگذاری محتوا** توسط `cptt-erp-extras.js`:
   - MutationObserver مراقب DOM است
   - وقتی `#cptt-cashflow-slot` ظاهر شد، محتوا را با fetch از
     `admin.php?page=cptt-finance-cashflow&embed=1` می‌گیرد
   - فقط بین `<body>...</body>` را استخراج و در slot می‌گذارد
   - form submit را intercept می‌کند — به‌جای reload صفحه، همان slot
     را با پارامترهای فرم refresh می‌کند (SPA-like)
   - `CPTT_InputNormalize.scan()` را روی slot صدا می‌زند تا datepicker
     شمسی هم روی فیلدهای تاریخ فعال شود

### ج) ظاهر هماهنگ با ERP

در `cptt-erp-extras.js` یک بلاک CSS اختصاصی برای `.cptt-cashflow-slot`
اضافه شد که همان سبک Tailwind-like پنل ERP را روی محتوای رندرشده اعمال
می‌کند: کارت‌های سفید با border، KPI با نوار رنگی سمت راست، جدول‌های
راه‌راه، دکمه‌های primary با gradient بنفش، اسکرول‌بار زیبا.

### د) حذف دکمه‌ی floating

از نسخه‌ی 8.5.1، یک دکمه‌ی floating در گوشه صفحه بود که modal + iframe
باز می‌کرد. این کاملاً حذف شد. کاربر حالا از خود sidebar به تب می‌رود
— دقیقاً مثل بقیه‌ی تب‌ها.

## 📁 فایل‌های تغییریافته

| فایل | تغییر |
|---|---|
| `assets/finance-ui/app.js` | patch: fallback برای hh/gj (۳ substitution) + آیتم sidebar + case render (۳ substitution دیگر) — مجموعاً +۶۳۴ بایت |
| `assets/js/cptt-erp-extras.js` | بازنویسی کامل: حذف FAB/iframe، اضافه‌ی MutationObserver + fetch + form intercept + CSS ERP-hommogeneous |
| `client-project-tracker.php` | بامپ نسخه به 8.5.2 |

## 🛡️ ایمنی

- ✅ patch app.js فقط ۶ substring دقیقاً تعیین‌شده را عوض می‌کند (هر یک دقیقاً ۱ occurrence)
- ✅ syntax check با Node.js پاس
- ✅ همه‌ی تعاریف موجود در باندل دست‌نخورده
- ✅ کامپوننت `Ye` (EmptyState) از قبل در scope بندل وجود دارد
- ✅ دیتای دیتابیس تغییر نکرد
- ✅ E-1، ساعت audit-trail، datepicker شمسی، ورودی فارسی/انگلیسی همه همچنان کار می‌کنند

## 🎯 UX نهایی

- ✅ باز کردن پنل ERP → **سایدبار سمت راست → گروه «خزانه‌داری»**
- ✅ در آن گروه یک آیتم جدید: **«جریان نقدی (Cash-View)»**
- ✅ کلیک → تب داخل خود پنل باز می‌شود با ظاهری هماهنگ (نه popup، نه iframe)
- ✅ تب‌های «صندوق‌ها و حساب‌ها» / «انتقال بین حساب‌ها» / «درآمدها و هزینه‌ها»
  دیگر سفید نمی‌شوند — یک کارت با پیام مفید نشان می‌دهند و کاربر را
  به تب جریان نقدی هدایت می‌کنند
- ✅ فیلترهای «از تاریخ / تا تاریخ» با datepicker شمسی از v8.4.0
- ✅ ارقام فارسی/انگلیسی هر دو در فیلدها قبول می‌شوند
