# PHASE_1_REPORT

> Phase 1 Execution Artifact  
> Program: ERP Refactor / Accounting Unification  
> Source references: `ACCOUNTING_SYSTEM_ANALYSIS.md`, `ERP_ARCHITECTURE.md`, `ERP_REFACTOR_ROADMAP.md`, `PHASE_0_REPORT.md`  
> Mode: **No code change / No behavior change / Domain Canonicalization only**

---

# 0) هدف این گزارش

این سند، شروع اجرایی **Phase 1 — Domain Canonicalization** است و فقط روی این موارد تمرکز دارد:

1. تعریف **canonical domain model**
2. تعیین **field naming** استاندارد در سطح دامنه
3. تعیین **relation map** رسمی بین مدل‌ها
4. تعیین **state machine** رسمی برای aggregateهای اصلی
5. تعیین **dimension model** رسمی
6. تعیین **policy رسمی برای account type / account nature**
7. تعیین **mapping صریح بین مدل‌های فعلی و مدل‌های هدف**
8. ثبت ambiguityها و نقاطی که هنوز نیازمند تصمیم یا بررسی بیشتر هستند

> این سند عمداً هیچ تغییری در کد، schema، query، migration یا رفتار runtime ایجاد نمی‌کند.

---

# 1) وضعیت شروع Phase 1

## 1.1 مبنای شروع

Phase 1 بر اساس این artefactها شروع می‌شود:
- `ACCOUNTING_SYSTEM_ANALYSIS.md`
- `ERP_ARCHITECTURE.md`
- `ERP_REFACTOR_ROADMAP.md`
- `PHASE_0_REPORT.md`

## 1.2 وابستگی به Phase 0

طبق Roadmap، Phase 1 وابسته به Phase 0 است.  
از آنجا که Phase 0 در این workspace از منظر **مستندسازی و baseline ساختاری** انجام شده ولی از منظر **runtime/staging reconciliation** هنوز به‌صورت کامل بسته نشده، این Phase 1 با این فرض آغاز می‌شود:

- baseline ساختاری معتبر است
- baseline runtime عددی توسط تیم/کاربر خارج از این workspace قابل تکمیل است
- تصمیمات این سند فقط **معماری و مدلسازی دامنه** هستند، نه تصمیم اجرایی درباره migration واقعی

## 1.3 وضعیت نسخه و زیپ

این artefact یک **خروجی مستنداتی** است و هیچ تغییر کدی در افزونه ایجاد نمی‌کند؛ بنابراین در این مرحله:
- version bump انجام نشده
- zip نصبی جدید ساخته نشده

---

# 2) قواعد Canonicalization در Phase 1

## 2.1 قاعده‌ی اصلی

در معماری هدف، هر مفهوم مالی باید:
- **یک نام canonical** داشته باشد
- **یک owner مشخص** داشته باشد
- **یک SoT مشخص** داشته باشد
- **یک lifecycle مشخص** داشته باشد
- **یک relation رسمی** با سایر مدل‌ها داشته باشد

## 2.2 قاعده‌ی نام‌گذاری

در سطح دامنه، نام‌ها به‌صورت زیر canonical می‌شوند:
- **Model names:** PascalCase
- **Field names:** camelCase
- **Persistence/storage columns:** می‌توانند در DB به شکل snake_case باقی بمانند، اما mapping آن‌ها باید صریح باشد

### مثال
- Domain field: `voucherNo`
- DB column current: `voucher_number`

## 2.3 قاعده‌ی عدم حدس

هرجا در کد فعلی قطعیت کافی وجود نداشته باشد، نتیجه با یکی از این برچسب‌ها ثبت می‌شود:
- `نامشخص`
- `نیاز به بررسی بیشتر`

## 2.4 قاعده‌ی تفکیک مفهوم‌ها

در Canonical Model باید این سه مفهوم از هم جدا شوند:
1. **Operational Reality**
2. **Accounting Reality**
3. **Reporting Read Model**

یعنی:
- `_cptt_steps` = واقعیت عملیاتی پروژه
- `Voucher/VoucherRow` = واقعیت حسابداری رسمی
- `ProjectFinancialSnapshot` = read model مشتق‌شده

---

# 3) مرزبندی دامنه (Bounded Context Canonicalization)

## 3.1 بسترهای دامنه‌ای نهایی

برای جلوگیری از اختلاط فعلی، مدل‌ها در Phase 1 در این contextها canonical می‌شوند:

### A) Accounting Core Context
مدل‌های اصلی:
- `Account`
- `Voucher`
- `VoucherRow`
- `JournalEntry`
- `GeneralLedgerEntry`
- `TrialBalanceRow`
- `FiscalYear`
- `FiscalPeriodLock`

### B) Treasury Context
مدل‌های اصلی:
- `TreasuryAccount`
- `TreasuryTransaction` (مفهوم transitional / طراحی‌شده، نه لزوماً جدول فعلی)
- `BankReconciliationSnapshot` (read/report model)

### C) Party & Settlement Context
مدل‌های اصلی:
- `Party`
- `Payable`
- `Cheque`
- `InstallmentPlan`
- `InstallmentRow`

### D) Commercial Context
مدل‌های اصلی:
- `Invoice`
- `InvoiceRow`

### E) Project Operational Context
مدل‌های اصلی:
- `Project`
- `ProjectStepOperationalState`

### F) Reporting Context
مدل‌های اصلی:
- `ProjectFinancialSnapshot`
- `IncomeStatementRow`
- `BalanceSheetRow`
- `DashboardFinancialSnapshot`
- `AgingRow`

## 3.2 نتیجه‌ی مرزبندی

این مرزبندی به‌صورت رسمی اعلام می‌کند که:
- `_cptt_steps` متعلق به **Project Operational Context** است
- `Voucher/VoucherRow` متعلق به **Accounting Core Context** است
- `P&L/BS/TB` متعلق به **Reporting Context** است
- `wp_cptt_fin_ledger` و `wp_cptt_ledger` در وضعیت فعلی، **transitional legacy stores** هستند و مدل canonical نهایی حسابداری محسوب نمی‌شوند

---

# 4) جدول Canonical Model Inventory

| Canonical Model | نوع | SoT نهایی | منبع فعلی | تصمیم Phase 1 |
|---|---|---|---|---|
| `Account` | Aggregate / Master Data | Chart of Accounts | `cpttf_erp_coa_nodes` | Canonicalized |
| `TreasuryAccount` | Aggregate / Master Data | Treasury account registry | `wp_cptt_fin_accounts` | Canonicalized |
| `Voucher` | Aggregate Root | `wp_cptt_erp_vouchers` | `wp_cptt_erp_vouchers` | Canonicalized |
| `VoucherRow` | Child Entity | `wp_cptt_erp_voucher_rows` | `wp_cptt_erp_voucher_rows` | Canonicalized |
| `JournalEntry` | Derived Accounting Model | Derived from posted `VoucherRow` | physical table ندارد | Canonicalized as derived model |
| `GeneralLedgerEntry` | Derived / Posted Accounting Model | Derived from `JournalEntry` یا posted rows | physical canonical table ندارد | Canonicalized conceptually |
| `TrialBalanceRow` | Derived Report Model | Derived from `GeneralLedgerEntry` | client-side aggregation فعلی | Canonicalized as report base |
| `FiscalYear` | Aggregate / Master Data | FiscalYear registry | `cpttf_erp_fiscal_years` | Canonicalized |
| `FiscalPeriodLock` | Aggregate / Policy Model | Lock registry | `cpttf_erp_locks` | Canonicalized |
| `CostCenter` | Aggregate / Master Data | Cost center registry | `cpttf_erp_cost_centers` | Canonicalized |
| `Party` | Aggregate / Master Data | Party registry | `wp_users` + payable/cheque free-text | Canonicalized with ambiguity |
| `Currency` | Master Data | Currency registry | `cptt_currency_settings` + ERP rate options | نیاز به بررسی بیشتر |
| `CurrencyRate` | Master Data | Rate registry | `cpttf_erp_currency_rates` | Canonicalized |
| `Payable` | Aggregate | `wp_cptt_erp_payables` | `wp_cptt_erp_payables` | Canonicalized |
| `InstallmentPlan` | Aggregate | `wp_cptt_erp_installments` | `wp_cptt_erp_installments` | Canonicalized |
| `InstallmentRow` | Child Entity | `wp_cptt_erp_installment_rows` | `wp_cptt_erp_installment_rows` | Canonicalized |
| `Cheque` | Aggregate | `wp_cptt_erp_cheques` | `wp_cptt_erp_cheques` | Canonicalized |
| `Invoice` | Aggregate | `wp_cptt_erp_invoices` | `wp_cptt_erp_invoices` | Canonicalized |
| `InvoiceRow` | Child Entity | `wp_cptt_erp_invoice_rows` | `wp_cptt_erp_invoice_rows` | Canonicalized |
| `ProjectFinancialSnapshot` | Read Model | Derived from accounting layer | فعلاً `_cptt_steps`-based logic | Canonicalized as read model only |
| `AuditLog` | Append-only Audit Model | `wp_cptt_erp_audit` | `wp_cptt_erp_audit` | Canonicalized |
| `LegacyFinanceLedgerEvent` | Transitional Legacy Model | SoT نهایی نیست | `wp_cptt_fin_ledger` | Transitional only |
| `LegacyProjectLedgerEvent` | Transitional Legacy Model | SoT نهایی نیست | `wp_cptt_ledger` | Transitional only |
| `ProjectStepOperationalState` | Operational Model | `_cptt_steps` | `_cptt_steps` | Keep operational / not accounting SoT |

---

# 5) نام‌گذاری Canonical فیلدها

## 5.1 Dictionary عمومی

| Domain Name | Persistence نمونه فعلی | توضیح |
|---|---|---|
| `id` | `id` | شناسه دامنه |
| `createdAt` | `created_at` | timestamp |
| `createdBy` | `created_by` | ایجادکننده |
| `updatedAt` | `updated_at` | نامشخص / بسته به مدل |
| `status` | `status` | وضعیت دامنه |
| `description` | `description` / `notes` | شرح |
| `sourceType` | `source_type` / `ref_type` | نوع منبع کسب‌وکاری |
| `sourceId` | `source_id` / `ref_id` | شناسه منبع کسب‌وکاری |
| `dateFa` | `date_fa` | تاریخ شمسی |
| `dateTs` | timestamp / parse result | timestamp متناظر |

## 5.2 قواعد Field Canonicalization

1. **Domain language** باید یکنواخت باشد
2. اگر current storage چند نام برای یک مفهوم دارد، یک نام canonical انتخاب می‌شود
3. اگر current storage یک فیلد را با دو semantics متفاوت استفاده می‌کند، باید شکسته شود
4. اگر current storage فیلدی ندارد ولی concept لازم است، در Phase 1 به‌عنوان **canonical required field** ثبت می‌شود، حتی اگر هنوز در DB موجود نباشد

---

# 6) Canonical Field Mapping — مدل‌های اصلی

## 6.1 Account

### Canonical definition
`Account` = گره رسمی Chart of Accounts

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `coa_nodes[].id` | قطعی | شناسه منطقی حساب |
| `code` | `coa_nodes[].code` | قطعی | کد حساب |
| `name` | `coa_nodes[].name` | قطعی | نام حساب |
| `level` | `coa_nodes[].type` | قطعی | `group/general/subsidiary/detail` |
| `parentId` | `coa_nodes[].parentId` | قطعی | والد درخت |
| `accountNature` | derive from code prefix | Transitional | فعلاً از prefix 1..6 مشتق می‌شود |
| `postingAllowed` | نامشخص | نیاز به بررسی بیشتر | از کد فعلی rule قطعی استخراج نشد |
| `active` | نامشخص | نیاز به بررسی بیشتر | فیلد فعال/غیرفعال canonical لازم است |

### تصمیم Phase 1
- `level` باید از `accountNature` جدا شود
- `accountNature` نباید در بلندمدت فقط از prefix نتیجه گرفته شود
- `postingAllowed` باید صریح شود، نه ضمنی

---

## 6.2 TreasuryAccount

### Canonical definition
`TreasuryAccount` = حساب نقد/بانک عملیاتی که به یک حساب CoA لینک می‌شود

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `wp_cptt_fin_accounts.id` | قطعی | شناسه خزانه |
| `name` | `name` | قطعی | نام حساب |
| `treasuryType` | `type` | قطعی | `cash/bank` |
| `bankName` | `bank_name` | قطعی | نام بانک |
| `accountNumber` | `account_number` | قطعی | شماره حساب |
| `iban` | `iban` | قطعی | شبا |
| `cardNumber` | `card_number` | قطعی | کارت |
| `initialBalance` | `initial_balance` | قطعی | مانده اولیه |
| `currencyCode` | `currency` | قطعی | ارز نمایشی/عملیاتی |
| `active` | `status` | قطعی | 1/0 → bool |
| `linkedAccountId` | treasury→COA mapping option | Transitional | از option mapping resolve می‌شود |
| `createdBy` | `created_by` | قطعی | ایجادکننده |
| `createdAt` | `created_at` | قطعی | زمان ایجاد |

### تصمیم Phase 1
- `TreasuryAccount` مدل جدا از `Account` است
- رابطه آن با `Account` باید **explicit mapping** داشته باشد
- `treasuryType` با `accountNature` یکی نیست

---

## 6.3 Voucher

### Canonical definition
`Voucher` = سند حسابداری رسمی و root اصلی accounting transaction

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `wp_cptt_erp_vouchers.id` | قطعی | شناسه دامنه |
| `voucherNo` | `voucher_number` | قطعی | شماره عددی |
| `voucherCode` | `voucher_code` | قطعی | کد نمایشی |
| `voucherType` | `voucher_type` | قطعی | `JV/RV/PV/TV/CV/OV` |
| `voucherDateFa` | `date_fa` | قطعی | تاریخ شمسی سند |
| `description` | `description` | قطعی | شرح |
| `status` | `status` | قطعی | وضعیت lifecycle |
| `companyId` | `company_id` | قطعی | شرکت |
| `branchId` | `branch_id` | قطعی | شعبه |
| `fiscalYearId` | `fiscal_year_id` | قطعی | سال مالی |
| `currencyCode` | `currency` | قطعی | ارز |
| `exchangeRate` | `exchange_rate` | قطعی | نرخ تبدیل |
| `createdBy` | `created_by` | قطعی | ایجادکننده |
| `approvedByAccountant` | `approved_by_accountant` | قطعی | تأیید حسابدار |
| `approvedByManager` | `approved_by_manager` | قطعی | تأیید مدیر مالی |
| `approvedByCEO` | `approved_by_ceo` | قطعی | تأیید مدیرعامل |
| `isAutoGenerated` | `is_auto_generated` | قطعی | خودکار/دستی |
| `sourceType` | `source_type` / `ref_type` | Transitional | نام واحد دامنه باید `sourceType` باشد |
| `sourceId` | `ref_id` | Transitional | نام واحد دامنه باید `sourceId` باشد |
| `postedAt` | نامشخص | نیاز به بررسی بیشتر | در مدل دامنه لازم است |
| `reversedVoucherId` | از reverse link logical | نیاز به بررسی بیشتر | باید صریح شود |
| `createdAt` | `created_at` | قطعی | زمان ایجاد |

### تصمیم Phase 1
- canonical terminology برای tracing باید `sourceType/sourceId` باشد
- `ref_type/ref_id` فقط نام storage legacy تلقی می‌شود
- `postedAt` در مدل دامنه لازم است، حتی اگر در storage فعلی صریح نباشد

---

## 6.4 VoucherRow

### Canonical definition
`VoucherRow` = ردیف سند حسابداری

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `wp_cptt_erp_voucher_rows.id` | قطعی | شناسه ردیف |
| `voucherId` | `voucher_id` | قطعی | وابستگی به Voucher |
| `rowNo` | `row_no` | قطعی | شماره ردیف |
| `accountId` | `account_id` | قطعی | حساب |
| `accountNameSnapshot` | `account_name` | قطعی | snapshot عنوان |
| `debit` | `debit` | قطعی | بدهکار |
| `credit` | `credit` | قطعی | بستانکار |
| `description` | `description` | قطعی | شرح ردیف |
| `projectId` | `project_id` | قطعی | dimension پروژه |
| `customerId` | `customer_id` | Transitional | در target باید به `partyId` نگاشت شود |
| `expertId` | `expert_id` | Transitional | در target باید به `partyId` نگاشت شود |
| `costCenterId` | `cost_center_id` | قطعی | dimension مرکز هزینه |
| `partyId` | derived | Canonical only | فیلد دامنه هدف |
| `partyRole` | derived | Canonical only | `customer/expert/supplier/...` |
| `currencyCode` | نامشخص | نیاز به بررسی بیشتر | فعلاً بیشتر در header voucher است |
| `exchangeRate` | نامشخص | نیاز به بررسی بیشتر | در row فعلی صریح نیست |

### تصمیم Phase 1
- در مدل دامنه نهایی، `customerId` و `expertId` باید زیر مفهوم واحد `partyId` canonical شوند
- `partyRole` باید صریح باشد
- اگر در یک ردیف هم‌زمان بیش از یک نقش party لازم باشد، نیاز به بررسی بیشتر دارد

---

## 6.5 JournalEntry

### Canonical definition
`JournalEntry` = نمایش/ثبت journal-level هر ردیف سند posted

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | derived | Canonical only | می‌تواند از `rowId` مشتق شود |
| `voucherId` | VoucherRow + Voucher | قطعی | مرجع سند |
| `voucherRowId` | `VoucherRow.id` | قطعی | مرجع ردیف |
| `postingDateFa` | `Voucher.date_fa` | قطعی | تاریخ ثبت |
| `accountId` | `VoucherRow.account_id` | قطعی | حساب |
| `debit` | `VoucherRow.debit` | قطعی | بدهکار |
| `credit` | `VoucherRow.credit` | قطعی | بستانکار |
| `description` | row/header combined | Transitional | شرح line-level/journal |
| `status` | `Voucher.status` | Transitional | فقط posted/finalized باید source نهایی باشد |
| `dimensions` | row + header | قطعی | project/party/cost center/fy/branch/company |

### تصمیم Phase 1
- `JournalEntry` در مدل هدف یک **derived accounting model** است
- نسبت canonical آن با `VoucherRow` برابر **1:1** در وضعیت فعلی در نظر گرفته می‌شود
- materialization فیزیکی آن در Phase 1 تصمیم‌گیری نشده است

---

## 6.6 GeneralLedgerEntry

### Canonical definition
`GeneralLedgerEntry` = سطر ثبت‌شده در موتور مانده‌گیری حسابداری

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | canonical required | Canonical only | شناسه GL entry |
| `journalEntryId` | derived from journal | Canonical only | مرجع journal |
| `accountId` | journal/account | قطعی | حساب |
| `debit` | journal | قطعی | بدهکار |
| `credit` | journal | قطعی | بستانکار |
| `runningBalance` | derived | Canonical only | مانده جاری |
| `fiscalYearId` | voucher header | قطعی | سال مالی |
| `periodKey` | derived from date | Canonical only | کلید دوره |
| `projectId` | row dimension | قطعی | پروژه |
| `partyId` | canonicalized from row | Transitional | شخص |
| `costCenterId` | row dimension | قطعی | مرکز هزینه |

### تصمیم Phase 1
- `GeneralLedgerEntry` باید **engine-level balance model** تلقی شود
- در وضعیت فعلی materialized canonical store برای آن نامشخص است
- اما در دامنه نهایی، همه balance-based reportها باید از این مدل یا مشتقات رسمی آن تغذیه شوند

---

## 6.7 FiscalYear

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | option row `id` | قطعی | شناسه سال مالی |
| `companyId` | `companyId` | قطعی | شرکت |
| `name` | `name` | قطعی | نام سال مالی |
| `startDateFa` | `startDate` | قطعی | شروع |
| `endDateFa` | `endDate` | قطعی | پایان |
| `status` | `status` | قطعی | `OPEN/CLOSED` |
| `closedAt` | `closedAt` | قطعی | زمان بستن |
| `closedBy` | `closedBy` | قطعی | بستن توسط |
| `reopenedAt` | `reopenedAt` | قطعی | بازگشایی |
| `reopenedBy` | `reopenedBy` | قطعی | بازگشایی توسط |

---

## 6.8 FiscalPeriodLock

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | option row / logical key | نیاز به بررسی بیشتر | shape دقیق option نیازمند review بیشتر |
| `fiscalYearId` | lock data | قطعی مفهومی | وابسته به FY |
| `startDateFa` | lock data | قطعی مفهومی | شروع دوره |
| `endDateFa` | lock data | قطعی مفهومی | پایان دوره |
| `isLocked` | lock data | قطعی مفهومی | قفل/باز |
| `lockedBy` | lock data | قطعی مفهومی | قفل‌کننده |
| `lockedAt` | lock data | نیاز به بررسی بیشتر | بستگی به shape فعلی |

---

## 6.9 CostCenter

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | option row `id` | قطعی | شناسه |
| `name` | `name` | قطعی | نام |
| `code` | `code` | قطعی | کد |
| `costCenterType` | `type` | قطعی | `PROJECT/UNIT/TEAM/BRANCH` |
| `budget` | `budget` | قطعی | بودجه |
| `active` | نامشخص | نیاز به بررسی بیشتر | فیلد canonical لازم است |

---

## 6.10 Party

### Canonical definition
`Party` = هر شخص/طرف حساب مالی شامل مشتری، کارشناس، تامین‌کننده، پیمانکار یا سایر طرف‌ها

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | mixed / derived | Transitional | برای user-backed و non-user-backed متفاوت است |
| `partyType` | derived from source | Transitional | `customer/expert/supplier/contractor/other` |
| `refUserId` | `wp_users.ID` | قطعی برای customer/expert | اگر party از user آمده باشد |
| `displayName` | `display_name` / `party_name` | Transitional | نام نمایشی |
| `phone` | user meta / free-text | نیاز به بررسی بیشتر | منبع پراکنده |
| `taxId` | نامشخص | نیاز به بررسی بیشتر | مدل صریح دیده نشد |
| `active` | نامشخص | نیاز به بررسی بیشتر | مدل صریح دیده نشد |

### تصمیم Phase 1
- `Party` در target باید first-class model باشد
- customer و expert می‌توانند `refUserId` داشته باشند
- supplier/contractor فعلاً first-class نیستند و باید در migration plan تعیین تکلیف شوند
- این بخش یکی از مهم‌ترین ambiguityهای دامنه است

---

## 6.11 Currency و CurrencyRate

### Currency

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `code` | `IRT/IRR/USD/EUR/...` | قطعی مفهومی | کد ارز |
| `displayName` | display settings | نیاز به بررسی بیشتر | منبع یکپارچه نیست |
| `decimals` | `cptt_currency_settings.decimals` | قطعی | اعشار |
| `active` | نامشخص | نیاز به بررسی بیشتر | ثبت صریح دیده نشد |

### CurrencyRate

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | option row / logical key | نیاز به بررسی بیشتر | shape دقیق option row نیازمند review بیشتر |
| `baseCurrency` | rate option | قطعی مفهومی | ارز پایه |
| `quoteCurrency` | rate option | قطعی مفهومی | ارز مظنه |
| `rate` | rate option | قطعی مفهومی | نرخ |
| `effectiveDate` | rate option | قطعی مفهومی | تاریخ اثر |

### تصمیم Phase 1
- Currency display settings و Currency accounting rates باید از هم جدا تعریف شوند
- full multi-currency accounting در وضعیت فعلی **نامشخص / ناقص** است

---

## 6.12 Payable

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `wp_cptt_erp_payables.id` | قطعی | شناسه |
| `partyId` | `party_id` | Transitional | باید به Party canonical وصل شود |
| `partyType` | `party_type` | قطعی | نوع طرف حساب |
| `partyNameSnapshot` | `party_name` | قطعی | snapshot نام |
| `amount` | `amount` | قطعی | مبلغ کل |
| `paidAmount` | `paid_amount` | قطعی | مبلغ پرداخت‌شده |
| `remainingAmount` | derived | قطعی | `amount - paidAmount` |
| `issueDateFa` | `issue_date` | قطعی | تاریخ صدور |
| `dueDateFa` | `due_date` | قطعی | سررسید |
| `projectId` | `project_id` | قطعی | پروژه |
| `description` | `description` | قطعی | شرح |
| `status` | `status` | قطعی | وضعیت |
| `createdAt` | `created_at` | قطعی | ایجاد |

---

## 6.13 InstallmentPlan / InstallmentRow

### InstallmentPlan

| Canonical Field | منبع فعلی | وضعیت |
|---|---|---|
| `id` | `wp_cptt_erp_installments.id` | قطعی |
| `customerId` | `customer_id` | Transitional |
| `customerNameSnapshot` | `customer_name` | قطعی |
| `projectId` | `project_id` | قطعی |
| `projectNameSnapshot` | `project_name` | قطعی |
| `totalAmount` | `total_amount` | قطعی |
| `installmentCount` | `installments_count` | قطعی |
| `intervalDays` | `interval_days` | قطعی |
| `firstDueDateFa` | `first_due_date` | قطعی |
| `description` | `description` | قطعی |
| `createdAt` | `created_at` | قطعی |

### InstallmentRow

| Canonical Field | منبع فعلی | وضعیت |
|---|---|---|
| `id` | نامشخص | نیاز به بررسی بیشتر |
| `planId` | `plan_id` | قطعی |
| `installmentNo` | `no` | قطعی |
| `dueDateFa` | `due_date` | قطعی |
| `amount` | `amount` | قطعی |
| `paidAmount` | `paid_amount` | قطعی |
| `paidDateFa` | `paid_date` | قطعی |
| `status` | `status` | قطعی |

### تصمیم Phase 1
- اگر `InstallmentRow.id` در current storage صریح نباشد، در canonical model لازم است

---

## 6.14 Cheque

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `id` | `wp_cptt_erp_cheques.id` | قطعی | شناسه |
| `chequeKind` | `kind` | قطعی | `receivable/payable` |
| `number` | `number` | قطعی | شماره چک |
| `sayyadi` | `sayyadi` | قطعی | شناسه صیادی |
| `bank` | `bank` | قطعی | بانک |
| `branch` | `branch` | قطعی | شعبه |
| `amount` | `amount` | قطعی | مبلغ |
| `issueDateFa` | `issue_date` | قطعی | تاریخ صدور |
| `dueDateFa` | `due_date` | قطعی | سررسید |
| `partyId` | `party_id` | Transitional | باید به Party canonical وصل شود |
| `partyType` | `party_type` | قطعی | نوع طرف حساب |
| `partyNameSnapshot` | `party_name` | قطعی | snapshot |
| `projectId` | `project_id` | قطعی | پروژه |
| `treasuryAccountId` | `treasury_account_id` | قطعی | حساب خزانه |
| `status` | `status` | قطعی | وضعیت چک |
| `description` | `description` | قطعی | شرح |
| `attachmentId` | `attachment_id` | قطعی | پیوست |
| `createdAt` | `created_at` | قطعی | ایجاد |

---

## 6.15 Invoice / InvoiceRow

### Invoice

| Canonical Field | منبع فعلی | وضعیت |
|---|---|---|
| `id` | `wp_cptt_erp_invoices.id` | قطعی |
| `number` | `number` | قطعی |
| `invoiceType` | `type` | قطعی |
| `customerId` | `customer_id` | Transitional |
| `customerNameSnapshot` | `customer_name` | قطعی |
| `projectId` | `project_id` | قطعی |
| `projectNameSnapshot` | `project_name` | قطعی |
| `issueDateFa` | `issue_date` | قطعی |
| `dueDateFa` | `due_date` | قطعی |
| `subtotal` | `subtotal` | قطعی |
| `discount` | `discount` | قطعی |
| `taxRate` | `tax_rate` | قطعی |
| `taxAmount` | `tax_amount` | قطعی |
| `total` | `total` | قطعی |
| `currencyCode` | `currency` | قطعی |
| `status` | `status` | قطعی |
| `notes` | `notes` | قطعی |
| `voucherId` | `voucher_id` | قطعی | linkage to accounting |
| `createdBy` | `created_by` | قطعی |
| `createdAt` | `created_at` | قطعی |

### InvoiceRow

| Canonical Field | منبع فعلی | وضعیت |
|---|---|---|
| `id` | نامشخص | نیاز به بررسی بیشتر |
| `invoiceId` | `invoice_id` | قطعی |
| `rowNo` | `row_no` | قطعی |
| `title` | `title` | قطعی |
| `description` | `description` | قطعی |
| `quantity` | `quantity` | قطعی |
| `unitPrice` | `unit_price` | قطعی |
| `amount` | `amount` | قطعی |

---

## 6.16 ProjectFinancialSnapshot

### Canonical definition
`ProjectFinancialSnapshot` = read model مشتق‌شده برای نمایش وضعیت مالی پروژه

| Canonical Field | منبع فعلی | وضعیت | توضیح |
|---|---|---|---|
| `projectId` | derived / current project meta flows | قطعی مفهومی | شناسه پروژه |
| `billedAmount` | فعلاً `_cptt_steps.cost`-based | Transitional | در target باید از accounting/report layer مشتق شود |
| `collectedAmount` | فعلاً `_cptt_steps.paid`-based | Transitional | در target باید از accounting/report layer مشتق شود |
| `customerOutstanding` | فعلاً cost-paid | Transitional | در target باید derived from GL باشد |
| `expertOutstanding` | فعلاً exp_to_expert-expert_paid | Transitional | در target باید derived from GL/payables باشد |
| `expertPaid` | فعلاً `_cptt_steps.expert_paid` | Transitional | read model |
| `grossProfitOperational` | فعلاً paid-expertPaid | Transitional | operational KPI |
| `netProfitAccounting` | نامشخص / incomplete | نیاز به بررسی بیشتر | باید از accounting statement layer مشتق شود |

### تصمیم Phase 1
- `ProjectFinancialSnapshot` در target **SoT نیست**
- این مدل باید فقط read model باشد
- `_cptt_steps` فقط منبع عملیاتی باقی می‌ماند، نه financial statement source

---

## 6.17 AuditLog

| Canonical Field | منبع فعلی | وضعیت |
|---|---|---|
| `id` | `wp_cptt_erp_audit.id` | قطعی |
| `userId` | `user_id` | قطعی |
| `userName` | `user_name` | قطعی |
| `actionType` | `action_type` | قطعی |
| `entityType` | `entity_type` | قطعی |
| `entityId` | `entity_id` | قطعی |
| `beforeData` | `before_data` | قطعی |
| `afterData` | `after_data` | قطعی |
| `createdAt` | `created_at` | قطعی |
| `dateFa` | `date_fa` | قطعی |

---

# 7) State Machineهای رسمی

## 7.1 Voucher State Machine

### وضعیت‌های canonical فعلی
- `DRAFT`
- `ACCOUNTANT_APPROVED`
- `MANAGER_APPROVED`
- `FINALIZED`

### جریان canonical فعلی

```text
DRAFT
↓
ACCOUNTANT_APPROVED
↓
MANAGER_APPROVED
↓
FINALIZED
```

### قواعد Phase 1
- `Voucher` فقط وقتی منبع قطعی reportهای حسابداری است که **posted/finalized** تلقی شود
- در مدل فعلی، وضعیت `FINALIZED` نزدیک‌ترین معادل posted است
- وجود statusهای دیگر مانند `POSTED`, `REVERSED`, `VOID`, `ARCHIVED` در کد فعلی **نامشخص / نیازمند بررسی بیشتر** است
- reversal در وضعیت فعلی بیشتر به‌صورت **سند معکوس جداگانه** مدل می‌شود، نه الزاماً status مستقل روی سند اصلی

---

## 7.2 FiscalYear State Machine

### وضعیت‌ها
- `OPEN`
- `CLOSED`

### جریان

```text
OPEN
↓ close
CLOSED
↓ reopen
OPEN
```

---

## 7.3 Payable State Machine

### وضعیت‌ها
- `open`
- `partially_paid`
- `paid`
- `overdue`

### جریان canonical

```text
open
├─> partially_paid
├─> overdue
└─> paid

partially_paid
├─> overdue
└─> paid

overdue
└─> paid
```

---

## 7.4 InstallmentRow State Machine

### وضعیت‌ها
- `unpaid`
- `paid`
- `overdue`

### جریان canonical

```text
unpaid
├─> paid
└─> overdue

overdue
└─> paid
```

---

## 7.5 Cheque State Machine

### چک دریافتی
- `received`
- `in_collection`
- `collected`
- `bounced`
- `transferred`
- `cancelled`

### چک پرداختی
- `issued`
- `awaiting_due`
- `paid`
- `cancelled_pay`

### نتیجه Phase 1
- دو state machine مجزا برای `receivable cheque` و `payable cheque` لازم است
- یک state machine واحد برای همه چک‌ها کافی نیست

---

## 7.6 Invoice State Machine

### وضعیت‌ها
- `draft`
- `sent`
- `partial`
- `paid`
- `cancelled`

### جریان canonical

```text
draft
├─> sent
└─> cancelled

sent
├─> partial
├─> paid
└─> cancelled

partial
└─> paid
```

---

# 8) Relation Map رسمی

## 8.1 روابط اصلی accounting core

| From | Relation | To | توضیح |
|---|---|---|---|
| `Voucher` | 1 → N | `VoucherRow` | هر سند چند ردیف دارد |
| `VoucherRow` | N → 1 | `Account` | هر ردیف روی یک حساب ثبت می‌شود |
| `VoucherRow` | 0..1 → 1 | `Project` | dimension پروژه |
| `VoucherRow` | 0..1 → 1 | `CostCenter` | dimension مرکز هزینه |
| `VoucherRow` | 0..1 → 1 | `Party` | dimension شخص |
| `Voucher` | N → 1 | `FiscalYear` | هر سند متعلق به یک سال مالی است |
| `JournalEntry` | 1 ↔ 1 | `VoucherRow` | در canonical model فعلی |
| `GeneralLedgerEntry` | 1 ↔ 1 | `JournalEntry` | در canonical model فعلی |
| `TrialBalanceRow` | N → 1 | `Account` | تجمیع در سطح حساب |

## 8.2 روابط treasury/commercial/party

| From | Relation | To | توضیح |
|---|---|---|---|
| `TreasuryAccount` | N → 1 | `Account` | از طریق linkedAccountId |
| `Payable` | N → 1 | `Party` | طرف حساب بدهی |
| `Cheque` | N → 1 | `Party` | طرف حساب چک |
| `Cheque` | N → 1 | `TreasuryAccount` | خزانه مرتبط |
| `InstallmentPlan` | N → 1 | `Party` | مشتری/طرف قسط |
| `InstallmentPlan` | 1 → N | `InstallmentRow` | ردیف‌های قسط |
| `Invoice` | N → 1 | `Party` | مشتری |
| `Invoice` | 1 → N | `InvoiceRow` | ردیف‌های فاکتور |
| `Invoice` | 0..1 → 1 | `Voucher` | سند حسابداری متناظر |

## 8.3 روابط reporting

| From | Relation | To | توضیح |
|---|---|---|---|
| `GeneralLedgerEntry` | N → 1 | `TrialBalanceRow` | بر اساس account aggregation |
| `TrialBalanceRow` | N → 1 | `IncomeStatementRow` | فقط برای accountNatureهای درآمد/هزینه |
| `TrialBalanceRow` | N → 1 | `BalanceSheetRow` | فقط برای accountNatureهای دارایی/بدهی/سرمایه |
| `Voucher/GL/Party/Project` | → | `ProjectFinancialSnapshot` | read model مشتق‌شده |

---

# 9) Dimension Model رسمی

## 9.1 هدف

Dimensionها باید به‌عنوان **attribute** تعریف شوند، نه منبع حقیقت موازی.

## 9.2 Dimensionهای canonical

| Dimension | سطح | وضعیت target | توضیح |
|---|---|---|---|
| `companyId` | Voucher Header | canonical | شرکت |
| `branchId` | Voucher Header | canonical | شعبه |
| `fiscalYearId` | Voucher Header | canonical و ضروری | سال مالی |
| `projectId` | Voucher Row | canonical optional | پروژه |
| `partyId` | Voucher Row | canonical optional | شخص/طرف حساب |
| `partyRole` | Voucher Row | canonical optional | نقش طرف حساب |
| `costCenterId` | Voucher Row | canonical optional | مرکز هزینه |
| `currencyCode` | Voucher Header | canonical | ارز |
| `exchangeRate` | Voucher Header | canonical | نرخ تبدیل |
| `sourceType` | Voucher Header | canonical و ضروری | منبع رویداد |
| `sourceId` | Voucher Header | canonical و ضروری | شناسه رویداد |

## 9.3 قواعد Dimensionها

1. `fiscalYearId` روی Voucher **ضروری** است
2. `sourceType/sourceId` برای traceability **ضروری** است
3. `projectId/partyId/costCenterId` dimension هستند، نه SoT مستقل
4. dimension نباید جایگزین Ledger یا Voucher شود
5. گزارش‌های نهایی باید dimensions را **فیلتر/segment** کنند، نه اینکه source خود را از dimension بگیرند

## 9.4 تصمیم‌های مهم

- `customerId` و `expertId` باید canonicalized به `partyId + partyRole` شوند
- `companyId` و `branchId` در header می‌مانند
- `projectId` در row-level می‌ماند چون همه ردیف‌های یک سند الزاماً project-bound نیستند

---

# 10) Policy رسمی برای Account Type / Account Nature

## 10.1 مشکل فعلی

در سیستم فعلی، واژه‌ی «نوع حساب» حداقل در سه معنا استفاده می‌شود:
1. نوع خزانه: `cash/bank`
2. نوع گره COA: `group/general/subsidiary/detail`
3. ماهیت حسابداری بر اساس prefix: `1..6`

این سه مفهوم باید از هم جدا شوند.

## 10.2 مدل canonical نهایی

### A) `treasuryType`
فقط برای `TreasuryAccount`
- `cash`
- `bank`

### B) `accountLevel`
فقط برای `Account`
- `group`
- `general`
- `subsidiary`
- `detail`

### C) `accountNature`
فقط برای `Account`
- `asset`
- `liability`
- `equity`
- `revenue`
- `expense`

## 10.3 Transitional derivation rule

تا وقتی `accountNature` به‌صورت صریح در master data ذخیره نشده، mapping انتقالی به این صورت است:

| Prefix code | Nature |
|---|---|
| `1` | `asset` |
| `2` | `asset` |
| `3` | `liability` |
| `4` | `equity` |
| `5` | `revenue` |
| `6` | `expense` |

## 10.4 قاعده‌ی نهایی

در معماری هدف:
- reportها باید از `accountNature` استفاده کنند
- استفاده از prefix فقط **strategy انتقالی** است
- `accountLevel` نباید با `accountNature` اشتباه گرفته شود
- `treasuryType` نباید در گزارش‌های مالی جای `accountNature` را بگیرد

## 10.5 Posting policy

در مورد اینکه کدام level از حساب اجازه posting مستقیم داشته باشد:
- **نامشخص / نیاز به بررسی بیشتر**
- از تحلیل کد فعلی rule قطعی و غیرمبهم استخراج نشد

---

# 11) Mapping مدل‌های فعلی به مدل‌های هدف

## 11.1 جدول Migration Mapping سطح کلان

| منبع فعلی | مدل هدف | Strategy | وضعیت Phase 1 |
|---|---|---|---|
| `wp_cptt_erp_vouchers` | `Voucher` | Retain + normalize naming | قطعی |
| `wp_cptt_erp_voucher_rows` | `VoucherRow` | Retain + canonicalize dimensions | قطعی |
| `VoucherRow` derived view | `JournalEntry` | Formalize as canonical derived model | قطعی |
| `Journal/Voucher posted rows` | `GeneralLedgerEntry` | Formalize as accounting balance model | قطعی مفهومی |
| `GL aggregation` | `TrialBalanceRow` | Derived from GL | قطعی مفهومی |
| `cpttf_erp_fiscal_years` | `FiscalYear` | Canonicalize | قطعی |
| `cpttf_erp_locks` | `FiscalPeriodLock` | Canonicalize | قطعی |
| `cpttf_erp_cost_centers` | `CostCenter` | Canonicalize | قطعی |
| `cpttf_erp_coa_nodes` | `Account` | Canonicalize | قطعی |
| `wp_cptt_fin_accounts` | `TreasuryAccount` | Retain as treasury master | قطعی |
| `wp_users + payable/cheque names` | `Party` | Merge into party registry | ambiguity دارد |
| `wp_cptt_erp_payables` | `Payable` | Retain + party canonicalization | قطعی |
| `wp_cptt_erp_installments` | `InstallmentPlan` | Retain | قطعی |
| `wp_cptt_erp_installment_rows` | `InstallmentRow` | Retain | قطعی |
| `wp_cptt_erp_cheques` | `Cheque` | Retain + party canonicalization | قطعی |
| `wp_cptt_erp_invoices` | `Invoice` | Retain | قطعی |
| `wp_cptt_erp_invoice_rows` | `InvoiceRow` | Retain | قطعی |
| `wp_cptt_erp_audit` | `AuditLog` | Retain | قطعی |
| `_cptt_steps` | `ProjectStepOperationalState` | Keep operational | قطعی |
| `_cptt_steps`-based calculations | `ProjectFinancialSnapshot` | Replace by accounting-derived read model in target | قطعی مفهومی |
| `wp_cptt_fin_ledger` | `LegacyFinanceLedgerEvent` / transitional treasury event store | Transitional / merge later | قطعی |
| `wp_cptt_ledger` | `LegacyProjectLedgerEvent` / transitional settlement history | Transitional / merge later | قطعی |
| `wp_cptt_fin_categories` | نامشخص | نیاز به بررسی بیشتر | ambiguity |
| option arrays for companies/branches/permissions/etc. | canonical master tables/models | migrate later | قطعی مفهومی |

## 11.2 نتیجه‌های کلیدی Mapping

### نتیجه 1
`Voucher` و `VoucherRow` پایه‌ی canonical architecture باقی می‌مانند.

### نتیجه 2
`JournalEntry` و `GeneralLedgerEntry` باید به‌صورت مدل‌های رسمی دامنه/موتور تعریف شوند، حتی اگر امروز table مستقلی نداشته باشند.

### نتیجه 3
`_cptt_steps` حذف مفهومی نمی‌شود، ولی **از جایگاه SoT حسابداری پایین می‌آید** و فقط operational source باقی می‌ماند.

### نتیجه 4
هر دو ledger فعلی (`wp_cptt_fin_ledger`, `wp_cptt_ledger`) canonical final accounting ledger محسوب نمی‌شوند.

---

# 12) Canonical Rule Matrix برای SoT

| مفهوم | SoT فعلی | SoT canonical هدف | تصمیم Phase 1 |
|---|---|---|---|
| سند حسابداری | `wp_cptt_erp_vouchers` | `Voucher` | تثبیت شد |
| ردیف سند | `wp_cptt_erp_voucher_rows` | `VoucherRow` | تثبیت شد |
| روزنامه | derived from rows | `JournalEntry` | formalized |
| دفتر کل | نامشخص / mixed | `GeneralLedgerEntry` | formalized |
| تراز آزمایشی | client-side vouchers aggregation | `TrialBalanceRow` from GL | formalized |
| سود و زیان | prefix-based client-side | `IncomeStatementRow` from TB | formalized |
| ترازنامه | prefix-based client-side | `BalanceSheetRow` from TB | formalized |
| مطالبات مشتری | `_cptt_steps` | GL receivable accounts | target confirmed |
| بدهی کارشناس | `_cptt_steps` + ledger | GL/payable accounts | target confirmed |
| مانده خزانه | `fin_accounts + fin_ledger` | TreasuryAccount + accounting posting | target confirmed |
| وضعیت مالی پروژه | `_cptt_steps`-based duplicated logic | `ProjectFinancialSnapshot` from accounting/report layer | target confirmed |

---

# 13) Ambiguity Register

## 13.1 Party registry strategy
- آیا `Party` باید table مستقل داشته باشد یا از ترکیب user + non-user master ساخته شود؟
- وضعیت فعلی برای supplier/contractor first-class نیست
- **نتیجه:** نیاز به بررسی بیشتر

## 13.2 PostingAllowed policy on COA
- آیا posting فقط روی detail مجاز است؟
- آیا subsidiary هم مجاز است؟
- از کد فعلی rule قطعی استخراج نشد
- **نتیجه:** نیاز به بررسی بیشتر

## 13.3 Journal materialization
- آیا `JournalEntry` باید table فیزیکی داشته باشد یا derived model کافی است؟
- **نتیجه:** نیاز به بررسی بیشتر

## 13.4 GL materialization
- آیا `GeneralLedgerEntry` باید persisted table باشد یا engine/read layer کافی است؟
- **نتیجه:** نیاز به بررسی بیشتر

## 13.5 Currency architecture
- آیا سیستم واقعاً multi-currency accounting خواهد داشت یا فقط display/rate support؟
- **نتیجه:** نیاز به بررسی بیشتر

## 13.6 InvoiceRow / InstallmentRow identifiers
- آیا شناسه canonical مستقل برای همه rowها در current storage وجود دارد؟
- **نتیجه:** نیاز به بررسی بیشتر

## 13.7 Category model fate
- `wp_cptt_fin_categories` در مدل نهایی دقیقاً باید به چه aggregateای نگاشت شود؟
- category مالی عملیاتی؟ report tag؟ expense class؟
- **نتیجه:** نیاز به بررسی بیشتر

## 13.8 Reversal semantics
- آیا reversal باید status مستقل روی سند اصلی داشته باشد یا صرفاً relation بین voucherها کافی است؟
- **نتیجه:** نیاز به بررسی بیشتر

---

# 14) ارزیابی انجام Taskهای Phase 1 نسبت به Roadmap

## 14.1 Taskهای Phase 1 در Roadmap

طبق `ERP_REFACTOR_ROADMAP.md`، Phase 1 شامل این Taskها بود:
- تعریف مدل‌های نهایی دامنه
- تعیین canonical field names
- تعیین state machine رسمی
- تعریف relation map رسمی
- تعریف dimension model رسمی
- تعریف policy برای account type / account nature
- تعیین migration mapping

## 14.2 وضعیت این artefact

| Task | وضعیت |
|---|---|
| تعریف مدل‌های نهایی دامنه | ✅ انجام شد |
| تعیین canonical field names | ✅ انجام شد |
| تعیین state machine رسمی | ✅ انجام شد |
| تعریف relation map رسمی | ✅ انجام شد |
| تعریف dimension model رسمی | ✅ انجام شد |
| policy برای account type / account nature | ✅ انجام شد |
| migration mapping از مدل‌های فعلی به هدف | ✅ انجام شد |
| ambiguity register | ✅ انجام شد |

## 14.3 Definition of Done Phase 1

Phase 1 زمانی Done تلقی می‌شود که:
1. canonical domain model نهایی ثبت شده باشد ✅
2. relation map نهایی ثبت شده باشد ✅
3. ambiguityهای اصلی یا رفع شده باشند یا صریحاً برچسب خورده باشند ✅
4. mapping مدل فعلی → مدل هدف ثبت شده باشد ✅
5. review معماری/کسب‌وکار روی این سند انجام شده باشد ⏳

### نتیجه
از منظر **مستندسازی معماری**، Phase 1 در این artefact **شروع و تا حد زیادی تدوین شده است**؛  
اما از منظر **تصویب نهایی معماری** هنوز نیازمند review تصمیم‌های ambiguity است.

---

# 15) خروجی مورد انتظار برای Phase 2

Phase 2 باید مستقیماً بر اساس همین سند ادامه پیدا کند و این موارد را طراحی کند:

1. Service Catalog نهایی
2. Repository Catalog نهایی
3. Service contractها
4. transaction boundaryها
5. idempotency policy
6. traceability policy

## 15.1 پیش‌نیازهای مستقیم Phase 2 از این سند
- `Voucher` owner مشخص شد
- `VoucherRow` owner مشخص شد
- `JournalEntry` و `GeneralLedgerEntry` formalized شدند
- `Party` ambiguityها مشخص شد
- `Dimension Model` رسمی شد
- `AccountNature` policy مشخص شد

---

# 16) جمع‌بندی نهایی Phase 1

مهم‌ترین خروجی Phase 1 این است که از این نقطه به بعد، پروژه باید این زبان دامنه‌ای را به‌عنوان مرجع رسمی بپذیرد:

```text
Account
TreasuryAccount
Voucher
VoucherRow
JournalEntry
GeneralLedgerEntry
TrialBalanceRow
FiscalYear
FiscalPeriodLock
Party
CostCenter
Payable
InstallmentPlan
InstallmentRow
Cheque
Invoice
ProjectFinancialSnapshot
AuditLog
```

و مهم‌تر از آن، این تفکیک باید مرجع رسمی تصمیم‌های فازهای بعد باشد:

```text
Operational State != Accounting State != Reporting Read Model
```

### نتیجه‌ی نهایی Phase 1
- `Voucher/VoucherRow` به‌عنوان هسته‌ی دامنه حسابداری تثبیت شد
- `JournalEntry/GeneralLedgerEntry` به‌عنوان مدل‌های رسمی target architecture تعریف شدند
- `_cptt_steps` از نقش accounting SoT کنار گذاشته شد و فقط operational model تلقی شد
- dual ledger به‌عنوان canonical final state رد شد
- language رسمی دامنه برای ادامه‌ی Phase 2 به بعد مشخص شد

---

**پایان گزارش Phase 1**
