# WAVE_2_HOTFIX_8.5.4 — UI یکپارچه + عملیات درجای ERP + رفع باگ hash

> نسخه: **8.5.4** — تاریخ: 1405/04/17

## 🎯 سه گزارش کاربر

1. **UI پنل قدیمی WP** نشان داده می‌شد به‌جای ظاهر پنل ERP
2. **دکمه‌های عملیات** به پیشخوان WP هدایت می‌کردند به‌جای انجام درجا
3. **باگ hash routing** — «کلیک روی یک تب → آدرس عوض می‌شه ولی روی تب قبلی می‌مونم»

## ✅ اصلاحات

### الف) UI ۱۰۰٪ یکپارچه با پنل ERP

بازنویسی کامل `page-embed-treasury.php` با استفاده از **همان class های
CSS اصلی پنل ERP** (`cptt-card`, `cptt-btn-primary`, `cptt-btn-danger`,
`cptt-btn-ghost`, `cptt-btn-sm`, `cptt-input`, `cptt-input-num`,
`cptt-select`, `cptt-table`, `cptt-table-wrap`, `cptt-pill-*`,
`cptt-filterbar`, `cptt-label`, `cptt-jalali-date`).

این class ها همه در `app.css` که خود ERP لود می‌کند تعریف شده‌اند —
یعنی ظاهر ۱۰۰٪ یکسان با بقیه تب‌ها بدون نیاز به CSS اضافی.

**الگوی رندر (شبیه دقیقاً بندل React):**
```
SectionHeader (icon + title + subtitle + actions)
  → KPI Grid (۳ کارت با آیکن رنگی)
    → FilterBar (اگر لازم بود)
      → Card > Table (با pagination خودکار)
```

هر ۳ تب (treasury, transfers, income_expense) با این الگو ساخته شدند.

### ب) عملیات درجا (بدون رفتن به پیشخوان WP)

`cptt-erp-extras.js` حالا یک **Modal manager** کامل دارد:
- `openModal()` — modal با animation slide-up
- `closeModal()` — با Esc، کلیک روی backdrop، دکمه‌ی ×
- `confirmDialog()` — confirmation کوچک با variant danger
- `toast()` — پیام موفقیت/خطا در پایین صفحه

هر صفحه‌ی embed یک `<template>` با فرم دارد. کلیک روی دکمه‌ی عمل:
1. Template را clone می‌کند
2. Modal با آن باز می‌کند
3. Submit → `ajaxPost()` با nonce از `window.CPTTF_ERP.nonce`
4. Reload خودکار slot بعد از موفقیت
5. Toast پیام

**عملیات پیاده‌شده:**
| تب | عمل | AJAX action | ورودی |
|---|---|---|---|
| treasury | افزودن/ویرایش | `cpttf_erp_treasury_save` | `account={JSON}` |
| treasury | غیرفعال‌سازی | `cpttf_erp_treasury_delete` | `id=t{ID}` |
| transfers | ثبت انتقال | `cpttf_erp_treasury_transfer` | `from_id`, `to_id`, `amount`, `description` |
| income_expense | ثبت درآمد/هزینه | `cpttf_erp_ie_save` | `item={JSON}` |
| income_expense | حذف | `cpttf_erp_ie_delete` | `id=ie{ID}` |

همه‌ی این handlerها **از قبل** در `class-cptt-finance-erp.php` وجود داشتند
— فقط UI به آن‌ها متصل نبود.

### ج) رفع باگ hash routing

**علت باگ:** در 8.5.3، `document.addEventListener('click', ...)` روی
هر کلیکی در صفحه trigger می‌شد. اگر متن کارت/جدول به‌طور تصادفی با یک
label تب match می‌شد (مثلاً کلیک روی سطری که کلمه‌ی «چک» داشت)، hash
اشتباه update می‌شد ولی React state عوض نمی‌شد.

**اصلاح:** listener فقط داخل `<aside>` (sidebar) نصب می‌شود. اگر
sidebar تازه‌واردی mount شود، MutationObserver آن را می‌بیند و listener
اضافه می‌کند.

```js
// v8.5.3 (باگ‌دار):
document.addEventListener('click', ...)

// v8.5.4 (درست):
aside.addEventListener('click', ..., true)
```

## 📁 فایل‌های تغییریافته

| فایل | تغییر |
|---|---|
| `includes/finance/page-embed-treasury.php` | بازنویسی کامل با class های ERP + template های فرم |
| `assets/js/cptt-erp-extras.js` | بازنویسی: Modal manager، action handlers، sidebar-only hash tracking |
| `client-project-tracker.php` | بامپ نسخه به 8.5.4 |

## 🎨 نمونه ظاهر

**هر ۳ تب:**
- Section header با آیکن circular آبی + عنوان bold + subtitle خاکستری + دکمه‌های عمل در راست
- ۳ کارت KPI با آیکن رنگی، عدد بزرگ، subtitle کوچک، border-radius بزرگ، hover shadow
- Filter card با یکنواخت label + input + button
- Card اصلی با جدول `cptt-table` (همان جدول بقیه تب‌ها)
- سطرها با hover لطیف
- Badge (`cptt-pill-success`, `cptt-pill-danger`, ...) برای وضعیت
- دکمه‌های عمل کوچک با آیکن (✎ ✂ 🗑) در ستون آخر
- Empty state زیبا با border-dashed
- Modal با animation slide-up، header با header gradient، footer با دکمه‌های primary
- Toast bar در پایین صفحه با gradient سبز/قرمز

## 🛡️ ایمنی

- ✅ syntax check همه فایل‌ها (۴ PHP + ۳ JS)
- ✅ عملیات نوشتنی از nonce استفاده می‌کند (defense in depth)
- ✅ دیتای دیتابیس دست‌نخورده — همان handlerهای موجود صدا می‌شوند
- ✅ E-1 fix، ساعت audit-trail، datepicker شمسی، ورودی فارسی/انگلیسی همه فعال
- ✅ Modal بعد از submit خودکار slot را reload می‌کند
- ✅ hash routing حالا فقط داخل sidebar کار می‌کند — false-positive حذف شد

## 🎯 UX نهایی

- ✅ باز کردن پنل ERP → گروه «خزانه‌داری» یا «درآمد/هزینه»
- ✅ کلیک روی هر تب سفارشی → لود سریع محتوا با ظاهر یکسان با بقیه پنل
- ✅ دکمه‌ی «➕ افزودن حساب» → modal داخل خود ERP باز می‌شود
- ✅ ذخیره → toast «حساب با موفقیت ذخیره شد» + جدول رفرش می‌شود
- ✅ دکمه‌ی «🗑» → confirm dialog → حذف با toast
- ✅ F5 روی هر تب → همان تب باقی می‌ماند
- ✅ کلیک بین تب‌ها → بدون reload صفحه، hash به‌روزرسانی
- ✅ کلیک روی متن جدول/کارت‌ها → **دیگر تصادفی hash عوض نمی‌شود**
