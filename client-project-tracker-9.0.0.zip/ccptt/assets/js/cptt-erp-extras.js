/*!
 * cptt-erp-extras.js — v8.5.4
 *
 * قابلیت‌ها:
 *   1) Slot loader: تب‌های سفارشی داخل پنل ERP (cashflow, treasury,
 *      transfers, income_expense) — محتوا از PHP embed می‌آید.
 *   2) Persistent tab (URL hash) — با click tracking فقط داخل <aside>.
 *   3) Modal manager: template-based modal ها با AJAX submit.
 *   4) Generic pagination.
 *   5) UI هماهنگ با ERP — از همان class های cptt-* که در app.css هستند.
 */
(function(){
	'use strict';
	if (window.CPTT_ERP_Extras) return;
	window.CPTT_ERP_Extras = { version: '8.5.4' };

	// ---------- Config: slot → PHP page ----------
	var SLOTS = {
		'cashflow':       { page: 'cptt-finance-cashflow',     extra: {} },
		'treasury':       { page: 'cptt-finance-treasury',     extra: {} },
		'transfers':      { page: 'cptt-finance-treasury',     extra: { new: 'transfer' } },
		'income_expense': { page: 'cptt-finance-transactions', extra: {} }
	};

	// ---------- URL / AJAX helpers ----------
	function baseAdminUrl(){
		var b = document.body;
		if (b && b.dataset && b.dataset.cpttAdminUrl) return b.dataset.cpttAdminUrl;
		return (window.ajaxurl || '').replace(/admin-ajax\.php.*$/, '') + 'admin.php';
	}
	function ajaxUrl(){
		return (window.ajaxurl) || (window.CPTTF_ERP && window.CPTTF_ERP.ajax) || '/wp-admin/admin-ajax.php';
	}
	function erpNonce(){
		return (window.CPTTF_ERP && window.CPTTF_ERP.nonce) || '';
	}
	function buildUrl(slotKey, params){
		var cfg = SLOTS[slotKey]; if (!cfg) return '';
		var qs = ['page=' + encodeURIComponent(cfg.page), 'embed=1'];
		for (var k in cfg.extra) qs.push(encodeURIComponent(k) + '=' + encodeURIComponent(cfg.extra[k]));
		if (params) for (var k2 in params) if (params[k2] !== undefined && params[k2] !== null && params[k2] !== '') {
			qs.push(encodeURIComponent(k2) + '=' + encodeURIComponent(params[k2]));
		}
		return baseAdminUrl() + '?' + qs.join('&');
	}
	function ajaxPost(action, data){
		var fd = new FormData();
		fd.append('action', action);
		fd.append('nonce', erpNonce());
		for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) {
			fd.append(k, data[k]);
		}
		return fetch(ajaxUrl(), { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function(res){ return res.json(); })
			.then(function(json){
				// v8.5.7 — بعد از هر write موفق، state سرتاسری بندل ERP را رفرش کنیم
				// تا voucher/موجودی/تسویه‌های جدید بدون F5 در همه‌ی تب‌های React ظاهر شوند.
				if (json && json.success && typeof window.__cpttErpRefreshAll === 'function') {
					try { window.__cpttErpRefreshAll(); } catch(e){}
				}
				return json;
			});
	}

	// ---------- CSS injection (only for slot wrapper + modal + pagination) ----------
	// UI اصلی از cptt-* class ها می‌آید که در app.css موجودند.
	// اینجا فقط چیزهای اضافی که تعریف نشده‌اند inject می‌شود.
	function injectStyle(){
		if (document.getElementById('cptt-erp-extras-css')) return;
		var css = [
			// Slot wrapper
			'.cptt-erp-slot{position:relative;min-height:400px;padding:0;}',
			'.cptt-erp-slot.is-loading{opacity:.55;pointer-events:none;}',
			'.cptt-erp-slot.is-loading::before{content:"⏳ در حال بارگذاری…";position:absolute;top:120px;left:50%;transform:translateX(-50%);color:#64748b;font-size:13px;z-index:10;padding:10px 20px;background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(15,23,42,.15);font-family:inherit;}',
			'.cptt-erp-slot.is-error{padding:20px;color:#991b1b;background:#fee2e2;border-radius:12px;border:1px solid #fecaca;font-family:inherit;}',
			'.cptt-erp-slot .cpttf-embed-body{padding:0!important;background:transparent!important;min-height:auto!important;}',

			// Table wrap (for scrolling body + sticky header)
			'.cptt-erp-slot .cptt-table-wrap{overflow:auto;max-height:none;}',
			'.cptt-erp-slot .cptt-table-wrap .cptt-table thead th{position:sticky;top:0;background:#f8fafc;z-index:2;}',

			// Buttons — use cptt-btn from app.css but add subtle animation
			'.cptt-erp-slot .cptt-btn{transition:all .15s;display:inline-flex;align-items:center;gap:6px;}',
			'.cptt-erp-slot .cptt-btn:hover{transform:translateY(-1px);}',

			// Section header responsive
			'.cptt-erp-slot .space-y-5>*+*{margin-top:20px;}',

			// KPI grid responsive
			'@media(max-width:640px){.cptt-erp-slot .grid{grid-template-columns:1fr!important;}}',

			// Empty state
			'.cptt-erp-slot .rounded-2xl{border-radius:1.1rem;}',

			// Pagination controls
			'.cptt-erp-pagination{display:flex;justify-content:center;align-items:center;gap:6px;padding:14px;flex-wrap:wrap;background:#fafbfc;border-top:1px solid #f1f5f9;border-radius:0 0 1.1rem 1.1rem;}',
			'.cptt-erp-pagination button{min-width:34px;height:32px;padding:0 10px;border-radius:8px;border:1px solid #e2e8f0;background:#fff;color:#334155;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;}',
			'.cptt-erp-pagination button:hover:not(:disabled){background:#eef2ff;border-color:#6366f1;color:#4f46e5;transform:translateY(-1px);}',
			'.cptt-erp-pagination button.is-active{background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(99,102,241,.3);}',
			'.cptt-erp-pagination button:disabled{opacity:.4;cursor:not-allowed;}',
			'.cptt-erp-pagination-info{color:#64748b;font-size:11px;margin-inline-end:auto;}',

			// Modal — same look-and-feel as ERP panel (Dana font, cptt-* classes)
			// FONT_FAMILY = "Dana, Vazirmatn, Tahoma, sans-serif" (same as ERP panel)
			'.cptt-erp-modal-overlay{position:fixed;inset:0;background:rgba(15,23,42,.6);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);z-index:100000;display:flex;align-items:center;justify-content:center;padding:20px;animation:cpttErpFade .18s ease;font-family:"Dana","Vazirmatn",Tahoma,sans-serif;direction:rtl;}',
			'@keyframes cpttErpFade{from{opacity:0;}to{opacity:1;}}',
			'@keyframes cpttErpSlide{from{transform:translateY(20px);opacity:0;}to{transform:translateY(0);opacity:1;}}',
			'.cptt-erp-modal{background:#fff;border-radius:1.1rem;overflow:hidden;width:100%;max-width:600px;box-shadow:0 24px 60px rgba(0,0,0,.35);animation:cpttErpSlide .22s ease;display:flex;flex-direction:column;max-height:90vh;font-family:inherit;}',
			'.cptt-erp-modal *{font-family:inherit;}',
			'.cptt-erp-modal-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #e2e8f0;background:linear-gradient(180deg,#fafbfc,#fff);}',
			'.cptt-erp-modal-title{margin:0;font-size:14px;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:8px;}',
			'.cptt-erp-modal-close{background:none;border:none;font-size:22px;line-height:1;cursor:pointer;color:#64748b;padding:4px 10px;border-radius:8px;transition:all .15s;}',
			'.cptt-erp-modal-close:hover{background:#fee2e2;color:#991b1b;}',
			'.cptt-erp-modal-body{padding:20px;overflow-y:auto;flex:1;}',
			'.cptt-erp-modal-footer{padding:12px 20px;background:#fafbfc;border-top:1px solid #e2e8f0;display:flex;gap:8px;justify-content:flex-end;}',

			// Input / Select / Textarea inside modal — دقیقاً همان cptt-input/select
			'.cptt-erp-modal .cptt-input,.cptt-erp-modal .cptt-select,.cptt-erp-modal .cptt-textarea,.cptt-erp-modal .cptt-input-num{width:100%;padding:0.65rem 1rem;border:1.5px solid #e2e8f0;border-radius:0.9rem;background:#fff;color:#0f172a;font-size:0.8125rem;font-family:inherit;font-weight:500;text-align:right;direction:rtl;transition:border-color .15s,box-shadow .15s;box-shadow:0 1px 2px rgba(15,23,42,.04);outline:0;line-height:1.6;box-sizing:border-box;}',
			'.cptt-erp-modal .cptt-input:focus,.cptt-erp-modal .cptt-select:focus,.cptt-erp-modal .cptt-textarea:focus,.cptt-erp-modal .cptt-input-num:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.15);}',
			'.cptt-erp-modal .cptt-select{padding-left:2.5rem;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 20 20\' fill=\'%236366f1\'%3E%3Cpath fill-rule=\'evenodd\' d=\'M5.23 7.21a.75.75 0 011.06.02L10 11.06l3.71-3.83a.75.75 0 111.08 1.04l-4.25 4.39a.75.75 0 01-1.08 0L5.21 8.27a.75.75 0 01.02-1.06z\' clip-rule=\'evenodd\'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:left 0.75rem center;background-size:1rem;appearance:none;-webkit-appearance:none;}',
			'.cptt-erp-modal .cptt-input-num{font-feature-settings:"tnum" 1;font-variant-numeric:tabular-nums;text-align:right;}',
			'.cptt-erp-modal .cptt-label{display:block;font-size:0.75rem;font-weight:600;color:#475569;margin-bottom:0.375rem;line-height:1.4;}',
			'.cptt-erp-modal .cptt-btn{padding:0.6rem 1.1rem;border-radius:0.65rem;border:none;font-size:0.8125rem;font-weight:600;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:6px;transition:all .15s;}',
			'.cptt-erp-modal .cptt-btn-primary{background:#4f46e5;color:#fff;box-shadow:0 2px 4px rgba(79,70,229,.22);}',
			'.cptt-erp-modal .cptt-btn-primary:hover{background:#4338ca;transform:translateY(-1px);}',
			'.cptt-erp-modal .cptt-btn-danger{background:#e11d48;color:#fff;box-shadow:0 2px 4px rgba(225,29,72,.22);}',
			'.cptt-erp-modal .cptt-btn-danger:hover{background:#be123c;transform:translateY(-1px);}',
			'.cptt-erp-modal .cptt-btn-ghost{background:transparent;color:#475569;border:1px solid #e2e8f0;}',
			'.cptt-erp-modal .cptt-btn-ghost:hover{background:#f1f5f9;color:#0f172a;}',

			// Balance hint inside select label (transfer form)
			'.cptt-erp-balance-hint{display:block;color:#64748b;font-size:11px;font-weight:500;margin-top:6px;padding:6px 10px;background:#f8fafc;border-radius:8px;border:1px dashed #e2e8f0;font-family:inherit;font-feature-settings:"tnum" 1;}',
			'.cptt-erp-balance-hint strong{color:#0f172a;font-weight:700;}',
			'.cptt-erp-balance-hint.is-insufficient{background:#fef2f2;border-color:#fecaca;color:#991b1b;}',
			'.cptt-erp-balance-hint.is-insufficient strong{color:#7f1d1d;}',

			// Toast
			'.cptt-erp-toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);background:#0f172a;color:#fff;padding:12px 22px;border-radius:12px;font-size:13px;font-family:"Dana","Vazirmatn",Tahoma,sans-serif;direction:rtl;box-shadow:0 12px 30px rgba(0,0,0,.35);z-index:100001;opacity:0;transition:all .25s;pointer-events:none;}',
			'.cptt-erp-toast.is-show{opacity:1;transform:translateX(-50%) translateY(0);}',
			'.cptt-erp-toast.is-success{background:linear-gradient(135deg,#059669,#047857);}',
			'.cptt-erp-toast.is-error{background:linear-gradient(135deg,#dc2626,#b91c1c);}',

			// Confirm dialog
			'.cptt-erp-confirm-body{color:#334155;font-size:13.5px;line-height:1.75;text-align:center;padding:12px 4px;}',
			'.cptt-erp-confirm-body strong{display:block;color:#0f172a;font-size:15px;margin-bottom:8px;}'
		].join('\n');
		var s = document.createElement('style');
		s.id = 'cptt-erp-extras-css';
		s.textContent = css;
		document.head.appendChild(s);
	}

	// ---------- Extract body ----------
	function extractBody(html){
		if (/^\s*<div class="cpttf-embed-body"/.test(html)) return html;
		var m = /<body[^>]*>([\s\S]*?)<\/body>/i.exec(html);
		if (m) return m[1];
		return html;
	}

	// ---------- Toast ----------
	var toastEl = null;
	function toast(msg, kind){
		if (!toastEl) {
			toastEl = document.createElement('div');
			toastEl.className = 'cptt-erp-toast';
			document.body.appendChild(toastEl);
		}
		toastEl.textContent = msg;
		toastEl.className = 'cptt-erp-toast is-show is-' + (kind || 'info');
		clearTimeout(toastEl._t);
		toastEl._t = setTimeout(function(){ toastEl.classList.remove('is-show'); }, 2600);
	}

	// ---------- Modal manager ----------
	var currentModal = null;
	function openModal(opts){
		closeModal();
		var overlay = document.createElement('div');
		overlay.className = 'cptt-erp-modal-overlay';
		var modal = document.createElement('div');
		modal.className = 'cptt-erp-modal';
		if (opts.size === 'sm') modal.style.maxWidth = '420px';
		if (opts.size === 'lg') modal.style.maxWidth = '780px';

		var head = document.createElement('div');
		head.className = 'cptt-erp-modal-head';
		head.innerHTML = '<h3 class="cptt-erp-modal-title">' + (opts.icon || '') + '<span>' + (opts.title || '') + '</span></h3>'
			+ '<button type="button" class="cptt-erp-modal-close" aria-label="بستن">×</button>';
		modal.appendChild(head);

		var body = document.createElement('div');
		body.className = 'cptt-erp-modal-body';
		if (typeof opts.content === 'string') body.innerHTML = opts.content;
		else if (opts.content) body.appendChild(opts.content);
		modal.appendChild(body);

		var footer = document.createElement('div');
		footer.className = 'cptt-erp-modal-footer';
		if (opts.footer) {
			if (typeof opts.footer === 'string') footer.innerHTML = opts.footer;
			else footer.appendChild(opts.footer);
		} else {
			footer.innerHTML = '<button type="button" class="cptt-btn cptt-btn-ghost" data-cptt-modal-close>لغو</button>'
				+ '<button type="button" class="cptt-btn cptt-btn-primary" data-cptt-modal-submit>ذخیره</button>';
		}
		modal.appendChild(footer);

		overlay.appendChild(modal);
		document.body.appendChild(overlay);
		document.body.style.overflow = 'hidden';

		// event bindings
		head.querySelector('.cptt-erp-modal-close').addEventListener('click', closeModal);
		overlay.addEventListener('click', function(e){ if (e.target === overlay) closeModal(); });
		var submitBtn = footer.querySelector('[data-cptt-modal-submit]');
		var cancelBtns = footer.querySelectorAll('[data-cptt-modal-close]');
		cancelBtns.forEach(function(b){ b.addEventListener('click', closeModal); });
		if (submitBtn && opts.onSubmit) {
			submitBtn.addEventListener('click', function(){
				var form = body.querySelector('form');
				var data = {};
				if (form) {
					var els = form.querySelectorAll('input,select,textarea');
					for (var i = 0; i < els.length; i++) {
						var el = els[i];
						if (!el.name || el.disabled) continue;
						if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) continue;
						var v = el.value;
						if (window.CPTT_InputNormalize && window.CPTT_InputNormalize.toEn) v = window.CPTT_InputNormalize.toEn(v);
						data[el.name] = v;
					}
				}
				submitBtn.disabled = true;
				submitBtn.textContent = 'در حال ذخیره…';
				Promise.resolve(opts.onSubmit(data, form)).then(function(res){
					submitBtn.disabled = false;
					submitBtn.textContent = 'ذخیره';
					if (res && res.close !== false) closeModal();
				}).catch(function(){
					submitBtn.disabled = false;
					submitBtn.textContent = 'ذخیره';
				});
			});
		}
		// input-normalize scan for datepicker / amount format
		if (window.CPTT_InputNormalize && window.CPTT_InputNormalize.scan) {
			try { window.CPTT_InputNormalize.scan(body); } catch(e){}
		}
		currentModal = overlay;
	}
	function closeModal(){
		if (currentModal) {
			currentModal.remove();
			currentModal = null;
			document.body.style.overflow = '';
		}
	}
	document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });

	// ---------- Confirm dialog ----------
	function confirmDialog(opts){
		return new Promise(function(resolve){
			openModal({
				title: opts.title || 'تایید عملیات',
				icon: opts.icon || '⚠️',
				size: 'sm',
				content: '<div class="cptt-erp-confirm-body">'
					+ (opts.strong ? '<strong>' + opts.strong + '</strong>' : '')
					+ (opts.message || 'آیا مطمئن هستید؟')
					+ '</div>',
				footer: null,
				onSubmit: function(){ resolve(true); return { close: true }; }
			});
			// override submit button label & style
			setTimeout(function(){
				var submit = currentModal && currentModal.querySelector('[data-cptt-modal-submit]');
				if (submit) {
					submit.textContent = opts.confirmLabel || 'حذف';
					if (opts.danger !== false) {
						submit.classList.remove('cptt-btn-primary');
						submit.classList.add('cptt-btn-danger');
					}
				}
			}, 10);
			// on cancel/close → resolve(false)
			if (currentModal) {
				var origRemove = currentModal.remove.bind(currentModal);
				currentModal.remove = function(){ resolve(false); origRemove(); };
			}
		});
	}

	// ---------- Load a slot ----------
	var slotState = {};

	function loadSlot(slot, slotKey, params){
		if (!slot) return;
		slot.classList.add('is-loading');
		slot.classList.remove('is-error');
		var url = buildUrl(slotKey, params);
		fetch(url, { credentials: 'same-origin' })
			.then(function(res){ if (!res.ok) throw new Error('HTTP ' + res.status); return res.text(); })
			.then(function(html){
				slot.classList.remove('is-loading');
				slot.innerHTML = extractBody(html);
				bindInteractions(slot, slotKey);
				if (window.CPTT_InputNormalize && window.CPTT_InputNormalize.scan) {
					try { window.CPTT_InputNormalize.scan(slot); } catch(e){}
				}
				applyPagination(slot);
			})
			.catch(function(err){
				slot.classList.remove('is-loading');
				slot.classList.add('is-error');
				slot.textContent = 'خطا در بارگذاری: ' + (err && err.message ? err.message : err);
			});
	}
	function reloadSlot(slotKey){
		var slot = document.querySelector('[data-slot="' + slotKey + '"]');
		if (slot) loadSlot(slot, slotKey, slotState[slotKey] || null);
	}

	// ---------- Bind interactions after slot load ----------
	function bindInteractions(slot, slotKey){
		// 1) filter form (method="get") → reload slot with new params
		var forms = slot.querySelectorAll('form:not([data-cptt-erp-form])');
		for (var i = 0; i < forms.length; i++) {
			var f = forms[i];
			if (f._cpttBound) continue;
			f._cpttBound = true;
			f.addEventListener('submit', function(e){
				if (e.currentTarget.method && e.currentTarget.method.toLowerCase() === 'post') return;
				e.preventDefault();
				var form = e.currentTarget;
				var params = {};
				var inputs = form.querySelectorAll('input,select,textarea');
				for (var j = 0; j < inputs.length; j++) {
					var el = inputs[j];
					if (!el.name || el.disabled) continue;
					if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) continue;
					if (el.name === 'page' || el.name === 'embed') continue;
					var v = el.value;
					if (window.CPTT_InputNormalize && window.CPTT_InputNormalize.toEn) v = window.CPTT_InputNormalize.toEn(v);
					params[el.name] = v;
				}
				slotState[slotKey] = params;
				loadSlot(slot, slotKey, params);
			});
		}
		// 2) action buttons — delegate
		slot.addEventListener('click', function(e){
			var btn = e.target.closest('[data-cptt-action]');
			if (!btn) return;
			var act = btn.getAttribute('data-cptt-action');
			handleAction(act, btn, slot, slotKey);
		});
	}

	// ---------- Action handlers ----------
	function handleAction(act, btn, slot, slotKey){
		switch(act){
			case 'treasury-add':      return actTreasuryEdit(null);
			case 'treasury-edit':     return actTreasuryEdit(btn.dataset);
			case 'treasury-delete':   return actTreasuryDelete(btn.dataset);
			case 'transfer-add':      return actTransferAdd();
			case 'ie-add':            return actIeAdd(btn.dataset.type || 'income');
			case 'ie-delete':         return actIeDelete(btn.dataset);
			case 'ie-reset-filter':
				slotState[slotKey] = null;
				loadSlot(slot, slotKey, null);
				return;
		}
	}

	// -- Treasury add/edit --
	function actTreasuryEdit(data){
		var tpl = document.getElementById('cptt-tpl-treasury-form');
		if (!tpl) { toast('template not found', 'error'); return; }
		var content = tpl.content.cloneNode(true);
		// populate if editing
		if (data && data.id) {
			var form = content.querySelector('form');
			form.querySelector('[name="id"]').value = 't' + data.id;
			form.querySelector('[name="name"]').value = data.name || '';
			form.querySelector('[name="type"]').value = data.type || 'bank';
			form.querySelector('[name="icon"]').value = data.icon || '';
			form.querySelector('[name="account_number"]').value = data.accountNumber || '';
			form.querySelector('[name="iban"]').value = data.iban || '';
			form.querySelector('[name="status"]').value = data.status || '1';
		}
		openModal({
			title: data && data.id ? 'ویرایش حساب' : 'افزودن حساب جدید',
			icon: '🏦',
			content: content,
			onSubmit: function(fd){
				if (!fd.name) { toast('نام حساب الزامی است', 'error'); return; }
				// backend expects _POST['account'] = JSON
				var payload = {
					id: fd.id || '',
					name: fd.name,
					type: (fd.type === 'bank') ? 'BANK' : 'CASH',
					icon: fd.icon || '',
					accountNumber: fd.account_number || '',
					iban: fd.iban || '',
					status: fd.status || '1'
				};
				return ajaxPost('cpttf_erp_treasury_save', { account: JSON.stringify(payload) })
					.then(function(res){
						if (res && res.success) {
							toast('حساب با موفقیت ذخیره شد', 'success');
							reloadSlot('treasury');
							return { close: true };
						} else {
							toast(res && res.data ? res.data : 'خطای ناشناخته', 'error');
							return { close: false };
						}
					});
			}
		});
	}
	function actTreasuryDelete(data){
		if (!data || !data.id) return;
		confirmDialog({
			title: 'غیرفعال کردن حساب',
			strong: data.name || '—',
			message: 'این حساب غیرفعال می‌شود ولی داده‌های آن حفظ می‌شود. مطمئنید؟',
			confirmLabel: 'غیرفعال کن',
			icon: '⚠️'
		}).then(function(ok){
			if (!ok) return;
			ajaxPost('cpttf_erp_treasury_delete', { id: 't' + data.id })
				.then(function(res){
					if (res && res.success) {
						toast('حساب غیرفعال شد', 'success');
						reloadSlot('treasury');
					} else {
						toast(res && res.data ? res.data : 'خطای ناشناخته', 'error');
					}
				});
		});
	}

	// -- Transfer add --
	function actTransferAdd(){
		var tpl = document.getElementById('cptt-tpl-transfer-form');
		if (!tpl) { toast('template not found', 'error'); return; }
		openModal({
			title: 'ثبت انتقال بین حساب‌ها',
			icon: '🔁',
			content: tpl.content.cloneNode(true),
			onSubmit: function(fd){
				if (!fd.from_id || !fd.to_id || !fd.amount) {
					toast('همه‌ی فیلدها الزامی هستند', 'error'); return { close: false };
				}
				if (fd.from_id === fd.to_id) {
					toast('حساب مبدا و مقصد یکی است', 'error'); return { close: false };
				}
				var amount = parseFloat(String(fd.amount).replace(/[,\s]/g, '')) || 0;
				if (amount <= 0) { toast('مبلغ نامعتبر است', 'error'); return { close: false }; }
				// v8.5.5: client-side balance guard (defense in depth؛ backend هم چک می‌کند)
				var form = currentModal.querySelector('form[data-cptt-transfer-form]');
				if (form) {
					try {
						var accs = JSON.parse(form.getAttribute('data-accounts') || '{}');
						var fromAcc = accs[fd.from_id];
						if (fromAcc && amount > fromAcc.balance + 0.005) {
							toast('موجودی حساب مبدأ کافی نیست (' + formatNum(fromAcc.balance) + ' تومان)', 'error');
							return { close: false };
						}
					} catch(e){}
				}
				return ajaxPost('cpttf_erp_treasury_transfer', {
					from_id: 't' + fd.from_id,
					to_id: 't' + fd.to_id,
					amount: amount,
					description: fd.note || ''
				}).then(function(res){
					if (res && res.success) {
						toast('انتقال با موفقیت ثبت شد', 'success');
						reloadSlot('transfers');
						// همچنین treasury tab را invalidate کن تا موجودی به‌روز شود
						var trSlot = document.querySelector('[data-slot="treasury"]');
						if (trSlot && _initedSlots) _initedSlots.delete(trSlot);
						return { close: true };
					} else {
						toast(res && res.data ? res.data : 'خطای ناشناخته', 'error');
						return { close: false };
					}
				});
			}
		});
		// bind balance-hint updates
		setTimeout(function(){ bindTransferBalanceHints(); }, 20);
	}
	function formatNum(n){
		try { return new Intl.NumberFormat('en-US').format(Math.round(n)); }
		catch(e){ return String(Math.round(n)); }
	}
	function bindTransferBalanceHints(){
		var form = currentModal && currentModal.querySelector('form[data-cptt-transfer-form]');
		if (!form) return;
		var fromSel = form.querySelector('[data-cptt-balance-select="from"]');
		var toSel   = form.querySelector('[data-cptt-balance-select="to"]');
		var fromHint = form.querySelector('[data-cptt-balance-hint="from"]');
		var toHint   = form.querySelector('[data-cptt-balance-hint="to"]');
		var amtEl    = form.querySelector('[data-cptt-transfer-amount]');
		var remHint  = form.querySelector('[data-cptt-transfer-remainder]');

		function showHint(sel, hint, kind){
			if (!sel || !hint) return;
			var opt = sel.options[sel.selectedIndex];
			var bal = opt ? parseFloat(opt.getAttribute('data-balance') || '0') : 0;
			if (!sel.value) {
				hint.style.display = 'none';
				return null;
			}
			hint.classList.remove('is-insufficient');
			hint.innerHTML = 'موجودی فعلی: <strong>' + formatNum(bal) + '</strong> تومان';
			hint.style.display = 'block';
			return bal;
		}
		function refresh(){
			var fromBal = showHint(fromSel, fromHint, 'from');
			showHint(toSel, toHint, 'to');
			// remainder + validation
			if (fromBal !== null && amtEl && remHint) {
				var amt = parseFloat(String(amtEl.value || '').replace(/[,\s۰-۹]/g, function(c){
					if (c === ',' || c === ' ') return '';
					return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c));
				})) || 0;
				if (amt > 0) {
					var rem = fromBal - amt;
					remHint.style.display = 'block';
					if (amt > fromBal + 0.005) {
						remHint.classList.add('is-insufficient');
						remHint.innerHTML = '⚠️ کسری موجودی: <strong>' + formatNum(amt - fromBal) + '</strong> تومان';
						if (fromHint) fromHint.classList.add('is-insufficient');
					} else {
						remHint.classList.remove('is-insufficient');
						remHint.innerHTML = 'مانده پس از انتقال: <strong>' + formatNum(rem) + '</strong> تومان';
						if (fromHint) fromHint.classList.remove('is-insufficient');
					}
				} else {
					remHint.style.display = 'none';
				}
			}
		}
		if (fromSel) fromSel.addEventListener('change', refresh);
		if (toSel)   toSel.addEventListener('change', refresh);
		if (amtEl)   amtEl.addEventListener('input', refresh);
		refresh();
	}

	// -- Income/Expense add --
	function actIeAdd(type){
		var tplId = type === 'expense' ? 'cptt-tpl-ie-form-expense' : 'cptt-tpl-ie-form-income';
		var tpl = document.getElementById(tplId);
		if (!tpl) { toast('template not found', 'error'); return; }
		openModal({
			title: type === 'expense' ? 'ثبت هزینه جدید' : 'ثبت درآمد جدید',
			icon: type === 'expense' ? '📤' : '💵',
			content: tpl.content.cloneNode(true),
			onSubmit: function(fd){
				if (!fd.amount || !fd.description || !fd.account_id) {
					toast('مبلغ، شرح و حساب الزامی است', 'error');
					return { close: false };
				}
				var amount = parseFloat(String(fd.amount).replace(/[,\s]/g, '')) || 0;
				if (amount <= 0) { toast('مبلغ نامعتبر', 'error'); return { close: false }; }
				var payload = {
					type: (fd.type === 'income') ? 'INCOME' : 'EXPENSE',
					amount: amount,
					title: fd.description,
					description: '',
					bankAccountId: 't' + fd.account_id,
					date: fd.date_local || ''
				};
				if (fd.category_id && fd.category_id !== '0') payload.category_id = fd.category_id;
				return ajaxPost('cpttf_erp_ie_save', { item: JSON.stringify(payload) })
					.then(function(res){
						if (res && res.success) {
							toast((fd.type === 'income') ? 'درآمد ثبت شد' : 'هزینه ثبت شد', 'success');
							reloadSlot('income_expense');
							return { close: true };
						} else {
							toast(res && res.data ? res.data : 'خطای ناشناخته', 'error');
							return { close: false };
						}
					});
			}
		});
	}
	function actIeDelete(data){
		if (!data || !data.id) return;
		confirmDialog({
			title: 'حذف تراکنش',
			strong: data.desc || '—',
			message: 'این تراکنش حذف و سند مربوطه‌اش برگشت خواهد خورد. مطمئنید؟',
			confirmLabel: 'حذف کن',
			icon: '🗑'
		}).then(function(ok){
			if (!ok) return;
			ajaxPost('cpttf_erp_ie_delete', { id: 'ie' + data.id })
				.then(function(res){
					if (res && res.success) {
						toast('تراکنش حذف شد', 'success');
						reloadSlot('income_expense');
					} else {
						toast(res && res.data ? res.data : 'خطای ناشناخته', 'error');
					}
				});
		});
	}

	// ---------- Pagination (generic) ----------
	function applyPagination(root){
		var containers = root.querySelectorAll('[data-cptt-paginate]');
		for (var i = 0; i < containers.length; i++) {
			var c = containers[i];
			if (c._cpttPagInit) continue;
			c._cpttPagInit = true;
			var perPage = parseInt(c.getAttribute('data-cptt-paginate'), 10) || 25;
			var tbl = c.querySelector('table');
			if (!tbl) continue;
			paginateTable(tbl, perPage, c);
		}
	}
	function paginateTable(tbl, perPage, container){
		var tbody = tbl.querySelector('tbody');
		if (!tbody) return;
		var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
		if (rows.length <= perPage) return;

		// pagination bar after container
		var pag = document.createElement('div');
		pag.className = 'cptt-erp-pagination';
		container.parentNode.insertBefore(pag, container.nextSibling);

		var totalPages = Math.ceil(rows.length / perPage);
		var current = 1;
		function faNum(n){
			if (window.CPTT_InputNormalize && window.CPTT_InputNormalize.toFa) return window.CPTT_InputNormalize.toFa(String(n));
			return String(n);
		}
		function render(){
			for (var i = 0; i < rows.length; i++) {
				var page = Math.floor(i / perPage) + 1;
				rows[i].style.display = (page === current) ? '' : 'none';
			}
			pag.innerHTML = '';
			var info = document.createElement('span');
			info.className = 'cptt-erp-pagination-info';
			var start = (current - 1) * perPage + 1;
			var end = Math.min(current * perPage, rows.length);
			info.textContent = 'نمایش ' + faNum(start) + '–' + faNum(end) + ' از ' + faNum(rows.length);
			pag.appendChild(info);
			function btn(label, page, disabled, active){
				var b = document.createElement('button');
				b.type = 'button'; b.textContent = label; b.disabled = !!disabled;
				if (active) b.classList.add('is-active');
				b.addEventListener('click', function(){ if (!disabled) { current = page; render(); container.scrollTop = 0; } });
				return b;
			}
			pag.appendChild(btn('«', 1, current === 1));
			pag.appendChild(btn('‹', current - 1, current === 1));
			var maxBtns = 5;
			var startP = Math.max(1, current - 2);
			var endP = Math.min(totalPages, startP + maxBtns - 1);
			if (endP - startP < maxBtns - 1) startP = Math.max(1, endP - maxBtns + 1);
			for (var p = startP; p <= endP; p++) pag.appendChild(btn(faNum(p), p, false, p === current));
			pag.appendChild(btn('›', current + 1, current === totalPages));
			pag.appendChild(btn('»', totalPages, current === totalPages));
		}
		render();
	}

	// ---------- Slot detection (via MutationObserver) ----------
	// v8.5.5: WeakSet برای المان‌های init‌شده — چون React ممکن است element
	// را reuse کند، ما بر مبنای شناسه‌ی خود element track می‌کنیم، نه فقط
	// یک property روی آن. اگر تب عوض شد و همان element با محتوای خالی
	// دوباره ظاهر شد (بدون content قبلی)، آن را دوباره لود می‌کنیم.
	var _initedSlots = typeof WeakSet !== 'undefined' ? new WeakSet() : null;
	function scan(){
		for (var slotKey in SLOTS) {
			var slot = document.querySelector('[data-slot="' + slotKey + '"]');
			if (!slot) continue;
			var wasInit = _initedSlots ? _initedSlots.has(slot) : !!slot._cpttInit;
			var isEmpty = slot.children.length === 0 && slot.textContent.trim() === '';
			// اگر element جدید است، یا element قدیمی است ولی خالی شده (تب تغییر کرد
			// و React همان div را reuse کرد اما content قبلی از dom رفت)، دوباره لود کن
			if (wasInit && !isEmpty) continue;
			if (_initedSlots) _initedSlots.add(slot);
			slot._cpttInit = true;
			loadSlot(slot, slotKey, slotState[slotKey] || null);
		}
	}

	// ---------- Hash routing (persistent tab across refresh) ----------
	// FIX v8.5.4: قبلاً روی هر click در document listen می‌کردیم که در متن
	// جدول‌ها و کارت‌ها هم trigger می‌شد و hash را اشتباه update می‌کرد.
	// حالا فقط clickهای داخل <aside> (sidebar) را track می‌کنیم.
	function updateHash(tabId){
		if (!tabId) return;
		var newHash = '#tab=' + encodeURIComponent(tabId);
		if (window.location.hash === newHash) return;
		try { history.replaceState(null, '', window.location.pathname + window.location.search + newHash); }
		catch(e){ window.location.hash = 'tab=' + tabId; }
	}
	function readHashTab(){
		var h = window.location.hash || '';
		var m = /[#&]tab=([^&]+)/.exec(h);
		if (m) try { return decodeURIComponent(m[1]); } catch(e){ return m[1]; }
		return null;
	}

	var TAB_LABELS = {
		'dashboard':'داشبورد مالی','coding':'کدینگ حساب','vouchers':'اسناد حسابداری',
		'income_expense':'درآمدها و هزینه','settlements':'تسویه کارشناسان',
		'receivables':'مطالبات مشتریان','party_statement':'صورت',
		'treasury':'صندوق','transfers':'انتقال بین','ledger_view':'گردش حساب',
		'cheques':'چک','installments':'اقساط','payables':'پرداختنی',
		'aging_report':'سن مطالبات','cashflow':'جریان نقدی',
		'project_accounting':'حساب پروژه','cost_centers':'مراکز',
		'categories':'دسته‌بندی','fiscal_year':'سال مالی',
		'audit_log':'ممیزی','permissions':'دسترسی',
		'journal':'دفتر روزنامه','ledger':'دفتر کل','subsidiary_ledger':'دفتر معین',
		'trial_balance':'تراز آزمایشی','income_statement':'سود و زیان','balance_sheet':'ترازنامه'
	};
	// v8.5.6 — نگاشت تب → گروه پدر. اگر تب داخل یک گروه بسته باشد،
	// اول باید گروه را با کلیک روی label آن باز کنیم و سپس تب را کلیک کنیم.
	var TAB_GROUP = {
		'journal':'دفاتر و گزارشات','ledger':'دفاتر و گزارشات','subsidiary_ledger':'دفاتر و گزارشات',
		'trial_balance':'دفاتر و گزارشات','income_statement':'دفاتر و گزارشات','balance_sheet':'دفاتر و گزارشات',
		'treasury':'خزانه‌داری','transfers':'خزانه‌داری','ledger_view':'خزانه‌داری',
		'cheques':'خزانه‌داری','payables':'خزانه‌داری','cashflow':'خزانه‌داری',
		'receivables':'مطالبات مشتریان','party_statement':'مطالبات مشتریان',
		'installments':'مطالبات مشتریان','aging_report':'مطالبات مشتریان',
		'fiscal_year':'سال مالی و دوره','audit_log':'سال مالی و دوره','permissions':'سال مالی و دوره'
	};
	function labelToTabId(text){
		if (!text) return null;
		text = text.trim();
		if (text.length > 60) return null;
		for (var id in TAB_LABELS) {
			var lbl = TAB_LABELS[id];
			if (text === lbl || text.indexOf(lbl) === 0) return id;
		}
		return null;
	}
	function findTabButton(tabId){
		var lbl = TAB_LABELS[tabId]; if (!lbl) return null;
		// v8.5.7 — روی موبایل ممکن است <aside> فعلاً بسته باشد یا وجود نداشته
		// باشد. برای اطمینان، اگر aside پیدا نشد از کل document جستجو کنیم.
		var aside = document.querySelector('aside');
		var scope = aside || document.body;
		var candidates = scope.querySelectorAll('button');
		for (var i = 0; i < candidates.length; i++) {
			var el = candidates[i];
			var txt = (el.textContent || '').trim();
			if (txt.length > 60 || txt.length < 2) continue;
			if (txt === lbl || txt.indexOf(lbl) === 0) return el;
		}
		return null;
	}
	function activateTabById(tabId){
		// v8.5.7 — روش قطعی: مستقیم از React state استفاده کن (بندل patched)
		if (typeof window.__cpttErpSetTab === 'function') {
			try {
				window.__cpttErpSetTab(tabId);
				updateHash(tabId);
				return true;
			} catch(e){}
		}
		// Fallback (اگر بندل قدیمی patched نبود): از طریق کلیک روی sidebar
		var group = TAB_GROUP[tabId];
		if (group) {
			var tabVisible = findTabButton(tabId);
			if (!tabVisible) {
				var groupBtn = findGroupButton(group);
				if (groupBtn) {
					groupBtn.click();
					return false;
				}
			}
		}
		var btn = findTabButton(tabId);
		if (!btn) return false;
		btn.click();
		updateHash(tabId);
		return true;
	}

	function findGroupButton(groupLabel){
		var aside = document.querySelector('aside');
		if (!aside) return null;
		var candidates = aside.querySelectorAll('button, [role="button"], [class*="cursor-pointer"]');
		for (var i = 0; i < candidates.length; i++) {
			var el = candidates[i];
			var txt = (el.textContent || '').trim();
			// گروه label شامل چند تب است، پس textContent می‌تواند طولانی باشد
			// اما label اصلی گروه باید در ابتدا یا نزدیک به آن باشد
			if (txt.indexOf(groupLabel) === 0 || txt.indexOf(groupLabel) < 30) {
				return el;
			}
		}
		return null;
	}

	function bindSidebarClickTracking(){
		// v8.5.8 — polling برای sync بین React state و URL hash.
		// KEY FIX: در ابتدای page load، اگر hash کاربر (مثلاً "cheques") هست
		// و بندل هنوز state پیش‌فرض "dashboard" را دارد، *نباید* hash کاربر
		// را overwrite کنیم. یک flag می‌گذاریم که فقط برای اولین ثانیه‌ها
		// این محافظت را برقرار می‌کند تا restoreTabFromHash فرصت داشته باشد.
		var initialHash = readHashTab();
		var lastSeen = initialHash || null;
		var bootProtection = !!initialHash;  // فقط اگر hash داشتیم محافظت لازم است
		// بعد از ۵ ثانیه، محافظت را غیرفعال کن (restore باید تا آن موقع تمام شده باشد)
		setTimeout(function(){ bootProtection = false; }, 5000);
		setInterval(function(){
			var cur = window.__cpttErpCurrentTab;
			if (!cur) return;
			if (cur === lastSeen) return;
			// در دوره‌ی محافظت (page load)، اگر cur=dashboard است و
			// hash کاربر چیز دیگری بود، صبر کن تا restore انجام شود
			if (bootProtection && cur === 'dashboard' && lastSeen !== 'dashboard') return;
			lastSeen = cur;
			updateHash(cur);
		}, 250);

		// Fallback (اگر بندل قدیمی patched نبود): sidebar click tracking
		function attach(aside){
			if (aside._cpttHashBound) return;
			aside._cpttHashBound = true;
			aside.addEventListener('click', function(e){
				var t = e.target;
				for (var i = 0; i < 6 && t && t !== aside; i++) {
					var txt = (t.textContent || '').trim();
					if (txt && txt.length < 60) {
						var id = labelToTabId(txt);
						if (id) {
							setTimeout(function(){ updateHash(id); }, 60);
							return;
						}
					}
					t = t.parentElement;
				}
			}, true);
		}
		var existing = document.querySelectorAll('aside');
		for (var i = 0; i < existing.length; i++) attach(existing[i]);
		if (window.MutationObserver) {
			var obs = new MutationObserver(function(muts){
				for (var m = 0; m < muts.length; m++) {
					for (var n = 0; n < muts[m].addedNodes.length; n++) {
						var node = muts[m].addedNodes[n];
						if (node.nodeType !== 1) continue;
						if (node.tagName === 'ASIDE') attach(node);
						var inner = node.querySelectorAll ? node.querySelectorAll('aside') : [];
						for (var k = 0; k < inner.length; k++) attach(inner[k]);
					}
				}
			});
			obs.observe(document.body, { childList: true, subtree: true });
		}
	}

	function restoreTabFromHash(){
		var tabId = readHashTab();
		if (!tabId || tabId === 'dashboard') return;
		// v8.5.8 — منتظر بمان تا setTab expose شود، سپس یک بار صدا بزن و stop.
		// هر ۱۰۰ms چک می‌کنیم؛ تا ۱۰ ثانیه تلاش می‌کنیم.
		var tries = 0, maxTries = 100;
		var iv = setInterval(function(){
			tries++;
			if (typeof window.__cpttErpSetTab === 'function') {
				try {
					if (window.__cpttErpCurrentTab !== tabId) {
						window.__cpttErpSetTab(tabId);
					}
				} catch(e){}
				// یک لحظه بعد verify — اگر شد، stop
				setTimeout(function(){
					if (window.__cpttErpCurrentTab === tabId) clearInterval(iv);
				}, 250);
				// اگر ۵ بار تلاش کردیم و هنوز نشد، متوقف کن (چیزی خراب است)
				if (tries >= 5 && window.__cpttErpCurrentTab === tabId) clearInterval(iv);
				return;
			}
			// Fallback (اگر بندل patched نبود): از روش قدیمی کلیک استفاده کن
			if (isTabActive(tabId)) { clearInterval(iv); return; }
			if (activateTabById(tabId)) {
				setTimeout(function(){ if (isTabActive(tabId)) clearInterval(iv); }, 300);
				return;
			}
			if (tries >= maxTries) clearInterval(iv);
		}, 100);
	}

	// بررسی اینکه آیا تب مورد نظر واقعاً فعال است — تشخیص از طریق slot یا active class در sidebar
	function isTabActive(tabId){
		if (SLOTS[tabId]) {
			return !!document.querySelector('[data-slot="' + tabId + '"]');
		}
		var btn = findTabButton(tabId);
		if (!btn) return false;
		// classes که در باندل برای تب فعال استفاده می‌شوند:
		//   - تب سطح-یک: "text-white bg-indigo-600"
		//   - تب داخل گروه: "text-indigo-300 bg-indigo-500/15 font-bold"
		var cls = btn.className || '';
		if (/\bbg-indigo-600\b|\bbg-indigo-500\/15\b/.test(cls)) return true;
		return false;
	}

	// ---------- Boot ----------
	function boot(){
		injectStyle();
		scan();
		// v8.5.8 — restore را زود شروع کن (نه با 500ms delay) و polling را با 3s delay
		restoreTabFromHash();
		bindSidebarClickTracking();
		if (window.MutationObserver) {
			var obs = new MutationObserver(function(){ scan(); });
			obs.observe(document.body, { childList: true, subtree: true });
		}
		window.addEventListener('hashchange', function(){
			var tabId = readHashTab();
			if (tabId) activateTabById(tabId);
		});
	}

	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
	else boot();

	// public API
	window.CPTT_ERP_Extras.openModal = openModal;
	window.CPTT_ERP_Extras.closeModal = closeModal;
	window.CPTT_ERP_Extras.confirmDialog = confirmDialog;
	window.CPTT_ERP_Extras.toast = toast;
	window.CPTT_ERP_Extras.reloadSlot = reloadSlot;
})();
