export const images = {
  heroKiwi: "https://images.pexels.com/photos/9228147/pexels-photo-9228147.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1200",
  heroSliced: "https://images.pexels.com/photos/3904800/pexels-photo-3904800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  orchardAerial: "https://images.pexels.com/photos/32343728/pexels-photo-32343728.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
  orchardAerial2: "https://images.pexels.com/photos/20769136/pexels-photo-20769136.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
  packing: "https://images.pexels.com/photos/32834443/pexels-photo-32834443.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
  warehouse: "https://images.pexels.com/photos/10834810/pexels-photo-10834810.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1200",
  gallery: [
    "https://images.pexels.com/photos/31558795/pexels-photo-31558795.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/10899479/pexels-photo-10899479.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/3904800/pexels-photo-3904800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/28948748/pexels-photo-28948748.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/8964274/pexels-photo-8964274.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/8963440/pexels-photo-8963440.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/34513636/pexels-photo-34513636.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
    "https://images.pexels.com/photos/11678431/pexels-photo-11678431.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=900",
  ],
};
