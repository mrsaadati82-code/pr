export type LangCode = "en" | "ar" | "fa";

export interface Content {
  dir: "ltr" | "rtl";
  meta: { name: string };
  nav: {
    home: string;
    about: string;
    nutrition: string;
    quality: string;
    markets: string;
    why: string;
    gallery: string;
    products: string;
    contact: string;
    cta: string;
  };
  hero: {
    badge: string;
    title1: string;
    title2: string;
    subtitle: string;
    ctaPrimary: string;
    ctaSecondary: string;
    scrollHint: string;
    stats: { value: string; label: string }[];
  };
  marquee: string[];
  about: {
    tag: string;
    title: string;
    p1: string;
    p2: string;
    bullets: string[];
    imgCaption: string;
  };
  nutrition: {
    tag: string;
    title: string;
    subtitle: string;
    items: { icon: string; title: string; desc: string }[];
  };
  quality: {
    tag: string;
    title: string;
    subtitle: string;
    steps: { number: string; title: string; desc: string }[];
  };
  markets: {
    tag: string;
    title: string;
    subtitle: string;
    regions: { flag: string; name: string; desc: string }[];
    exportLabel: string;
  };
  why: {
    tag: string;
    title: string;
    subtitle: string;
    features: { icon: string; title: string; desc: string }[];
  };
  gallery: {
    tag: string;
    title: string;
    subtitle: string;
  };
  products: {
    tag: string;
    title: string;
    subtitle: string;
    items: { emoji: string; name: string; desc: string }[];
  };
  contact: {
    tag: string;
    title: string;
    subtitle: string;
    form: {
      name: string;
      email: string;
      phone: string;
      country: string;
      message: string;
      submit: string;
    };
    info: { label: string; value: string }[];
  };
  footer: {
    description: string;
    quickLinks: string;
    productsTitle: string;
    contactTitle: string;
    rights: string;
  };
}

export const en: Content = {
  dir: "ltr",
  meta: { name: "Arasb Kiwi" },
  nav: {
    home: "Home",
    about: "About",
    nutrition: "Nutrition",
    quality: "Quality",
    markets: "Markets",
    why: "Why Us",
    gallery: "Gallery",
    products: "Products",
    contact: "Contact",
    cta: "Request a Quote",
  },
  hero: {
    badge: "Premium Iranian Export",
    title1: "Hayward Kiwi, Grown",
    title2: "Under the Sun of Northern Iran",
    subtitle:
      "Fresh, vibrant green and vitamin-rich kiwi fruit — hand-picked from the lush orchards of Northern Iran and delivered worldwide through advanced cold-chain logistics.",
    ctaPrimary: "Request a Quote",
    ctaSecondary: "Explore the Fruit",
    scrollHint: "Scroll to discover",
    stats: [
      { value: "20+", label: "Export Countries" },
      { value: "5,000+", label: "Tons Shipped Yearly" },
      { value: "15+", label: "Years of Experience" },
      { value: "100%", label: "Cold-Chain Coverage" },
    ],
  },
  marquee: [
    "Fresh Hayward Kiwi",
    "Northern Iran Orchards",
    "Cold-Chain Logistics",
    "Export-Grade Packaging",
    "Vitamin C Rich",
    "Global Delivery",
  ],
  about: {
    tag: "About the Fruit",
    title: "Nature's Green Jewel, Perfected by Iranian Soil",
    p1: "Iranian kiwi fruit is increasingly recognized in global markets for its bright green color, tangy-sweet flavor, and outstanding nutritional profile.",
    p2: "Grown in the fertile northern regions of Iran under ideal climatic conditions — mild winters, humid summers, and rich alluvial soil — our export-grade kiwis deliver consistent quality and freshness that meets international standards. Iran is among the world's most prominent kiwi producers, with exports reaching Asia, the Middle East, Europe and beyond.",
    bullets: [
      "Hand-selected for size, firmness & sugar content",
      "Harvested at optimal ripeness for export journeys",
      "Grown following sustainable farming practices",
      "Rich in Vitamin C, dietary fiber and antioxidants",
    ],
    imgCaption: "Hand-picked in the orchards of Guilan & Mazandaran",
  },
  nutrition: {
    tag: "Health & Nutrition",
    title: "Small Fruit, Powerful Benefits",
    subtitle:
      "Kiwi is one of the most nutrient-dense fruits on earth — a daily boost of vitamins wrapped in a naturally sweet-tart taste.",
    items: [
      { icon: "🍊", title: "Vitamin C Powerhouse", desc: "One kiwi delivers more vitamin C than an orange, giving your immune system a natural boost." },
      { icon: "🌾", title: "Digestive Health", desc: "Rich in dietary fiber and the actinidin enzyme, supporting smooth, healthy digestion." },
      { icon: "❤️", title: "Heart Friendly", desc: "High potassium content helps regulate blood pressure and supports heart function." },
      { icon: "🛡️", title: "Antioxidant Rich", desc: "Packed with polyphenols and carotenoids that fight everyday oxidative stress." },
      { icon: "⚖️", title: "Low Calorie", desc: "Naturally sweet with low sugar and calorie content — ideal for a balanced diet." },
      { icon: "✨", title: "Skin & Immunity", desc: "The Vitamin E and C combination promotes glowing skin and stronger immunity." },
    ],
  },
  quality: {
    tag: "Our Process",
    title: "Quality, Packaging & Cold-Chain Expertise",
    subtitle: "From orchard to destination port, every step is engineered to preserve freshness.",
    steps: [
      { number: "01", title: "Harvest & Sorting", desc: "Kiwis are hand-harvested at peak maturity and precision-sorted by size, firmness and brix level." },
      { number: "02", title: "Grading & Packing", desc: "Export-oriented packaging tailored to buyer specifications ensures protection and long shelf life." },
      { number: "03", title: "Pre-Cooling", desc: "Immediate pre-cooling and controlled cold storage lock in freshness before departure." },
      { number: "04", title: "Cold-Chain Shipping", desc: "Refrigerated containers maintain optimal temperature and humidity throughout the journey." },
      { number: "05", title: "Global Delivery", desc: "On-time, reliable delivery to wholesalers, importers and distributors worldwide." },
    ],
  },
  markets: {
    tag: "Global Reach",
    title: "Target Markets & Export Opportunities",
    subtitle: "Iran is among the world's prominent kiwi producers, with exports reaching every corner of the globe.",
    exportLabel: "Active Export Lane",
    regions: [
      { flag: "🌍", name: "Middle East", desc: "Strong demand across the Gulf and Levant for fresh, high-brix kiwi." },
      { flag: "🇪🇺", name: "Europe", desc: "Premium retailers seeking authentic, traceable orchard origin." },
      { flag: "🌏", name: "Asia & Far East", desc: "Fast-growing appetite for fresh green kiwi in retail and HORECA." },
      { flag: "🧭", name: "CIS & Caucasus", desc: "Established trade corridors with consistent seasonal volume." },
      { flag: "🕌", name: "Persian Gulf", desc: "Short transit routes enabling same-week farm-to-shelf delivery." },
      { flag: "🌴", name: "Africa", desc: "Emerging markets seeking reliable, quality-consistent suppliers." },
    ],
  },
  why: {
    tag: "Our Advantage",
    title: "Why Choose Arasb Kiwi",
    subtitle: "A trusted partner for wholesalers, importers, distributors and retail chains worldwide.",
    features: [
      { icon: "🌱", title: "Authentic Origin", desc: "100% Iranian-grown produce with traceable, authentic orchard origin." },
      { icon: "🔍", title: "Rigorous Quality Control", desc: "Every batch is precision-graded for visual, textural and flavor excellence." },
      { icon: "📦", title: "Flexible Packaging", desc: "Custom packaging solutions tailored to buyer specifications and regional requirements." },
      { icon: "✅", title: "Global Compliance", desc: "Meets international food safety, labeling and import standards." },
      { icon: "❄️", title: "Reliable Cold-Chain", desc: "Advanced logistics network ensuring freshness across long-distance shipping." },
      { icon: "🤝", title: "Trusted Partnerships", desc: "Trusted by gourmet retailers, high-end distributors and specialty markets worldwide." },
    ],
  },
  gallery: {
    tag: "Gallery",
    title: "A Glimpse Into Our Orchards & Packing Lines",
    subtitle: "Freshness you can see, quality you can trust.",
  },
  products: {
    tag: "Our Portfolio",
    title: "Beyond Kiwi — Authentic Iranian Treasures",
    subtitle: "We proudly export a curated range of premium Iranian agricultural products.",
    items: [
      { emoji: "🥝", name: "Hayward Kiwi", desc: "Bright green, tangy-sweet and vitamin-rich." },
      { emoji: "🌴", name: "Dates", desc: "Naturally sweet, hand-selected premium varieties." },
      { emoji: "🥜", name: "Pistachios", desc: "Roasted or raw, prized for rich flavor." },
      { emoji: "🌸", name: "Saffron", desc: "The world's finest, hand-harvested red gold." },
      { emoji: "🍎", name: "Apples", desc: "Crisp, juicy apples from northern orchards." },
    ],
  },
  contact: {
    tag: "Get In Touch",
    title: "Let's Start Your Kiwi Import Journey",
    subtitle: "Reach out for pricing, samples, and shipping schedules — our export team replies within 24 hours.",
    form: {
      name: "Full Name",
      email: "Email Address",
      phone: "Phone / WhatsApp",
      country: "Country",
      message: "Tell us about your order (quantity, packaging, destination port...)",
      submit: "Send Inquiry",
    },
    info: [
      { label: "Head Office", value: "Tehran, Iran" },
      { label: "Phone / WhatsApp", value: "+98 912 000 0000" },
      { label: "Email", value: "export@arasbtrading.com" },
      { label: "Working Hours", value: "Sat – Thu, 9:00 – 18:00 (GMT+3:30)" },
    ],
  },
  footer: {
    description:
      "Arasb Trading specializes in supplying premium fresh Iranian kiwi and agricultural products to wholesalers, importers and distributors worldwide.",
    quickLinks: "Quick Links",
    productsTitle: "Our Products",
    contactTitle: "Contact",
    rights: "All rights reserved.",
  },
};

export const fa: Content = {
  dir: "rtl",
  meta: { name: "کیوی آراسب" },
  nav: {
    home: "خانه",
    about: "درباره محصول",
    nutrition: "ارزش غذایی",
    quality: "کیفیت و بسته‌بندی",
    markets: "بازارهای هدف",
    why: "چرا ما",
    gallery: "گالری",
    products: "محصولات",
    contact: "تماس با ما",
    cta: "درخواست قیمت",
  },
  hero: {
    badge: "صادرات ممتاز ایرانی",
    title1: "کیوی هایوارد،",
    title2: "پرورش‌یافته زیر آفتاب شمال ایران",
    subtitle:
      "میوه‌ی کیوی تازه، سبز و درخشان و سرشار از ویتامین؛ برداشت‌شده از باغ‌های سرسبز شمال ایران و ارسال‌شده به سراسر جهان با زنجیره‌ی سرمایشی پیشرفته.",
    ctaPrimary: "درخواست قیمت",
    ctaSecondary: "معرفی محصول",
    scrollHint: "برای مشاهده بیشتر اسکرول کنید",
    stats: [
      { value: "+۲۰", label: "کشور صادراتی" },
      { value: "+۵۰۰۰", label: "تن صادرات سالانه" },
      { value: "+۱۵", label: "سال تجربه" },
      { value: "۱۰۰٪", label: "پوشش زنجیره سرد" },
    ],
  },
  marquee: [
    "کیوی تازه هایوارد",
    "باغ‌های شمال ایران",
    "زنجیره تأمین سرد",
    "بسته‌بندی صادراتی",
    "سرشار از ویتامین ث",
    "ارسال به سراسر جهان",
  ],
  about: {
    tag: "درباره محصول",
    title: "گوهر سبز طبیعت، پرورش‌یافته در خاک ایران",
    p1: "کیوی ایرانی به دلیل رنگ سبز درخشان، طعم ترش‌وشیرین دلپذیر و پروفایل تغذیه‌ای برجسته، روزبه‌روز جایگاه بیشتری در بازارهای جهانی پیدا می‌کند.",
    p2: "این محصول در مناطق حاصلخیز شمال ایران و در شرایط اقلیمی ایده‌آل—زمستان‌های ملایم، تابستان‌های مرطوب و خاک آبرفتی غنی—پرورش می‌یابد. کیوی‌های صادراتی ما کیفیت و تازگی یکنواختی را ارائه می‌دهند که با استانداردهای بین‌المللی مطابقت دارد. ایران یکی از تولیدکنندگان برتر کیوی در جهان است و صادرات آن به آسیا، خاورمیانه، اروپا و فراتر از آن می‌رسد.",
    bullets: [
      "انتخاب دستی بر اساس اندازه، سفتی و میزان قند",
      "برداشت‌شده در بهترین زمان رسیدگی برای سفرهای صادراتی",
      "پرورش‌یافته با روش‌های کشاورزی پایدار",
      "سرشار از ویتامین ث، فیبر غذایی و آنتی‌اکسیدان",
    ],
    imgCaption: "برداشت‌شده در باغ‌های گیلان و مازندران",
  },
  nutrition: {
    tag: "سلامت و تغذیه",
    title: "میوه‌ای کوچک، فوایدی بزرگ",
    subtitle: "کیوی یکی از پرارزش‌ترین میوه‌ها از نظر تغذیه‌ای در جهان است؛ دُز روزانه‌ای از ویتامین در طعمی طبیعی و دلپذیر.",
    items: [
      { icon: "🍊", title: "منبع غنی ویتامین ث", desc: "یک عدد کیوی ویتامین ث بیشتری نسبت به پرتقال دارد و سیستم ایمنی بدن را تقویت می‌کند." },
      { icon: "🌾", title: "سلامت دستگاه گوارش", desc: "سرشار از فیبر غذایی و آنزیم اکتینیدین، که به هضم سالم کمک می‌کند." },
      { icon: "❤️", title: "دوستدار قلب", desc: "پتاسیم بالا به تنظیم فشار خون و عملکرد قلب کمک می‌کند." },
      { icon: "🛡️", title: "غنی از آنتی‌اکسیدان", desc: "سرشار از پلی‌فنول‌ها و کاروتنوئیدها که با استرس اکسیداتیو مقابله می‌کنند." },
      { icon: "⚖️", title: "کالری پایین", desc: "طعم شیرین طبیعی با قند و کالری کم؛ مناسب برای رژیم متعادل." },
      { icon: "✨", title: "پوست و ایمنی", desc: "ترکیب ویتامین ث و ای به داشتن پوستی شاداب و ایمنی قوی‌تر کمک می‌کند." },
    ],
  },
  quality: {
    tag: "فرآیند ما",
    title: "کیفیت، بسته‌بندی و تخصص زنجیره سرد",
    subtitle: "از باغ تا بندر مقصد، هر مرحله برای حفظ تازگی محصول طراحی شده است.",
    steps: [
      { number: "۰۱", title: "برداشت و درجه‌بندی", desc: "کیوی‌ها در اوج رسیدگی به‌صورت دستی برداشت و بر اساس اندازه، سفتی و میزان بریکس دقیقاً درجه‌بندی می‌شوند." },
      { number: "۰۲", title: "بسته‌بندی صادراتی", desc: "بسته‌بندی متناسب با نیاز خریدار، محافظت و ماندگاری بالا را تضمین می‌کند." },
      { number: "۰۳", title: "پیش‌سرمایش", desc: "پیش‌سرمایش فوری و نگهداری در سردخانه کنترل‌شده، تازگی را پیش از ارسال حفظ می‌کند." },
      { number: "۰۴", title: "حمل زنجیره سرد", desc: "کانتینرهای یخچالی دما و رطوبت مطلوب را در طول مسیر حفظ می‌کنند." },
      { number: "۰۵", title: "تحویل جهانی", desc: "تحویل به‌موقع و مطمئن به عمده‌فروشان، واردکنندگان و توزیع‌کنندگان در سراسر جهان." },
    ],
  },
  markets: {
    tag: "حضور جهانی",
    title: "بازارهای هدف و فرصت‌های صادراتی",
    subtitle: "ایران یکی از تولیدکنندگان برجسته کیوی در جهان است و صادرات آن به تمام نقاط جهان می‌رسد.",
    exportLabel: "مسیر فعال صادراتی",
    regions: [
      { flag: "🌍", name: "خاورمیانه", desc: "تقاضای بالا در خلیج فارس و شام برای کیوی تازه و پُربریکس." },
      { flag: "🇪🇺", name: "اروپا", desc: "خرده‌فروشان پریمیوم به‌دنبال منشأ اصیل و قابل ردیابی." },
      { flag: "🌏", name: "آسیا و خاور دور", desc: "افزایش سریع تقاضا برای کیوی سبز تازه در خرده‌فروشی و هورکا." },
      { flag: "🧭", name: "کشورهای مستقل مشترک‌المنافع و قفقاز", desc: "کریدورهای تجاری تثبیت‌شده با حجم فصلی پایدار." },
      { flag: "🕌", name: "خلیج فارس", desc: "مسیرهای حمل کوتاه که امکان تحویل هفته‌ای مزرعه تا قفسه را می‌دهد." },
      { flag: "🌴", name: "آفریقا", desc: "بازارهای نوظهور به‌دنبال تأمین‌کنندگانی مطمئن و باکیفیت ثابت." },
    ],
  },
  why: {
    tag: "مزیت ما",
    title: "چرا کیوی آراسب را انتخاب کنیم",
    subtitle: "شریکی مورد اعتماد برای عمده‌فروشان، واردکنندگان، توزیع‌کنندگان و زنجیره‌های خرده‌فروشی در سراسر جهان.",
    features: [
      { icon: "🌱", title: "منشأ اصیل", desc: "محصولی صددرصد ایرانی با منشأ باغی قابل ردیابی و اصیل." },
      { icon: "🔍", title: "کنترل کیفیت دقیق", desc: "هر محموله از نظر ظاهر، بافت و طعم به‌دقت درجه‌بندی می‌شود." },
      { icon: "📦", title: "بسته‌بندی انعطاف‌پذیر", desc: "راهکارهای بسته‌بندی سفارشی متناسب با نیاز خریدار و منطقه." },
      { icon: "✅", title: "انطباق با استانداردهای جهانی", desc: "مطابق با استانداردهای بین‌المللی ایمنی غذا، برچسب‌گذاری و واردات." },
      { icon: "❄️", title: "زنجیره سرد مطمئن", desc: "شبکه لجستیک پیشرفته که تازگی را در مسافت‌های طولانی تضمین می‌کند." },
      { icon: "🤝", title: "همکاری مورد اعتماد", desc: "مورد اعتماد خرده‌فروشان لوکس، توزیع‌کنندگان و بازارهای تخصصی جهان." },
    ],
  },
  gallery: {
    tag: "گالری",
    title: "نگاهی به باغ‌ها و خطوط بسته‌بندی ما",
    subtitle: "تازگی‌ای که می‌بینید، کیفیتی که به آن اعتماد می‌کنید.",
  },
  products: {
    tag: "سبد محصولات",
    title: "فراتر از کیوی — گنجینه‌های اصیل ایرانی",
    subtitle: "ما با افتخار طیف منتخبی از محصولات کشاورزی ممتاز ایرانی را صادر می‌کنیم.",
    items: [
      { emoji: "🥝", name: "کیوی هایوارد", desc: "سبز درخشان، ترش‌وشیرین و سرشار از ویتامین." },
      { emoji: "🌴", name: "خرما", desc: "شیرینی طبیعی، انواع ممتاز و منتخب دستی." },
      { emoji: "🥜", name: "پسته", desc: "برشته یا خام، مشهور به طعم غنی." },
      { emoji: "🌸", name: "زعفران", desc: "طلای سرخ ناب جهان، برداشت‌شده به‌صورت دستی." },
      { emoji: "🍎", name: "سیب", desc: "سیب‌های ترد و آبدار از باغ‌های شمال." },
    ],
  },
  contact: {
    tag: "در تماس باشید",
    title: "سفر واردات کیوی خود را آغاز کنید",
    subtitle: "برای استعلام قیمت، نمونه محصول و برنامه حمل با ما تماس بگیرید — تیم صادرات ما ظرف ۲۴ ساعت پاسخ می‌دهد.",
    form: {
      name: "نام و نام خانوادگی",
      email: "آدرس ایمیل",
      phone: "تلفن / واتساپ",
      country: "کشور",
      message: "درباره سفارش خود بگویید (مقدار، بسته‌بندی، بندر مقصد...)",
      submit: "ارسال درخواست",
    },
    info: [
      { label: "دفتر مرکزی", value: "تهران، ایران" },
      { label: "تلفن / واتساپ", value: "۰۰۹۸۹۱۲۰۰۰۰۰۰۰" },
      { label: "ایمیل", value: "export@arasbtrading.com" },
      { label: "ساعات کاری", value: "شنبه تا پنجشنبه، ۹:۰۰ تا ۱۸:۰۰" },
    ],
  },
  footer: {
    description:
      "شرکت بازرگانی آراسب متخصص تأمین کیوی تازه و محصولات کشاورزی ممتاز ایرانی برای عمده‌فروشان، واردکنندگان و توزیع‌کنندگان در سراسر جهان است.",
    quickLinks: "دسترسی سریع",
    productsTitle: "محصولات ما",
    contactTitle: "تماس",
    rights: "کلیه حقوق محفوظ است.",
  },
};

export const ar: Content = {
  dir: "rtl",
  meta: { name: "كيوي أراسب" },
  nav: {
    home: "الرئيسية",
    about: "عن المنتج",
    nutrition: "القيمة الغذائية",
    quality: "الجودة والتغليف",
    markets: "الأسواق المستهدفة",
    why: "لماذا نحن",
    gallery: "معرض الصور",
    products: "منتجاتنا",
    contact: "تواصل معنا",
    cta: "اطلب عرض سعر",
  },
  hero: {
    badge: "تصدير إيراني ممتاز",
    title1: "كيوي هايوارد،",
    title2: "ينمو تحت شمس شمال إيران",
    subtitle:
      "فاكهة كيوي طازجة، خضراء زاهية وغنية بالفيتامينات، تُقطف يدويًا من بساتين شمال إيران الخصبة وتُصدَّر إلى جميع أنحاء العالم عبر سلسلة تبريد متطورة.",
    ctaPrimary: "اطلب عرض سعر",
    ctaSecondary: "اكتشف المنتج",
    scrollHint: "مرر للأسفل للاكتشاف",
    stats: [
      { value: "+20", label: "دولة تصدير" },
      { value: "+5,000", label: "طن يُشحن سنويًا" },
      { value: "+15", label: "سنة خبرة" },
      { value: "100%", label: "تغطية سلسلة التبريد" },
    ],
  },
  marquee: [
    "كيوي هايوارد الطازج",
    "بساتين شمال إيران",
    "سلسلة تبريد متكاملة",
    "تغليف بمعايير التصدير",
    "غني بفيتامين سي",
    "توصيل عالمي",
  ],
  about: {
    tag: "عن المنتج",
    title: "جوهرة الطبيعة الخضراء، صقلتها تربة إيران",
    p1: "أصبحت فاكهة الكيوي الإيرانية معروفة بشكل متزايد في الأسواق العالمية بفضل لونها الأخضر الزاهي، ونكهتها الحلوة الحامضة، وقيمتها الغذائية المتميزة.",
    p2: "تُزرع في المناطق الشمالية الخصبة من إيران في ظل ظروف مناخية مثالية — شتاء معتدل وصيف رطب وتربة طينية غنية — لتقدّم كيوي بمعايير تصدير تتميز بجودة وطزاجة ثابتة تلبي المعايير الدولية. تُعد إيران من أبرز الدول المنتجة للكيوي في العالم، وتصل صادراتها إلى آسيا والشرق الأوسط وأوروبا وما وراءها.",
    bullets: [
      "اختيار يدوي دقيق حسب الحجم والصلابة ونسبة السكر",
      "يُقطف في مرحلة النضج المثلى لتحمل رحلة التصدير",
      "يُزرع باتباع ممارسات زراعية مستدامة",
      "غني بفيتامين سي والألياف الغذائية ومضادات الأكسدة",
    ],
    imgCaption: "يُقطف يدويًا من بساتين كيلان ومازندران",
  },
  nutrition: {
    tag: "الصحة والتغذية",
    title: "فاكهة صغيرة، فوائد عظيمة",
    subtitle: "الكيوي من أغنى الفواكه بالعناصر الغذائية على وجه الأرض — جرعة يومية من الفيتامينات بنكهة حلوة حامضة طبيعية.",
    items: [
      { icon: "🍊", title: "مصدر غني بفيتامين سي", desc: "حبة كيوي واحدة توفر فيتامين سي أكثر من البرتقالة، لتعزيز المناعة بشكل طبيعي." },
      { icon: "🌾", title: "صحة الجهاز الهضمي", desc: "غني بالألياف الغذائية وإنزيم الأكتينيدين، مما يدعم هضمًا صحيًا وسلسًا." },
      { icon: "❤️", title: "مفيد لصحة القلب", desc: "ارتفاع نسبة البوتاسيوم يساعد على تنظيم ضغط الدم ووظائف القلب." },
      { icon: "🛡️", title: "غني بمضادات الأكسدة", desc: "مليء بالبوليفينول والكاروتينات التي تحارب الإجهاد التأكسدي اليومي." },
      { icon: "⚖️", title: "قليل السعرات", desc: "حلو المذاق طبيعيًا وبسعرات وسكريات منخفضة — مثالي لنظام غذائي متوازن." },
      { icon: "✨", title: "للبشرة والمناعة", desc: "مزيج فيتامين سي وإي يمنح بشرة نضرة ومناعة أقوى." },
    ],
  },
  quality: {
    tag: "عملياتنا",
    title: "الجودة والتغليف وخبرة سلسلة التبريد",
    subtitle: "من البستان إلى ميناء الوجهة، كل خطوة مصممة للحفاظ على الطزاجة.",
    steps: [
      { number: "01", title: "الحصاد والفرز", desc: "يُقطف الكيوي يدويًا في ذروة النضج ويُفرز بدقة حسب الحجم والصلابة ونسبة السكر." },
      { number: "02", title: "التدريج والتعبئة", desc: "تغليف موجه للتصدير ومصمم وفق مواصفات المشتري لضمان الحماية وطول مدة الصلاحية." },
      { number: "03", title: "التبريد المسبق", desc: "تبريد فوري وتخزين بارد مضبوط يحافظان على الطزاجة قبل الشحن." },
      { number: "04", title: "الشحن بسلسلة التبريد", desc: "حاويات مبردة تحافظ على درجة الحرارة والرطوبة المثلى طوال الرحلة." },
      { number: "05", title: "التوصيل العالمي", desc: "تسليم موثوق وفي الوقت المحدد لتجار الجملة والمستوردين والموزعين حول العالم." },
    ],
  },
  markets: {
    tag: "انتشار عالمي",
    title: "الأسواق المستهدفة وفرص التصدير",
    subtitle: "تُعد إيران من أبرز الدول المنتجة للكيوي في العالم، وتصل صادراتها إلى كل ركن من أركان العالم.",
    exportLabel: "مسار تصدير نشط",
    regions: [
      { flag: "🌍", name: "الشرق الأوسط", desc: "طلب قوي في الخليج وبلاد الشام على الكيوي الطازج عالي السكر." },
      { flag: "🇪🇺", name: "أوروبا", desc: "تجار تجزئة راقون يبحثون عن منشأ بستاني أصيل وقابل للتتبع." },
      { flag: "🌏", name: "آسيا والشرق الأقصى", desc: "طلب متنامٍ بسرعة على الكيوي الأخضر الطازج في التجزئة والضيافة." },
      { flag: "🧭", name: "دول رابطة الدول المستقلة والقوقاز", desc: "ممرات تجارية راسخة بحجم موسمي ثابت." },
      { flag: "🕌", name: "الخليج الفارسي", desc: "مسارات شحن قصيرة تتيح التوصيل من المزرعة إلى الرف خلال أسبوع." },
      { flag: "🌴", name: "أفريقيا", desc: "أسواق ناشئة تبحث عن موردين موثوقين وبجودة ثابتة." },
    ],
  },
  why: {
    tag: "ميزتنا",
    title: "لماذا تختار كيوي أراسب",
    subtitle: "شريك موثوق لتجار الجملة والمستوردين والموزعين وسلاسل التجزئة حول العالم.",
    features: [
      { icon: "🌱", title: "منشأ أصيل", desc: "منتج إيراني 100% بمنشأ بستاني أصيل وقابل للتتبع." },
      { icon: "🔍", title: "رقابة جودة صارمة", desc: "يُدرَّج كل شحنة بدقة من حيث المظهر والقوام والنكهة." },
      { icon: "📦", title: "تغليف مرن", desc: "حلول تغليف مخصصة تناسب مواصفات المشتري ومتطلبات المنطقة." },
      { icon: "✅", title: "امتثال عالمي", desc: "مطابق لمعايير سلامة الغذاء والتوسيم والاستيراد الدولية." },
      { icon: "❄️", title: "سلسلة تبريد موثوقة", desc: "شبكة لوجستية متطورة تضمن الطزاجة عبر الشحن لمسافات طويلة." },
      { icon: "🤝", title: "شراكات موثوقة", desc: "موثوق به من قبل متاجر التجزئة الفاخرة والموزعين والأسواق المتخصصة عالميًا." },
    ],
  },
  gallery: {
    tag: "معرض الصور",
    title: "لمحة عن بساتيننا وخطوط التعبئة",
    subtitle: "طزاجة تراها بعينك، وجودة تثق بها.",
  },
  products: {
    tag: "مجموعتنا",
    title: "أبعد من الكيوي — كنوز إيرانية أصيلة",
    subtitle: "نفخر بتصدير مجموعة مختارة من المنتجات الزراعية الإيرانية الفاخرة.",
    items: [
      { emoji: "🥝", name: "كيوي هايوارد", desc: "أخضر زاهٍ، حلو حامض وغني بالفيتامينات." },
      { emoji: "🌴", name: "التمور", desc: "حلاوة طبيعية، أصناف فاخرة مختارة يدويًا." },
      { emoji: "🥜", name: "الفستق", desc: "محمص أو نيء، مشهور بنكهته الغنية." },
      { emoji: "🌸", name: "الزعفران", desc: "الذهب الأحمر الأنقى في العالم، يُحصد يدويًا." },
      { emoji: "🍎", name: "التفاح", desc: "تفاح مقرمش وعصيري من بساتين الشمال." },
    ],
  },
  contact: {
    tag: "تواصل معنا",
    title: "لنبدأ رحلة استيراد الكيوي الخاصة بك",
    subtitle: "تواصل معنا لمعرفة الأسعار والحصول على عينات وجداول الشحن — يرد فريق التصدير خلال 24 ساعة.",
    form: {
      name: "الاسم الكامل",
      email: "البريد الإلكتروني",
      phone: "الهاتف / واتساب",
      country: "الدولة",
      message: "أخبرنا عن طلبك (الكمية، التغليف، ميناء الوجهة...)",
      submit: "إرسال الطلب",
    },
    info: [
      { label: "المكتب الرئيسي", value: "طهران، إيران" },
      { label: "الهاتف / واتساب", value: "0098912000000+" },
      { label: "البريد الإلكتروني", value: "export@arasbtrading.com" },
      { label: "ساعات العمل", value: "السبت – الخميس، 9:00 – 18:00" },
    ],
  },
  footer: {
    description:
      "تختص شركة أراسب التجارية بتوريد الكيوي الإيراني الطازج والمنتجات الزراعية الفاخرة لتجار الجملة والمستوردين والموزعين حول العالم.",
    quickLinks: "روابط سريعة",
    productsTitle: "منتجاتنا",
    contactTitle: "تواصل",
    rights: "جميع الحقوق محفوظة.",
  },
};

export const translations: Record<LangCode, Content> = { en, ar, fa };

export const languageLabels: Record<LangCode, { native: string; flag: string }> = {
  en: { native: "English", flag: "🇬🇧" },
  ar: { native: "العربية", flag: "🇸🇦" },
  fa: { native: "فارسی", flag: "🇮🇷" },
};
