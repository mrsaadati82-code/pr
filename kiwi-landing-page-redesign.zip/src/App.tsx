import { useEffect, useState } from "react";
import { translations, type LangCode } from "./i18n/translations";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import About from "./components/About";
import Nutrition from "./components/Nutrition";
import Quality from "./components/Quality";
import Markets from "./components/Markets";
import WhyUs from "./components/WhyUs";
import Gallery from "./components/Gallery";
import Products from "./components/Products";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  const [lang, setLang] = useState<LangCode>("en");
  const t = translations[lang];
  const isRTL = t.dir === "rtl";

  useEffect(() => {
    document.documentElement.setAttribute("lang", lang);
    document.documentElement.setAttribute("dir", t.dir);
    document.body.setAttribute("data-dir", t.dir);
  }, [lang, t.dir]);

  return (
    <div className="min-h-screen bg-[#0e1b0f] text-white antialiased" dir={t.dir}>
      <Navbar t={t} lang={lang} setLang={setLang} isRTL={isRTL} />
      <Hero t={t} />
      <Marquee t={t} isRTL={isRTL} />
      <About t={t} isRTL={isRTL} />
      <Nutrition t={t} />
      <Quality t={t} isRTL={isRTL} />
      <Markets t={t} />
      <WhyUs t={t} />
      <Gallery t={t} />
      <Products t={t} />
      <Contact t={t} />
      <Footer t={t} />
    </div>
  );
}
