import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import Reveal from "./Reveal";

export default function Nutrition({ t }: { t: Content }) {
  return (
    <section id="nutrition" className="relative bg-[#0a140a] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.nutrition.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.nutrition.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.nutrition.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {t.nutrition.items.map((item, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <motion.div
                whileHover={{ y: -8, borderColor: "rgba(163,230,53,0.4)" }}
                className="group h-full rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-6 transition-colors"
              >
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-lime-400/10 text-3xl transition-transform group-hover:scale-110 group-hover:rotate-6">
                  {item.icon}
                </div>
                <h3 className="text-lg font-bold text-white">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/60">{item.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
