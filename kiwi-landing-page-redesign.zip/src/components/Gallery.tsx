import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import { images } from "../constants/images";
import Reveal from "./Reveal";

export default function Gallery({ t }: { t: Content }) {
  return (
    <section id="gallery" className="relative bg-[#0a140a] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.gallery.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.gallery.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.gallery.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 columns-2 gap-4 sm:columns-3 lg:columns-4 [&>*]:mb-4">
          {images.gallery.map((src, i) => (
            <Reveal key={i} delay={(i % 4) * 0.08} className="break-inside-avoid">
              <motion.div
                whileHover={{ scale: 1.03 }}
                className="group relative overflow-hidden rounded-2xl border border-white/10"
              >
                <img
                  src={src}
                  alt="Kiwi orchard and packing gallery"
                  className={`w-full object-cover transition duration-500 group-hover:scale-110 ${
                    i % 3 === 0 ? "h-72" : i % 3 === 1 ? "h-56" : "h-64"
                  }`}
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 transition group-hover:opacity-100" />
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
