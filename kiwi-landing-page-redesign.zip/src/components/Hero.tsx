import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import type { Content } from "../i18n/translations";
import { images } from "../constants/images";

export default function Hero({ t }: { t: Content }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const imgY = useTransform(scrollYProgress, [0, 1], [0, 90]);

  return (
    <section
      id="home"
      ref={ref}
      className="relative flex min-h-screen items-center overflow-hidden bg-[#0e1b0f] pt-24"
    >
      {/* Background layers */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#13260f] via-[#0e1b0f] to-[#0a140a]" />
      <div className="bg-noise absolute inset-0 opacity-40" />
      <div className="absolute -top-40 -left-40 h-[32rem] w-[32rem] rounded-full bg-lime-500/20 blur-[120px]" />
      <div className="absolute -bottom-40 -right-20 h-[28rem] w-[28rem] rounded-full bg-emerald-600/20 blur-[120px]" />

      {/* Floating kiwi slices */}
      <motion.div
        style={{ y }}
        className="pointer-events-none absolute end-[6%] top-[18%] hidden h-24 w-24 rounded-full bg-[radial-gradient(circle_at_center,#d7e89a_0%,#8bc34a_55%,#33691e_100%)] shadow-2xl md:block animate-float-slow"
      >
        <div className="absolute inset-3 rounded-full bg-[#eef3d0] opacity-90" />
        <div className="absolute inset-[38%] rounded-full bg-[#4a3413]" />
      </motion.div>
      <motion.div
        style={{ y: imgY }}
        className="pointer-events-none absolute start-[8%] bottom-[12%] hidden h-16 w-16 rounded-full bg-[radial-gradient(circle_at_center,#d7e89a_0%,#8bc34a_55%,#33691e_100%)] opacity-80 shadow-xl md:block animate-float-slower"
      />
      <div className="pointer-events-none absolute end-[20%] bottom-[8%] hidden h-10 w-10 rounded-full border-2 border-lime-300/40 md:block animate-spin-slow" />

      <div className="relative z-10 mx-auto grid max-w-7xl grid-cols-1 items-center gap-14 px-5 lg:grid-cols-2 lg:px-8">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-lime-400/30 bg-lime-400/10 px-4 py-1.5 text-sm font-medium text-lime-300"
          >
            <span className="h-2 w-2 animate-pulse rounded-full bg-lime-400" />
            {t.hero.badge}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl font-extrabold leading-[1.15] text-white sm:text-5xl lg:text-6xl"
          >
            {t.hero.title1}{" "}
            <span className="text-gradient-kiwi">{t.hero.title2}</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-white/70"
          >
            {t.hero.subtitle}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="rounded-full bg-gradient-to-r from-lime-400 to-green-600 px-7 py-3.5 font-semibold text-[#0e1b0f] shadow-xl shadow-lime-900/40 transition hover:scale-105"
            >
              {t.hero.ctaPrimary}
            </a>
            <a
              href="#about"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById("about")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="rounded-full border border-white/20 px-7 py-3.5 font-semibold text-white transition hover:border-lime-400/60 hover:text-lime-300"
            >
              {t.hero.ctaSecondary}
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-14 grid grid-cols-2 gap-6 sm:grid-cols-4"
          >
            {t.hero.stats.map((s, i) => (
              <div key={i} className="border-s-2 border-lime-500/40 ps-3">
                <div className="text-2xl font-extrabold text-white sm:text-3xl">{s.value}</div>
                <div className="mt-1 text-xs text-white/50 sm:text-sm">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.2 }}
          style={{ opacity }}
          className="relative mx-auto w-full max-w-md lg:max-w-lg"
        >
          <div className="absolute inset-0 -z-10 rounded-full bg-lime-400/25 blur-[80px]" />
          <motion.div style={{ y: imgY }} className="relative overflow-hidden rounded-[2.5rem] border border-white/10 shadow-2xl shadow-black/50">
            <img
              src={images.heroKiwi}
              alt="Fresh premium kiwi"
              className="h-[420px] w-full object-cover sm:h-[500px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e1b0f]/70 via-transparent to-transparent" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="absolute -bottom-8 start-1/2 w-[85%] -translate-x-1/2 rounded-2xl border border-white/10 bg-[#132217]/90 p-4 backdrop-blur-xl"
          >
            <div className="flex items-center gap-3">
              <img src={images.heroSliced} alt="" className="h-12 w-12 rounded-xl object-cover" />
              <div>
                <div className="text-sm font-semibold text-white">Hayward Grade A</div>
                <div className="text-xs text-white/50">100% Iranian Origin</div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/40 sm:flex"
      >
        <span className="text-xs tracking-wide">{t.hero.scrollHint}</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 5v14M5 12l7 7 7-7" />
        </svg>
      </motion.div>
    </section>
  );
}
