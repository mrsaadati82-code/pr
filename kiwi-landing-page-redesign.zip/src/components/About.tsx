import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import { images } from "../constants/images";
import Reveal from "./Reveal";

export default function About({ t, isRTL }: { t: Content; isRTL: boolean }) {
  return (
    <section id="about" className="relative overflow-hidden bg-[#0e1b0f] py-24 sm:py-32">
      <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-[#132217] to-transparent" />
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-5 lg:grid-cols-2 lg:px-8">
        <Reveal direction={isRTL ? "right" : "left"} className="relative">
          <div className="relative">
            <div className="absolute -inset-6 -z-10 rounded-[2.5rem] bg-gradient-to-br from-lime-500/20 to-emerald-800/10 blur-2xl" />
            <div className="overflow-hidden rounded-[2rem] border border-white/10 shadow-2xl">
              <img src={images.orchardAerial} alt="Kiwi orchard in Northern Iran" className="h-[420px] w-full object-cover sm:h-[480px]" />
            </div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="absolute -bottom-10 end-4 w-56 overflow-hidden rounded-2xl border border-white/10 bg-[#132217]/90 p-3 shadow-xl backdrop-blur-lg sm:end-8"
            >
              <img src={images.heroSliced} alt="" className="mb-2 h-24 w-full rounded-xl object-cover" />
              <p className="text-xs text-white/70">{t.about.imgCaption}</p>
            </motion.div>
          </div>
        </Reveal>

        <div>
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.about.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl lg:text-[2.6rem] lg:leading-tight">
              {t.about.title}
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-6 leading-relaxed text-white/70">{t.about.p1}</p>
          </Reveal>
          <Reveal delay={0.3}>
            <p className="mt-4 leading-relaxed text-white/60">{t.about.p2}</p>
          </Reveal>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {t.about.bullets.map((b, i) => (
              <Reveal key={i} delay={0.35 + i * 0.08}>
                <div className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
                  <span className="mt-0.5 flex h-6 w-6 flex-none items-center justify-center rounded-full bg-lime-400/20 text-lime-300">
                    ✓
                  </span>
                  <span className="text-sm text-white/75">{b}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
