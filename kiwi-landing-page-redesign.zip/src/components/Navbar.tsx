import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Content, LangCode } from "../i18n/translations";
import { languageLabels } from "../i18n/translations";

interface NavbarProps {
  t: Content;
  lang: LangCode;
  setLang: (l: LangCode) => void;
  isRTL: boolean;
}

export default function Navbar({ t, lang, setLang, isRTL }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { id: "home", label: t.nav.home },
    { id: "about", label: t.nav.about },
    { id: "nutrition", label: t.nav.nutrition },
    { id: "quality", label: t.nav.quality },
    { id: "markets", label: t.nav.markets },
    { id: "why", label: t.nav.why },
    { id: "gallery", label: t.nav.gallery },
    { id: "contact", label: t.nav.contact },
  ];

  const scrollTo = (id: string) => {
    setOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-[#0e1b0f]/90 backdrop-blur-lg shadow-lg shadow-black/20 py-2" : "bg-transparent py-4"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 lg:px-8">
        <button
          onClick={() => scrollTo("home")}
          className="flex items-center gap-2 text-lg font-extrabold text-white"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-lime-300 to-green-700 text-lg shadow-lg shadow-lime-900/40">
            🥝
          </span>
          <span className="tracking-tight">
            Aras<span className="text-gradient-kiwi">b</span> Kiwi
          </span>
        </button>

        <nav className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <button
              key={l.id}
              onClick={() => scrollTo(l.id)}
              className="text-sm font-medium text-white/80 transition-colors hover:text-lime-300"
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="relative hidden sm:block">
            <button
              onClick={() => setLangOpen((v) => !v)}
              className="flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-sm text-white transition hover:border-lime-400/50"
            >
              <span>{languageLabels[lang].flag}</span>
              <span>{languageLabels[lang].native}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 9l6 6 6-6" />
              </svg>
            </button>
            <AnimatePresence>
              {langOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className={`absolute ${isRTL ? "left-0" : "right-0"} mt-2 w-36 overflow-hidden rounded-xl border border-white/10 bg-[#132217] shadow-xl`}
                >
                  {(Object.keys(languageLabels) as LangCode[]).map((code) => (
                    <button
                      key={code}
                      onClick={() => {
                        setLang(code);
                        setLangOpen(false);
                      }}
                      className={`flex w-full items-center gap-2 px-4 py-2.5 text-sm hover:bg-lime-500/10 ${
                        lang === code ? "text-lime-300" : "text-white/80"
                      }`}
                    >
                      <span>{languageLabels[code].flag}</span>
                      <span>{languageLabels[code].native}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button
            onClick={() => scrollTo("contact")}
            className="hidden rounded-full bg-gradient-to-r from-lime-400 to-green-600 px-5 py-2 text-sm font-semibold text-[#0e1b0f] shadow-lg shadow-lime-900/30 transition hover:scale-105 hover:shadow-lime-500/40 md:inline-block"
          >
            {t.nav.cta}
          </button>

          <button
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white lg:hidden"
            aria-label="Menu"
          >
            {open ? (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 7h16M4 12h16M4 17h16" />
              </svg>
            )}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden bg-[#0e1b0f]/95 backdrop-blur-lg lg:hidden"
          >
            <div className="flex flex-col gap-1 px-5 pb-5 pt-2">
              {links.map((l) => (
                <button
                  key={l.id}
                  onClick={() => scrollTo(l.id)}
                  className="rounded-lg px-3 py-2.5 text-start text-white/85 hover:bg-white/5"
                >
                  {l.label}
                </button>
              ))}
              <div className="mt-2 flex gap-2">
                {(Object.keys(languageLabels) as LangCode[]).map((code) => (
                  <button
                    key={code}
                    onClick={() => setLang(code)}
                    className={`flex-1 rounded-lg border px-3 py-2 text-sm ${
                      lang === code ? "border-lime-400 text-lime-300" : "border-white/15 text-white/70"
                    }`}
                  >
                    {languageLabels[code].flag} {languageLabels[code].native}
                  </button>
                ))}
              </div>
              <button
                onClick={() => scrollTo("contact")}
                className="mt-3 rounded-full bg-gradient-to-r from-lime-400 to-green-600 px-5 py-2.5 text-sm font-semibold text-[#0e1b0f]"
              >
                {t.nav.cta}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
