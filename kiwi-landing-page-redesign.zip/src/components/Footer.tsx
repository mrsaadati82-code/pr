import type { Content } from "../i18n/translations";

export default function Footer({ t }: { t: Content }) {
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <footer className="relative border-t border-white/10 bg-[#0e1b0f] pt-16">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid grid-cols-1 gap-10 pb-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2 text-lg font-extrabold text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-lime-300 to-green-700 text-lg">
                🥝
              </span>
              Arasb Kiwi
            </div>
            <p className="text-sm leading-relaxed text-white/55">{t.footer.description}</p>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wide text-lime-300/80">{t.footer.quickLinks}</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              {[
                { id: "about", label: t.nav.about },
                { id: "quality", label: t.nav.quality },
                { id: "markets", label: t.nav.markets },
                { id: "gallery", label: t.nav.gallery },
              ].map((l) => (
                <li key={l.id}>
                  <button onClick={() => scrollTo(l.id)} className="transition hover:text-lime-300">
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wide text-lime-300/80">{t.footer.productsTitle}</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              {t.products.items.map((p, i) => (
                <li key={i} className="flex items-center gap-2">
                  <span>{p.emoji}</span> {p.name}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-bold uppercase tracking-wide text-lime-300/80">{t.footer.contactTitle}</h4>
            <ul className="space-y-2.5 text-sm text-white/60">
              {t.contact.info.slice(0, 3).map((info, i) => (
                <li key={i}>{info.value}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-3 border-t border-white/10 py-6 text-xs text-white/40 sm:flex-row">
          <p>© {new Date().getFullYear()} Arasb Trading. {t.footer.rights}</p>
          <p>{t.meta.name}</p>
        </div>
      </div>
    </footer>
  );
}
