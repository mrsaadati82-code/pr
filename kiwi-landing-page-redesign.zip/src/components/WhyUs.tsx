import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import Reveal from "./Reveal";

export default function WhyUs({ t }: { t: Content }) {
  return (
    <section id="why" className="relative bg-[#0e1b0f] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.why.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.why.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.why.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-white/10 bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
          {t.why.features.map((f, i) => (
            <Reveal key={i} delay={i * 0.06} className="h-full">
              <motion.div
                whileHover={{ backgroundColor: "rgba(163,230,53,0.06)" }}
                className="h-full bg-[#0e1b0f] p-8"
              >
                <div className="mb-4 text-3xl">{f.icon}</div>
                <h3 className="text-lg font-bold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/60">{f.desc}</p>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
