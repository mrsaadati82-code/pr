import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import Reveal from "./Reveal";

export default function Products({ t }: { t: Content }) {
  return (
    <section id="products" className="relative bg-[#0e1b0f] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.products.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.products.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.products.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-5">
          {t.products.items.map((p, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <motion.div
                whileHover={{ y: -8, scale: 1.03 }}
                className={`flex h-full flex-col items-center rounded-2xl border p-6 text-center transition ${
                  i === 0
                    ? "border-lime-400/50 bg-gradient-to-b from-lime-400/15 to-transparent"
                    : "border-white/10 bg-white/[0.03]"
                }`}
              >
                <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-white/5 text-4xl">
                  {p.emoji}
                </div>
                <h3 className="font-bold text-white">{p.name}</h3>
                <p className="mt-1.5 text-xs leading-relaxed text-white/55">{p.desc}</p>
                {i === 0 && (
                  <span className="mt-3 rounded-full bg-lime-400/20 px-2.5 py-0.5 text-[10px] font-semibold text-lime-300">
                    ★ Featured
                  </span>
                )}
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
