import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import Reveal from "./Reveal";

export default function Markets({ t }: { t: Content }) {
  return (
    <section id="markets" className="relative bg-[#0a140a] py-24 sm:py-32">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-lime-400/5" />
        <div className="absolute left-1/2 top-1/2 h-[850px] w-[850px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-lime-400/5" />
      </div>
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.markets.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.markets.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.markets.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {t.markets.regions.map((r, i) => (
            <Reveal key={i} delay={i * 0.08}>
              <motion.div
                whileHover={{ y: -6 }}
                className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-lime-400/[0.06] to-transparent p-6"
              >
                <div className="mb-3 flex items-center gap-3">
                  <span className="text-3xl">{r.flag}</span>
                  <h3 className="text-lg font-bold text-white">{r.name}</h3>
                </div>
                <p className="text-sm leading-relaxed text-white/60">{r.desc}</p>
                <div className="mt-4 flex items-center gap-2 text-xs font-medium text-lime-300/80">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-lime-400" />
                  {t.markets.exportLabel}
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
