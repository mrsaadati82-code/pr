import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import { images } from "../constants/images";
import Reveal from "./Reveal";

export default function Quality({ t, isRTL }: { t: Content; isRTL: boolean }) {
  return (
    <section id="quality" className="relative overflow-hidden bg-[#0e1b0f] py-24 sm:py-32">
      <div className="pointer-events-none absolute inset-0">
        <img src={images.packing} alt="" className="h-full w-full object-cover opacity-[0.08]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.quality.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.quality.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.quality.subtitle}</p>
          </Reveal>
        </div>

        <div className="relative mt-20">
          <div
            className={`absolute top-0 hidden h-full w-px bg-gradient-to-b from-lime-400/60 via-lime-400/20 to-transparent lg:block ${
              isRTL ? "right-1/2" : "left-1/2"
            }`}
          />
          <div className="flex flex-col gap-10 lg:gap-16">
            {t.quality.steps.map((step, i) => {
              const leftSide = i % 2 === 0;
              return (
                <div key={i} className="relative grid grid-cols-1 items-center gap-6 lg:grid-cols-2">
                  <Reveal
                    direction={leftSide ? "right" : "left"}
                    className={`${leftSide ? "lg:order-1" : "lg:order-2"}`}
                  >
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      className={`rounded-2xl border border-white/10 bg-white/[0.03] p-7 ${
                        leftSide ? "lg:text-end" : "lg:text-start"
                      }`}
                    >
                      <span className="text-4xl font-extrabold text-lime-400/30">{step.number}</span>
                      <h3 className="mt-2 text-xl font-bold text-white">{step.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-white/60">{step.desc}</p>
                    </motion.div>
                  </Reveal>
                  <div className={`hidden lg:block ${leftSide ? "lg:order-2" : "lg:order-1"}`} />
                  <div
                    className={`absolute top-1/2 hidden h-4 w-4 -translate-y-1/2 rounded-full border-4 border-[#0e1b0f] bg-lime-400 shadow-lg shadow-lime-500/40 lg:block ${
                      isRTL ? "right-1/2 translate-x-1/2" : "left-1/2 -translate-x-1/2"
                    }`}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
