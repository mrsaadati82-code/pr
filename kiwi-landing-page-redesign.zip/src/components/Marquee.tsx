import type { Content } from "../i18n/translations";

export default function Marquee({ t, isRTL }: { t: Content; isRTL: boolean }) {
  const items = [...t.marquee, ...t.marquee];
  return (
    <div className="relative z-20 overflow-hidden border-y border-lime-400/10 bg-gradient-to-r from-[#132217] via-[#17301a] to-[#132217] py-4">
      <div className={`flex w-max gap-10 whitespace-nowrap ${isRTL ? "animate-marquee-rtl" : "animate-marquee"}`}>
        {[...items, ...items].map((text, i) => (
          <div key={i} className="flex items-center gap-3 text-sm font-medium text-lime-200/80 sm:text-base">
            <span className="text-lime-400">🥝</span>
            {text}
          </div>
        ))}
      </div>
    </div>
  );
}
