import { useState } from "react";
import { motion } from "framer-motion";
import type { Content } from "../i18n/translations";
import Reveal from "./Reveal";

export default function Contact({ t }: { t: Content }) {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative overflow-hidden bg-[#0a140a] py-24 sm:py-32">
      <div className="absolute -top-20 left-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-lime-500/10 blur-[130px]" />
      <div className="relative mx-auto max-w-6xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <span className="mb-4 inline-block rounded-full bg-lime-400/10 px-4 py-1.5 text-sm font-semibold text-lime-300">
              {t.contact.tag}
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">{t.contact.title}</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-4 text-white/60">{t.contact.subtitle}</p>
          </Reveal>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-5">
          <Reveal direction="right" className="lg:col-span-2">
            <div className="flex h-full flex-col justify-between gap-8 rounded-3xl border border-white/10 bg-white/[0.03] p-8">
              <div className="space-y-6">
                {t.contact.info.map((info, i) => (
                  <div key={i}>
                    <div className="text-xs font-semibold uppercase tracking-wide text-lime-300/70">{info.label}</div>
                    <div className="mt-1 text-white/90" dir="ltr">{info.value}</div>
                  </div>
                ))}
              </div>
              <div className="flex gap-3">
                {["✆", "✉", "🌐"].map((icon, i) => (
                  <div
                    key={i}
                    className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-lime-300"
                  >
                    {icon}
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal direction="left" delay={0.1} className="lg:col-span-3">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
                setTimeout(() => setSent(false), 4000);
              }}
              className="rounded-3xl border border-white/10 bg-white/[0.03] p-8"
            >
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <input
                  required
                  placeholder={t.contact.form.name}
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-lime-400/60"
                />
                <input
                  required
                  type="email"
                  placeholder={t.contact.form.email}
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-lime-400/60"
                />
                <input
                  placeholder={t.contact.form.phone}
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-lime-400/60"
                />
                <input
                  placeholder={t.contact.form.country}
                  className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-lime-400/60"
                />
              </div>
              <textarea
                rows={4}
                placeholder={t.contact.form.message}
                className="mt-5 w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder-white/40 outline-none focus:border-lime-400/60"
              />
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="mt-6 w-full rounded-xl bg-gradient-to-r from-lime-400 to-green-600 px-6 py-3.5 font-semibold text-[#0e1b0f] shadow-lg shadow-lime-900/30"
              >
                {sent ? "✓" : t.contact.form.submit}
              </motion.button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
