<?php
if (!defined('ABSPATH')) exit;
function cpttf_render_sync_page(){
    $audit = CPTT_Finance::legacy_project_audit();
    $accounts = CPTT_Finance::get_accounts(true);
    $acc_opts=''; foreach($accounts as $a){ $acc_opts.='<option value="'.(int)$a->id.'">'.esc_html($a->icon.' '.$a->name.' — موجودی: '.CPTT_Finance::fmt(CPTT_Finance::account_balance((int)$a->id)).' ریال').'</option>'; }
    ?>
    <section class="cpttf-card">
        <header class="cpttf-card__head"><h2>🧩 همگام‌سازی امن داده‌های قدیمی</h2><small>هیچ داده‌ای حذف یا بازنویسی نمی‌شود؛ فقط برای اختلاف‌های تأییدشده سند افتتاحیه ساخته می‌شود.</small></header>
        <div class="cpttf-card__body">
            <div class="cpttf-grid cpttf-grid--3">
                <div class="cpttf-kpi"><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">اختلاف دریافتی قدیمی با دفتر مالی</span><strong class="cpttf-kpi__value" id="cpttf-sync-income-total"><?php echo CPTT_Finance::fmt($audit['totals']['income_delta']); ?> <small>ریال</small></strong></div></div>
                <div class="cpttf-kpi"><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">اختلاف تسویه کارشناسان با دفتر مالی</span><strong class="cpttf-kpi__value" id="cpttf-sync-payout-total"><?php echo CPTT_Finance::fmt($audit['totals']['payout_delta']); ?> <small>ریال</small></strong></div></div>
                <div class="cpttf-kpi"><div class="cpttf-kpi__body"><span class="cpttf-kpi__label">پروژه‌های بررسی‌شده</span><strong class="cpttf-kpi__value"><?php echo esc_html(number_format_i18n($audit['totals']['projects'])); ?></strong></div></div>
            </div>
            <div class="cpttf-notice" style="margin:14px 0;padding:12px;border-radius:14px;background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;line-height:1.9;">
                قبل از اجرای همگام‌سازی از دیتابیس بکاپ داشته باشید. این ابزار فقط سند جدید ایجاد می‌کند و به مراحل/پرداخت‌های قدیمی دست نمی‌زند.
            </div>
            <div style="display:grid;grid-template-columns:1fr auto auto;gap:10px;align-items:end;margin-bottom:14px;">
                <label><span>حساب مقصد/مبدأ برای سندهای افتتاحیه</span><select id="cpttf-sync-account" style="width:100%;margin-top:6px;"><?php echo $acc_opts; ?></select></label>
                <button type="button" class="cpttf-btn cpttf-btn--primary" id="cpttf-sync-income">ساخت سند دریافتی‌های قدیمی</button>
                <button type="button" class="cpttf-btn cpttf-btn--warn" id="cpttf-sync-payout">ساخت سند تسویه‌های قدیمی</button>
            </div>
            <div id="cpttf-sync-msg" style="font-weight:900;margin-bottom:10px;"></div>
            <div class="cpttf-table-wrap"><table class="cpttf-table"><thead><tr><th>پروژه</th><th>دریافتی در پروژه</th><th>دریافتی در دفتر</th><th>اختلاف دریافتی</th><th>تسویه کارشناس در پروژه</th><th>تسویه در دفتر</th><th>اختلاف تسویه</th></tr></thead><tbody>
                <?php foreach(array_slice($audit['rows'],0,300) as $r): ?><tr><td><b><?php echo esc_html($r['title']); ?></b><small style="display:block;color:#64748b">#<?php echo (int)$r['id']; ?></small></td><td><?php echo CPTT_Finance::fmt($r['paid_meta']); ?></td><td><?php echo CPTT_Finance::fmt($r['paid_ledger']); ?></td><td class="cpttf-text-success"><b><?php echo CPTT_Finance::fmt($r['income_delta']); ?></b></td><td><?php echo CPTT_Finance::fmt($r['expert_meta']); ?></td><td><?php echo CPTT_Finance::fmt($r['expert_ledger']); ?></td><td class="cpttf-text-danger"><b><?php echo CPTT_Finance::fmt($r['payout_delta']); ?></b></td></tr><?php endforeach; ?>
            </tbody></table></div>
        </div>
    </section>
    <script>
    (function(){
      function post(kind){
        if(!confirm('برای اختلاف‌های فعلی سند افتتاحیه ساخته شود؟ این عملیات حذف/ویرایش داده قدیمی انجام نمی‌دهد.')) return;
        var msg=document.getElementById('cpttf-sync-msg'); if(msg){msg.style.color='#475569';msg.textContent='در حال انجام...';}
        var fd=new FormData(); fd.append('action','cptt_fin_legacy_import'); fd.append('nonce',(window.CPTT_FIN&&CPTT_FIN.nonce)||''); fd.append('kind',kind); fd.append('account_id',document.getElementById('cpttf-sync-account').value||'0');
        fetch((window.CPTT_FIN&&CPTT_FIN.ajax)||'',{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json()).then(j=>{ if(j&&j.success){ if(msg){msg.style.color='#059669';msg.textContent='✅ '+j.data.created+' سند به مبلغ '+Number(j.data.sum||0).toLocaleString('en-US')+' ریال ساخته شد. صفحه را رفرش کنید.';} } else { if(msg){msg.style.color='#dc2626';msg.textContent=(j&&j.data)||'خطا';} } }).catch(()=>{ if(msg){msg.style.color='#dc2626';msg.textContent='خطای شبکه';} });
      }
      var a=document.getElementById('cpttf-sync-income'), b=document.getElementById('cpttf-sync-payout'); if(a)a.onclick=function(){post('income')}; if(b)b.onclick=function(){post('payout')};
    })();
    </script>
    <?php
}
