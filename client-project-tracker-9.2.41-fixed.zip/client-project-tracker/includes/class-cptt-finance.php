<?php
/**
 * CPTT Finance — Modern modular finance subsystem for the Hamahang plugin.
 *
 * v6.4.0 — Phase 1: data model, ledger, 5 standalone admin modules with
 * SaaS-style mobile-first UI.
 *
 * Modules (each has its own admin page + URL + nav):
 *   - cptt-finance               → Financial dashboard (KPIs + charts)
 *   - cptt-finance-receivables   → Customer receivables (debtors)
 *   - cptt-finance-payouts       → Expert payouts (settlements)
 *   - cptt-finance-transactions  → Standalone income/expense register
 *   - cptt-finance-treasury      → Cash & bank accounts + transfers + ledger
 *
 * Design rules:
 *   - Nothing existing is removed; the old "حساب و کتاب" page (CPTT_Admin) stays.
 *   - Every existing financial operation can ALSO write to the unified ledger
 *     (cptt_fin_ledger) via auto-hooks.
 *   - Tables are upgrade-safe (dbDelta) and use a stored version option.
 *   - Currency uses CPTT_Currency where available (toman/rial).
 *   - All UI is responsive, theme-aware, and accessible.
 */

if (!defined('ABSPATH')) exit;

class CPTT_Finance {

	const DB_VERSION = '1.1.0';
	const DB_OPTION  = 'cptt_finance_db_version';
	const NONCE      = 'cptt_finance_nonce';

	private static $instance = null;
	public static function instance(){
		if (self::$instance === null) self::$instance = new self();
		return self::$instance;
	}

	private function __construct(){
		add_action('admin_menu',  [$this, 'register_menus'], 12);
		add_action('admin_init',  [$this, 'maybe_install_tables']);
		add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
		// v9.2.6 — add cptt-v2-scope to <body> on all finance pages so the
		// font/color rules injected by CPTT_Settings::inject_dynamic_css()
		// apply to every element (same as expert dashboard). Dashicons are
		// restored to their icon font via a targeted override below.
		add_filter('admin_body_class', [$this, 'add_body_class']);

		// AJAX: data CRUD
		add_action('wp_ajax_cptt_fin_account_save',   [$this, 'ajax_account_save']);
		add_action('wp_ajax_cptt_fin_account_delete', [$this, 'ajax_account_delete']);
		add_action('wp_ajax_cptt_fin_cat_save',       [$this, 'ajax_cat_save']);
		add_action('wp_ajax_cptt_fin_cat_delete',     [$this, 'ajax_cat_delete']);
		add_action('wp_ajax_cptt_fin_tx_save',        [$this, 'ajax_tx_save']);
		add_action('wp_ajax_cptt_fin_tx_delete',      [$this, 'ajax_tx_delete']);
		add_action('wp_ajax_cptt_fin_tx_reverse',     [$this, 'ajax_tx_reverse']);
		add_action('wp_ajax_cptt_fin_recv_resync',    [$this, 'ajax_recv_resync']);
		add_action('wp_ajax_cptt_fin_recv_audit',     [$this, 'ajax_recv_audit']);
		add_action('wp_ajax_cptt_fin_recv_project_reset', [$this, 'ajax_recv_project_reset']);
		add_action('wp_ajax_cptt_fin_recv_project_ledger', [$this, 'ajax_recv_project_ledger']);
		add_action('wp_ajax_cptt_fin_transfer',       [$this, 'ajax_transfer']);
		add_action('wp_ajax_cptt_fin_dashboard_data', [$this, 'ajax_dashboard_data']);
		add_action('wp_ajax_cptt_fin_legacy_import', [$this, 'ajax_legacy_import']);

		// Auto-log existing project finance events into the ledger
		add_action('cptt_after_expert_payout',           [$this, 'log_expert_payout'], 10, 5);
		add_action('cptt_after_manual_expert_payment',   [$this, 'log_manual_payment'], 10, 3);
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Table names
	 * ─────────────────────────────────────────────────────────────────── */
	public static function tbl_accounts(){   global $wpdb; return $wpdb->prefix . 'cptt_fin_accounts'; }
	public static function tbl_categories(){ global $wpdb; return $wpdb->prefix . 'cptt_fin_categories'; }
	public static function tbl_ledger(){     global $wpdb; return $wpdb->prefix . 'cptt_fin_ledger'; }

	/* ───────────────────────────────────────────────────────────────────
	 * Install / upgrade tables
	 * ─────────────────────────────────────────────────────────────────── */
	public function maybe_install_tables(){
		$need = get_option(self::DB_OPTION) !== self::DB_VERSION;
		if (!$need) {
			// ensure voucher columns exist even if option already bumped on partial deploys
			global $wpdb;
			$col = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM " . self::tbl_ledger() . " LIKE %s", 'voucher_no'));
			if (!$col) $need = true;
		}
		if (!$need) return;
		self::install_tables();
		update_option(self::DB_OPTION, self::DB_VERSION);
		// Seed default categories on first install
		self::seed_defaults();
	}

	public static function install_tables(){
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$t_acc = self::tbl_accounts();
		$t_cat = self::tbl_categories();
		$t_lgr = self::tbl_ledger();

		$sql1 = "CREATE TABLE $t_acc (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			type VARCHAR(20) NOT NULL DEFAULT 'cash',
			bank_name VARCHAR(190) DEFAULT NULL,
			account_number VARCHAR(60) DEFAULT NULL,
			iban VARCHAR(40) DEFAULT NULL,
			card_number VARCHAR(40) DEFAULT NULL,
			initial_balance DECIMAL(20,2) NOT NULL DEFAULT 0,
			currency VARCHAR(10) NOT NULL DEFAULT 'IRT',
			color VARCHAR(20) NOT NULL DEFAULT '#6366f1',
			icon VARCHAR(20) NOT NULL DEFAULT '🏦',
			status TINYINT NOT NULL DEFAULT 1,
			meta LONGTEXT DEFAULT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY type_idx (type),
			KEY status_idx (status)
		) $charset;";

		$sql2 = "CREATE TABLE $t_cat (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			type VARCHAR(20) NOT NULL,
			parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			color VARCHAR(20) NOT NULL DEFAULT '#64748b',
			icon VARCHAR(20) NOT NULL DEFAULT '🏷',
			sort_order INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY type_idx (type)
		) $charset;";

		$sql3 = "CREATE TABLE $t_lgr (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			account_id BIGINT UNSIGNED NOT NULL,
			type VARCHAR(30) NOT NULL,
			direction TINYINT NOT NULL,
			amount DECIMAL(20,2) NOT NULL DEFAULT 0,
			category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			step_id VARCHAR(64) NOT NULL DEFAULT '',
			customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			expert_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ref_type VARCHAR(40) NOT NULL DEFAULT '',
			ref_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			linked_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			voucher_no VARCHAR(40) NOT NULL DEFAULT '',
			voucher_kind VARCHAR(20) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'posted',
			reversed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reverses_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			date_at INT NOT NULL,
			date_fa VARCHAR(40) NOT NULL DEFAULT '',
			description TEXT,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at INT NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			KEY account_idx (account_id),
			KEY type_idx (type),
			KEY date_idx (date_at),
			KEY project_idx (project_id),
			KEY customer_idx (customer_id),
			KEY expert_idx (expert_id),
			KEY voucher_idx (voucher_no),
			KEY status_idx (status),
			KEY reverses_idx (reverses_id)
		) $charset;";

		dbDelta($sql1);
		dbDelta($sql2);
		dbDelta($sql3);
	}

	public static function seed_defaults(){
		global $wpdb;
		$t = self::tbl_categories();
		$exists = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t");
		if ($exists > 0) return;
		$rows = [
			['name'=>'فروش پروژه','type'=>'income','color'=>'#16a34a','icon'=>'💼'],
			['name'=>'پیش پرداخت','type'=>'income','color'=>'#22c55e','icon'=>'💵'],
			['name'=>'سایر درآمدها','type'=>'income','color'=>'#06b6d4','icon'=>'💰'],
			['name'=>'دستمزد کارشناسان','type'=>'expense','color'=>'#f59e0b','icon'=>'👤'],
			['name'=>'هزینه‌های اداری','type'=>'expense','color'=>'#a855f7','icon'=>'🏢'],
			['name'=>'هزینه‌های بازاریابی','type'=>'expense','color'=>'#ec4899','icon'=>'📣'],
			['name'=>'هزینه نرم‌افزار/سرور','type'=>'expense','color'=>'#0ea5e9','icon'=>'☁️'],
			['name'=>'سایر هزینه‌ها','type'=>'expense','color'=>'#ef4444','icon'=>'📦'],
		];
		foreach ($rows as $r) $wpdb->insert($t, $r);

		// Seed a default cash account
		$ta = self::tbl_accounts();
		$cnt = (int)$wpdb->get_var("SELECT COUNT(*) FROM $ta");
		if ($cnt === 0) {
			$wpdb->insert($ta, [
				'name'  => 'صندوق نقدی',
				'type'  => 'cash',
				'icon'  => '💵',
				'color' => '#16a34a',
				'created_at' => (int) current_time('timestamp', true),
				'created_by' => (int) get_current_user_id(),
			]);
		}
	}

	/* ───────────────────────────────────────────────────────────────────
	 * Admin Menus — every module is a standalone page
	 * ─────────────────────────────────────────────────────────────────── */
	public function register_menus(){
		// Parent menu
		add_menu_page(
			'مالی هماهنگ',
			'💰 مالی',
			'edit_cptt_projects',
			'cptt-finance',
			[$this, 'render_dashboard_page'],
			'dashicons-money-alt',
			25
		);
		// Sub-pages
		add_submenu_page('cptt-finance', 'داشبورد مالی',     'داشبورد مالی',     'edit_cptt_projects', 'cptt-finance',                [$this, 'render_dashboard_page']);
		add_submenu_page('cptt-finance', 'مطالبات مشتریان',  'مطالبات مشتریان',  'edit_cptt_projects', 'cptt-finance-receivables',    [$this, 'render_receivables_page']);
		add_submenu_page('cptt-finance', 'تسویه کارشناسان',  'تسویه کارشناسان',  'edit_cptt_projects', 'cptt-finance-payouts',        [$this, 'render_payouts_page']);
		add_submenu_page('cptt-finance', 'درآمد و هزینه',     'درآمد و هزینه',    'edit_cptt_projects', 'cptt-finance-transactions',   [$this, 'render_transactions_page']);
		add_submenu_page('cptt-finance', 'خزانه‌داری',         'خزانه‌داری',        'edit_cptt_projects', 'cptt-finance-treasury',       [$this, 'render_treasury_page']);
		add_submenu_page('cptt-finance', 'دسته‌بندی‌های مالی',  'دسته‌بندی‌ها',      'edit_cptt_projects', 'cptt-finance-categories',     [$this, 'render_categories_page']);
		// v6.4.1 — Classic project accounting view migrated under Finance menu.
		add_submenu_page('cptt-finance', 'حساب پروژه‌ها', '📒 حساب پروژه‌ها', 'edit_cptt_projects', 'cptt-finance-classic',        [$this, 'render_classic_accounting_page']);
		add_submenu_page('cptt-finance', 'همگام‌سازی داده‌های قدیمی', '🧩 همگام‌سازی', 'manage_options', 'cptt-finance-sync', [$this, 'render_sync_page']);
		add_submenu_page('cptt-finance', 'گردش حساب',            '📑 گردش حساب',     'edit_cptt_projects', 'cptt-finance-ledger',         [$this, 'render_ledger_page']);
		// v8.5.0 — C-2: Cash Flow (Cash-View) report — non-destructive, read-only view.
	}

	public function add_body_class($classes){
		$page = isset($_GET['page']) ? (string)$_GET['page'] : '';
		if (strpos($page, 'cptt-finance') === 0) {
			$classes .= ' cptt-v2-scope';
		}
		return $classes;
	}

	public function enqueue_admin_assets($hook){
		if (strpos($hook, 'cptt-finance') === false) return;
		wp_enqueue_style('cptt-finance', CPTT_URL . 'assets/css/finance.css', [], CPTT_VERSION);
		// v9.2.24 — classic accounting page reuses CPTT_Admin markup/JS/CSS
		$page = isset($_GET['page']) ? (string)$_GET['page'] : '';
		if ($page === 'cptt-finance-classic') {
			wp_enqueue_style('cptt-admin', CPTT_URL . 'assets/css/admin.css', ['cptt-finance'], CPTT_VERSION);
			wp_enqueue_script('jquery-ui-sortable');
			wp_enqueue_script('cptt-admin', CPTT_URL . 'assets/js/admin.js', ['jquery','jquery-ui-sortable'], CPTT_VERSION, true);
			wp_localize_script('cptt-admin', 'CPTT_CURRENCY', ['unit'=>'rial','label'=>'ریال','factor'=>1,'decimals'=>0]);
			wp_localize_script('cptt-admin', 'CPTT_ADMIN', [
				'ajax' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('cptt_admin_nonce'),
				'branding' => class_exists('CPTT_Settings') ? CPTT_Settings::get() : [],
				'logo_url' => class_exists('CPTT_Settings') ? wp_get_attachment_image_url(CPTT_Settings::get()['logo_id'] ?? 0, 'large') : '',
			]);
			wp_add_inline_style('cptt-admin', self::classic_host_css());
		}

		// v9.2.6 — CPTT_Settings::inject_dynamic_css() paints every element
		// under body.cptt-v2-scope with the plugin font (including dashicons,
		// which then render as boxes). Restore icon fonts here — higher
		// specificity + !important beats the settings override.
		$scoped_css = "
			body.cptt-v2-scope .dashicons,
			body.cptt-v2-scope .dashicons-before::before,
			body.cptt-v2-scope [class^='dashicons-']::before,
			body.cptt-v2-scope [class*=' dashicons-']::before,
			body.cptt-v2-scope #adminmenu .wp-menu-image::before,
			body.cptt-v2-scope #wpadminbar .ab-icon::before,
			body.cptt-v2-scope #wpadminbar .ab-item::before {
				font-family: dashicons !important;
			}
			body.cptt-v2-scope .material-icons,
			body.cptt-v2-scope .material-symbols-outlined {
				font-family: 'Material Icons', 'Material Symbols Outlined' !important;
			}
		";
		wp_add_inline_style('cptt-finance', $scoped_css);

		// v9.2.0 — Chart.js (bundled locally so it works on restricted Iranian hosts)
		wp_enqueue_script('cptt-chartjs', CPTT_URL . 'assets/vendor/chart.umd.min.js', [], '4.4.1', true);
		wp_enqueue_script('cptt-finance', CPTT_URL . 'assets/js/finance.js', ['jquery','cptt-chartjs'], CPTT_VERSION, true);
		wp_localize_script('cptt-finance', 'CPTT_FIN', [
			'ajax'  => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce(self::NONCE),
			// v9.2.13 — admin_nonce is needed for step settlement AJAX (CPTT_Admin handlers)
			'admin_nonce' => wp_create_nonce('cptt_admin_nonce'),
			'currency' => 'ریال',
		]);
	}

	/* v9.2.4 — read plugin font from CPTT_Settings safely */
	private function _get_plugin_font_stack(){
		$f = 'dana';
		if (class_exists('CPTT_Settings')) {
			$s = CPTT_Settings::get_styles();
			$f = isset($s['font_family']) ? $s['font_family'] : 'dana';
		}
		switch ($f) {
			case 'iransans':  return "'IranSans', Tahoma, sans-serif";
			case 'iranyekan': return "'IranYekan', Tahoma, sans-serif";
			case 'kalameh':   return "'Kalameh', Tahoma, sans-serif";
			case 'peyda':     return "'Peyda', Tahoma, sans-serif";
			case 'vazir':     return "'Vazirmatn', Tahoma, sans-serif";
			case 'dana':
			default:          return "'Dana', Tahoma, sans-serif";
		}
	}
	private function _get_plugin_font_face_css(){
		// The @font-face declarations are already emitted in the page head by
		// CPTT_Settings::inject_dynamic_css() (which runs on every admin page).
		// Returning empty avoids duplicating them.
		return '';
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * HELPERS
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function fmt($n){
		// v9.2.1/9.2.13 — format the stored amount as-is (no unit conversion).
		// Unit conversion is display-only via CPTT_Currency when callers need it;
		// finance pages store/read the same scale the rest of the plugin uses.
		// Always Persian digits, even if site locale is non-Persian.
		$s = number_format((float)$n, 0, '.', ',');
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'to_persian_digits')) {
			return CPTT_Core::to_persian_digits($s);
		}
		$fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
		return preg_replace_callback('/[0-9]/', function($m) use ($fa){ return $fa[(int)$m[0]]; }, $s);
	}
	public static function fa_date($ts){
		$ts = (int)$ts;
		if ($ts <= 0) return '—';
		return class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($ts) : date('Y-m-d H:i', $ts);
	}
	public static function currency_label(){
		return 'ریال'; // v9.2.18 — always rial
	}

	public static function get_accounts($only_active = true){
		global $wpdb;
		$where = $only_active ? 'WHERE status=1' : '';
		return $wpdb->get_results("SELECT * FROM " . self::tbl_accounts() . " $where ORDER BY id ASC");
	}
	public static function get_account($id){
		global $wpdb;
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_accounts() . " WHERE id=%d", $id));
	}
	public static function get_categories($type = ''){
		global $wpdb;
		if ($type === '') {
			return $wpdb->get_results("SELECT * FROM " . self::tbl_categories() . " ORDER BY type ASC, sort_order ASC, id ASC");
		}
		return $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::tbl_categories() . " WHERE type=%s ORDER BY sort_order ASC, id ASC", $type));
	}

	/**
	 * Compute current balance of an account = initial + ∑(direction * amount)
	 */
	public static function account_balance($account_id){
		global $wpdb;
		$acc = self::get_account($account_id);
		if (!$acc) return 0.0;
		$sum = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(direction * amount), 0) FROM " . self::tbl_ledger() . " WHERE account_id=%d",
			$account_id
		));
		return (float)$acc->initial_balance + $sum;
	}

	/**
	 * v6.4.1 — Balance of an account at a given timestamp (inclusive of
	 * older transactions). Used by the ledger view for running-balance.
	 * Pass $ts=0 to get just the initial balance (no transactions yet).
	 */
	public static function account_balance_at($account_id, $ts){
		global $wpdb;
		$acc = self::get_account($account_id);
		if (!$acc) return 0.0;
		if ($ts <= 0) return (float) $acc->initial_balance;
		$sum = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(direction * amount), 0) FROM " . self::tbl_ledger() . " WHERE account_id=%d AND date_at <= %d",
			$account_id, $ts
		));
		return (float)$acc->initial_balance + $sum;
	}

	/**
	 * Recompute the project settlement flag from the canonical step amounts.
	 * This keeps receivables/cards honest after deleting or reversing a payment.
	 */
	private static function refresh_project_settlement_flag($project_id){
		$project_id = (int)$project_id;
		if ($project_id <= 0) return false;
		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) {
			update_post_meta($project_id, '_cptt_is_settled', 0);
			return false;
		}
		$cost = 0.0; $paid = 0.0;
		foreach ($steps as $st) {
			if (!is_array($st)) continue;
			$cost += (float)($st['cost'] ?? 0);
			$paid += (float)($st['paid'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) {
					if (!is_array($ef)) continue;
					$cost += (float)($ef['cost'] ?? 0);
					$paid += (float)($ef['paid'] ?? 0);
				}
			}
		}
		$is_settled = ($cost > 0 && ($cost - $paid) <= 0.5) ? 1 : 0;
		update_post_meta($project_id, '_cptt_is_settled', $is_settled);
		return (bool)$is_settled;
	}

	/**
	 * Insert a ledger entry. $args:
	 *   account_id (req), type (req), direction (+1/-1), amount (req),
	 *   category_id, project_id, step_id, customer_id, expert_id,
	 *   ref_type, ref_id, linked_id, date_at, description
	 */
	public static function ledger_insert($args){
		global $wpdb;
		$defaults = [
			'account_id'  => 0,
			'type'        => 'manual',
			'direction'   => 1,
			'amount'      => 0,
			'category_id' => 0,
			'project_id'  => 0,
			'step_id'     => '',
			'customer_id' => 0,
			'expert_id'   => 0,
			'ref_type'    => '',
			'ref_id'      => 0,
			'linked_id'   => 0,
			'voucher_no'  => '',
			'voucher_kind'=> '',
			'status'      => 'posted',
			'reversed_by' => 0,
			'reverses_id' => 0,
			'date_at'     => (int) current_time('timestamp', true),
			'description' => '',
			'created_by'  => (int) get_current_user_id(),
		];
		$a = array_merge($defaults, $args);
		$a['amount']    = (float) $a['amount'];
		$a['direction'] = (int) $a['direction'] >= 0 ? 1 : -1;
		$a['date_fa']   = class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime((int)$a['date_at']) : date('Y-m-d H:i', (int)$a['date_at']);
		$a['created_at']= (int) current_time('timestamp', true);
		if (empty($a['voucher_kind'])) {
			$a['voucher_kind'] = self::voucher_kind_for_type((string)$a['type'], (int)$a['direction']);
		}
		if (empty($a['voucher_no'])) {
			$a['voucher_no'] = self::next_voucher_no((string)$a['voucher_kind']);
		}
		if (empty($a['status'])) $a['status'] = 'posted';
		$wpdb->insert(self::tbl_ledger(), $a);
		return (int) $wpdb->insert_id;
	}

	/** v9.2.20 — map ledger type to voucher kind */
	public static function voucher_kind_for_type($type, $direction = 1){
		$type = sanitize_key((string)$type);
		if (in_array($type, ['income'], true)) return 'receipt';
		if (in_array($type, ['expense','expert_payout'], true)) return 'payment';
		if ($type === 'transfer_in' || $type === 'transfer_out') return 'transfer';
		return ((int)$direction >= 0) ? 'receipt' : 'payment';
	}

	/** v9.2.20 — sequential voucher number like RCV-1405-000123 / PAY-1405-000123 */
	public static function next_voucher_no($kind = 'receipt'){
		$kind = $kind === 'payment' ? 'payment' : ($kind === 'transfer' ? 'transfer' : 'receipt');
		$prefix = $kind === 'payment' ? 'PAY' : ($kind === 'transfer' ? 'TRF' : 'RCV');
		$year = 1400;
		if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'jalali_datetime')) {
			$fa = CPTT_Core::jalali_datetime(current_time('timestamp', true));
			if (preg_match('/(\d{4})/', (string)$fa, $m)) $year = (int)$m[1];
		} else {
			$year = (int) date('Y');
		}
		$opt = 'cptt_fin_voucher_seq_' . $kind . '_' . $year;
		$n = (int) get_option($opt, 0) + 1;
		update_option($opt, $n, false);
		return sprintf('%s-%d-%06d', $prefix, $year, $n);
	}

	/** v9.2.20 — human label for voucher/type */
	public static function voucher_label($row){
		$kind = is_object($row) ? (string)($row->voucher_kind ?? '') : (string)($row['voucher_kind'] ?? '');
		$type = is_object($row) ? (string)($row->type ?? '') : (string)($row['type'] ?? '');
		$status = is_object($row) ? (string)($row->status ?? 'posted') : (string)($row['status'] ?? 'posted');
		if ($kind === '') $kind = self::voucher_kind_for_type($type);
		$map = [
			'receipt'  => '📥 سند دریافتی',
			'payment'  => '📤 سند پرداختی',
			'transfer' => '🔁 سند انتقال',
		];
		$label = $map[$kind] ?? '📄 سند';
		if ($type === 'expert_payout') $label = '👤 سند پرداختی (تسویه کارشناس)';
		if ($status === 'reversed') $label .= ' · برگشت‌خورده';
		if ($status === 'reversal') $label = '↩️ سند برگشت';
		return $label;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * AUTO-HOOKS (link existing system to the ledger)
	 * ═══════════════════════════════════════════════════════════════════ */
	public function log_expert_payout($project_id, $step_id, $expert_id, $amount, $mode){
		// v9.2.15 — allow caller to pick treasury account via filter / global request
		$account_id = 0;
		if (!empty($_POST['account_id'])) $account_id = absint($_POST['account_id']);
		if (!$account_id) $account_id = (int) apply_filters('cptt_expert_payout_account_id', 0, $project_id, $step_id, $expert_id, $amount, $mode);
		if (!$account_id) $account_id = self::default_cash_account_id();
		if (!$account_id || (float)$amount <= 0) return;
		$mode_label = ($mode === 'final') ? 'تسویه نهایی' : 'پرداخت جزئی';
		self::ledger_insert([
			'account_id'   => $account_id,
			'type'         => 'expert_payout',
			'direction'    => -1,
			'amount'       => (float)$amount,
			'project_id'   => (int)$project_id,
			'step_id'      => (string)$step_id,
			'expert_id'    => (int)$expert_id,
			'ref_type'     => 'expert_payout',
			'voucher_kind' => 'payment',
			'status'       => 'posted',
			'description'  => $mode_label . ' با کارشناس - مرحله',
		]);
	}
	public function log_manual_payment($expert_id, $amount, $note){
		$account_id = !empty($_POST['account_id']) ? absint($_POST['account_id']) : 0;
		if (!$account_id) $account_id = self::default_cash_account_id();
		if (!$account_id || (float)$amount <= 0) return;
		self::ledger_insert([
			'account_id'   => $account_id,
			'type'         => 'expert_payout',
			'direction'    => -1,
			'amount'       => (float)$amount,
			'expert_id'    => (int)$expert_id,
			'ref_type'     => 'manual_payment',
			'voucher_kind' => 'payment',
			'status'       => 'posted',
			'description'  => (string)$note ?: 'پرداخت دستی به کارشناس',
		]);
	}
	public static function default_cash_account_id(){
		global $wpdb;
		$id = (int) $wpdb->get_var("SELECT id FROM " . self::tbl_accounts() . " WHERE status=1 ORDER BY id ASC LIMIT 1");
		return $id;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * KPI computations (used by dashboard + receivables)
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function compute_kpis(){
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$total_cost=0; $total_paid=0; $total_remain=0;
		$debt_projects = 0; $settled = 0; $unsettled = 0;
		$expert_payouts_total = 0;
		foreach ($projects as $p) {
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$pc=0; $pp=0; $ep=0;
			foreach ($steps as $st) {
				$pc += (float)($st['cost'] ?? 0);
				$pp += (float)($st['paid'] ?? 0);
				$ep += (float)($st['expert_paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) {
						$pc += (float)($ef['cost'] ?? 0);
						$pp += (float)($ef['paid'] ?? 0);
					}
				}
			}
			$total_cost += $pc;
			$total_paid += $pp;
			$remain = max(0, $pc - $pp);
			$total_remain += $remain;
			if ($remain > 0) $debt_projects++;
			if ((int)get_post_meta($p->ID,'_cptt_is_settled',true)) $settled++; else $unsettled++;
			$expert_payouts_total += $ep;
		}
		$gross_profit = $total_paid - $expert_payouts_total;
		return [
			'total_revenue'    => $total_paid,           // received money
			'total_invoiced'   => $total_cost,
			'receivables'      => $total_remain,
			'expert_payouts'   => $expert_payouts_total,
			'gross_profit'     => $gross_profit,
			'debt_projects'    => $debt_projects,
			'settled_projects' => $settled,
			'unsettled_projects'=> $unsettled,
			'projects_total'   => count($projects),
		];
	}

	/* v6.4.1 — Monthly aggregation combining BOTH the unified ledger AND
	 * existing project finance data. This way the dashboard correctly
	 * reflects revenue & expert payouts even before the user has imported
	 * everything into the ledger.
	 *
	 * Projects are matched by their post_date_gmt (creation month) because
	 * step-level dates aren't stored consistently. This is a pragmatic
	 * approximation that becomes more accurate as users start using the
	 * ledger for new income/expense events.
	 */
	public static function monthly_series(){
		global $wpdb;
		$series = []; // 'YYYY-MM' => ['income'=>0,'expense'=>0, 'jlabel'=>'YYYY/MM']
		$now = current_time('timestamp', true);

		// Use Jalali month labels so users see Persian dates
		$fa_months = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

		for ($i = 5; $i >= 0; $i--) {
			$ts = strtotime("-{$i} months", $now);
			$mk = date('Y-m', $ts);
			$jlabel = $mk;
			if (class_exists('CPTT_Core')) {
				// v9.2.0 — use *_en variant so regex can match ASCII digits
				$jfull = method_exists('CPTT_Core', 'jalali_datetime_en')
					? CPTT_Core::jalali_datetime_en($ts)
					: CPTT_Core::jalali_datetime($ts);
				if (preg_match('#^(\d{4})/(\d{1,2})/#', $jfull, $mm)) {
					$jy = (int)$mm[1]; $jmn = (int)$mm[2];
					$jlabel = (isset($fa_months[$jmn-1]) ? $fa_months[$jmn-1] : $jmn) . ' ' . $jy;
				}
			}
			$series[$mk] = ['label' => $jlabel, 'income' => 0, 'expense' => 0];
		}
		$cutoff = strtotime('-6 months', $now);

		// 1) From ledger (income/expense direction)
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT DATE_FORMAT(FROM_UNIXTIME(date_at), '%%Y-%%m') AS mk, direction, type, SUM(amount) AS s
			 FROM " . self::tbl_ledger() . "
			 WHERE date_at >= %d AND type NOT IN ('transfer_in','transfer_out')
			 GROUP BY mk, direction, type",
			$cutoff
		));
		foreach ($rows as $r) {
			if (!isset($series[$r->mk])) continue;
			if ((int)$r->direction > 0) $series[$r->mk]['income']  += (float)$r->s;
			else                         $series[$r->mk]['expense'] += (float)$r->s;
		}

		// 2) From projects (paid → income, expert_paid → expense) bucketed by
		// the project's creation month. This bridges old data into the chart.
		$projects = get_posts([
			'post_type'   => 'cptt_project',
			'post_status' => 'any',
			'numberposts' => -1,
			'date_query'  => [['after' => date('Y-m-d', $cutoff), 'inclusive' => true]],
		]);
		foreach ($projects as $p) {
			$mk = date('Y-m', strtotime($p->post_date_gmt));
			if (!isset($series[$mk])) continue;
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$paid = 0; $epaid = 0;
			foreach ($steps as $st) {
				$paid  += (float)($st['paid']        ?? 0);
				$epaid += (float)($st['expert_paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) $paid += (float)($ef['paid'] ?? 0);
				}
			}
			$series[$mk]['income']  += $paid;
			$series[$mk]['expense'] += $epaid;
		}

		return array_values($series);
	}

	/**
	 * v6.4.1 — Top customers by REVENUE (paid amount), top 6.
	 */
	public static function top_customers_series($limit = 6){
		$map = []; // cid => ['name'=>, 'paid'=>, 'remain'=>]
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		foreach ($projects as $p) {
			$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
			if (!$cid) continue;
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			if (!is_array($steps)) continue;
			$paid = 0; $cost = 0;
			foreach ($steps as $st) {
				$cost += (float)($st['cost'] ?? 0);
				$paid += (float)($st['paid'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) { $cost += (float)($ef['cost']??0); $paid += (float)($ef['paid']??0); }
				}
			}
			if (!isset($map[$cid])) {
				$u = get_user_by('id', $cid);
				$map[$cid] = ['name' => $u ? $u->display_name : ('#'.$cid), 'paid' => 0, 'remain' => 0];
			}
			$map[$cid]['paid']   += $paid;
			$map[$cid]['remain'] += max(0, $cost - $paid);
		}
		uasort($map, function($a,$b){ return ($b['paid'] <=> $a['paid']); });
		return array_slice(array_values($map), 0, $limit);
	}

	/**
	 * v6.4.1 — Income breakdown by category for current ledger entries.
	 */
	public static function category_breakdown($type = 'expense'){
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT l.category_id, c.name, c.color, c.icon, SUM(l.amount) AS s
			 FROM " . self::tbl_ledger() . " l
			 LEFT JOIN " . self::tbl_categories() . " c ON c.id = l.category_id
			 WHERE l.type=%s
			 GROUP BY l.category_id
			 ORDER BY s DESC
			 LIMIT 8",
			$type
		));
		$out = [];
		foreach ($rows as $r) {
			$out[] = [
				'name'  => $r->name ?: 'بدون دسته',
				'color' => $r->color ?: '#94a3b8',
				'icon'  => $r->icon  ?: '🏷',
				'value' => (float)$r->s,
			];
		}
		return $out;
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * AJAX HANDLERS
	 * ═══════════════════════════════════════════════════════════════════ */
	private function check_ajax(){
		if (!is_user_logged_in() || !current_user_can('edit_cptt_projects')) {
			wp_send_json_error('no_access', 403);
		}
		check_ajax_referer(self::NONCE, 'nonce');
	}

	public function ajax_account_save(){
		$this->check_ajax();
		global $wpdb;
		$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
		$data = [
			'name'            => sanitize_text_field($_POST['name'] ?? ''),
			'type'            => in_array(($_POST['type'] ?? 'cash'), ['cash','bank'], true) ? $_POST['type'] : 'cash',
			'bank_name'       => sanitize_text_field($_POST['bank_name'] ?? ''),
			'account_number'  => sanitize_text_field($_POST['account_number'] ?? ''),
			'iban'            => sanitize_text_field($_POST['iban'] ?? ''),
			'card_number'     => sanitize_text_field($_POST['card_number'] ?? ''),
			'initial_balance' => self::parse_amount($_POST['initial_balance'] ?? 0),
			'color'           => sanitize_text_field($_POST['color'] ?? '#6366f1'),
			'icon'            => sanitize_text_field($_POST['icon'] ?? '🏦'),
			'status'          => isset($_POST['status']) ? (int)$_POST['status'] : 1,
		];
		if ($data['name'] === '') wp_send_json_error('نام حساب الزامی است', 400);
		if ($id > 0) {
			$wpdb->update(self::tbl_accounts(), $data, ['id'=>$id]);
		} else {
			$data['created_at'] = (int) current_time('timestamp', true);
			$data['created_by'] = (int) get_current_user_id();
			$wpdb->insert(self::tbl_accounts(), $data);
			$id = (int) $wpdb->insert_id;
		}
		wp_send_json_success(['id'=>$id]);
	}

	public function ajax_account_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);
		$has_ledger = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . self::tbl_ledger() . " WHERE account_id=%d", $id));
		if ($has_ledger > 0) {
			// Soft-disable instead of delete
			$wpdb->update(self::tbl_accounts(), ['status'=>0], ['id'=>$id]);
			wp_send_json_success(['archived'=>true]);
		}
		$wpdb->delete(self::tbl_accounts(), ['id'=>$id]);
		wp_send_json_success(['deleted'=>true]);
	}

	public function ajax_cat_save(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$data = [
			'name'      => sanitize_text_field($_POST['name'] ?? ''),
			'type'      => in_array(($_POST['type'] ?? ''), ['income','expense'], true) ? $_POST['type'] : 'expense',
			'parent_id' => (int)($_POST['parent_id'] ?? 0),
			'color'     => sanitize_text_field($_POST['color'] ?? '#64748b'),
			'icon'      => sanitize_text_field($_POST['icon'] ?? '🏷'),
			'sort_order'=> (int)($_POST['sort_order'] ?? 0),
		];
		if ($data['name'] === '') wp_send_json_error('نام دسته الزامی است', 400);
		if ($id > 0) $wpdb->update(self::tbl_categories(), $data, ['id'=>$id]);
		else { $wpdb->insert(self::tbl_categories(), $data); $id = (int)$wpdb->insert_id; }
		wp_send_json_success(['id'=>$id]);
	}

	public function ajax_cat_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);
		$wpdb->delete(self::tbl_categories(), ['id'=>$id]);
		wp_send_json_success(['deleted'=>true]);
	}

	public function ajax_tx_save(){
		$this->check_ajax();
		global $wpdb;
		$id          = (int)($_POST['id'] ?? 0);
		$type        = ($_POST['tx_type'] ?? 'expense') === 'income' ? 'income' : 'expense';
		$account_id  = (int)($_POST['account_id'] ?? 0);
		$amount      = self::parse_amount($_POST['amount'] ?? 0);
		$category_id = (int)($_POST['category_id'] ?? 0);
		$project_id  = (int)($_POST['project_id'] ?? 0);
		$customer_id = (int)($_POST['customer_id'] ?? 0);
		$person_id   = (int)($_POST['person_id'] ?? 0);
		$expert_id   = (int)($_POST['expert_id'] ?? 0);
		// person_id can be customer or expert; map by role
		if ($person_id > 0) {
			$pu = get_user_by('id', $person_id);
			if ($pu) {
				$roles = (array)$pu->roles;
				if (in_array('cptt_expert', $roles, true) || in_array('administrator', $roles, true)) {
					$expert_id = $person_id;
					if (!$customer_id) $customer_id = 0;
				} else {
					$customer_id = $person_id;
				}
			}
		}
		$description = sanitize_textarea_field($_POST['description'] ?? '');
		$date_local  = sanitize_text_field($_POST['date_local'] ?? '');

		if (!$account_id) wp_send_json_error('انتخاب حساب الزامی است', 400);
		if ($amount <= 0) wp_send_json_error('مبلغ نامعتبر', 400);

		$date_at = self::parse_jalali_local($date_local) ?: current_time('timestamp', true);
		$old_row = $id > 0 ? $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id)) : null;

		$voucher_kind = $type === 'income' ? 'receipt' : 'payment';
		$row = [
			'account_id'   => $account_id,
			'type'         => $type,
			'direction'    => $type === 'income' ? 1 : -1,
			'amount'       => $amount,
			'category_id'  => $category_id,
			'project_id'   => $project_id,
			'customer_id'  => $customer_id,
			'expert_id'    => $expert_id,
			'description'  => $description,
			'date_at'      => $date_at,
			'date_fa'      => class_exists('CPTT_Core') ? CPTT_Core::jalali_datetime($date_at) : date('Y-m-d H:i', $date_at),
			'created_by'   => (int) get_current_user_id(),
			'created_at'   => (int) current_time('timestamp', true),
			'ref_type'     => 'manual_tx',
			'voucher_kind' => $voucher_kind,
			'status'       => 'posted',
		];
		if ($id > 0) {
			// If an existing income receipt is edited, undo its old side-effect first;
			// then the new amount/project below is applied exactly once.
			if ($old_row && $old_row->type === 'income' && (int)$old_row->project_id > 0 && (float)$old_row->amount > 0) {
				self::_reverse_income_from_project((int)$old_row->project_id, (float)$old_row->amount);
			}
			// keep original voucher_no on edit
			unset($row['created_at']);
			$wpdb->update(self::tbl_ledger(), $row, ['id'=>$id]);
		} else {
			$row['voucher_no'] = self::next_voucher_no($voucher_kind);
			$wpdb->insert(self::tbl_ledger(), $row);
			$id = (int) $wpdb->insert_id;
		}

		// v9.2.7 — Apply INCOME with a project_id back onto the project's
		// step ledger (_cptt_steps.paid) so the receivables page reflects
		// the settlement immediately. Otherwise the ledger and the project
		// meta diverge and the debtor never disappears from the list.
		if ($type === 'income' && $project_id > 0 && $amount > 0) {
			self::_apply_income_to_project($project_id, (float)$amount);
		}
		if ($old_row && (int)$old_row->project_id > 0) self::refresh_project_settlement_flag((int)$old_row->project_id);
		if ($project_id > 0) self::refresh_project_settlement_flag($project_id);

		wp_send_json_success(['id'=>$id]);
	}

	/**
	 * Distribute a paid amount across the project's still-open steps
	 * (fills each step's remaining balance in order until the amount runs out).
	 * Also handles `extra_finance` sub-rows.
	 */
	public static function _apply_income_to_project($project_id, $amount){
		$project_id = (int)$project_id;
		$remaining  = (float)$amount;
		if ($project_id <= 0 || $remaining <= 0) return 0;

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return 0;

		$applied = 0.0;
		foreach ($steps as $si => $st) {
			if ($remaining <= 0) break;
			$cost = (float)($st['cost'] ?? 0);
			$paid = (float)($st['paid'] ?? 0);
			$open = max(0, $cost - $paid);
			if ($open > 0) {
				$take = min($open, $remaining);
				$steps[$si]['paid'] = $paid + $take;
				$remaining -= $take;
				$applied   += $take;
			}
			// Extra finance rows on the same step
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ei => $ef) {
					if ($remaining <= 0) break;
					$ec = (float)($ef['cost'] ?? 0);
					$ep = (float)($ef['paid'] ?? 0);
					$eo = max(0, $ec - $ep);
					if ($eo > 0) {
						$take = min($eo, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $ep + $take;
						$remaining -= $take;
						$applied   += $take;
					}
				}
			}
		}
		update_post_meta($project_id, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($project_id);
		return $applied;
	}

	public function ajax_tx_delete(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		if (!$id) wp_send_json_error('invalid', 400);

		// v9.2.8 — If this row was an INCOME tied to a project, reverse the
		// paid amount from the project's steps so the debtor re-appears in
		// the receivables list. Symmetric to _apply_income_to_project().
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id));
		$affected_project_id = $row ? (int)$row->project_id : 0;
		if ($row && $row->type === 'income' && $affected_project_id > 0 && (float)$row->amount > 0) {
			self::_reverse_income_from_project($affected_project_id, (float)$row->amount);
		}

		$wpdb->delete(self::tbl_ledger(), ['id'=>$id]);
		if ($affected_project_id > 0) self::refresh_project_settlement_flag($affected_project_id);
		wp_send_json_success(['deleted'=>true]);
	}


	/**
	 * v9.2.20 — reverse a posted voucher (creates opposite document and undoes side-effects)
	 */
	public function ajax_tx_reverse(){
		$this->check_ajax();
		global $wpdb;
		$id = (int)($_POST['id'] ?? 0);
		$note = sanitize_textarea_field($_POST['note'] ?? '');
		if (!$id) wp_send_json_error('شناسه سند نامعتبر است', 400);
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::tbl_ledger() . " WHERE id=%d", $id));
		if (!$row) wp_send_json_error('سند یافت نشد', 404);
		$status = (string)($row->status ?? 'posted');
		if ($status === 'reversed') wp_send_json_error('این سند قبلاً برگشت خورده است', 400);
		if ($status === 'reversal') wp_send_json_error('سند برگشت را نمی‌توان دوباره برگشت زد', 400);
		if ((int)($row->reversed_by ?? 0) > 0) wp_send_json_error('این سند قبلاً برگشت خورده است', 400);

		$amount = (float)$row->amount;
		if ($amount <= 0) wp_send_json_error('مبلغ سند نامعتبر است', 400);

		// reverse side-effects first
		if ($row->type === 'income' && (int)$row->project_id > 0) {
			self::_reverse_income_from_project((int)$row->project_id, $amount);
		}
		if ($row->type === 'expert_payout') {
			self::_reverse_expert_payout_row($row);
		}

		$orig_kind = (string)($row->voucher_kind ?? '');
		if ($orig_kind === '') $orig_kind = self::voucher_kind_for_type((string)$row->type, (int)$row->direction);
		// reversal keeps same type but opposite direction, status=reversal
		$rev_dir = ((int)$row->direction >= 0) ? -1 : 1;
		$desc = 'برگشت سند ' . ((string)($row->voucher_no ?: ('#'.$row->id)));
		if ($note !== '') $desc .= ' — ' . $note;
		if (!empty($row->description)) $desc .= ' | اصل: ' . $row->description;

		$rev_id = self::ledger_insert([
			'account_id'   => (int)$row->account_id,
			'type'         => (string)$row->type,
			'direction'    => $rev_dir,
			'amount'       => $amount,
			'category_id'  => (int)$row->category_id,
			'project_id'   => (int)$row->project_id,
			'step_id'      => (string)$row->step_id,
			'customer_id'  => (int)$row->customer_id,
			'expert_id'    => (int)$row->expert_id,
			'ref_type'     => 'reversal',
			'ref_id'       => (int)$row->id,
			'linked_id'    => (int)$row->id,
			'voucher_kind' => $orig_kind,
			'status'       => 'reversal',
			'reverses_id'  => (int)$row->id,
			'description'  => $desc,
		]);

		$wpdb->update(self::tbl_ledger(), [
			'status' => 'reversed',
			'reversed_by' => $rev_id,
		], ['id' => (int)$row->id]);
		if ((int)$row->project_id > 0) self::refresh_project_settlement_flag((int)$row->project_id);

		wp_send_json_success(['reversed'=>true, 'reversal_id'=>$rev_id, 'voucher_no'=> (string)$wpdb->get_var($wpdb->prepare("SELECT voucher_no FROM ".self::tbl_ledger()." WHERE id=%d", $rev_id))]);
	}

	/**
	 * Undo expert step settlement effects for a ledger payout row.
	 * Best-effort: reduces expert_paid for that expert/step and reopens settlement.
	 */
	public static function _reverse_expert_payout_row($row){
		$project_id = (int)($row->project_id ?? 0);
		$step_id = (string)($row->step_id ?? '');
		$expert_id = (int)($row->expert_id ?? 0);
		$amount = (float)($row->amount ?? 0);
		if ($project_id <= 0 || $step_id === '' || $amount <= 0) return false;
		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return false;
		$found = false;
		foreach ($steps as $i => $st) {
			$sid = isset($st['id']) ? (string)$st['id'] : (string)$i;
			if ($sid !== $step_id) continue;
			$found = true;
			$key = (string)$expert_id;
			if ($expert_id && isset($steps[$i]['expert_settlements'][$key]) && is_array($steps[$i]['expert_settlements'][$key])) {
				$cur = (float)($steps[$i]['expert_settlements'][$key]['expert_paid'] ?? 0);
				$new = max(0, $cur - $amount);
				if ($new <= 0.001) {
					unset($steps[$i]['expert_settlements'][$key]);
					if (empty($steps[$i]['expert_settlements'])) unset($steps[$i]['expert_settlements']);
				} else {
					$steps[$i]['expert_settlements'][$key]['expert_paid'] = $new;
					$steps[$i]['expert_settlements'][$key]['step_settled'] = 0;
					unset($steps[$i]['expert_settlements'][$key]['settle_at'], $steps[$i]['expert_settlements'][$key]['settle_at_fa'], $steps[$i]['expert_settlements'][$key]['admin_received']);
				}
				// recompute mirrors
				$pool = 0.0; $pool_admin = 0.0; $any_open = false;
				if (!empty($steps[$i]['expert_settlements']) && is_array($steps[$i]['expert_settlements'])) {
					foreach ($steps[$i]['expert_settlements'] as $er) {
						if (!is_array($er)) continue;
						$pool += (float)($er['expert_paid'] ?? 0);
						$pool_admin += (float)($er['admin_received'] ?? 0);
						if (empty($er['step_settled'])) $any_open = true;
					}
				} else { $any_open = true; }
				$steps[$i]['expert_paid'] = $pool;
				$steps[$i]['admin_received'] = $pool_admin;
				$steps[$i]['step_settled'] = $any_open ? 0 : 1;
				if ($any_open) unset($steps[$i]['settle_at'], $steps[$i]['settle_at_fa'], $steps[$i]['settled_by']);
			} else {
				// legacy single fields
				$cur = (float)($steps[$i]['expert_paid'] ?? 0);
				$steps[$i]['expert_paid'] = max(0, $cur - $amount);
				$steps[$i]['step_settled'] = 0;
				$steps[$i]['admin_received'] = 0;
				unset($steps[$i]['settle_at'], $steps[$i]['settle_at_fa'], $steps[$i]['settled_by']);
			}
			break;
		}
		if (!$found) return false;
		update_post_meta($project_id, '_cptt_steps', $steps);
		update_post_meta($project_id, '_cptt_is_settled', 0);
		return true;
	}

	/**
	 * v9.2.8 — inverse of _apply_income_to_project(): removes a paid amount
	 * from the project's step ledger, starting with the LAST paid step so
	 * we roll back in reverse order (LIFO).
	 */
	public static function _reverse_income_from_project($project_id, $amount){
		$project_id = (int)$project_id;
		$remaining  = (float)$amount;
		if ($project_id <= 0 || $remaining <= 0) return 0;

		$steps = get_post_meta($project_id, '_cptt_steps', true);
		if (!is_array($steps)) return 0;

		$reversed = 0.0;
		// walk backwards (LIFO)
		$keys = array_reverse(array_keys($steps));
		foreach ($keys as $si) {
			if ($remaining <= 0) break;
			$st = $steps[$si];
			// First reverse extra_finance rows on this step (also LIFO)
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				$ekeys = array_reverse(array_keys($st['extra_finance']));
				foreach ($ekeys as $ei) {
					if ($remaining <= 0) break;
					$ep = (float)($st['extra_finance'][$ei]['paid'] ?? 0);
					if ($ep > 0) {
						$take = min($ep, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $ep - $take;
						$remaining -= $take;
						$reversed  += $take;
					}
				}
			}
			// Then the step's own paid
			$paid = (float)($steps[$si]['paid'] ?? 0);
			if ($remaining > 0 && $paid > 0) {
				$take = min($paid, $remaining);
				$steps[$si]['paid'] = $paid - $take;
				$remaining -= $take;
				$reversed  += $take;
			}
		}
		update_post_meta($project_id, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($project_id);
		return $reversed;
	}

	/**
	 * v9.2.10 — Receivables ↔ Ledger resync (hard mode).
	 *
	 * Treats the ledger as the single source of truth: for every project,
	 * sets total paid = SUM(income rows with matching project_id), capped
	 * by the project's total cost. Distributes the target amount across
	 * steps in order (step 1 first, then extra_finance rows, then step 2…).
	 *
	 * Any manual `paid` values that were entered before ledger tracking
	 * existed will be overwritten. The user must re-enter them as ledger
	 * transactions if they want them preserved.
	 */
	public function ajax_recv_resync(){
		$this->check_ajax();
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1,'fields'=>'ids']);
		$changed = 0;
		foreach ($projects as $pid) {
			$steps = get_post_meta($pid, '_cptt_steps', true);
			if (!is_array($steps) || empty($steps)) continue;

			// current paid across all steps + extra_finance
			$current_paid = 0.0;
			$capacity     = 0.0;
			foreach ($steps as $st) {
				$current_paid += (float)($st['paid'] ?? 0);
				$capacity     += (float)($st['cost'] ?? 0);
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ef) {
						$current_paid += (float)($ef['paid'] ?? 0);
						$capacity     += (float)($ef['cost'] ?? 0);
					}
				}
			}
			// sum of income ledger rows tied to this project
			$ledger_paid = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(amount),0) FROM " . self::tbl_ledger() . " WHERE project_id=%d AND type='income'",
				$pid
			));

			$target_total = min($capacity, $ledger_paid);
			if (abs($target_total - $current_paid) < 0.5) continue; // already in sync

			// Reset all paid values, then re-fill in step order up to target_total
			$remaining = $target_total;
			foreach ($steps as $si => $st) {
				$cap_step = (float)($st['cost'] ?? 0);
				if ($cap_step > 0 && $remaining > 0) {
					$take = min($cap_step, $remaining);
					$steps[$si]['paid'] = $take;
					$remaining -= $take;
				} else {
					$steps[$si]['paid'] = 0;
				}
				if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
					foreach ($st['extra_finance'] as $ei => $ef) {
						$cap_ef = (float)($ef['cost'] ?? 0);
						if ($cap_ef > 0 && $remaining > 0) {
							$take = min($cap_ef, $remaining);
							$steps[$si]['extra_finance'][$ei]['paid'] = $take;
							$remaining -= $take;
						} else {
							$steps[$si]['extra_finance'][$ei]['paid'] = 0;
						}
					}
				}
			}
			update_post_meta($pid, '_cptt_steps', $steps);
			self::refresh_project_settlement_flag($pid);
			$changed++;
		}
		wp_send_json_success(['changed'=>$changed]);
	}

	/**
	 * v9.2.11 — Audit view for receivables page.
	 * Returns every project with cost + meta paid + ledger paid + delta,
	 * so the user can see exactly where mismatches live.
	 */
	public function ajax_recv_audit(){
		$this->check_ajax();
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$out = [];
		foreach ($projects as $p) {
			$steps = get_post_meta($p->ID, '_cptt_steps', true);
			$cost = 0.0; $paid_meta = 0.0;
			if (is_array($steps)) {
				foreach ($steps as $st) {
					$cost      += (float)($st['cost'] ?? 0);
					$paid_meta += (float)($st['paid'] ?? 0);
					if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
						foreach ($st['extra_finance'] as $ef) {
							$cost      += (float)($ef['cost'] ?? 0);
							$paid_meta += (float)($ef['paid'] ?? 0);
						}
					}
				}
			}
			$paid_ledger = (float) $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(amount),0) FROM " . self::tbl_ledger() . " WHERE project_id=%d AND type='income'",
				$p->ID
			));
			$cid = (int) get_post_meta($p->ID, '_cptt_client_user_id', true);
			$cu  = $cid ? get_user_by('id', $cid) : null;
			$out[] = [
				'id'          => (int)$p->ID,
				'title'       => get_the_title($p),
				'client'      => $cu ? $cu->display_name : '—',
				'cost'        => $cost,
				'paid_meta'   => $paid_meta,
				'paid_ledger' => $paid_ledger,
				'delta'       => $paid_meta - $paid_ledger,
				'remain'      => max(0, $cost - $paid_meta),
				'edit_url'    => get_edit_post_link($p->ID, 'raw'),
			];
		}
		wp_send_json_success(['projects'=>$out]);
	}

	/**
	 * v9.2.11 — Reset ONE project's paid values to match ledger exactly.
	 * Same algorithm as ajax_recv_resync but scoped to a single project.
	 */
	public function ajax_recv_project_reset(){
		$this->check_ajax();
		global $wpdb;
		$pid = (int)($_POST['project_id'] ?? 0);
		if ($pid <= 0) wp_send_json_error('invalid', 400);
		$steps = get_post_meta($pid, '_cptt_steps', true);
		if (!is_array($steps) || empty($steps)) wp_send_json_error('no_steps', 400);

		$capacity = 0.0;
		foreach ($steps as $st) {
			$capacity += (float)($st['cost'] ?? 0);
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ef) $capacity += (float)($ef['cost'] ?? 0);
			}
		}
		$ledger_paid = (float) $wpdb->get_var($wpdb->prepare(
			"SELECT COALESCE(SUM(amount),0) FROM " . self::tbl_ledger() . " WHERE project_id=%d AND type='income'",
			$pid
		));
		$target = min($capacity, $ledger_paid);
		$remaining = $target;
		foreach ($steps as $si => $st) {
			$cap_step = (float)($st['cost'] ?? 0);
			if ($cap_step > 0 && $remaining > 0) {
				$take = min($cap_step, $remaining);
				$steps[$si]['paid'] = $take;
				$remaining -= $take;
			} else {
				$steps[$si]['paid'] = 0;
			}
			if (!empty($st['extra_finance']) && is_array($st['extra_finance'])) {
				foreach ($st['extra_finance'] as $ei => $ef) {
					$cap_ef = (float)($ef['cost'] ?? 0);
					if ($cap_ef > 0 && $remaining > 0) {
						$take = min($cap_ef, $remaining);
						$steps[$si]['extra_finance'][$ei]['paid'] = $take;
						$remaining -= $take;
					} else {
						$steps[$si]['extra_finance'][$ei]['paid'] = 0;
					}
				}
			}
		}
		update_post_meta($pid, '_cptt_steps', $steps);
		self::refresh_project_settlement_flag($pid);
		wp_send_json_success(['project_id'=>$pid,'new_paid'=>$target]);
	}

	/**
	 * v9.2.12 — Return all ledger income rows for a single project so the
	 * user can inspect / delete duplicates from inside the audit modal.
	 */
	public function ajax_recv_project_ledger(){
		$this->check_ajax();
		global $wpdb;
		$pid = (int)($_POST['project_id'] ?? 0);
		if ($pid <= 0) wp_send_json_error('invalid', 400);
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT id, amount, date_at, date_fa, description, account_id
			 FROM " . self::tbl_ledger() . "
			 WHERE project_id=%d AND type='income'
			 ORDER BY date_at DESC, id DESC",
			$pid
		));
		$out = [];
		foreach ($rows as $r) {
			$acc = self::get_account((int)$r->account_id);
			$out[] = [
				'id'          => (int)$r->id,
				'amount'      => (float)$r->amount,
				'date_fa'     => (string)$r->date_fa,
				'description' => (string)$r->description,
				'account'     => $acc ? ($acc->icon . ' ' . $acc->name) : '—',
			];
		}
		wp_send_json_success(['rows'=>$out]);
	}

	public function ajax_transfer(){
		$this->check_ajax();
		$from = (int)($_POST['from_id'] ?? 0);
		$to   = (int)($_POST['to_id']   ?? 0);
		$amt  = self::parse_amount($_POST['amount'] ?? 0);
		$desc = sanitize_text_field($_POST['description'] ?? '');
		$date_local = sanitize_text_field($_POST['date_local'] ?? '');
		if (!$from || !$to || $from === $to) wp_send_json_error('حساب مبدا و مقصد نامعتبر', 400);
		if ($amt <= 0) wp_send_json_error('مبلغ نامعتبر', 400);
		$ts = self::parse_jalali_local($date_local) ?: current_time('timestamp', true);

		$out_id = self::ledger_insert([
			'account_id'=>$from,'type'=>'transfer_out','direction'=>-1,'amount'=>$amt,
			'date_at'=>$ts,'description'=>'انتقال به حساب #'.$to.($desc?(' — '.$desc):'')
		]);
		$in_id = self::ledger_insert([
			'account_id'=>$to,'type'=>'transfer_in','direction'=>1,'amount'=>$amt,
			'date_at'=>$ts,'description'=>'انتقال از حساب #'.$from.($desc?(' — '.$desc):''),
			'linked_id'=>$out_id
		]);
		// Update the OUT row's linked_id to point at the IN row
		global $wpdb;
		$wpdb->update(self::tbl_ledger(), ['linked_id'=>$in_id], ['id'=>$out_id]);
		wp_send_json_success(['ok'=>true]);
	}


	public static function legacy_project_audit(){
		global $wpdb;
		$projects = get_posts(['post_type'=>'cptt_project','post_status'=>'any','numberposts'=>-1]);
		$out=[]; $tot=['income_delta'=>0,'payout_delta'=>0,'projects'=>0];
		foreach($projects as $p){
			$steps=get_post_meta($p->ID,'_cptt_steps',true); if(!is_array($steps)) continue;
			$cost=0; $paid=0; $expert=0;
			foreach($steps as $st){ if(!is_array($st)) continue; $cost+=(float)($st['cost']??0); $paid+=(float)($st['paid']??0); $expert+=(float)($st['expert_paid']??0); if(!empty($st['extra_finance'])&&is_array($st['extra_finance'])) foreach($st['extra_finance'] as $ef){ if(is_array($ef)){ $cost+=(float)($ef['cost']??0); $paid+=(float)($ef['paid']??0); } } }
			$ledger_income=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(direction*amount),0) FROM ".self::tbl_ledger()." WHERE project_id=%d AND type='income'",$p->ID));
			$ledger_payout=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(CASE WHEN direction<0 THEN amount ELSE -amount END),0) FROM ".self::tbl_ledger()." WHERE project_id=%d AND type='expert_payout'",$p->ID));
			$income_delta=max(0,$paid-$ledger_income); $payout_delta=max(0,$expert-$ledger_payout);
			if($cost||$paid||$expert||$income_delta||$payout_delta){ $tot['projects']++; $tot['income_delta']+=$income_delta; $tot['payout_delta']+=$payout_delta; $out[]=['id'=>$p->ID,'title'=>get_the_title($p),'cost'=>$cost,'paid_meta'=>$paid,'paid_ledger'=>$ledger_income,'income_delta'=>$income_delta,'expert_meta'=>$expert,'expert_ledger'=>$ledger_payout,'payout_delta'=>$payout_delta]; }
		}
		return ['rows'=>$out,'totals'=>$tot];
	}
	public function ajax_legacy_import(){
		$this->check_ajax();
		if(!current_user_can('manage_options')) wp_send_json_error('no_access',403);
		$account_id=(int)($_POST['account_id']??0); $kind=sanitize_key($_POST['kind']??'income');
		if(!$account_id) wp_send_json_error('حساب خزانه را انتخاب کنید.',400);
		$audit=self::legacy_project_audit(); $created=0; $sum=0;
		foreach($audit['rows'] as $r){
			if($kind==='income'){ $amount=(float)$r['income_delta']; if($amount<=0.5) continue; self::ledger_insert(['account_id'=>$account_id,'type'=>'income','direction'=>1,'amount'=>$amount,'project_id'=>(int)$r['id'],'ref_type'=>'legacy_import_income','voucher_kind'=>'receipt','status'=>'posted','description'=>'ورود داده قدیمی: دریافتی‌های ثبت‌شده قبل از دفتر مالی']); }
			elseif($kind==='payout'){ $amount=(float)$r['payout_delta']; if($amount<=0.5) continue; self::ledger_insert(['account_id'=>$account_id,'type'=>'expert_payout','direction'=>-1,'amount'=>$amount,'project_id'=>(int)$r['id'],'ref_type'=>'legacy_import_payout','voucher_kind'=>'payment','status'=>'posted','description'=>'ورود داده قدیمی: تسویه‌های کارشناسان قبل از دفتر مالی']); }
			$created++; $sum+=$amount;
		}
		wp_send_json_success(['created'=>$created,'sum'=>$sum,'audit'=>self::legacy_project_audit()]);
	}

	public function ajax_dashboard_data(){
		$this->check_ajax();
		wp_send_json_success([
			'kpis'    => self::compute_kpis(),
			'monthly' => self::monthly_series(),
		]);
	}

	/* ═══════════════════════════════════════════════════════════════════
	 * Page renderers (loaded from separate template files)
	 * ═══════════════════════════════════════════════════════════════════ */
	private function shell_open($title, $current){
		$tabs = [
			'cptt-finance'                => ['label' => '📊 داشبورد',         'icon' => '📊'],
			'cptt-finance-receivables'    => ['label' => '👥 مطالبات',         'icon' => '👥'],
			'cptt-finance-payouts'        => ['label' => '💼 تسویه‌ها',         'icon' => '💼'],
			'cptt-finance-transactions'   => ['label' => '💸 درآمد/هزینه',      'icon' => '💸'],
			'cptt-finance-treasury'       => ['label' => '🏦 خزانه',           'icon' => '🏦'],
			'cptt-finance-ledger'         => ['label' => '📑 گردش حساب',       'icon' => '📑'],
			'cptt-finance-classic'        => ['label' => '📒 حساب پروژه‌ها',    'icon' => '📒'],
			'cptt-finance-sync'           => ['label' => '🧩 همگام‌سازی',      'icon' => '🧩'],
			'cptt-finance-categories'     => ['label' => '🏷 دسته‌ها',          'icon' => '🏷'],
		];
		?>
		<div class="cpttf-app" dir="rtl">
			<header class="cpttf-app__topbar">
				<div class="cpttf-app__brand">
					<span class="cpttf-app__brand-mark">💰</span>
					<div>
						<strong>مالی هماهنگ</strong>
						<small><?php echo esc_html($title); ?></small>
					</div>
				</div>
				<nav class="cpttf-app__nav">
					<?php foreach ($tabs as $slug => $info): ?>
						<a class="cpttf-app__tab <?php echo $slug === $current ? 'is-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=' . $slug)); ?>"><?php echo esc_html($info['label']); ?></a>
					<?php endforeach; ?>
				</nav>
			</header>
			<main class="cpttf-app__main">
		<?php
	}
	private function shell_close(){
		?>
			</main>
		</div>
		<?php
	}

	public function render_dashboard_page(){
		require_once CPTT_PATH . 'includes/finance/page-dashboard.php';
		$this->shell_open('داشبورد مالی', 'cptt-finance');
		cpttf_render_dashboard();
		$this->shell_close();
	}
	public function render_receivables_page(){
		require_once CPTT_PATH . 'includes/finance/page-receivables.php';
		$this->shell_open('مطالبات مشتریان', 'cptt-finance-receivables');
		cpttf_render_receivables();
		$this->shell_close();
	}
	public function render_payouts_page(){
		require_once CPTT_PATH . 'includes/finance/page-payouts.php';
		$this->shell_open('تسویه کارشناسان', 'cptt-finance-payouts');
		cpttf_render_payouts();
		$this->shell_close();
	}
	public function render_transactions_page(){
		require_once CPTT_PATH . 'includes/finance/page-transactions.php';
		$this->shell_open('درآمد و هزینه', 'cptt-finance-transactions');
		cpttf_render_transactions();
		$this->shell_close();
	}
	public function render_treasury_page(){
		require_once CPTT_PATH . 'includes/finance/page-treasury.php';
		$this->shell_open('خزانه‌داری', 'cptt-finance-treasury');
		cpttf_render_treasury();
		$this->shell_close();
	}
	public function render_categories_page(){
		require_once CPTT_PATH . 'includes/finance/page-categories.php';
		$this->shell_open('دسته‌بندی‌های مالی', 'cptt-finance-categories');
		cpttf_render_categories();
		$this->shell_close();
	}
	public function render_ledger_page(){
		require_once CPTT_PATH . 'includes/finance/page-ledger.php';
		$this->shell_open('گردش حساب', 'cptt-finance-ledger');
		cpttf_render_ledger();
		$this->shell_close();
	}

	/** v9.2.24 — layout fixes when classic accounting is embedded in finance shell */
	public static function classic_host_css(){
		return '
/* host resets */
.cpttf-classic-host{padding:0!important;overflow:visible!important;}
.cpttf-classic-host .wrap.cptt-dashboard.cptt-accounting{margin:0!important;padding:8px 4px 20px!important;background:transparent!important;max-width:100%!important;}
.cpttf-classic-host .cptt-dashboard__hero{display:none!important;}

/* KPI cards: force proper grid + readable values */
.cpttf-classic-host .cptt-acct-kpi-grid{
  display:grid!important;
  grid-template-columns:repeat(auto-fit,minmax(180px,1fr))!important;
  gap:12px!important;
  margin:0 0 16px!important;
  width:100%!important;
}
.cpttf-classic-host .cptt-acct-kpi{
  display:flex!important;
  flex-direction:row!important;
  align-items:center!important;
  gap:12px!important;
  background:#fff!important;
  border:1px solid #e5e7eb!important;
  border-radius:16px!important;
  padding:14px!important;
  box-shadow:0 8px 20px rgba(15,23,42,.05)!important;
  min-height:84px!important;
  width:auto!important;
  max-width:none!important;
  float:none!important;
}
.cpttf-classic-host .cptt-acct-kpi__icon{
  width:44px!important;height:44px!important;border-radius:12px!important;
  display:flex!important;align-items:center!important;justify-content:center!important;
  font-size:20px!important;flex:0 0 44px!important;
}
.cpttf-classic-host .cptt-acct-kpi__body{flex:1 1 auto!important;min-width:0!important;}
.cpttf-classic-host .cptt-acct-kpi__label{font-size:12px!important;font-weight:800!important;color:#64748b!important;margin:0 0 4px!important;line-height:1.3!important;}
.cpttf-classic-host .cptt-acct-kpi__value{font-size:20px!important;font-weight:950!important;color:#0f172a!important;line-height:1.15!important;word-break:break-word!important;}
.cpttf-classic-host .cptt-acct-kpi__body small{display:block!important;margin-top:2px!important;color:#94a3b8!important;font-size:11px!important;}

/* charts + filters */
.cpttf-classic-host .cptt-finance-pro-panel{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))!important;gap:12px!important;margin:0 0 16px!important;}
.cpttf-classic-host .cptt-acct-filters,
.cpttf-classic-host .cptt-acct-filters--sticky{
  display:flex!important;flex-wrap:wrap!important;gap:10px!important;align-items:flex-end!important;
  position:static!important;top:auto!important;background:#fff!important;border:1px solid #e5e7eb!important;
  border-radius:14px!important;padding:12px!important;margin:0 0 14px!important;
}
.cpttf-classic-host .cptt-acct-filters label{display:flex!important;flex-direction:column!important;gap:4px!important;min-width:130px!important;flex:1 1 140px!important;font-size:12px!important;font-weight:800!important;color:#334155!important;}
.cpttf-classic-host .cptt-acct-filters input,
.cpttf-classic-host .cptt-acct-filters select{width:100%!important;min-height:36px!important;box-sizing:border-box!important;}
.cpttf-classic-host .cptt-acct-filters .button{height:36px!important;align-self:flex-end!important;}

/* table */
.cpttf-classic-host .cptt-acct-table-wrap{overflow-x:auto!important;border:1px solid #e5e7eb!important;border-radius:14px!important;background:#fff!important;}
.cpttf-classic-host .cptt-acct-table{width:100%!important;border-collapse:collapse!important;}
.cpttf-classic-host .cptt-acct-table th{position:static!important;top:auto!important;}

@media (max-width:782px){
  .cpttf-classic-host .cptt-acct-kpi-grid{grid-template-columns:1fr 1fr!important;}
  .cpttf-classic-host .cptt-acct-filters label{min-width:100%!important;}
}
@media (max-width:520px){
  .cpttf-classic-host .cptt-acct-kpi-grid{grid-template-columns:1fr!important;}
}
';
	}

	public function render_classic_accounting_page(){
		require_once CPTT_PATH . 'includes/finance/page-project-accounts.php';
		$this->shell_open('حساب پروژه‌ها', 'cptt-finance-classic');
		cpttf_render_project_accounts();
		$this->shell_close();
	}
	public function render_sync_page(){
		require_once CPTT_PATH . 'includes/finance/page-sync.php';
		$this->shell_open('همگام‌سازی داده‌های قدیمی', 'cptt-finance-sync');
		cpttf_render_sync_page();
		$this->shell_close();
	}


	/* ═══════════════════════════════════════════════════════════════════
	 * Small parsing helpers
	 * ═══════════════════════════════════════════════════════════════════ */
	public static function parse_amount($v){
		if (class_exists('CPTT_Currency')) return (float) CPTT_Currency::parse_input($v);
		$v = (string)$v;
		$v = preg_replace('/[^\d.\-]/', '', str_replace(',', '', $v));
		return (float)$v;
	}
	public static function parse_jalali_local($s){
		// Accept "YYYY/MM/DD HH:mm" Jalali OR fallback to strtotime
		$s = trim((string)$s);
		if ($s === '') return 0;
		// Convert Persian digits to ASCII
		$s = strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
		if (preg_match('#^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2}))?$#', $s, $m)) {
			$jy = (int)$m[1]; $jm = (int)$m[2]; $jd = (int)$m[3];
			$h = isset($m[4]) ? (int)$m[4] : 0; $mi = isset($m[5]) ? (int)$m[5] : 0;
			if (class_exists('CPTT_Core') && method_exists('CPTT_Core', 'jalali_to_gregorian')) {
				$g = CPTT_Core::jalali_to_gregorian($jy, $jm, $jd);
				if (is_array($g) && count($g) === 3) {
					return mktime($h, $mi, 0, $g[1], $g[2], $g[0]);
				}
			}
			// rough fallback
			return strtotime("$jy-$jm-$jd $h:$mi");
		}
		return (int) strtotime($s);
	}
}
