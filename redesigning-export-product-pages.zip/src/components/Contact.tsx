import { motion } from 'framer-motion';
import { Send, MapPin, Phone, Mail } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h2 className="text-sm font-bold tracking-widest text-amber-600 uppercase mb-3">Get in Touch</h2>
            <h3 className="text-3xl md:text-5xl font-serif text-stone-900 mb-6">Request a Wholesale Quote</h3>
            <p className="text-stone-600 text-lg mb-10">
              Interested in importing premium Iranian dates? Fill out the form below 
              with your requirements, and our dedicated export team will get back to you 
              within 24 hours.
            </p>

            <div className="space-y-6 mb-10">
              <div className="flex items-center gap-4 text-stone-600 hover:text-amber-600 transition-colors">
                <div className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center shrink-0 text-amber-600">
                  <Mail className="w-5 h-5" />
                </div>
                <span className="font-medium">export@arasbtrading.com</span>
              </div>
              <div className="flex items-center gap-4 text-stone-600 hover:text-amber-600 transition-colors">
                <div className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center shrink-0 text-amber-600">
                  <Phone className="w-5 h-5" />
                </div>
                <span className="font-medium">+98 (912) 000-0000 (WhatsApp/Call)</span>
              </div>
              <div className="flex items-center gap-4 text-stone-600">
                <div className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center shrink-0 text-amber-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <span className="font-medium">Tehran, Iran (Head Office)</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="bg-white rounded-3xl p-8 shadow-xl border border-stone-100"
          >
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-stone-700 mb-2">Company / Name</label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all bg-stone-50"
                    placeholder="Your Company Ltd."
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-stone-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all bg-stone-50"
                    placeholder="you@company.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="product" className="block text-sm font-medium text-stone-700 mb-2">Product of Interest</label>
                  <select
                    id="product"
                    className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all bg-stone-50 text-stone-700"
                  >
                    <option>Mazafati Dates</option>
                    <option>Piarom Dates</option>
                    <option>Zahedi Dates</option>
                    <option>Multiple / Other</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="volume" className="block text-sm font-medium text-stone-700 mb-2">Estimated Volume</label>
                  <select
                    id="volume"
                    className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all bg-stone-50 text-stone-700"
                  >
                    <option>Less than 1 FCL</option>
                    <option>1-5 FCL (20ft/40ft)</option>
                    <option>More than 5 FCL</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-stone-700 mb-2">Additional Requirements</label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all bg-stone-50 resize-none"
                  placeholder="Tell us about your packaging needs, destination port, etc."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-4 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-xl transition-all hover:shadow-[0_0_20px_-5px_rgba(217,119,6,0.5)]"
              >
                Send Inquiry
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Contact;
