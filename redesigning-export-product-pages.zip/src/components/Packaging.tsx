import { motion } from 'framer-motion';
import { Package, Box, Settings } from 'lucide-react';

const Packaging = () => {
  return (
    <section id="packaging" className="py-24 bg-stone-900 text-stone-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="w-full lg:w-1/2"
          >
            <h2 className="text-sm font-bold tracking-widest text-amber-500 uppercase mb-3">Tailored Logistics</h2>
            <h3 className="text-3xl md:text-5xl font-serif text-white mb-6">Packaging & Export Solutions</h3>
            <p className="text-stone-400 text-lg mb-10 leading-relaxed">
              We understand that presentation and preservation are paramount. 
              Our packaging solutions are designed to protect the integrity of the dates 
              during long transit times while meeting your market's aesthetic requirements.
            </p>

            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                  <Package className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-xl font-medium text-white mb-2">Bulk Export Cartons</h4>
                  <p className="text-stone-400">Standard 5kg and 10kg telescopic or regular slotted cartons. Highly durable and stackable for palletized sea freight.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                  <Box className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-xl font-medium text-white mb-2">Retail Ready</h4>
                  <p className="text-stone-400">Smaller consumer packs ranging from 250g to 1kg. Options include window boxes, plastic tubs, and zip-lock pouches.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                  <Settings className="w-6 h-6 text-amber-500" />
                </div>
                <div>
                  <h4 className="text-xl font-medium text-white mb-2">Private Label (OEM)</h4>
                  <p className="text-stone-400">Complete customization of packaging design and labeling to seamlessly integrate with your brand identity.</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative aspect-square rounded-3xl overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-600/20 to-transparent z-10" />
              <img
                src="https://images.pexels.com/photos/10834810/pexels-photo-10834810.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1000&h=1000"
                alt="Warehouse Logistics"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Floating stats card */}
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="absolute -bottom-10 -left-10 bg-white p-6 rounded-2xl shadow-xl hidden md:block"
            >
              <div className="flex items-center gap-4">
                <div className="text-4xl font-serif text-amber-600 font-bold">50+</div>
                <div className="text-stone-900 font-medium leading-tight text-sm">
                  Countries <br /> Exported To
                </div>
              </div>
            </motion.div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Packaging;
