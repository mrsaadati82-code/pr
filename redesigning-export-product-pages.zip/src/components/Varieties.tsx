import { motion } from 'framer-motion';

const varieties = [
  {
    name: 'Mazafati (Kimia)',
    type: 'Fresh / Soft',
    moisture: '15-35%',
    color: 'Dark Brown to Black',
    description: 'The most popular Iranian date globally. Known for its melt-in-the-mouth texture and high moisture content. Perfect for direct consumption.',
    image: 'https://images.pexels.com/photos/15913423/pexels-photo-15913423.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=800&h=1000'
  },
  {
    name: 'Piarom (Maryami)',
    type: 'Semi-Dry',
    moisture: '15%',
    color: 'Dark Brown',
    description: 'The "Chocolate Date". Highly prized for its thin skin, rich meaty flesh, and complex caramel flavor. Excellent for luxury retail.',
    image: 'https://images.pexels.com/photos/12944736/pexels-photo-12944736.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=800&h=1000'
  },
  {
    name: 'Zahedi',
    type: 'Dry',
    moisture: 'Under 14%',
    color: 'Golden / Light Brown',
    description: 'A distinctly nutty, less sweet date with a golden hue. Highly durable with a long shelf life, ideal for industrial use and snacking.',
    image: 'https://images.pexels.com/photos/11081584/pexels-photo-11081584.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=800&h=1000'
  }
];

const Varieties = () => {
  return (
    <section id="varieties" className="py-24 bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="text-center mb-20">
          <h2 className="text-sm font-bold tracking-widest text-amber-600 uppercase mb-3">Our Collection</h2>
          <h3 className="text-3xl md:text-5xl font-serif text-stone-900 mb-6">Premium Varieties</h3>
          <p className="max-w-2xl mx-auto text-stone-600">
            From the lush oases of Bam to the sun-drenched groves of Hormozgan, 
            we source the finest cultivars Iran has to offer.
          </p>
        </div>

        <div className="flex flex-col gap-24">
          {varieties.map((item, idx) => (
            <div
              key={item.name}
              className={`flex flex-col gap-10 lg:items-center ${
                idx % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'
              }`}
            >
              {/* Image */}
              <motion.div
                initial={{ opacity: 0, x: idx % 2 === 1 ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7 }}
                className="w-full lg:w-1/2"
              >
                <div className="relative aspect-[4/5] md:aspect-[16/10] lg:aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                  <div className="absolute inset-0 bg-stone-900/10 mix-blend-multiply z-10" />
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-1000 hover:scale-110"
                  />
                </div>
              </motion.div>

              {/* Text */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="w-full lg:w-1/2 lg:px-12"
              >
                <span className="inline-block px-4 py-1.5 rounded-full bg-amber-100 text-amber-800 text-sm font-semibold mb-6">
                  {item.type}
                </span>
                <h4 className="text-4xl font-serif text-stone-900 mb-6">{item.name}</h4>
                <p className="text-lg text-stone-600 mb-8 leading-relaxed">
                  {item.description}
                </p>
                
                <div className="grid grid-cols-2 gap-6 border-t border-stone-200 pt-8">
                  <div>
                    <p className="text-sm text-stone-500 uppercase tracking-wider mb-1">Moisture</p>
                    <p className="font-medium text-stone-900">{item.moisture}</p>
                  </div>
                  <div>
                    <p className="text-sm text-stone-500 uppercase tracking-wider mb-1">Color</p>
                    <p className="font-medium text-stone-900">{item.color}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-stone-500 uppercase tracking-wider mb-1">Available Packaging</p>
                    <p className="font-medium text-stone-900">5kg, 10kg Cartons & Custom Retail Boxes</p>
                  </div>
                </div>

                <div className="mt-10">
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 text-amber-600 font-semibold hover:text-amber-700 transition-colors"
                  >
                    Request Sample →
                  </a>
                </div>
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Varieties;
