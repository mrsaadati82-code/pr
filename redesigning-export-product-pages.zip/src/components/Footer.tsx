import { Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black text-stone-400 py-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-1 md:col-span-2">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-amber-300 flex items-center justify-center">
                <span className="text-black font-serif font-bold text-lg">A</span>
              </div>
              <span className="text-white font-serif text-xl tracking-wide">
                Aras B<span className="text-amber-500 text-sm align-super ml-0.5">®</span>
              </span>
            </a>
            <p className="max-w-md text-sm leading-relaxed mb-6">
              Premium exporter of Iranian agricultural products. 
              We bring the authentic taste of nature to the world, ensuring the highest standards of quality and logistics.
            </p>
            <div className="flex items-center gap-4">
              <a href="mailto:export@arasbtrading.com" className="text-stone-400 hover:text-amber-500 transition-colors">
                <Mail className="w-5 h-5" />
              </a>
              <a href="#contact" className="text-stone-400 hover:text-amber-500 transition-colors">
                <Phone className="w-5 h-5" />
              </a>
              <a href="#contact" className="text-stone-400 hover:text-amber-500 transition-colors">
                <MapPin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-medium mb-6">Quick Links</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#features" className="hover:text-amber-500 transition-colors">Why Aras B</a></li>
              <li><a href="#varieties" className="hover:text-amber-500 transition-colors">Our Varieties</a></li>
              <li><a href="#packaging" className="hover:text-amber-500 transition-colors">Packaging</a></li>
              <li><a href="#contact" className="hover:text-amber-500 transition-colors">Request Quote</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-medium mb-6">Legal</h4>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-amber-500 transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-amber-500 transition-colors">Certifications</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 text-sm text-center md:text-left flex flex-col md:flex-row justify-between items-center gap-4">
          <p>© {new Date().getFullYear()} Aras B Trading. All rights reserved.</p>
          <p>Designed for Global Export.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
