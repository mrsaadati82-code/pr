import { motion } from 'framer-motion';
import { ShieldCheck, Truck, Droplets, Medal } from 'lucide-react';

const features = [
  {
    icon: <Medal className="w-8 h-8 text-amber-500" />,
    title: "Export-Grade Quality",
    description: "Every date is meticulously sorted and graded to meet international standards for size, moisture, and blemish-free skin."
  },
  {
    icon: <ShieldCheck className="w-8 h-8 text-amber-500" />,
    title: "Certified Processing",
    description: "Processed in ISO and HACCP certified facilities, guaranteeing pristine hygiene from harvest to packaging."
  },
  {
    icon: <Truck className="w-8 h-8 text-amber-500" />,
    title: "Global Logistics",
    description: "Reliable cold chain and ambient shipping solutions to deliver freshness to Europe, Asia, and the Middle East."
  },
  {
    icon: <Droplets className="w-8 h-8 text-amber-500" />,
    title: "Optimal Moisture Control",
    description: "Advanced drying and storage techniques preserve the natural sweetness, rich texture, and extended shelf life."
  }
];

const Features = () => {
  return (
    <section id="features" className="py-24 bg-stone-950 text-stone-100">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold tracking-widest text-amber-600 uppercase mb-3">Why Aras B Trading</h2>
          <h3 className="text-3xl md:text-5xl font-serif mb-6 text-white">Excellence in Every Harvest</h3>
          <p className="max-w-2xl mx-auto text-stone-400">
            We bridge the gap between traditional Iranian agriculture and global B2B markets, 
            ensuring consistent quality, reliable supply, and uncompromised food safety.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="p-8 rounded-2xl bg-stone-900 border border-stone-800 hover:border-amber-900/50 transition-colors group"
            >
              <div className="w-16 h-16 rounded-xl bg-amber-500/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h4 className="text-xl font-medium text-white mb-3">{feature.title}</h4>
              <p className="text-stone-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
