import React from 'react';
import { motion } from 'framer-motion';

const otherProducts = [
  { name: 'Pistachios', image: 'https://images.unsplash.com/photo-1543325049-5775f2b84803?auto=format&fit=crop&q=80&w=400' },
  { name: 'Dates', image: 'https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=400' },
  { name: 'Apples', image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6bcd6?auto=format&fit=crop&q=80&w=400' },
  { name: 'Kiwis', image: 'https://images.unsplash.com/photo-1585059895524-72359e061381?auto=format&fit=crop&q=80&w=400' },
];

const OtherProducts = () => {
  return (
    <section className="py-24 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="max-w-xl">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Beyond <span className="text-saffron-gold">Saffron</span></h2>
            <p className="text-gray-400">Explore our full range of premium Iranian agricultural exports, maintained with the same standards of excellence.</p>
          </div>
          <button className="text-saffron-gold font-bold border-b border-saffron-gold pb-1 hover:text-white hover:border-white transition-all">
            View All Products
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {otherProducts.map((product, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="group relative h-64 rounded-2xl overflow-hidden"
            >
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-6 left-6">
                <h4 className="text-xl font-display font-bold text-white">{product.name}</h4>
                <div className="h-0.5 w-0 group-hover:w-full bg-saffron-gold transition-all duration-300" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OtherProducts;
