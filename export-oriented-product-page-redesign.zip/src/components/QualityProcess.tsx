import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Zap, Microscope, Award } from 'lucide-react';

const steps = [
  {
    icon: <Zap className="text-saffron-gold" />,
    title: 'Precision Harvesting',
    description: 'Flowers are picked at dawn before sunrise to preserve the volatile oils and aromatic compounds.'
  },
  {
    icon: <Microscope className="text-saffron-gold" />,
    title: 'Lab Testing',
    description: 'Every batch undergoes rigorous chemical analysis for crocin (color), picrocrocin (taste), and safranal (aroma).'
  },
  {
    icon: <ShieldCheck className="text-saffron-gold" />,
    title: 'Sorting & Grading',
    description: 'Expert sorters meticulously separate the stigmas by hand to ensure only the finest parts make the cut.'
  },
  {
    icon: <Award className="text-saffron-gold" />,
    title: 'Global Export',
    description: 'Packed in vacuum-sealed containers to maintain freshness during international transit.'
  }
];

const QualityProcess = () => {
  return (
    <section id="quality" className="py-24 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-saffron-red/5 blur-[150px] -z-10" />
      
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2"
          >
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-8 leading-tight">
              Quality That Defies <br />
              <span className="text-saffron-gold">Standards</span>
            </h2>
            <p className="text-gray-400 mb-12 text-lg">
              At Arasb Trading, we don't just export saffron; we export a legacy of excellence. Our processes are ISO 3632 certified, ensuring you receive the purest red gold available.
            </p>

            <div className="grid sm:grid-cols-2 gap-8">
              {steps.map((step, i) => (
                <div key={i} className="flex flex-col gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-saffron-gold/10 flex items-center justify-center border border-saffron-gold/20">
                    {step.icon}
                  </div>
                  <div>
                    <h4 className="text-xl font-display font-bold mb-2">{step.title}</h4>
                    <p className="text-sm text-gray-500 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2 relative"
          >
            <div className="relative rounded-3xl overflow-hidden border border-white/10 aspect-square">
              <img 
                src="/saffron-harvest.jpg" 
                alt="Saffron Harvesting" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              
              <div className="absolute bottom-8 left-8 right-8 p-6 glass-morphism rounded-2xl">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs uppercase tracking-widest text-saffron-gold font-bold">Lab Results</span>
                  <span className="text-xs text-gray-400">Batch #8821</span>
                </div>
                <div className="space-y-4">
                  <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      whileInView={{ width: '95%' }}
                      transition={{ duration: 1.5, ease: "easeOut" }}
                      className="h-full bg-saffron-red"
                    />
                  </div>
                  <div className="flex justify-between text-xs">
                    <span>Crocin Content (Color)</span>
                    <span className="font-bold">268.4</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative background circle */}
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-saffron-gold/20 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default QualityProcess;
