import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Super Negin',
    description: 'The most prestigious and expensive type. Features long, thick, and perfectly straight threads with no orange or yellow parts.',
    features: ['Highest Crocin level (>250)', 'Deep red color', 'Longest threads'],
    image: 'https://images.unsplash.com/photo-1615485242220-43522209386c?auto=format&fit=crop&q=80&w=600',
    color: 'from-red-900 to-red-600'
  },
  {
    id: 2,
    name: 'Negin',
    description: 'A very high-quality grade similar to Super Negin but with slightly shorter threads. Offers excellent aroma and color.',
    features: ['High coloring power', 'Pure red stigmas', 'Strong aroma'],
    image: 'https://images.unsplash.com/photo-1599391033230-01934c9c10f8?auto=format&fit=crop&q=80&w=600',
    color: 'from-red-800 to-red-500'
  },
  {
    id: 3,
    name: 'Sargol',
    description: 'Consists of the tips of the saffron threads. It has a very strong aroma and high coloring power.',
    features: ['100% Red stigmas', 'Intense flavor', 'Crumbled appearance'],
    image: 'https://images.unsplash.com/photo-1599391033061-001099e23215?auto=format&fit=crop&q=80&w=600',
    color: 'from-red-700 to-red-400'
  }
];

const ProductTypes = () => {
  return (
    <section id="products" className="py-24 bg-[#0a0a0a]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-display font-bold mb-6"
          >
            Our Exclusive <span className="text-saffron-gold">Varieties</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 max-w-2xl mx-auto"
          >
            We specialize in various grades of Iranian saffron, each catering to specific culinary and industrial requirements.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {products.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="group relative overflow-hidden rounded-3xl bg-[#151515] border border-white/5 hover:border-saffron-gold/30 transition-all duration-500"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[50%] group-hover:grayscale-0"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${product.color} opacity-20 group-hover:opacity-40 transition-opacity`} />
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl font-display font-bold mb-3">{product.name}</h3>
                <p className="text-sm text-gray-400 mb-6 leading-relaxed">
                  {product.description}
                </p>
                <ul className="space-y-3">
                  {product.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-gray-300">
                      <CheckCircle2 size={16} className="text-saffron-gold" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="w-full mt-8 py-3 rounded-xl border border-white/10 group-hover:bg-saffron-gold group-hover:text-black font-semibold transition-all">
                  Request Quote
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductTypes;
