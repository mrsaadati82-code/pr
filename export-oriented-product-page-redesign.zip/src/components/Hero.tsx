import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Star } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 bg-cover bg-center scale-105"
          style={{ backgroundImage: 'url("/hero-saffron.jpg")' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-[#0a0a0a]" />
      </div>

      <div className="container mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="flex items-center gap-2 mb-6"
          >
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star key={i} size={14} className="fill-saffron-gold text-saffron-gold" />
              ))}
            </div>
            <span className="text-saffron-gold text-xs font-bold tracking-widest uppercase">Premium Iranian Export Quality</span>
          </motion.div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold leading-tight mb-6">
            The Red Gold <br />
            <span className="text-gradient">of Khorasan</span>
          </h1>
          
          <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-xl leading-relaxed">
            Discover the world's most exquisite saffron. Hand-picked from the sun-drenched fields of Khorasan, our Super Negin grade saffron brings unparalleled aroma, color, and flavor to the global market.
          </p>

          <div className="flex flex-col sm:flex-row gap-5">
            <button className="bg-saffron-red hover:bg-red-700 text-white px-8 py-4 rounded-full font-bold text-lg transition-all transform hover:scale-105 flex items-center justify-center gap-3 group">
              Explore Our Collection
              <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="glass-morphism hover:bg-white/10 text-white px-8 py-4 rounded-full font-bold text-lg transition-all border border-white/20">
              Download Catalog
            </button>
          </div>

          <div className="mt-12 flex items-center gap-8 border-t border-white/10 pt-8">
            <div>
              <div className="text-3xl font-display font-bold text-white">ISO 3632</div>
              <div className="text-xs text-gray-400 uppercase tracking-widest">Certified Quality</div>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div>
              <div className="text-3xl font-display font-bold text-white">Grade 1</div>
              <div className="text-xs text-gray-400 uppercase tracking-widest">Super Negin</div>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div>
              <div className="text-3xl font-display font-bold text-white">100%</div>
              <div className="text-xs text-gray-400 uppercase tracking-widest">Natural & Organic</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1.2, delay: 0.2 }}
          className="relative hidden lg:block"
        >
          <div className="relative z-10 w-full aspect-square max-w-lg mx-auto">
             <div className="absolute inset-0 bg-saffron-gold/20 blur-[120px] rounded-full" />
             <img 
               src="/saffron-packaging.jpg" 
               alt="Saffron Packaging" 
               className="w-full h-full object-cover rounded-2xl shadow-2xl border border-white/10"
             />
          </div>
          
          {/* Floating Element */}
          <motion.div
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-10 -right-10 glass-morphism p-6 rounded-2xl shadow-xl z-20 border border-saffron-gold/20"
          >
            <div className="text-saffron-gold font-display text-4xl font-bold mb-1">98%</div>
            <div className="text-[10px] uppercase tracking-wider text-gray-400">Purity Color Grade</div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-gray-400"
      >
        <span className="text-[10px] uppercase tracking-[0.3em]">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-saffron-gold to-transparent" />
      </motion.div>
    </section>
  );
};

export default Hero;
