import React from 'react';
import { motion } from 'framer-motion';
import { Send, Phone, Mail, MapPin } from 'lucide-react';

const ContactForm = () => {
  return (
    <section id="contact" className="py-24 bg-[#050505] relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-display font-bold mb-8"
            >
              Start Your <span className="text-saffron-gold">Export Journey</span>
            </motion.h2>
            <p className="text-gray-400 text-lg mb-12">
              Ready to bring the finest Iranian saffron to your market? Contact us today for wholesale inquiries, custom packaging solutions, or samples.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                  <Phone size={20} className="text-saffron-gold" />
                </div>
                <div>
                  <h4 className="text-lg font-bold">Call Us</h4>
                  <p className="text-gray-400">+98 912 345 6789</p>
                  <p className="text-gray-400">+98 51 3844 1234</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                  <Mail size={20} className="text-saffron-gold" />
                </div>
                <div>
                  <h4 className="text-lg font-bold">Email Us</h4>
                  <p className="text-gray-400">info@arasbtrading.com</p>
                  <p className="text-gray-400">export@arasbtrading.com</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 shrink-0">
                  <MapPin size={20} className="text-saffron-gold" />
                </div>
                <div>
                  <h4 className="text-lg font-bold">Main Office</h4>
                  <p className="text-gray-400">No. 12, Saffron Tower, Mashhad, Razavi Khorasan, Iran</p>
                </div>
              </div>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="glass-morphism p-10 rounded-3xl border border-white/10 relative"
          >
            <form className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-saffron-gold transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="john@example.com"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-saffron-gold transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Subject</label>
                <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-saffron-gold transition-colors appearance-none">
                  <option>Wholesale Inquiry</option>
                  <option>Retail Packaging</option>
                  <option>Request Samples</option>
                  <option>Partnership</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-500">Message</label>
                <textarea 
                  rows={4} 
                  placeholder="Tell us about your requirements..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-saffron-gold transition-colors resize-none"
                />
              </div>

              <button className="w-full bg-saffron-gold text-black font-bold py-4 rounded-xl flex items-center justify-center gap-3 hover:bg-yellow-500 transition-colors shadow-lg shadow-saffron-gold/10">
                Send Inquiry
                <Send size={18} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
