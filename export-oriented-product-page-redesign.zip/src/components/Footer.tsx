import React from 'react';
import { Globe, Mail, Phone, ShieldCheck } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black border-t border-white/5 py-16">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-saffron-red rounded-lg flex items-center justify-center font-display text-2xl font-bold text-white">A</div>
              <span className="text-xl font-display font-bold tracking-wider">ARASB <span className="text-saffron-gold">TRADING</span></span>
            </div>
            <p className="text-gray-500 max-w-sm mb-8 leading-relaxed">
              Premium exporter of Iranian agricultural products, specializing in the highest grade saffron for the global luxury market.
            </p>
            <div className="flex gap-4">
              {[Globe, Mail, Phone, ShieldCheck].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-saffron-gold hover:text-black transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-gray-500">
              <li><a href="#" className="hover:text-saffron-gold transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-saffron-gold transition-colors">About Us</a></li>
              <li><a href="#products" className="hover:text-saffron-gold transition-colors">Saffron Types</a></li>
              <li><a href="#quality" className="hover:text-saffron-gold transition-colors">Quality Control</a></li>
              <li><a href="#contact" className="hover:text-saffron-gold transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Resources</h4>
            <ul className="space-y-4 text-gray-500">
              <li><a href="#" className="hover:text-saffron-gold transition-colors">Lab Reports</a></li>
              <li><a href="#" className="hover:text-saffron-gold transition-colors">Import Guide</a></li>
              <li><a href="#" className="hover:text-saffron-gold transition-colors">Packaging Options</a></li>
              <li><a href="#" className="hover:text-saffron-gold transition-colors">Sustainability</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:row items-center justify-between pt-8 border-t border-white/5 text-gray-600 text-sm">
          <p>© 2024 Arasb Trading Company. All rights reserved.</p>
          <div className="flex gap-8 mt-4 md:mt-0">
            <a href="#" className="hover:text-gray-400">Privacy Policy</a>
            <a href="#" className="hover:text-gray-400">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
