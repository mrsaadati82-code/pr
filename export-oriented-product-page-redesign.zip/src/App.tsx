import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductTypes from './components/ProductTypes';
import QualityProcess from './components/QualityProcess';
import OtherProducts from './components/OtherProducts';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';
import { motion, useScroll, useSpring } from 'framer-motion';

function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="relative">
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-saffron-gold z-[60] origin-left"
        style={{ scaleX }}
      />
      
      <Navbar />
      
      <main>
        <Hero />
        
        <section className="py-20 bg-[#0a0a0a] border-y border-white/5">
          <div className="container mx-auto px-6">
            <div className="flex flex-wrap justify-center gap-12 md:gap-24 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
              <div className="text-2xl font-display font-bold">ISO 22000</div>
              <div className="text-2xl font-display font-bold">HACCP</div>
              <div className="text-2xl font-display font-bold">GMP CERTIFIED</div>
              <div className="text-2xl font-display font-bold">FDA REGISTERED</div>
              <div className="text-2xl font-display font-bold">HALAL</div>
            </div>
          </div>
        </section>

        <QualityProcess />
        
        <section className="py-24 relative overflow-hidden bg-black">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1599391033230-01934c9c10f8?auto=format&fit=crop&q=80&w=2000')] bg-fixed bg-center opacity-20" />
          <div className="container mx-auto px-6 relative z-10 text-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-6xl font-display font-bold mb-8"
            >
              The World's Most <span className="text-saffron-red">Expensive</span> Spice <br />
              <span className="text-saffron-gold">Grown in the Heart of Iran</span>
            </motion.h2>
            <p className="text-gray-300 max-w-3xl mx-auto text-lg mb-12 leading-relaxed">
              Did you know it takes approximately 150,000 flowers to produce just one kilogram of dried saffron? Each thread is harvested by hand, following traditions that span centuries. We bridge this tradition with modern logistics to deliver freshness to your doorstep.
            </p>
          </div>
        </section>

        <ProductTypes />

        <OtherProducts />

        {/* Feature Highlights */}
        <section className="py-24 bg-[#050505]">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { title: 'Global Shipping', desc: 'Secure air-freight to over 50 countries worldwide.' },
                { title: 'Custom Packaging', desc: 'Private labeling and luxury gift packaging available.' },
                { title: 'Direct Sourcing', desc: 'Straight from the farms of Khorasan to your warehouse.' },
                { title: 'Price Guarantee', desc: 'Competitive wholesale pricing for bulk export orders.' }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/[0.08] transition-all"
                >
                  <h4 className="text-saffron-gold font-bold mb-3">{item.title}</h4>
                  <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <ContactForm />
      </main>

      <Footer />
    </div>
  );
}

export default App;
